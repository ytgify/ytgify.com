import { lstat } from "node:fs/promises";
import { dirname, isAbsolute, join, relative, resolve, sep } from "node:path";

import { WorkflowError } from "./errors.js";
import { applicationTargetsFromConfig } from "./application-targets.js";
import { assertSafeProjectPath } from "./project-path-safety.js";
import { createSchemaRegistry, readYaml } from "./schema-registry.js";

const CANONICAL_CONFIG = ".workflows/config.yaml";
const DEFAULT_REQUIREMENTS = ".workflows/requirements.yaml";
const PRECEDENCE = Object.freeze(["explicit-config", "canonical-config", "legacy-no-config"]);

function fail(code, message, details) {
  throw new WorkflowError(code, message, { exitCode: 3, details });
}

async function entry(path) {
  try {
    return await lstat(path);
  } catch (error) {
    if (error.code === "ENOENT") return null;
    throw error;
  }
}

function contained(root, path) {
  const suffix = relative(root, path);
  return suffix === "" || (!suffix.startsWith(`..${sep}`) && suffix !== ".." && !isAbsolute(suffix));
}

async function discoverRepositoryRoot(start) {
  let cursor = resolve(start);
  const startEntry = await entry(cursor);
  if (!startEntry?.isDirectory() || startEntry.isSymbolicLink()) {
    fail("PROJECT_ROOT_NOT_FOUND", "Project resolution must start from a real directory", { path: cursor });
  }

  for (;;) {
    if (await entry(join(cursor, ".git"))) return cursor;
    const parent = dirname(cursor);
    if (parent === cursor) break;
    cursor = parent;
  }
  fail("PROJECT_ROOT_NOT_FOUND", "Could not find a repository root", { start: resolve(start) });
}

async function assertProjectRoot(path) {
  const rootEntry = await entry(path);
  if (!rootEntry?.isDirectory() || rootEntry.isSymbolicLink()) {
    fail("PROJECT_ROOT_INVALID", "Project root must be a real directory", { projectRoot: path });
  }
}

function logicalPath(root, value, label) {
  if (typeof value !== "string" || value.length === 0 || isAbsolute(value) || /^[A-Za-z]:[/\\]/u.test(value)) {
    fail("PATH_TRAVERSAL", `${label} must be a repository-relative path`, { path: value });
  }
  const portableParts = value.split(/[\\/]+/u);
  if (portableParts.some((part) => part === ".." || part === "")) {
    fail("PATH_TRAVERSAL", `${label} contains path traversal`, { path: value });
  }
  const absolute = resolve(root, ...portableParts);
  if (!contained(root, absolute)) fail("PATH_TRAVERSAL", `${label} escapes the repository`, { path: value });
  return { absolute, logical: portableParts.filter((part) => part !== ".").join("/") };
}

async function configuredContext({ root, config, source, registry }) {
  await assertSafeProjectPath(root, config.absolute, "Project config", { finalType: "file", allowMissing: true });
  const configEntry = await entry(config.absolute);
  if (!configEntry) {
    fail("PROJECT_CONFIG_NOT_FOUND", "Project config does not exist", { path: config.absolute, source });
  }

  const value = registry.validate("config", await readYaml(config.absolute));
  const applicationTargets = applicationTargetsFromConfig(value);
  const definitions = logicalPath(root, value.paths.definitions, "Workflow definitions path");
  const localStore = logicalPath(root, value.paths.runStore, "Local store path");
  const evaluationRequirements =
    value.schema === "agent-workflow-config/v1"
      ? logicalPath(root, value.paths.requirements ?? DEFAULT_REQUIREMENTS, "Evaluation requirements path")
      : null;
  await assertSafeProjectPath(root, definitions.absolute, "Workflow definitions path", {
    finalType: "directory",
    allowMissing: true,
  });
  await assertSafeProjectPath(root, localStore.absolute, "Local store path", {
    finalType: "directory",
    allowMissing: true,
  });
  if (evaluationRequirements) {
    await assertSafeProjectPath(root, evaluationRequirements.absolute, "Evaluation requirements path", {
      finalType: "file",
      allowMissing: true,
    });
  }

  return registry.validate("projectContext", {
    schema: "agent-workflow-project-context/v2",
    projectRoot: root,
    resolution: {
      mode: "configured",
      source,
      configPath: config.logical,
      precedence: [...PRECEDENCE],
    },
    project: { id: value.project.id, appName: value.project.appName },
    paths: {
      workflowDefinitions: definitions.logical,
      localStore: localStore.logical,
      ...(evaluationRequirements ? { evaluationRequirements: evaluationRequirements.logical } : {}),
    },
    applicationTargets,
  });
}

/** Resolve the single ProjectContext consumed by future CLI and Studio surfaces. */
export async function resolveProjectContext(options = {}) {
  const cwdWasProvided = Object.hasOwn(options, "cwd");
  const cwd = resolve(options.cwd ?? process.cwd());
  const requestedRoot = options.projectRoot === undefined ? null : resolve(options.projectRoot);
  const root = requestedRoot ?? (await discoverRepositoryRoot(cwd));

  await assertProjectRoot(root);
  if (cwdWasProvided && !(await entry(cwd))?.isDirectory()) {
    fail("PROJECT_ROOT_NOT_FOUND", "Project cwd must be a directory", { cwd });
  }
  if (cwdWasProvided && !contained(root, cwd)) {
    fail("PROJECT_ROOT_AMBIGUOUS", "Project root and cwd identify different repositories", {
      projectRoot: root,
      cwd,
    });
  }

  const registry = options.registry ?? (await createSchemaRegistry());
  const hasConfigPath = Object.hasOwn(options, "configPath");
  const hasExplicitConfigPath = Object.hasOwn(options, "explicitConfigPath");
  if (hasConfigPath && hasExplicitConfigPath && options.configPath !== options.explicitConfigPath) {
    fail("PROJECT_CONFIG_AMBIGUOUS", "Only one explicit project config path may be supplied");
  }
  const explicitValue = hasExplicitConfigPath ? options.explicitConfigPath : options.configPath;

  if (hasConfigPath || hasExplicitConfigPath) {
    if (typeof explicitValue !== "string" || explicitValue.length === 0) {
      fail("PROJECT_CONFIG_INVALID", "Explicit project config path must be a non-empty string");
    }
    const explicitBase = cwdWasProvided ? cwd : root;
    const absolute = isAbsolute(explicitValue) ? resolve(explicitValue) : resolve(explicitBase, explicitValue);
    if (!contained(root, absolute)) {
      fail("PATH_TRAVERSAL", "Explicit project config must be contained by the repository", {
        path: explicitValue,
      });
    }
    const logical = relative(root, absolute).split(sep).join("/");
    return configuredContext({ root, config: { absolute, logical }, source: "explicit-config", registry });
  }

  const canonical = logicalPath(root, CANONICAL_CONFIG, "Canonical project config");
  if (await entry(canonical.absolute)) {
    return configuredContext({ root, config: canonical, source: "canonical-config", registry });
  }

  const definitions = logicalPath(root, ".workflows", "Legacy workflow definitions path");
  const localStore = logicalPath(root, ".workflows/local", "Legacy local store path");
  await assertSafeProjectPath(root, definitions.absolute, "Legacy workflow definitions path", {
    finalType: "directory",
    allowMissing: true,
  });
  await assertSafeProjectPath(root, localStore.absolute, "Legacy local store path", {
    finalType: "directory",
    allowMissing: true,
  });
  return registry.validate("projectContext", {
    schema: "agent-workflow-project-context/v2",
    projectRoot: root,
    resolution: {
      mode: "legacy-no-config",
      source: "legacy-no-config",
      configPath: null,
      precedence: [...PRECEDENCE],
    },
    paths: { workflowDefinitions: definitions.logical, localStore: localStore.logical },
    applicationTargets: { inventory: [], warnings: [] },
  });
}
