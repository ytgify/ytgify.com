import { randomUUID } from "node:crypto";
import { constants } from "node:fs";
import { link, lstat, mkdir, open, readdir, unlink } from "node:fs/promises";
import { join, relative, resolve, sep } from "node:path";
import { WorkflowError } from "./errors.js";
import { verifyFindingVerificationContract } from "./finding-verification-contracts.js";
import { buildRunReport } from "./run-report.js";
import { sha256 } from "./stable-json.js";

const COMMIT = /^[a-f0-9]{40}$/;
const ACTOR_ID = /^[A-Za-z][A-Za-z0-9_-]*$/;
const WRITE_AUTHORITY = Symbol("finding-verification-write-authority");
const REPLAY_AUTHORITY = Symbol("finding-verification-replay-authority");

function fail(code, message) {
  throw new WorkflowError(code, message, { exitCode: 3 });
}

function receiptContent(receipt) {
  const { receiptHash: _receiptHash, ...content } = receipt;
  return content;
}

function assertReceiptHash(receipt) {
  if (receipt.receiptHash !== sha256(receiptContent(receipt)))
    fail("FINDING_VERIFICATION_HASH_MISMATCH", "Finding verification receipt hash does not match its content");
}

async function verifiedRun(runStore, runId) {
  const [run, report] = await Promise.all([
    runStore.readRun(runId),
    buildRunReport(runStore, runId, { skipPerspective: true }),
  ]);
  if (report.status !== "completed" || report.integrity.overall !== "verified")
    fail("FINDING_VERIFICATION_RUN_INVALID", "Finding verification requires a completed run with verified evidence");
  return { run, report };
}

function normalizeCheck(check, criterion, report) {
  if (!criterion) fail("FINDING_VERIFICATION_CRITERION_UNKNOWN", "Check references an unknown contract criterion");
  const step = report.steps.find((item) => item.id === check.stepId);
  const note = step?.notes?.[check.noteIndex];
  if (!step || !note) fail("FINDING_VERIFICATION_NOTE_INVALID", "Check note must belong to the verified source run");
  if (!Array.isArray(check.artifactIds) || check.artifactIds.length === 0)
    fail("FINDING_VERIFICATION_EVIDENCE_REQUIRED", "Finding-specific correction verification requires evidence");
  const artifacts = check.artifactIds.map((artifactId) => {
    const artifact = step.evidence.find((item) => item.artifactId === artifactId);
    if (!artifact || artifact.integrity !== "verified" || artifact.type !== "screenshot")
      fail("FINDING_VERIFICATION_EVIDENCE_INVALID", "Check screenshots must belong to the verified run and be intact");
    return { artifactId, stepId: step.id, contentHash: artifact.contentHash, checkpoint: artifact.checkpoint };
  });
  const assessment = check.assessment;
  if (!["passed", "failed", "unassessed"].includes(assessment?.outcome))
    throw new TypeError("assessment.outcome is invalid");
  if (assessment.actor?.kind !== "agent" || !ACTOR_ID.test(assessment.actor.id ?? ""))
    throw new TypeError("assessment.actor must identify the assessing agent");
  if (typeof assessment.statement !== "string" || !assessment.statement.trim())
    throw new TypeError("assessment.statement is required");
  if (!COMMIT.test(assessment.implementationCommit ?? ""))
    throw new TypeError("assessment.implementationCommit is invalid");
  return {
    criterionId: criterion.id,
    stepId: step.id,
    noteIndex: check.noteIndex,
    note: { kind: note.kind, text: note.text },
    artifacts,
    assessment: {
      outcome: assessment.outcome,
      actor: structuredClone(assessment.actor),
      statement: assessment.statement.trim(),
      implementationCommit: assessment.implementationCommit,
    },
  };
}

export async function recordFindingVerification({
  runStore,
  verificationStore,
  finding,
  contract,
  runId,
  checks,
  recordedAt,
  replayAuthority,
}) {
  verifyFindingVerificationContract(finding, contract);
  const { run, report } = await verifiedRun(runStore, runId);
  const platform = run.manifest.platform;
  const applicable = contract.criteria.filter((criterion) => criterion.applicablePlatforms.includes(platform));
  if (applicable.length === 0)
    fail("FINDING_VERIFICATION_PLATFORM_INVALID", "Contract does not apply to this platform");
  if (!Array.isArray(checks)) throw new TypeError("checks must be an array");
  const normalized = checks.map((check) =>
    normalizeCheck(
      check,
      contract.criteria.find((criterion) => criterion.id === check.criterionId),
      report,
    ),
  );
  const expected = applicable.map((criterion) => criterion.id).sort();
  const actual = normalized.map((check) => check.criterionId).sort();
  if (new Set(actual).size !== actual.length || sha256(actual) !== sha256(expected))
    fail("FINDING_VERIFICATION_COVERAGE_INCOMPLETE", "Checks must cover every applicable contract criterion once");
  const ref = run.manifest.workflowRef;
  if (ref?.sourceKind !== "candidate" || !Number.isSafeInteger(ref.candidateRevision))
    fail("FINDING_VERIFICATION_SOURCE_INVALID", "Targeted verification requires candidate source identity");
  const content = {
    schema: "agent-workflow-finding-verification/v1",
    findingId: finding.findingId,
    workflowId: finding.workflowId,
    contractHash: contract.contractHash,
    findingHash: contract.findingHash,
    run: {
      runId,
      reportHash: sha256(report),
      platform,
      completedAt: report.timestamps.completedAt,
      candidateRevision: ref.candidateRevision,
      sourceBytesHash: ref.sourceBytesHash,
      contentHash: ref.contentHash,
      effectiveHash: ref.effectiveHash,
    },
    checks: normalized,
    recordedAt: replayAuthority === REPLAY_AUTHORITY ? recordedAt : new Date().toISOString(),
  };
  const withId = { ...content, receiptId: `verification_${sha256(content).slice(7, 39)}` };
  const receipt = { ...withId, receiptHash: sha256(withId) };
  if (!verificationStore) return receipt;
  try {
    return await verificationStore.writeReceipt(receipt, WRITE_AUTHORITY);
  } catch (error) {
    if (error.code !== "IMMUTABLE_FINDING_VERIFICATION_EXISTS") throw error;
    return verificationStore.readReceipt(finding.workflowId, finding.findingId, receipt.receiptId);
  }
}

export class FindingVerificationStore {
  constructor(root, { registry } = {}) {
    this.root = resolve(root, "finding-verifications");
    this.registry = registry;
  }
  async init() {
    await mkdir(this.root, { recursive: true });
    await assertSafeDirectory(this.root);
    return this;
  }
  directory(workflowId, findingId) {
    if (!/^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$/.test(workflowId) || !/^finding_[a-f0-9]{32}$/.test(findingId))
      fail("INVALID_FINDING_VERIFICATION_ID", "Invalid verification receipt identity");
    return join(this.root, workflowId, findingId);
  }
  path(workflowId, findingId, receiptId) {
    if (!/^verification_[a-f0-9]{32}$/.test(receiptId))
      fail("INVALID_FINDING_VERIFICATION_ID", "Invalid verification receipt ID");
    return join(this.directory(workflowId, findingId), `${receiptId}.json`);
  }
  async writeReceipt(receipt, authority) {
    if (authority !== WRITE_AUTHORITY)
      fail("FINDING_VERIFICATION_WRITE_FORBIDDEN", "Verification receipts require verified evidence");
    this.registry?.validate("findingVerification", receipt);
    const directory = this.directory(receipt.workflowId, receipt.findingId);
    await assertSafeVerificationAncestry(this.root, directory);
    await mkdir(directory, { recursive: true });
    await assertSafeDirectory(directory);
    const path = this.path(receipt.workflowId, receipt.findingId, receipt.receiptId);
    await assertSafeVerificationAncestry(this.root, path);
    const temporary = `${path}.${randomUUID()}.tmp`;
    const handle = await open(temporary, "wx", 0o600);
    try {
      await handle.writeFile(`${JSON.stringify(receipt, null, 2)}\n`);
      await handle.sync();
    } finally {
      await handle.close();
    }
    try {
      await link(temporary, path);
    } catch (error) {
      if (error.code === "EEXIST")
        fail("IMMUTABLE_FINDING_VERIFICATION_EXISTS", "Verification receipts cannot be replaced");
      throw error;
    } finally {
      await unlink(temporary).catch(() => {});
    }
    return structuredClone(receipt);
  }
  async readReceipt(workflowId, findingId, receiptId) {
    const path = this.path(workflowId, findingId, receiptId);
    await assertSafeVerificationAncestry(this.root, path);
    const entry = await lstat(path);
    if (!entry.isFile() || entry.isSymbolicLink())
      fail("FINDING_VERIFICATION_RECORD_CORRUPT", "Verification receipt is not a regular file");
    const handle = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW);
    let receipt;
    try {
      receipt = JSON.parse(await handle.readFile("utf8"));
    } catch {
      fail("FINDING_VERIFICATION_RECORD_CORRUPT", "Verification receipt is invalid JSON");
    } finally {
      await handle.close();
    }
    this.registry?.validate("findingVerification", receipt);
    assertReceiptHash(receipt);
    if (receipt.workflowId !== workflowId || receipt.findingId !== findingId || receipt.receiptId !== receiptId)
      fail("FINDING_VERIFICATION_RECORD_CORRUPT", "Verification receipt identity is invalid");
    return structuredClone(receipt);
  }
  async listReceiptIds(workflowId, findingId) {
    try {
      await assertSafeVerificationAncestry(this.root, this.directory(workflowId, findingId));
      await assertSafeDirectory(this.directory(workflowId, findingId));
      return (await readdir(this.directory(workflowId, findingId)))
        .filter((name) => /^verification_[a-f0-9]{32}\.json$/.test(name))
        .sort()
        .map((name) => name.slice(0, -5));
    } catch (error) {
      if (error.code === "ENOENT") return [];
      throw error;
    }
  }
}

async function assertSafeDirectory(path) {
  const entry = await lstat(path);
  if (!entry.isDirectory() || entry.isSymbolicLink())
    fail("FINDING_VERIFICATION_STORE_UNSAFE", "Finding verification paths cannot be symlinks");
}

async function assertSafeVerificationAncestry(root, path) {
  const suffix = relative(resolve(root), resolve(path));
  if (suffix.startsWith("..") || resolve(root, suffix) !== resolve(path))
    fail("PATH_TRAVERSAL", "Finding verification path escapes its root");
  let cursor = resolve(root);
  await assertSafeDirectory(cursor);
  for (const part of suffix.split(sep).filter(Boolean)) {
    cursor = join(cursor, part);
    try {
      const entry = await lstat(cursor);
      if (entry.isSymbolicLink())
        fail("FINDING_VERIFICATION_STORE_UNSAFE", "Finding verification ancestry cannot contain symlinks");
      if (cursor !== resolve(path) && !entry.isDirectory())
        fail("FINDING_VERIFICATION_STORE_UNSAFE", "Finding verification ancestry must contain directories");
    } catch (error) {
      if (error.code === "ENOENT") break;
      throw error;
    }
  }
}

export async function verifyFindingCorrection({ runStore, finding, contract, receipt }) {
  verifyFindingVerificationContract(finding, contract);
  assertReceiptHash(receipt);
  if (
    receipt.findingId !== finding.findingId ||
    receipt.workflowId !== finding.workflowId ||
    receipt.contractHash !== contract.contractHash ||
    receipt.findingHash !== contract.findingHash
  )
    fail(
      "FINDING_VERIFICATION_BINDING_INVALID",
      "Verification receipt is stale or belongs to another finding contract",
    );
  const replay = await recordFindingVerification({
    runStore,
    finding,
    contract,
    runId: receipt.run.runId,
    checks: receipt.checks.map((check) => ({
      criterionId: check.criterionId,
      stepId: check.stepId,
      noteIndex: check.noteIndex,
      artifactIds: check.artifacts.map((artifact) => artifact.artifactId),
      assessment: check.assessment,
    })),
    recordedAt: receipt.recordedAt,
    replayAuthority: REPLAY_AUTHORITY,
  });
  if (sha256(replay) !== sha256(receipt))
    fail("FINDING_VERIFICATION_STALE", "Finding verification source evidence no longer matches the receipt");
  if (receipt.checks.some((check) => check.assessment.outcome !== "passed"))
    fail("FINDING_VERIFICATION_NOT_PASSED", "Every finding-specific correction check must pass");
  return "verified";
}
