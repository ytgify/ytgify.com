import { randomUUID } from "node:crypto";
import { WorkflowError } from "./errors.js";
import { leasePolicyForManifest } from "./lease-policy.js";
import { sha256 } from "./stable-json.js";

async function verifyEvaluationLineage(store, run) {
  const manifest = run.manifest;
  if (manifest.phase !== "evaluation") return;
  if (
    manifest.leasePolicy?.name === "routine-codex-browser-v1" &&
    manifest.workflowRef?.sourceKind === "candidate" &&
    !manifest.evaluationGroupId &&
    !manifest.qualificationId
  )
    return;
  const invalid = () =>
    new WorkflowError("LIFECYCLE_LINEAGE_INVALID", "Pending evaluation no longer matches its immutable group member", {
      exitCode: 4,
      details: { runId: manifest.runId, groupId: manifest.evaluationGroupId },
    });
  if (!manifest.evaluationGroupId || !manifest.qualificationId || manifest.workflowRef?.sourceKind !== "promoted")
    throw invalid();
  // Load lazily because LifecycleStore's compatibility command delegates retirement here.
  const { LifecycleStore } = await import("./lifecycle-store.js");
  const lifecycleStore = new LifecycleStore(store.root, { registry: store.registry });
  const group = await lifecycleStore.readRecord("group", manifest.evaluationGroupId);
  const members = group.members.filter((member) => member.runId === manifest.runId);
  const member = members[0];
  if (
    members.length !== 1 ||
    group.workflowId !== manifest.workflowRef.id ||
    group.revision !== manifest.workflowRef.revision ||
    group.contentHash !== manifest.workflowRef.contentHash ||
    group.resetContractHash !== manifest.resetContractHash ||
    member.platform !== manifest.platform ||
    member.profile !== manifest.profile ||
    member.effectiveHash !== manifest.workflowRef.effectiveHash ||
    member.qualificationId !== manifest.qualificationId ||
    sha256(member.viewport) !== sha256(manifest.viewport)
  )
    throw invalid();
}

/** Retire a historical waiting state without granting or rewriting human approval. */
export async function retirePendingApproval({ store, runId, now = () => new Date() }) {
  const run = await store.readRun(runId);
  if (run.state.status !== "awaiting-approval") return run;
  leasePolicyForManifest(run.manifest);
  await verifyEvaluationLineage(store, run);
  const pendingHash = sha256(run.state.pendingApproval);
  const id = (prefix) => `${prefix}_${randomUUID().replaceAll("-", "")}`;
  return store.appendTransaction(runId, {
    operation: "run.retire-approval",
    requestId: id("req"),
    request: { command: "run.retire-approval", expectedRevision: run.state.revision },
    result: { retired: true },
    receiptId: id("receipt"),
    eventId: id("evt"),
    occurredAt: now().toISOString(),
    type: "approval.retired",
    source: "runner",
    payload: {},
    beforeAppend: async ({ current }) => {
      leasePolicyForManifest(current.manifest);
      await verifyEvaluationLineage(store, current);
      if (
        current.state.revision !== run.state.revision ||
        current.state.status !== "awaiting-approval" ||
        sha256(current.state.pendingApproval) !== pendingHash
      )
        throw new WorkflowError("REVISION_CONFLICT", "Historical waiting state changed before migration", {
          exitCode: 4,
        });
    },
  });
}
