import { sha256 } from "./stable-json.js";
import { WorkflowError } from "./errors.js";

function assertUnique(values, label) {
  const seen = new Set();
  const duplicates = new Set();

  for (const value of values) {
    if (seen.has(value)) duplicates.add(value);
    seen.add(value);
  }

  if (duplicates.size) {
    throw new WorkflowError("SEMANTIC_VALIDATION_FAILED", `Duplicate ${label}`, {
      exitCode: 3,
      details: { duplicates: [...duplicates].sort() },
    });
  }
}

function assertSubset(values, allowed, message, detailsKey) {
  const unknown = [...new Set(values.filter((value) => !allowed.has(value)))].sort();
  if (unknown.length) {
    throw new WorkflowError("SEMANTIC_VALIDATION_FAILED", message, {
      exitCode: 3,
      details: { [detailsKey]: unknown },
    });
  }
}

function unsafeFixtureRoute(pathTemplate) {
  throw new WorkflowError("SEMANTIC_VALIDATION_FAILED", "Fixture route template is unsafe", {
    exitCode: 3,
    details: { pathTemplate },
  });
}

export function fixtureRouteParameterNames(pathTemplate) {
  if (typeof pathTemplate !== "string" || !/^\/(?!\/)/u.test(pathTemplate)) unsafeFixtureRoute(pathTemplate);

  const forms = [pathTemplate];
  try {
    while (true) {
      const form = forms.at(-1);
      if (/%2f|%5c/iu.test(form)) unsafeFixtureRoute(pathTemplate);
      const decoded = decodeURIComponent(form);
      if (decoded === form) break;
      forms.push(decoded);
    }
  } catch {
    unsafeFixtureRoute(pathTemplate);
  }

  for (const form of forms) {
    if (
      // The route-template contract explicitly rejects every ASCII control character.
      // eslint-disable-next-line no-control-regex
      /[\\?#\u0000-\u001f\u007f]/u.test(form) ||
      /(?:^|\/)\.{1,2}(?:\/|$)/u.test(form) ||
      /:\/\//u.test(form) ||
      /\/\/[^/]/u.test(form) ||
      /@/u.test(form)
    ) {
      unsafeFixtureRoute(pathTemplate);
    }
  }

  return [...pathTemplate.matchAll(/\{([^{}]+)\}/gu)].map((match) => match[1]);
}

function validateFixtureRouteTemplate(route) {
  const parameterNames = fixtureRouteParameterNames(route.pathTemplate);
  const declaredParameters = Object.keys(route.parameters);
  assertUnique(parameterNames, `fixture route ${route.id} parameters`);
  assertSubset(
    parameterNames,
    new Set(declaredParameters),
    "Fixture route template references an undeclared parameter",
    "parameters",
  );
  assertSubset(
    declaredParameters,
    new Set(parameterNames),
    "Fixture route template is missing a declared parameter",
    "parameters",
  );
}

function assertAcyclic(stepsById) {
  const visiting = new Set();
  const visited = new Set();

  function visit(stepId, trail = []) {
    if (visiting.has(stepId)) {
      throw new WorkflowError("SEMANTIC_VALIDATION_FAILED", "Workflow dependency cycle", {
        exitCode: 3,
        details: { cycle: [...trail, stepId] },
      });
    }
    if (visited.has(stepId)) return;

    visiting.add(stepId);
    const step = stepsById.get(stepId);
    for (const dependency of step.dependsOn ?? []) {
      visit(dependency, [...trail, stepId]);
    }
    visiting.delete(stepId);
    visited.add(stepId);
  }

  for (const stepId of stepsById.keys()) visit(stepId);
}

export function validateWorkflowSemantics(workflow) {
  const platformIds = workflow.target.supportedPlatforms.map((platform) => platform.id);
  const stepIds = workflow.steps.map((step) => step.id);
  const handlerIds = workflow.optionalStateHandlers.map((handler) => handler.id);

  assertUnique(platformIds, "platform IDs");
  assertUnique(stepIds, "step IDs");
  assertUnique(handlerIds, "handler IDs");

  const fixtureRoutes = workflow.fixtureRoutes ?? [];
  assertUnique(
    fixtureRoutes.map(({ id }) => id),
    "fixture route IDs",
  );
  assertSubset(
    fixtureRoutes.map(({ capability }) => capability),
    new Set(workflow.start.preflightCapabilities),
    "Fixture route references an undeclared preflight capability",
    "capabilities",
  );
  for (const route of fixtureRoutes) validateFixtureRouteTemplate(route);

  const platforms = new Set(platformIds);
  const steps = new Set(stepIds);
  const handlers = new Set(handlerIds);
  const stepsById = new Map(workflow.steps.map((step) => [step.id, step]));

  if (workflow.evaluation) {
    assertSubset(
      [workflow.evaluation.resetStepId, workflow.evaluation.cleanupStepId],
      steps,
      "Evaluation contract references an unknown proof step",
      "stepIds",
    );
    const scenarios = workflow.evaluation.perspectiveScenarios ?? [];
    assertUnique(
      scenarios.map((scenario) => scenario.id),
      "perspective scenario IDs",
    );
    for (const scenario of scenarios) {
      assertSubset(scenario.stepIds, steps, "Perspective scenario references an unknown step", "stepIds");
    }
    const requiredViewport = workflow.evaluation.requiredViewport;
    if (requiredViewport && !platforms.has(requiredViewport.platform)) {
      throw new WorkflowError("SEMANTIC_VALIDATION_FAILED", "Evaluation viewport references an unsupported platform", {
        exitCode: 3,
      });
    }
  }

  assertSubset(
    Object.keys(workflow.platformOverrides ?? {}),
    platforms,
    "Platform override references an unsupported platform",
    "platforms",
  );

  for (const step of workflow.steps) {
    assertSubset(step.dependsOn ?? [], steps, `Step ${step.id} references an unknown dependency`, "stepIds");
    assertSubset(
      step.optionalHandlers ?? [],
      handlers,
      `Step ${step.id} references an unknown optional handler`,
      "handlerIds",
    );

    for (const evidence of step.evidence ?? []) {
      if (
        typeof evidence === "object" &&
        evidence.type === "media-inspection" &&
        evidence.focusInterval.endSeconds <= evidence.focusInterval.startSeconds
      ) {
        throw new WorkflowError("SEMANTIC_VALIDATION_FAILED", `Step ${step.id} has an invalid media interval`, {
          exitCode: 3,
        });
      }
    }
  }

  for (const [platformId, override] of Object.entries(workflow.platformOverrides ?? {})) {
    assertSubset(
      Object.keys(override.steps ?? {}),
      steps,
      `Platform ${platformId} overrides an unknown step`,
      "stepIds",
    );
  }

  assertAcyclic(stepsById);
  return workflow;
}

export function resolveWorkflow(workflow, platformId, options = {}) {
  validateWorkflowSemantics(workflow);
  const platform = workflow.target.supportedPlatforms.find((item) => item.id === platformId);
  if (!platform) {
    throw new WorkflowError("PLATFORM_NOT_SUPPORTED", `Unsupported platform: ${platformId}`, {
      exitCode: 3,
      details: { supported: workflow.target.supportedPlatforms.map((item) => item.id) },
    });
  }

  const override = workflow.platformOverrides?.[platformId] ?? {};
  const resolved = structuredClone(workflow);
  resolved.start = { ...resolved.start, ...(override.start ?? {}) };
  resolved.steps = resolved.steps.map((step) => ({
    ...step,
    ...(override.steps?.[step.id] ?? {}),
  }));
  delete resolved.platformOverrides;

  const effectiveHashVersion = typeof options === "string" ? options : (options.effectiveHashVersion ?? "resolved-v1");
  if (!new Set(["resolved-v1", "platform-v2"]).has(effectiveHashVersion)) {
    throw new WorkflowError(
      "EFFECTIVE_HASH_VERSION_UNSUPPORTED",
      `Unsupported effective hash version: ${effectiveHashVersion}`,
      {
        exitCode: 3,
      },
    );
  }

  return {
    workflow: resolved,
    sourceHash: sha256(workflow),
    effectiveHash:
      effectiveHashVersion === "platform-v2" ? sha256({ platform: platformId, workflow: resolved }) : sha256(resolved),
    effectiveHashVersion,
    platform,
  };
}
