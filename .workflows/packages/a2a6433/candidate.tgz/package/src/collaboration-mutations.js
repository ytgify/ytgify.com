import { randomUUID } from "node:crypto";
import { lstat, open, unlink } from "node:fs/promises";
import { isAbsolute, join, relative, resolve, sep } from "node:path";

import { WorkflowError } from "./errors.js";
import { sha256 } from "./stable-json.js";
import { consumeAuthenticatedUploadsForLease } from "./authenticated-upload-artifact.js";

const CHANNELS = new Set(["agent", "browser", "studio", "cli"]);
const OPERATIONS = {
  pause: { type: "run.pause_requested", operation: "run.pause", payload: ({ reason }) => ({ reason }) },
  stop: { type: "run.abandoned", operation: "run.stop", payload: ({ reason }) => ({ reason }) },
  "emergency-stop": {
    type: "run.emergency_stopped",
    operation: "run.emergency-stop",
    payload: ({ reason, leaseId }) => ({ leaseId, reason }),
  },
};

function fail(code, message, details, exitCode = 3) {
  throw new WorkflowError(code, message, { exitCode, details });
}

function id(prefix) {
  return `${prefix}_${randomUUID().replaceAll("-", "")}`;
}

async function withIntentLock(store, operation) {
  const projectRoot = resolve(store.projectRoot ?? "");
  const root = resolve(store.root ?? "");
  const suffix = relative(projectRoot, root);
  if (suffix === ".." || suffix.startsWith(`..${sep}`) || isAbsolute(suffix)) {
    fail("PATH_TRAVERSAL", "Review intent lock escapes its project");
  }
  let cursor = projectRoot;
  for (const part of ["", ...suffix.split(sep).filter(Boolean)]) {
    if (part) cursor = join(cursor, part);
    const entry = await lstat(cursor);
    if (!entry.isDirectory() || entry.isSymbolicLink()) {
      fail("REVIEW_INTENT_STORE_UNSAFE", "Review intent lock ancestry must contain only real directories");
    }
  }
  const lockPath = join(root, ".intent-write.lock");
  let handle;
  try {
    handle = await open(lockPath, "wx", 0o600);
  } catch (error) {
    if (error.code === "EEXIST") {
      fail("REVIEW_INTENT_STORE_LOCKED", "Another review intent mutation is in progress", undefined, 6);
    }
    throw error;
  }
  try {
    return await operation();
  } finally {
    await handle.close();
    await unlink(lockPath).catch(() => {});
  }
}

function exactRequest(request, allowed) {
  if (!request || Array.isArray(request) || typeof request !== "object")
    fail("INVALID_REQUEST", "Mutation request is required");
  const extras = Object.keys(request).filter((key) => !allowed.includes(key));
  if (extras.length)
    fail("INVALID_REQUEST", "Mutation request contains caller-controlled provenance or unknown fields", { extras });
  if (!Number.isSafeInteger(request.expectedRevision) || request.expectedRevision < 0) {
    fail("INVALID_REQUEST", "Mutation requires a non-negative expected revision");
  }
  if (!/^req_[A-Za-z0-9_-]+$/u.test(request.idempotencyKey ?? "")) {
    fail("INVALID_REQUEST", "Mutation requires an opaque request-shaped idempotency key");
  }
  return structuredClone(request);
}

/** Verify that source-bound feedback points to one exact durable run step and optional artifact. */
export async function verifyReviewIntentSource(runStore, workflowId, source) {
  let run;
  try {
    run = await runStore.readRun(source.runId);
  } catch {
    fail("REVIEW_INTENT_SOURCE_UNAVAILABLE", "Review intent source run is unavailable");
  }
  const recordedWorkflowId = run.manifest?.workflowRef?.id ?? run.workflow?.metadata?.id;
  const phase = run.manifest?.phase ?? run.state?.phase;
  const step = run.workflow?.steps?.find((item) => item.id === source.stepId);
  const artifact = source.artifactId
    ? Object.values(run.state?.traversal?.artifacts ?? {}).find((item) => item.artifactId === source.artifactId)
    : null;
  if (
    recordedWorkflowId !== workflowId ||
    phase !== source.phase ||
    !step ||
    (source.artifactId && (!artifact || artifact.relation?.stepId !== source.stepId))
  ) {
    fail("REVIEW_INTENT_SOURCE_MISMATCH", "Review intent source does not match the exact durable run evidence");
  }
  if (source.artifactId) {
    try {
      await runStore.readVerifiedEvidence(source.runId, source.artifactId);
    } catch {
      fail("REVIEW_INTENT_SOURCE_UNAVAILABLE", "Review intent source evidence is unavailable");
    }
  }
}

/** Persist a non-authoritative intent with server-owned neutral provenance. */
export async function appendNeutralReviewIntent({ store, request, verifySource, now = () => new Date() }) {
  const value = exactRequest(request, [
    "workflowId",
    "runId",
    "source",
    "expectedRevision",
    "idempotencyKey",
    "channel",
    "action",
    "supersedesIntentId",
  ]);
  if (!CHANNELS.has(value.channel)) fail("INVALID_REQUEST", "Unknown neutral caller channel");
  if (value.source) {
    const fields = Object.keys(value.source);
    if (
      fields.some((field) => !["phase", "runId", "stepId", "artifactId"].includes(field)) ||
      !new Set(["training", "evaluation"]).has(value.source.phase) ||
      !/^run_[A-Za-z0-9_-]+$/u.test(value.source.runId ?? "") ||
      !/^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$/u.test(value.source.stepId ?? "") ||
      (value.source.artifactId !== undefined && !/^artifact_[A-Za-z0-9_-]+$/u.test(value.source.artifactId)) ||
      (value.runId !== undefined && value.runId !== value.source.runId)
    ) {
      fail("INVALID_REQUEST", "Review intent source must identify one exact recorded step");
    }
  }
  return withIntentLock(store, async () => {
    const current = await store.listIntentRecords();
    const replay = current.find(({ record }) => record?.idempotencyKey === value.idempotencyKey);
    if (replay) {
      const matches =
        replay.integrity === "verified" &&
        replay.record.workflowId === value.workflowId &&
        replay.record.runId === value.runId &&
        JSON.stringify(replay.record.source) === JSON.stringify(value.source) &&
        replay.record.expectedRevision === value.expectedRevision &&
        replay.record.provenance?.actorKind === "caller" &&
        replay.record.provenance?.channel === value.channel &&
        replay.record.authority === "none" &&
        replay.record.supersedesIntentId === value.supersedesIntentId &&
        JSON.stringify(replay.record.action) === JSON.stringify(value.action);
      if (matches) return structuredClone(replay.record);
      fail("REVIEW_INTENT_IDEMPOTENCY_CONFLICT", "Idempotency key already identifies another review intent");
    }
    if (value.expectedRevision !== current.length) {
      fail("REVISION_CONFLICT", "Review intent revision has changed", {
        expected: value.expectedRevision,
        current: current.length,
      });
    }
    if (value.source) {
      if (typeof verifySource !== "function") {
        fail("REVIEW_INTENT_SOURCE_UNVERIFIED", "Source-bound feedback requires durable source verification");
      }
      await verifySource(value.workflowId, value.source);
    }
    return store.appendIntent({
      schema: "agent-workflow-review-intent/v1",
      intentId: `intent_${sha256(value.idempotencyKey).slice("sha256:".length, 39)}`,
      workflowId: value.workflowId,
      ...(value.runId ? { runId: value.runId } : {}),
      ...(value.source ? { source: value.source } : {}),
      expectedRevision: value.expectedRevision,
      idempotencyKey: value.idempotencyKey,
      action: value.action,
      provenance: { actorKind: "caller", channel: value.channel },
      authority: "none",
      ...(value.supersedesIntentId ? { supersedesIntentId: value.supersedesIntentId } : {}),
      createdAt: now().toISOString(),
    });
  });
}

/** Apply only authority-neutral operational mutations; resume is deliberately absent. */
export async function applyNeutralRunMutation({ store, runId, command, request, now = () => new Date() }) {
  const contract = OPERATIONS[command];
  if (!contract) fail("INVALID_REQUEST", "Only pause, stop, and emergency-stop are neutral mutations");
  const allowed =
    command === "emergency-stop"
      ? ["expectedRevision", "idempotencyKey", "reason", "leaseId"]
      : ["expectedRevision", "idempotencyKey", "reason"];
  const value = exactRequest(request, allowed);
  if (typeof value.reason !== "string" || value.reason.trim() === "")
    fail("INVALID_REQUEST", "Mutation reason is required");
  const transaction = await store.appendTransaction(runId, {
    operation: contract.operation,
    requestId: value.idempotencyKey,
    request: { command, ...value },
    result: { accepted: true, authority: "none" },
    receiptId: id("receipt"),
    eventId: id("evt"),
    occurredAt: now().toISOString(),
    type: contract.type,
    source: "adapter",
    payload: contract.payload(value),
    ...(command === "emergency-stop"
      ? {
          beforeAppend: async ({ current }) => {
            await consumeAuthenticatedUploadsForLease(current, value.leaseId, {
              outcome: "emergency-stopped",
              now,
            });
          },
        }
      : {}),
  });
  return transaction;
}
