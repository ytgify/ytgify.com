import { randomBytes, timingSafeEqual } from "node:crypto";

import {
  appendNeutralReviewIntent,
  applyNeutralRunMutation,
  verifyReviewIntentSource,
} from "./collaboration-mutations.js";

const STUDIO_MUTATION_BODY_LIMIT = 16 * 1024;

const JSON_CONTENT_TYPE = /^application\/json(?:;\s*charset=utf-8)?$/iu;

export class StudioMutationError extends Error {
  constructor(status, code) {
    super(code);
    this.name = "StudioMutationError";
    this.status = status;
    this.code = code;
  }
}

function reject(status, code) {
  throw new StudioMutationError(status, code);
}

function oneHeader(value) {
  return typeof value === "string" ? value : null;
}

function studioRequestAuthority(request) {
  const port = request.socket?.localPort;
  if (!Number.isSafeInteger(port) || port < 1 || port > 65535) return null;
  const host = `workflows.localhost:${port}`;
  return { host, origin: `http://${host}` };
}

export function requireExactStudioHost(request) {
  const authority = studioRequestAuthority(request);
  if (!authority || oneHeader(request.headers.host) !== authority.host) reject(421, "LOCAL_HOST_REQUIRED");
  return authority;
}

export function requireStudioMutationHeaders(request, csrfToken) {
  const authority = requireExactStudioHost(request);
  if (oneHeader(request.headers.origin) !== authority.origin) reject(403, "SAME_ORIGIN_REQUIRED");
  if (!JSON_CONTENT_TYPE.test(oneHeader(request.headers["content-type"]) ?? "")) {
    reject(415, "JSON_CONTENT_TYPE_REQUIRED");
  }
  const supplied = oneHeader(request.headers["x-workflows-csrf-token"]);
  if (!supplied || !constantTimeTokenEqual(supplied, csrfToken)) reject(403, "CSRF_TOKEN_INVALID");
}

function constantTimeTokenEqual(left, right) {
  const leftBytes = Buffer.from(left);
  const rightBytes = Buffer.from(right);
  return leftBytes.length === rightBytes.length && timingSafeEqual(leftBytes, rightBytes);
}

export function createStudioCsrfToken() {
  return randomBytes(32).toString("base64url");
}

export async function readStudioJsonBody(request, limit = STUDIO_MUTATION_BODY_LIMIT) {
  const declared = oneHeader(request.headers["content-length"]);
  if (declared !== null) {
    if (!/^(?:0|[1-9][0-9]*)$/u.test(declared)) reject(400, "CONTENT_LENGTH_INVALID");
    if (Number(declared) > limit) {
      request.resume();
      reject(413, "BODY_TOO_LARGE");
    }
  }
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > limit) {
      request.resume();
      reject(413, "BODY_TOO_LARGE");
    }
    chunks.push(chunk);
  }
  if (size === 0) reject(400, "JSON_BODY_REQUIRED");
  let value;
  try {
    value = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(Buffer.concat(chunks, size)));
  } catch {
    reject(400, "INVALID_JSON");
  }
  if (!value || Array.isArray(value) || typeof value !== "object") reject(400, "INVALID_REQUEST");
  return value;
}

function exactObject(value, fields) {
  if (!value || Array.isArray(value) || typeof value !== "object") reject(400, "INVALID_REQUEST");
  if (Object.keys(value).some((field) => !fields.includes(field))) reject(400, "INVALID_REQUEST");
  return value;
}

function requiredText(value, maximum = 1000) {
  return typeof value === "string" && value.trim().length > 0 && value.length <= maximum;
}

function revisionAndKey(value) {
  if (!Number.isSafeInteger(value.expectedRevision) || value.expectedRevision < 0) reject(400, "INVALID_REQUEST");
  if (!/^req_[A-Za-z0-9_-]{4,196}$/u.test(value.idempotencyKey ?? "")) reject(400, "INVALID_REQUEST");
}

function validateStudioReviewRequest(input) {
  const value = exactObject(input, [
    "workflowId",
    "runId",
    "source",
    "expectedRevision",
    "idempotencyKey",
    "action",
    "supersedesIntentId",
  ]);
  revisionAndKey(value);
  if (!/^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$/u.test(value.workflowId ?? "")) reject(400, "INVALID_REQUEST");
  if (value.runId !== undefined && !/^run_[A-Za-z0-9_-]+$/u.test(value.runId)) reject(400, "INVALID_REQUEST");
  if (value.source !== undefined) {
    const source = exactObject(value.source, ["phase", "runId", "stepId", "artifactId"]);
    if (
      !new Set(["training", "evaluation"]).has(source.phase) ||
      !/^run_[A-Za-z0-9_-]+$/u.test(source.runId ?? "") ||
      !/^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$/u.test(source.stepId ?? "") ||
      (source.artifactId !== undefined && !/^artifact_[A-Za-z0-9_-]+$/u.test(source.artifactId)) ||
      (value.runId !== undefined && value.runId !== source.runId)
    ) {
      reject(400, "INVALID_REQUEST");
    }
  }
  if (value.supersedesIntentId !== undefined && !/^intent_[A-Za-z0-9_-]+$/u.test(value.supersedesIntentId)) {
    reject(400, "INVALID_REQUEST");
  }
  const action = exactObject(value.action, ["kind", "summary"]);
  if (
    !new Set(["request-review", "request-pause", "request-stop", "request-change", "stage-acceptance"]).has(action.kind)
  ) {
    reject(400, "INVALID_REQUEST");
  }
  if (!requiredText(action.summary)) reject(400, "INVALID_REQUEST");
  return structuredClone(value);
}

function validateStudioRunRequest(input, command) {
  if (!new Set(["pause", "stop", "emergency-stop"]).has(command)) reject(400, "INVALID_REQUEST");
  const value = exactObject(input, ["expectedRevision", "idempotencyKey", "reason"]);
  revisionAndKey(value);
  if (!requiredText(value.reason)) reject(400, "INVALID_REQUEST");
  return structuredClone(value);
}

export function matchStudioMutationPath(path) {
  if (path === "/api/review-intents") return { kind: "review-intent" };
  const matched = path.match(/^\/api\/runs\/(run_[A-Za-z0-9_-]+)\/(pause|stop|emergency-stop)$/u);
  return matched ? { kind: "run", runId: matched[1], command: matched[2] } : null;
}

export async function executeStudioMutation({ route, body, runStore, reviewIntentStore }) {
  if (route.kind === "review-intent") {
    if (!reviewIntentStore) reject(503, "PROJECT_CONTEXT_UNAVAILABLE");
    const request = validateStudioReviewRequest(body);
    await reviewIntentStore.init();
    const replay = (await reviewIntentStore.listIntentRecords()).some(
      ({ integrity, record }) => integrity === "verified" && record?.idempotencyKey === request.idempotencyKey,
    );
    const intent = await appendNeutralReviewIntent({
      store: reviewIntentStore,
      request: { ...request, channel: "studio" },
      verifySource: (workflowId, source) => verifyReviewIntentSource(runStore, workflowId, source),
    });
    return { status: replay ? 200 : 201, payload: { intent } };
  }
  const request = validateStudioRunRequest(body, route.command);
  if (route.command === "emergency-stop") {
    const current = await runStore.readRun(route.runId);
    if (current.state.revision !== request.expectedRevision) reject(409, "REVISION_CONFLICT");
    if (!current.state.activeLease?.leaseId) reject(409, "ACTIVE_LEASE_REQUIRED");
    request.leaseId = current.state.activeLease.leaseId;
  }
  const mutation = await applyNeutralRunMutation({
    store: runStore,
    runId: route.runId,
    command: route.command,
    request,
  });
  return {
    status: mutation.replay ? 200 : 202,
    payload: {
      mutation: {
        kind: route.command,
        runId: route.runId,
        authority: "none",
        receipt: mutation.receipt,
      },
    },
  };
}
