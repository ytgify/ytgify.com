import { resolve } from "node:path";

import { launchRoutineEvaluation, launchSemanticRoutineEvaluation } from "./desktop-evaluation.js";
import { WorkflowError } from "./errors.js";

/** Validate and launch one routine evaluation while receiving all CLI-owned project/store resolution. */
export async function executeRoutineEvaluation(args, flags, registry, resolvers) {
  const platform = args[0] === "desktop" ? "desktop-web" : "mobile-web";
  let launched;
  if (flags.has("journey")) {
    if (args.length !== 1 || !flags.get("journey").trim()) {
      throw new WorkflowError("INVALID_USAGE", `evaluate ${args[0]} --journey requires product words`, {
        exitCode: 2,
      });
    }
    const unsupported = [...flags.keys()].filter(
      (name) => !["config", "journey", "json", "root", "store", "target", "target-url"].includes(name),
    );
    if (unsupported.length) {
      throw new WorkflowError("INVALID_USAGE", `evaluate ${args[0]} does not accept --${unsupported[0]}`, {
        exitCode: 2,
      });
    }
    if (flags.has("target") && !flags.get("target").trim()) {
      throw new WorkflowError("INVALID_USAGE", `evaluate ${args[0]} --target requires product words`, {
        exitCode: 2,
      });
    }
    if (flags.has("target") && flags.has("target-url")) {
      throw new WorkflowError("INVALID_USAGE", `evaluate ${args[0]} cannot combine --target with --target-url`, {
        exitCode: 2,
      });
    }
    const projectContext = await resolvers.projectContext();
    launched = await launchSemanticRoutineEvaluation({
      projectContext,
      journey: flags.get("journey"),
      target: flags.get("target"),
      targetUrl: flags.get("target-url"),
      platform,
      registry,
      ...(flags.has("store") ? { storeRoot: resolve(flags.get("store")) } : {}),
    });
  } else {
    const [, workflowPath] = args;
    if (!workflowPath || args.length !== 2) {
      throw new WorkflowError("INVALID_USAGE", `evaluate ${args[0]} requires PATH`, { exitCode: 2 });
    }
    const unsupported = [...flags.keys()].filter((name) => !["store", "json"].includes(name));
    if (unsupported.length) {
      throw new WorkflowError("INVALID_USAGE", `evaluate ${args[0]} accepts only --store PATH and --json`, {
        exitCode: 2,
      });
    }
    launched = await launchRoutineEvaluation({
      workflowPath: resolve(workflowPath),
      platform,
      store: await resolvers.controlStore(),
      registry,
    });
  }
  return {
    launchCard: launched.launchCard,
    state: {
      phase: launched.state.phase,
      status: launched.state.status,
      revision: launched.state.revision,
    },
  };
}
