import { sha256 } from "./stable-json.js";

const DESKTOP_AND_MOBILE = Object.freeze(["desktop-web", "mobile-web"]);

const CATALOG = Object.freeze({
  neutral: {
    id: "neutral",
    version: "1.0.0",
    supportedPlatforms: DESKTOP_AND_MOBILE,
    inquiryTopics: [
      "Undefined success conditions or product limits needed to judge a declared canonical outcome.",
      "Ambiguous cleanup or reset expectations visible in the recorded journey.",
    ],
    criteria: [
      {
        id: "canonical-outcomes",
        question: "Does every declared journey step reach its canonical outcome without contradicting visible state?",
        required: true,
        evidenceRequirements: ["step outcomes", "checkpoint screenshots", "cleanup outcome"],
        scenarioIds: ["canonical-journey", "reset", "cleanup"],
      },
    ],
  },
  ux: {
    id: "ux",
    version: "1.0.0",
    supportedPlatforms: DESKTOP_AND_MOBILE,
    inquiryTopics: [
      "Product language, units, limits, and result expectations that change whether the interface is understandable.",
      "Expected feedback or recovery behavior that cannot be inferred from verified interface evidence.",
    ],
    criteria: [
      {
        id: "loaded-source-identity",
        question:
          "After a source is loaded, does the interface identify it consistently and remove empty-selection messages?",
        required: true,
        evidenceRequirements: ["loaded-state screenshot", "source identity observation"],
        scenarioIds: ["load-source", "loaded-state"],
      },
      {
        id: "units-and-values",
        question: "Are quantities, units, and value changes understandable and internally consistent?",
        required: true,
        evidenceRequirements: ["input and result values", "units observation"],
        scenarioIds: ["configure", "result"],
      },
      {
        id: "action-feedback",
        question: "Does each consequential action provide timely, unambiguous feedback?",
        required: true,
        evidenceRequirements: ["action checkpoint", "feedback observation"],
        scenarioIds: ["configure", "submit", "download"],
      },
      {
        id: "result-interpretation",
        question: "Can a user understand the result and the next available action?",
        required: true,
        evidenceRequirements: ["result screenshot", "result interpretation observation"],
        scenarioIds: ["result", "download"],
      },
      {
        id: "error-recovery",
        question:
          "When the declared journey encounters an error, does the interface explain how to recover without losing valid work?",
        required: true,
        evidenceRequirements: ["declared error-state evidence or explicit unassessed reason"],
        scenarioIds: ["declared-error", "recovery"],
      },
    ],
  },
  "mobile-ux": {
    id: "mobile-ux",
    version: "1.0.0",
    supportedPlatforms: Object.freeze(["mobile-web"]),
    inquiryTopics: [
      "Mobile layout, reachability, and download expectations that require an explicit product decision.",
      "Viewport or device assumptions that the captured browser evidence cannot establish.",
    ],
    criteria: [
      {
        id: "mobile-controls-and-layout",
        question:
          "Are declared controls readable, reachable, and usable without obscuring required content in the mobile viewport?",
        required: true,
        evidenceRequirements: ["mobile viewport screenshots", "control interaction observations"],
        scenarioIds: ["canonical-journey", "configure", "result"],
      },
      {
        id: "mobile-download-discoverability",
        question: "Is the download action discoverable and understandable at the point a result is ready?",
        required: true,
        evidenceRequirements: ["result viewport screenshot", "download action observation"],
        scenarioIds: ["result", "download"],
      },
      {
        id: "viewport-evidence-limits",
        question:
          "Are conclusions limited to the captured viewport rather than claiming physical-device, touch, or exact-layout coverage?",
        required: true,
        evidenceRequirements: ["viewport dimensions", "evidence limitation observation"],
        scenarioIds: ["canonical-journey"],
      },
    ],
  },
  adversarial: {
    id: "adversarial",
    version: "1.0.0",
    supportedPlatforms: DESKTOP_AND_MOBILE,
    inquiryTopics: [
      "Declared boundary, invalid-input, concurrency, and recovery expectations whose acceptable behavior is undefined.",
      "Limits that determine when degraded behavior becomes a product defect.",
    ],
    criteria: [
      ...[
        [
          "malformed-files",
          "Does the declared malformed-file scenario reject invalid media without a misleading result?",
        ],
        ["boundary-values", "Are declared boundary values handled safely and clearly?"],
        ["repeated-actions", "Do declared repeated actions preserve consistent state?"],
        ["racing-actions", "Do declared overlapping actions avoid stale or contradictory results?"],
      ].map(([id, question]) => ({
        id,
        question,
        required: true,
        evidenceRequirements: ["Declared scenario action evidence", "Outcome observation"],
        scenarioIds: [id],
      })),
      {
        id: "declared-invalid-input",
        question:
          "For each declared invalid-input scenario, is the input rejected clearly without producing a misleading result?",
        required: true,
        evidenceRequirements: ["invalid-input action evidence", "rejection observation"],
        scenarioIds: ["invalid-input"],
      },
      {
        id: "stale-result-prevention",
        question:
          "For the declared stale-result scenario, does changing or clearing input prevent an old result from appearing current?",
        required: true,
        evidenceRequirements: ["before and after result evidence", "state transition observation"],
        scenarioIds: ["stale-result"],
      },
      {
        id: "adversarial-recovery",
        question:
          "After each declared adversarial scenario, can the canonical journey recover using only declared actions?",
        required: true,
        evidenceRequirements: ["recovery step evidence", "canonical outcome after recovery"],
        scenarioIds: ["invalid-input", "stale-result", "recovery"],
      },
    ],
  },
  performance: {
    id: "performance",
    version: "1.0.0",
    supportedPlatforms: DESKTOP_AND_MOBILE,
    inquiryTopics: [
      "The largest source workload the product is expected to accept for this journey.",
      "The completion latency and progress feedback users should consider acceptable at the declared workload.",
      "Expected degradation and recovery behavior at or beyond declared product limits.",
      "Timing, resource, device, and network conclusions that browser viewport evidence cannot establish.",
    ],
    criteria: [
      {
        id: "declared-workload-envelope",
        question: "Does the journey complete for the declared source workload envelope?",
        required: true,
        evidenceRequirements: [
          "declared workload requirement snapshot",
          "large-input source observation",
          "completed large-input journey evidence",
        ],
        scenarioIds: ["large-input", "completion"],
        requirementKeys: ["maximum-source-bytes"],
      },
      {
        id: "visible-responsiveness",
        question: "Does the declared large-input journey provide responsive controls and honest progress feedback?",
        required: true,
        evidenceRequirements: ["large-input action evidence", "progress and responsiveness observations"],
        scenarioIds: ["large-input", "progress-feedback"],
      },
      {
        id: "completion-latency",
        question:
          "Does the named reference workload complete within its declared reference-environment budget without treating a safety cutoff as acceptable latency?",
        required: true,
        evidenceRequirements: [
          "declared reference-workload latency requirement snapshot",
          "named reference workload and browser environment",
          "runner or browser monotonic timing observation",
          "completion evidence",
        ],
        scenarioIds: ["large-input", "completion"],
        requirementKeys: ["reference-workload-completion-milliseconds", "maximum-completion-milliseconds"],
      },
      {
        id: "limit-degradation-recovery",
        question:
          "At the declared workload limit, is degradation honest and can the journey recover using declared actions?",
        required: true,
        evidenceRequirements: ["limit behavior evidence", "declared recovery action evidence"],
        scenarioIds: ["limit-behavior", "recovery"],
        requirementKeys: ["maximum-source-bytes"],
      },
      {
        id: "browser-evidence-limits",
        question:
          "Are performance conclusions limited to observable browser timing and viewport evidence without unsupported device, resource, or network claims?",
        required: true,
        evidenceRequirements: ["timing source description", "viewport and capability limitation observation"],
        scenarioIds: ["large-input"],
      },
    ],
  },
});

function rubricContent(snapshot) {
  return {
    id: snapshot.id,
    version: snapshot.version,
    criteria: snapshot.criteria,
    supportedPlatforms: snapshot.supportedPlatforms,
    ...(snapshot.inquiryTopics ? { inquiryTopics: snapshot.inquiryTopics } : {}),
  };
}

function snapshotFor(entry) {
  const content = structuredClone(entry);
  return { ...content, rubricHash: sha256(content) };
}

export function assertPerspectiveSnapshot(snapshot, { platform } = {}) {
  if (!snapshot || typeof snapshot !== "object" || Array.isArray(snapshot)) {
    throw new TypeError("Evaluation perspective snapshot must be an object");
  }
  if (sha256(rubricContent(snapshot)) !== snapshot.rubricHash) {
    throw new TypeError("Evaluation perspective rubric hash does not match its canonical content");
  }
  if (platform && !snapshot.supportedPlatforms.includes(platform)) {
    throw new TypeError(`Evaluation perspective ${snapshot.id} does not support platform ${platform}`);
  }
  return snapshot;
}

export function resolvePerspective({ id, platform }) {
  const entry = CATALOG[id];
  if (!entry) throw new TypeError(`Unknown evaluation perspective: ${id}`);
  if (!entry.supportedPlatforms.includes(platform)) {
    throw new TypeError(`Evaluation perspective ${id} does not support platform ${platform}`);
  }
  return snapshotFor(entry);
}

export function listPerspectives() {
  return Object.values(CATALOG).map((entry) => snapshotFor(entry));
}
