import { resolve } from "node:path";

import { catalogProjectWorkflows, verifyCatalogWorkflowSource } from "./project-workflow-catalog.js";
import {
  projectSelectionSnapshot,
  selectVerifiedApplicationTarget,
  selectVerifiedCatalogSource,
} from "./project-surface-snapshot.js";

/** Resolve one current ordinary-language selection from one CLI-owned context/catalog/snapshot. */
export async function resolveCurrentJourneySource({
  journey,
  target,
  selectTarget = false,
  registry,
  resolveProjectContext,
}) {
  const projectContext = await resolveProjectContext();
  const catalog = await catalogProjectWorkflows(projectContext, { registry });
  const snapshot = await projectSelectionSnapshot(projectContext, {
    binding: "current",
    catalog,
    registry,
    terms: journey,
    targetTerms: target,
  });
  const source = selectVerifiedCatalogSource(snapshot, catalog);
  const applicationTarget = selectTarget ? selectVerifiedApplicationTarget(snapshot) : undefined;
  await verifyCatalogWorkflowSource(source);
  return { applicationTarget, projectContext, source };
}

/** Resolve one verified configured application target without selecting a workflow source. */
export async function resolveCurrentApplicationTarget({ target, registry, resolveProjectContext }) {
  const projectContext = await resolveProjectContext();
  const snapshot = await projectSelectionSnapshot(projectContext, { registry, targetTerms: target });
  return { applicationTarget: selectVerifiedApplicationTarget(snapshot), projectContext };
}

export function selectedStoreRoot(projectContext, explicitStore) {
  return explicitStore
    ? resolve(explicitStore)
    : resolve(projectContext.projectRoot, ...projectContext.paths.localStore.split("/"));
}
