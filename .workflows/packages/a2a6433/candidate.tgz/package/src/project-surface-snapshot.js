import { resolve } from "node:path";

import { AcceptanceStore } from "./acceptance-store.js";
import { acceptanceEvidenceVerifier } from "./acceptance-evidence.js";
import { selectApplicationTarget } from "./application-targets.js";
import { AuthSessionStore, authSessionScope } from "./auth-session-store.js";
import { FindingResolutionStore } from "./finding-resolution-store.js";
import { FindingVerificationContractStore } from "./finding-verification-contracts.js";
import { projectStudioFindings } from "./studio-findings.js";
import { FindingStore } from "./finding-store.js";
import { LifecycleStore } from "./lifecycle-store.js";
import { projectLifecycleProjection } from "./lifecycle-projection.js";
import { catalogProjectWorkflows } from "./project-workflow-catalog.js";
import { projectDiscoverySnapshot } from "./project-truth.js";
import { ReviewIntentStore } from "./review-intent-store.js";
import { RunControlStore } from "./run-control-store.js";
import { createSchemaRegistry } from "./schema-registry.js";
import { WorkflowError } from "./errors.js";
import { EvaluationQuestionStore } from "./evaluation-question-store.js";
import { EvaluationQuestionPolicyStore } from "./evaluation-question-policy-store.js";
import { readEvaluationRequirements } from "./evaluation-requirements.js";
import { createStudioProjectionContext } from "./studio-projection.js";

function localStoreRoot(projectContext) {
  return resolve(projectContext.projectRoot, ...projectContext.paths.localStore.split("/"));
}

function sessionStatus(record) {
  if (record?.state === "ready") return "ready";
  if (record?.state === "setup" || record?.state === "needs-login") return "sign-in-needed";
  return "needs-attention";
}

function sessionProjection(target, record, status) {
  return {
    targetId: target.id,
    label: target.label,
    environment: target.environment,
    origin: target.baseUrl,
    status: status ?? sessionStatus(record),
    lastVerifiedAt: record?.lastVerifiedAt ?? null,
  };
}

/** Read bounded, sanitized local readiness for exact configured user-session targets. */
export async function projectUserSessionReadiness(projectContext, options = {}) {
  const registry = options.registry ?? (await createSchemaRegistry());
  registry.validate("projectContext", projectContext);
  const targetContext = projectContext.applicationTargets ?? { inventory: [], warnings: [] };
  const authenticatedTargets = targetContext.inventory.filter(
    (target) => target.provenance === "configured-v1" && target.authentication?.mode === "user-session",
  );
  const sessionTargetContext = {
    inventory: authenticatedTargets,
    warnings: targetContext.warnings,
    ...(authenticatedTargets.some(({ id }) => id === targetContext.defaultTargetId)
      ? { defaultTargetId: targetContext.defaultTargetId }
      : {}),
  };
  const selection = selectApplicationTarget(sessionTargetContext, options.targetTerms ?? "");
  const candidateIds =
    selection.status === "selected"
      ? new Set([selection.targetId])
      : options.targetTerms && selection.status === "ambiguous"
        ? new Set(selection.candidateTargetIds)
        : null;
  const targets = authenticatedTargets
    .filter((target) => !candidateIds || candidateIds.has(target.id))
    .sort((left, right) => left.id.localeCompare(right.id));
  const authSessionStore =
    options.authSessionStore ?? new AuthSessionStore(localStoreRoot(projectContext), { registry });
  const sessions = [];
  for (const target of targets) {
    try {
      const record = await authSessionStore.read(authSessionScope(projectContext, target));
      sessions.push(sessionProjection(target, record));
    } catch (error) {
      sessions.push(
        sessionProjection(
          target,
          null,
          error?.code === "AUTH_SESSION_NOT_CONFIGURED" ? "not-set-up" : "needs-attention",
        ),
      );
    }
  }
  return { selection, sessions };
}

function activitySource(runStore, projectedRuns = null) {
  return {
    async listActivityRecords() {
      if (projectedRuns) {
        return projectedRuns.map((run) => ({
          workflowId: run.workflow?.id,
          runId: run.runId,
          platform: run.platform,
          phase: run.phase,
          status: run.status,
          startedAt: run.createdAt,
          integrity: run.status === "unavailable" ? "degraded" : "verified",
        }));
      }
      const runIds = await runStore.listRunIds();
      return Promise.all(
        runIds.map(async (runId) => {
          try {
            const run = await runStore.readRun(runId);
            return {
              workflowId: run.manifest.workflowRef?.id ?? run.workflow?.metadata?.id,
              runId,
              platform: run.manifest.platform,
              phase: run.state.phase,
              status: run.state.status,
              startedAt: run.manifest.createdAt,
              integrity: "verified",
            };
          } catch {
            return { runId, integrity: "degraded" };
          }
        }),
      );
    },
  };
}

function findingSource(runStore, findingStore, resolutionStore, contractStore, workflowIds, projectFinding, context) {
  return {
    async listFindingRecords() {
      const projections = await Promise.all(
        workflowIds.map((workflowId) =>
          projectFinding
            ? projectFinding(workflowId)
            : projectStudioFindings(runStore, findingStore, workflowId, resolutionStore, contractStore, context),
        ),
      );
      if (projections.some((projection) => projection.sourceIntegrity !== "verified")) {
        throw new WorkflowError("FINDINGS_UNAVAILABLE", "Finding records are unavailable");
      }
      return projections.flatMap((projection) => projection.findings);
    },
  };
}

async function projectEvaluationReadiness(projectContext, storeRoot, registry) {
  if (!projectContext.project?.id) {
    return {
      requirements: { status: "unavailable" },
      inquiryPolicy: { status: "unavailable" },
      questions: { status: "unavailable", verified: 0, degraded: 0 },
    };
  }
  const [requirements, policy, questions] = await Promise.allSettled([
    readEvaluationRequirements(projectContext, { registry }),
    new EvaluationQuestionPolicyStore(storeRoot, { registry }).read(projectContext.project.id),
    new EvaluationQuestionStore(storeRoot, { registry }).listAllRecords(),
  ]);
  const questionRecords = questions.status === "fulfilled" ? questions.value : [];
  return {
    requirements:
      requirements.status === "fulfilled"
        ? {
            status: "ready",
            recorded: requirements.value.recorded,
            count: requirements.value.catalog.requirements.length,
            catalogHash: requirements.value.catalogHash,
          }
        : { status: "unavailable" },
    inquiryPolicy:
      policy.status === "fulfilled"
        ? {
            status: "ready",
            recorded: policy.value.recorded,
            revision: policy.value.revision,
            depth: policy.value.depth,
          }
        : { status: "unavailable" },
    questions: {
      status: questions.status === "fulfilled" ? "ready" : "unavailable",
      verified: questionRecords.filter((item) => item.integrity === "verified").length,
      degraded: questionRecords.filter((item) => item.integrity === "degraded").length,
    },
  };
}

/** Read the exact shared ProjectContext-bound snapshot for CLI and Studio surfaces. */
export async function projectSurfaceSnapshot(projectContext, options = {}) {
  const registry = options.registry ?? (await createSchemaRegistry());
  registry.validate("projectContext", projectContext);

  const catalog = options.catalog ?? (await catalogProjectWorkflows(projectContext, { registry }));
  const storeRoot = localStoreRoot(projectContext);
  const runStore = options.runStore ?? new RunControlStore(storeRoot, { registry });
  const lifecycleStore = options.lifecycleStore ?? new LifecycleStore(storeRoot, { registry });
  const projectionContext = options.projectionContext ?? createStudioProjectionContext(runStore, lifecycleStore);
  const requestRunStore = projectionContext.runStore;
  const requestLifecycleStore = projectionContext.lifecycleStore;
  const findingStore = new FindingStore(storeRoot, { registry });
  const reviewIntentStore = new ReviewIntentStore(projectContext, { registry });
  const acceptanceStore = new AcceptanceStore(projectContext, {
    registry,
    verifyEvidence:
      options.verifyAcceptanceEvidence ??
      acceptanceEvidenceVerifier(projectContext, {
        registry,
        lifecycleStore: requestLifecycleStore,
        runStore: requestRunStore,
      }),
  });
  const lifecycle = options.lifecycle ?? (await projectLifecycleProjection(requestRunStore, requestLifecycleStore));
  const evaluationReadiness =
    options.evaluationReadiness ?? (await projectEvaluationReadiness(projectContext, storeRoot, registry));

  return projectDiscoverySnapshot(projectContext, {
    registry,
    catalog,
    terms: options.terms,
    targetTerms: options.targetTerms,
    binding: options.binding,
    revisions: options.revisions,
    now: options.now,
    asOf: options.asOf,
    maxAgeSeconds: options.maxAgeSeconds,
    activity: activitySource(requestRunStore, options.activityRecords),
    findings: findingSource(
      requestRunStore,
      findingStore,
      new FindingResolutionStore(storeRoot, { registry }),
      new FindingVerificationContractStore(storeRoot, { registry }),
      catalog.workflows.map((workflow) => workflow.id),
      options.findingProjection,
      projectionContext,
    ),
    reviewIntents: reviewIntentStore,
    acceptances: acceptanceStore,
    lifecycle,
    evaluationReadiness,
  });
}

/** Resolve catalog and target selection without reconstructing unrelated durable history. */
export async function projectSelectionSnapshot(projectContext, options = {}) {
  const registry = options.registry ?? (await createSchemaRegistry());
  registry.validate("projectContext", projectContext);
  const catalog = options.catalog ?? (await catalogProjectWorkflows(projectContext, { registry }));
  return projectDiscoverySnapshot(projectContext, {
    registry,
    catalog,
    terms: options.terms,
    targetTerms: options.targetTerms,
    binding: options.binding,
    revisions: options.revisions,
    now: options.now,
    asOf: options.asOf,
    maxAgeSeconds: options.maxAgeSeconds,
  });
}

/** Return the exact verified application target selected by shared discovery truth. */
export function selectVerifiedApplicationTarget(snapshot) {
  if (snapshot?.freshness?.status !== "fresh") unavailable("Application target discovery is stale; evaluate it again");
  if (snapshot?.integrity?.status !== "verified") {
    unavailable("Application target discovery is degraded; resolve its integrity issues before evaluation");
  }
  const selection = snapshot.applicationTargets?.selection;
  if (selection?.status === "empty") {
    throw new WorkflowError("APPLICATION_TARGET_NOT_FOUND", "No application target is configured", { exitCode: 3 });
  }
  if (selection?.status === "ambiguous") {
    throw new WorkflowError("APPLICATION_TARGET_SELECTION_AMBIGUOUS", selection.question, { exitCode: 3 });
  }
  const matches = (snapshot.applicationTargets?.inventory ?? []).filter(
    (target) =>
      target.id === selection?.targetId &&
      target.label === selection.label &&
      target.environment === selection.environment &&
      target.baseUrl === selection.baseUrl &&
      target.healthPath === selection.healthPath,
  );
  if (matches.length !== 1) unavailable("The selected application target is inconsistent; refresh project discovery");
  const selected = matches[0];
  return {
    targetId: selected.id,
    label: selected.label,
    environment: selected.environment,
    baseUrl: selected.baseUrl,
    ...(selected.healthPath === undefined ? {} : { healthPath: selected.healthPath }),
    reason: selection.reason,
    provenance: selected.provenance,
    ...(selected.provenance === "configured-v1" && selected.authentication?.mode === "user-session"
      ? { authentication: { mode: "user-session" } }
      : {}),
  };
}

function unavailable(message) {
  throw new WorkflowError("WORKFLOW_DISCOVERY_UNAVAILABLE", message, { exitCode: 3 });
}

/** Resolve the one verified current catalog source selected by the exact discovery snapshot. */
export function selectVerifiedCatalogSource(snapshot, catalog) {
  if (snapshot?.freshness?.status !== "fresh") unavailable("Journey discovery is stale; evaluate it again");
  if (
    snapshot?.integrity?.status !== "verified" ||
    snapshot?.inventory?.status !== "verified" ||
    catalog?.status !== "verified"
  ) {
    unavailable("Journey discovery is degraded; resolve its integrity issues before evaluation");
  }
  if (snapshot.selection?.status === "empty") {
    throw new WorkflowError("WORKFLOW_NOT_FOUND", "No journey matches that description", { exitCode: 3 });
  }
  if (snapshot.selection?.status === "ambiguous") {
    throw new WorkflowError("WORKFLOW_SELECTION_AMBIGUOUS", snapshot.selection.question, { exitCode: 3 });
  }
  const selectedInventory = snapshot.inventory.workflows.filter(
    (item) => item.workflowId === snapshot.selection?.workflowId && item.integrity === "verified",
  );
  const selectedSources = catalog.workflows.filter(
    (item) => item.id === snapshot.selection?.workflowId && item.status === "verified",
  );
  if (selectedInventory.length !== 1 || selectedSources.length !== 1 || !selectedSources[0].source) {
    unavailable("The selected journey source is unavailable; refresh project discovery before evaluation");
  }
  const selected = selectedSources[0];
  const expectedRevision = `candidate-r${selected.workflow.metadata.candidateRevision}`;
  if (
    snapshot.query?.binding !== "current" ||
    snapshot.selection.revision !== expectedRevision ||
    selected.source.workflow !== selected.workflow
  ) {
    unavailable("The selected journey revision is inconsistent; refresh project discovery before evaluation");
  }
  return selected.source;
}
