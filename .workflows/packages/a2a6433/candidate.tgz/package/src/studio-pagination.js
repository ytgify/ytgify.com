import { WorkflowError } from "./errors.js";

const STUDIO_HISTORY_PAGE_SIZE = 25;

function cursorError() {
  return new WorkflowError("STUDIO_CURSOR_INVALID", "Studio history cursor is invalid", { exitCode: 3 });
}

function createdAt(item) {
  return typeof item.createdAt === "string" ? item.createdAt : "";
}

function identity(item, idField) {
  const value = item[idField];
  if (typeof value !== "string" || !value || value.length > 256) throw cursorError();
  return value;
}

function compareHistory(left, right, idField) {
  return (
    createdAt(right).localeCompare(createdAt(left)) || identity(left, idField).localeCompare(identity(right, idField))
  );
}

function position(item, idField) {
  return [createdAt(item), identity(item, idField)];
}

function afterPosition(item, idField, [date, id]) {
  return date.localeCompare(createdAt(item)) || identity(item, idField).localeCompare(id);
}

function exactKeys(value, keys) {
  return (
    value &&
    typeof value === "object" &&
    !Array.isArray(value) &&
    Object.keys(value).length === keys.length &&
    keys.every((key) => Object.hasOwn(value, key))
  );
}

function decodeCursor(cursor, kind, collectionNames) {
  if (typeof cursor !== "string" || !cursor || cursor.length > 2048 || !/^[A-Za-z0-9_-]+$/u.test(cursor)) {
    throw cursorError();
  }
  try {
    const bytes = Buffer.from(cursor, "base64url");
    if (bytes.toString("base64url") !== cursor) throw cursorError();
    const value = JSON.parse(bytes.toString("utf8"));
    if (!exactKeys(value, ["v", "kind", "positions"]) || value.v !== 1 || value.kind !== kind) {
      throw cursorError();
    }
    if (!exactKeys(value.positions, collectionNames)) throw cursorError();
    for (const name of collectionNames) {
      const entry = value.positions[name];
      if (entry === false) continue;
      if (
        !Array.isArray(entry) ||
        entry.length !== 2 ||
        typeof entry[0] !== "string" ||
        entry[0].length > 64 ||
        typeof entry[1] !== "string" ||
        !entry[1] ||
        entry[1].length > 256
      ) {
        throw cursorError();
      }
    }
    return value.positions;
  } catch (error) {
    if (error?.code === "STUDIO_CURSOR_INVALID") throw error;
    throw cursorError();
  }
}

function encodeCursor(kind, positions) {
  return Buffer.from(JSON.stringify({ v: 1, kind, positions })).toString("base64url");
}

/**
 * Keyset pagination for one or more independently sorted Studio collections.
 * A false cursor position means that collection is exhausted, so advancing a
 * different collection cannot restart it.
 */
export function paginateStudioCollections({ kind, collections, cursor = null, limit = STUDIO_HISTORY_PAGE_SIZE }) {
  if (typeof kind !== "string" || !kind || !Number.isInteger(limit) || limit < 1 || limit > 100) {
    throw cursorError();
  }
  const collectionNames = Object.keys(collections).sort();
  if (!collectionNames.length) throw cursorError();
  const prior = cursor
    ? decodeCursor(cursor, kind, collectionNames)
    : Object.fromEntries(collectionNames.map((name) => [name, null]));
  const values = {};
  const positions = {};
  const total = {};
  const returned = {};
  let hasMore = false;

  for (const name of collectionNames) {
    const collection = collections[name];
    if (!exactKeys(collection, ["items", "idField"]) || !Array.isArray(collection.items)) throw cursorError();
    const ordered = [...collection.items].sort((left, right) => compareHistory(left, right, collection.idField));
    total[name] = ordered.length;
    if (prior[name] === false) {
      values[name] = [];
      returned[name] = 0;
      positions[name] = false;
      continue;
    }
    const remaining = prior[name]
      ? ordered.filter((item) => afterPosition(item, collection.idField, prior[name]) > 0)
      : ordered;
    const page = remaining.slice(0, limit);
    const collectionHasMore = remaining.length > page.length;
    values[name] = page;
    returned[name] = page.length;
    positions[name] = collectionHasMore ? position(page.at(-1), collection.idField) : false;
    hasMore ||= collectionHasMore;
  }

  return {
    values,
    page: {
      limit,
      total,
      returned,
      nextCursor: hasMore ? encodeCursor(kind, positions) : null,
    },
  };
}
