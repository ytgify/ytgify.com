import { execFile as execFileCallback } from "node:child_process";
import { createHash } from "node:crypto";
import { lstat, readFile } from "node:fs/promises";
import { basename, isAbsolute, join, normalize } from "node:path";
import { promisify } from "node:util";

import { WorkflowError } from "./errors.js";
import { assertSafeProjectPath } from "./project-path-safety.js";

const execFile = promisify(execFileCallback);
const MAX_FILE_BYTES = 8 * 1024 * 1024;
const mediaTypes = new Map([
  [".webm", "video/webm"],
  [".mp4", "video/mp4"],
  [".mov", "video/quicktime"],
  [".txt", "text/plain"],
  [".md", "text/markdown"],
]);

function invalid(message) {
  throw new WorkflowError("INVALID_USAGE", message, { exitCode: 2 });
}

function mimeFor(path) {
  const extension = path.slice(path.lastIndexOf(".")).toLowerCase();
  const mimeType = mediaTypes.get(extension);
  if (!mimeType) invalid("Exploration fixtures support only WebM, MP4, MOV, TXT, or Markdown files");
  return mimeType;
}

function parseSpec(value) {
  const first = value.indexOf("=");
  const last = value.lastIndexOf("=");
  if (first < 1 || last <= first + 1 || last >= value.length - 1)
    invalid("Each fixture needs NAME=RELATIVE_PATH=CONTROL_LABEL");
  const name = value.slice(0, first);
  const relativePath = value.slice(first + 1, last);
  const label = value.slice(last + 1);
  if (!/^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$/u.test(name)) invalid("Fixture name is not a semantic ID");
  if (
    isAbsolute(relativePath) ||
    relativePath.startsWith(".") ||
    relativePath.includes("\\") ||
    relativePath.includes(":") ||
    relativePath.split("/").some((part) => !part || part === "." || part === "..") ||
    normalize(relativePath) !== relativePath
  )
    invalid("Fixture path must be a normalized project-relative path");
  if (!/^[^\r\n]{1,200}$/u.test(label) || label.trim() !== label)
    invalid("Fixture control label must be an exact nonempty accessible name");
  return { name, relativePath, target: `label:${label}` };
}

async function trackedProjectFile(projectRoot, relativePath) {
  let result;
  try {
    result = await execFile("git", ["-C", projectRoot, "ls-files", "-z", "--error-unmatch", "--", relativePath], {
      timeout: 10_000,
      encoding: "buffer",
    });
  } catch {
    invalid("Exploration fixture must be a Git-indexed project file");
  }
  if (!result.stdout.equals(Buffer.from(`${relativePath}\0`))) invalid("Exploration fixture index identity changed");
}

async function indexedBytes(projectRoot, relativePath) {
  try {
    const result = await execFile("git", ["-C", projectRoot, "show", `:./${relativePath}`], {
      timeout: 10_000,
      encoding: "buffer",
      maxBuffer: MAX_FILE_BYTES + 1024,
    });
    return result.stdout;
  } catch {
    invalid("Exploration fixture Git index bytes are unavailable");
  }
}

export async function verifyExplorationFile(projectRoot, fixture) {
  const path = join(projectRoot, fixture.relativePath);
  await assertSafeProjectPath(projectRoot, path, "Exploration fixture", { finalType: "file", allowMissing: false });
  await trackedProjectFile(projectRoot, fixture.relativePath);
  const stat = await lstat(path);
  if (!stat.isFile() || stat.size < 1 || stat.size > MAX_FILE_BYTES)
    invalid("Exploration fixture must be a nonempty regular file within the size limit");
  const bytes = await readFile(path);
  await assertSafeProjectPath(projectRoot, path, "Exploration fixture", { finalType: "file", allowMissing: false });
  const sha256 = `sha256:${createHash("sha256").update(bytes).digest("hex")}`;
  if (fixture.sizeBytes !== undefined && (bytes.length !== fixture.sizeBytes || sha256 !== fixture.sha256))
    invalid("Exploration fixture bytes differ from the pinned run manifest");
  if (!bytes.equals(await indexedBytes(projectRoot, fixture.relativePath)))
    invalid("Exploration fixture Git index bytes differ from the working file");
  return { bytes, sizeBytes: bytes.length, sha256, mimeType: mimeFor(fixture.relativePath) };
}

export async function pinExplorationFiles(projectRoot, input) {
  if (input === undefined) return [];
  const specs = input.split(";");
  if (!specs.length || specs.length > 4 || specs.some((item) => !item))
    invalid("Exploration accepts one to four explicit project-file fixtures");
  const parsed = specs.map(parseSpec);
  if (new Set(parsed.map((item) => item.name)).size !== parsed.length) invalid("Fixture names must be unique");
  return Promise.all(
    parsed.map(async (fixture) => {
      const verified = await verifyExplorationFile(projectRoot, fixture);
      return {
        kind: "project-file",
        name: fixture.name,
        relativePath: fixture.relativePath,
        target: fixture.target,
        filename: basename(fixture.relativePath),
        sizeBytes: verified.sizeBytes,
        mimeType: verified.mimeType,
        sha256: verified.sha256,
      };
    }),
  );
}

export function matchesExplorationFile(manifest, action, requestedCapabilities) {
  if (manifest.phase !== "exploration" || action?.kind !== "upload-file") return false;
  if (!requestedCapabilities?.includes("browser.control") || !requestedCapabilities.includes("file-upload"))
    return false;
  const fixture = manifest.exploration?.fixtures?.find((item) => item.name === action.inputRef?.name);
  if (!fixture || action.target !== fixture.target) return false;
  const input = action.inputRef;
  return (
    input.kind === "project-file" &&
    input.filename === fixture.filename &&
    input.sizeBytes === fixture.sizeBytes &&
    input.mimeType === fixture.mimeType &&
    input.sha256 === fixture.sha256
  );
}
