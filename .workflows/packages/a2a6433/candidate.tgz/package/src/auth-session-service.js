import {
  assertUserSessionAdapter,
  authSessionCapabilityUnavailable,
  sanitizeMarkerCandidate,
} from "./auth-session-adapter.js";
import { WorkflowError } from "./errors.js";

const MAX_PROPOSAL_INSPECTIONS = 100;

function authError(code, message, details = {}) {
  return new WorkflowError(code, message, {
    exitCode: code === "AUTH_SESSION_REVISION_CONFLICT" ? 6 : 3,
    details,
  });
}

function assertExpected(current, expectedRevision) {
  if (current.revision !== expectedRevision) {
    throw authError("AUTH_SESSION_REVISION_CONFLICT", "Authentication session changed; reload and retry", {
      expectedRevision,
      actualRevision: current.revision,
    });
  }
}

function exactObject(value, keys) {
  return (
    value &&
    typeof value === "object" &&
    !Array.isArray(value) &&
    Object.keys(value).length === keys.length &&
    keys.every((key) => Object.hasOwn(value, key))
  );
}

async function adapterCall(operation, validate) {
  try {
    const value = await operation();
    if (!validate(value)) throw authSessionCapabilityUnavailable();
    return value;
  } catch {
    throw authSessionCapabilityUnavailable();
  }
}

function openedResult(value) {
  return (
    (exactObject(value, ["opened"]) || exactObject(value, ["opened", "sessionRef"])) &&
    value.opened === true &&
    (value.sessionRef === undefined || /^usersession_[A-Za-z0-9_-]+$/u.test(value.sessionRef))
  );
}

function proposedResult(value) {
  return exactObject(value, ["candidates"]) && Array.isArray(value.candidates);
}

function sanitizedProposals(value) {
  if (!proposedResult(value)) throw authSessionCapabilityUnavailable();
  const candidates = [];
  const seen = new Set();
  let inspected = 0;
  for (const candidate of value.candidates) {
    if (inspected === MAX_PROPOSAL_INSPECTIONS) throw authSessionCapabilityUnavailable();
    inspected += 1;
    let marker;
    try {
      marker = sanitizeMarkerCandidate(candidate);
    } catch (error) {
      if (error.code === "AUTH_MARKER_UNSAFE") continue;
      throw error;
    }
    const key = JSON.stringify([marker.routePath, marker.role, marker.name]);
    if (!seen.has(key)) {
      seen.add(key);
      candidates.push(marker);
    }
    if (candidates.length === 5) break;
  }
  return candidates;
}

function verificationResult(value) {
  return (
    (exactObject(value, ["outcome"]) || exactObject(value, ["outcome", "sessionRef"])) &&
    ["verified", "needs-login", "unavailable"].includes(value.outcome) &&
    (value.sessionRef === undefined || /^usersession_[A-Za-z0-9_-]+$/u.test(value.sessionRef)) &&
    (value.outcome === "verified" || value.sessionRef === undefined)
  );
}

function clearResult(value) {
  return exactObject(value, ["outcome"]) && ["cleared", "unavailable"].includes(value.outcome);
}

/** Coordinate sanitized metadata with a host-owned persistent browser profile. */
export class AuthSessionService {
  constructor({ store, adapter }) {
    if (!store || typeof store !== "object") throw authSessionCapabilityUnavailable();
    this.store = store;
    this.adapter = assertUserSessionAdapter(adapter);
  }

  async open(scope, expectedRevision) {
    let current;
    try {
      current = await this.store.provision(scope);
    } catch (error) {
      if (error.code !== "AUTH_SESSION_STALE" || !Number.isSafeInteger(expectedRevision)) throw error;
      await this.clearStale(scope, expectedRevision);
      current = await this.store.provision(scope);
    }
    await adapterCall(
      () =>
        this.adapter.open({
          browserProfileId: current.browserProfileId,
          origin: current.origin,
          ...(current.state === "ready" && current.marker ? { marker: current.marker } : {}),
        }),
      openedResult,
    );
    return current;
  }

  async clearStale(scope, expectedRevision) {
    const current = await this.store.readForRecovery(scope);
    assertExpected(current, expectedRevision);
    const staleScope = {
      projectId: current.projectId,
      targetId: current.targetId,
      environment: current.environment,
      origin: current.origin,
    };
    let result;
    try {
      result = await adapterCall(
        () => this.adapter.clear({ browserProfileId: current.browserProfileId, origin: current.origin }),
        clearResult,
      );
    } catch (error) {
      await this.store.markClearFailed(staleScope, expectedRevision);
      throw error;
    }
    if (result.outcome !== "cleared") {
      await this.store.markClearFailed(staleScope, expectedRevision);
      throw authError("AUTH_SESSION_CLEAR_FAILED", "Authentication session could not be cleared");
    }
    await this.store.remove(staleScope, expectedRevision);
  }

  async propose(scope) {
    const current = await this.store.read(scope);
    return adapterCall(
      async () =>
        sanitizedProposals(
          await this.adapter.proposeMarkers({
            browserProfileId: current.browserProfileId,
            origin: current.origin,
            limit: 5,
          }),
        ),
      Array.isArray,
    );
  }

  async confirm(scope, expectedRevision, candidate) {
    const current = await this.store.read(scope);
    assertExpected(current, expectedRevision);
    const marker = sanitizeMarkerCandidate(candidate);
    const result = await adapterCall(
      () =>
        this.adapter.verify({
          browserProfileId: current.browserProfileId,
          origin: current.origin,
          marker,
        }),
      verificationResult,
    );
    if (result.outcome === "unavailable") throw authSessionCapabilityUnavailable();
    if (result.outcome !== "verified") {
      throw authError("AUTH_MARKER_NOT_FOUND", "The selected marker was not verified");
    }
    return this.store.confirmMarker(scope, expectedRevision, marker);
  }

  async verify(scope) {
    const current = await this.store.read(scope);
    if (!current.marker || !current.markerHash) {
      throw authError("AUTH_MARKER_NOT_CONFIGURED", "Authentication marker is not configured");
    }
    const result = await adapterCall(
      () =>
        this.adapter.verify({
          browserProfileId: current.browserProfileId,
          origin: current.origin,
          marker: current.marker,
        }),
      verificationResult,
    );
    if (result.outcome === "unavailable") throw authSessionCapabilityUnavailable();
    const record = await this.store.recordVerification(scope, current.revision, result.outcome);
    return result.sessionRef ? { ...record, browserSessionRef: result.sessionRef } : record;
  }

  async reauthenticate(scope) {
    const current = await this.store.read(scope);
    await adapterCall(
      () =>
        this.adapter.open({
          browserProfileId: current.browserProfileId,
          origin: current.origin,
        }),
      openedResult,
    );
    return current;
  }

  async clear(scope, expectedRevision) {
    let current;
    try {
      current = await this.store.read(scope);
    } catch (error) {
      if (error.code !== "AUTH_SESSION_STALE") throw error;
      await this.clearStale(scope, expectedRevision);
      return { outcome: "cleared" };
    }
    assertExpected(current, expectedRevision);
    let result;
    try {
      result = await adapterCall(
        () =>
          this.adapter.clear({
            browserProfileId: current.browserProfileId,
            origin: current.origin,
          }),
        clearResult,
      );
    } catch (error) {
      await this.store.markClearFailed(scope, expectedRevision);
      throw error;
    }
    if (result.outcome !== "cleared") {
      await this.store.markClearFailed(scope, expectedRevision);
      throw authError("AUTH_SESSION_CLEAR_FAILED", "Authentication session could not be cleared");
    }
    await this.store.remove(scope, expectedRevision);
    return { outcome: "cleared" };
  }

  async dispose() {
    if (typeof this.adapter.dispose === "function") await this.adapter.dispose();
  }
}
