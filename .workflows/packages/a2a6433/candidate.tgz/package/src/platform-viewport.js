import { WorkflowError } from "./errors.js";

const DEFAULT_DESKTOP_VIEWPORT = Object.freeze({ width: 1440, height: 900 });

/** Resolve the exact workflow-declared geometry before an immutable run is written. */
export function resolvePlatformViewport(workflow, platformId) {
  const platform = workflow?.target?.supportedPlatforms?.find((item) => item.id === platformId);
  if (!platform) {
    throw new WorkflowError("PLATFORM_NOT_SUPPORTED", `Unsupported platform: ${platformId}`, { exitCode: 3 });
  }
  if (platform.viewport === "default-desktop") return { ...DEFAULT_DESKTOP_VIEWPORT };
  if (!platform.viewport || !Number.isInteger(platform.viewport.width) || !Number.isInteger(platform.viewport.height)) {
    throw new WorkflowError("VIEWPORT_REQUIRED", `${platformId} requires an exact viewport`, { exitCode: 3 });
  }
  return { width: platform.viewport.width, height: platform.viewport.height };
}
