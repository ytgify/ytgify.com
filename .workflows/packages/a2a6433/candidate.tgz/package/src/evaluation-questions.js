import { WorkflowError } from "./errors.js";
import { QUESTION_WRITE_AUTHORITY } from "./evaluation-question-store.js";
import { buildRunReport } from "./run-report.js";
import { sha256 } from "./stable-json.js";

function invalid(message, details = {}) {
  throw new WorkflowError("VALIDATION_FAILED", message, { exitCode: 3, details });
}

function scenarioStepIds(run, scenarioId) {
  if (scenarioId === "canonical-journey") return (run.workflow?.steps ?? []).map((step) => step.id);
  if (scenarioId === "reset") return [run.workflow?.evaluation?.resetStepId].filter(Boolean);
  if (scenarioId === "cleanup") return [run.workflow?.evaluation?.cleanupStepId].filter(Boolean);
  return run.workflow?.evaluation?.perspectiveScenarios?.find((item) => item.id === scenarioId)?.stepIds ?? [];
}

function normalizedText(value, label, maximum) {
  if (typeof value !== "string" || value.trim().length < 3 || value.length > maximum)
    invalid(`${label} must be specific and no longer than ${maximum} characters`);
  return value.trim();
}

function assertSuggestionValues(answerSpec, suggestions) {
  if (!Array.isArray(suggestions)) invalid("Question suggestions must be an array");
  const ids = new Set();
  for (const suggestion of suggestions) {
    if (ids.has(suggestion.id)) invalid("Question suggestion IDs must be unique");
    ids.add(suggestion.id);
    const { value } = suggestion;
    if (answerSpec.type === "boolean" && typeof value !== "boolean")
      invalid("Boolean question suggestions must use boolean values");
    if (answerSpec.type === "quantity") {
      if (!Number.isSafeInteger(value)) invalid("Quantity question suggestions must use integer values");
      if (answerSpec.minimum !== undefined && value < answerSpec.minimum)
        invalid("Question suggestion is below the permitted minimum");
      if (answerSpec.maximum !== undefined && value > answerSpec.maximum)
        invalid("Question suggestion is above the permitted maximum");
    }
    if (answerSpec.type === "text" && typeof value !== "string")
      invalid("Text question suggestions must use string values");
    if (answerSpec.type === "single-choice") {
      if (typeof value !== "string" || !answerSpec.options.some((option) => option.id === value))
        invalid("Single-choice suggestion must reference a declared option ID");
    }
  }
  if (
    answerSpec.type === "quantity" &&
    answerSpec.minimum !== undefined &&
    answerSpec.maximum !== undefined &&
    answerSpec.minimum > answerSpec.maximum
  )
    invalid("Question quantity minimum cannot exceed its maximum");
  if (answerSpec.type === "single-choice") {
    const optionIds = answerSpec.options.map((option) => option.id);
    if (new Set(optionIds).size !== optionIds.length) invalid("Question option IDs must be unique");
  }
}

async function enforceInquiryPolicy({ questionStore, runId, perspective, basis }) {
  const policy = perspective.inquiryPolicy ?? {
    depth: "balanced",
    optionalQuestionsPerStep: 2,
    optionalQuestionsPerRun: 16,
  };
  const criterionBlocker = basis.assessmentImpact === "blocks-criterion";
  if (!criterionBlocker && policy.depth === "focused")
    invalid("Focused inquiry accepts only questions that block a criterion assessment");
  if (!criterionBlocker && policy.depth === "balanced" && basis.priority === "exploratory")
    invalid("Balanced inquiry does not accept exploratory questions");
  if (criterionBlocker) return;
  const existing = (await questionStore.listQuestions(runId)).filter(
    (question) => question.assessmentImpact !== "blocks-criterion",
  );
  if (existing.length >= policy.optionalQuestionsPerRun)
    invalid("Evaluation run has reached its optional question allowance");
  if (existing.filter((question) => question.stepId === basis.stepId).length >= policy.optionalQuestionsPerStep)
    invalid("Evaluation step has reached its optional question allowance");
}

async function verifyObservation({ observation, scenarioId, stepId, report, runStore, runId }) {
  if (observation.scenarioId !== scenarioId || observation.stepId !== stepId)
    invalid("Question observations must refer to the question's exact scenario and step");
  const step = report.steps.find((item) => item.id === stepId);
  if (!step) invalid("Question step is unavailable for this run");
  if (observation.noteIndex !== undefined && !step.notes[observation.noteIndex])
    invalid("Question observation note is unavailable for this run");
  if (observation.artifactId !== undefined) {
    if (!step.evidence.some((item) => item.artifactId === observation.artifactId))
      invalid("Question evidence belongs to a different run or step");
    try {
      await runStore.readVerifiedEvidence(runId, observation.artifactId);
    } catch (error) {
      if (!["ENOENT", "NOT_FOUND", "VALIDATION_FAILED"].includes(error?.code) && !(error instanceof TypeError))
        throw error;
      invalid("Question evidence is missing or corrupt");
    }
  }
}

export async function proposeEvaluationQuestion({ questionStore, runStore, batchStore, runId, input }) {
  if (!input || typeof input !== "object" || Array.isArray(input)) invalid("Question input must be an object");
  const allowed = new Set([
    "criterionId",
    "scenarioId",
    "stepId",
    "requirementKey",
    "prompt",
    "rationale",
    "priority",
    "assessmentImpact",
    "answerSpec",
    "suggestions",
    "allowedScopes",
    "observations",
  ]);
  const unknown = Object.keys(input).filter((key) => !allowed.has(key));
  if (unknown.length) invalid(`Question input contains unsupported field: ${unknown[0]}`);
  const [run, report] = await Promise.all([
    runStore.readRun(runId),
    buildRunReport(runStore, runId, { skipPerspective: true }),
  ]);
  if (run.manifest.phase !== "evaluation") invalid("Questions can be proposed only from evaluation runs");
  const perspective = run.manifest.evaluationPerspective;
  if (!perspective) invalid("Evaluation perspective is not recorded for this run");
  const batch = await batchStore.read(perspective.batchId);
  const member = batch.members.find((item) => item.runId === runId);
  if (!member || member.perspectiveId !== perspective.id || member.platform !== run.manifest.platform)
    invalid("Question run does not match its recorded evaluation batch member");
  const selection = batch.selections.find(
    (item) => item.perspectiveId === perspective.id && item.platform === run.manifest.platform,
  );
  if (!selection || selection.rubric.rubricHash !== perspective.rubricHash)
    invalid("Question run does not match the batch's pinned rubric");
  const effectiveRubricHash = perspective.effectiveRubricHash ?? perspective.rubricHash;
  if (selection.effectiveRubricHash && selection.effectiveRubricHash !== effectiveRubricHash)
    invalid("Question run does not match the batch's effective rubric");
  const criterion = perspective.criteria.find((item) => item.id === input.criterionId);
  if (!criterion) invalid("Question criterion is absent from the run's pinned rubric");
  if (!criterion.scenarioIds.includes(input.scenarioId))
    invalid("Question scenario is absent from the pinned criterion");
  if (!scenarioStepIds(run, input.scenarioId).includes(input.stepId))
    invalid("Question step is not mapped to its declared scenario");
  if (!Array.isArray(input.observations) || input.observations.length === 0)
    invalid("Question requires at least one verified observation");
  for (const observation of input.observations)
    await verifyObservation({
      observation,
      scenarioId: input.scenarioId,
      stepId: input.stepId,
      report,
      runStore,
      runId,
    });
  assertSuggestionValues(input.answerSpec, input.suggestions);
  const workflowRevision =
    batch.source.sourceKind === "candidate" ? batch.source.candidateRevision : batch.source.revision;
  const basis = {
    workflowId: batch.source.workflowId,
    workflowRevision,
    runId,
    batchId: batch.batchId,
    platform: run.manifest.platform,
    perspectiveId: perspective.id,
    rubricHash: perspective.rubricHash,
    effectiveRubricHash,
    criterionId: input.criterionId,
    scenarioId: input.scenarioId,
    stepId: input.stepId,
    requirementKey: input.requirementKey,
    prompt: normalizedText(input.prompt, "Question prompt", 500),
    rationale: normalizedText(input.rationale, "Question rationale", 4000),
    priority: input.priority,
    assessmentImpact: input.assessmentImpact,
    answerSpec: structuredClone(input.answerSpec),
    suggestions: structuredClone(input.suggestions),
    allowedScopes: structuredClone(input.allowedScopes),
    observations: structuredClone(input.observations),
  };
  const questionId = `question_${sha256(basis).slice(7, 39)}`;
  try {
    const existing = await questionStore.readQuestion(runId, questionId);
    const existingBasis = structuredClone(existing);
    delete existingBasis.schema;
    delete existingBasis.questionId;
    delete existingBasis.createdAt;
    if (sha256(existingBasis) !== sha256(basis)) invalid("Question identity conflicts with its immutable request");
    return existing;
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
  }
  await enforceInquiryPolicy({ questionStore, runId, perspective, basis });
  const record = {
    schema: "agent-workflow-evaluation-question/v1",
    questionId,
    ...basis,
    createdAt: new Date().toISOString(),
  };
  try {
    return await questionStore.writeQuestion(record, QUESTION_WRITE_AUTHORITY);
  } catch (error) {
    if (error.code !== "IMMUTABLE_QUESTION_EXISTS") throw error;
    return questionStore.readQuestion(runId, questionId);
  }
}

export async function listEvaluationQuestions({ questionStore, workflowId }) {
  const records = await questionStore.listAll();
  return records
    .filter((record) => record.workflowId === workflowId)
    .sort((left, right) => left.createdAt.localeCompare(right.createdAt));
}
