import { catalogProjectWorkflows } from "./project-workflow-catalog.js";
import { emptyLifecycleProjection } from "./lifecycle-projection.js";
import { selectApplicationTarget } from "./application-targets.js";
import { createSchemaRegistry } from "./schema-registry.js";
import { sha256 } from "./stable-json.js";

const CURRENT_REVISION = /^candidate-r[1-9][0-9]*$/u;
const LATEST_REVISION = /^v[1-9][0-9]*$/u;

function text(value, fallback = "Unavailable") {
  const printable = [...String(value ?? "")]
    .map((character) => {
      const code = character.codePointAt(0);
      return code < 32 || code === 127 ? " " : character;
    })
    .join("");
  const sanitized = printable.replace(/\s+/gu, " ").trim();
  return (sanitized || fallback).slice(0, 500);
}

function timestamp(value, fallback) {
  const date = new Date(value);
  return Number.isNaN(date.valueOf()) ? fallback : date.toISOString();
}

function route(workflowId, suffix = "") {
  return `#/journeys/${encodeURIComponent(workflowId)}${suffix}`;
}

function normalizeTerms(value) {
  return (
    text(value, "")
      .toLocaleLowerCase("en-US")
      .match(/[a-z0-9]+/gu) ?? []
  );
}

function semanticMatch(candidate, terms) {
  if (!terms.length) return true;
  const haystack = normalizeTerms(
    [candidate.name, candidate.purpose, ...(candidate.platforms ?? []), ...(candidate.tags ?? [])].join(" "),
  );
  return terms.every((term) => haystack.includes(term));
}

function latest(entries) {
  return [...entries]
    .filter((entry) => LATEST_REVISION.test(entry.revision ?? ""))
    .sort(
      (left, right) =>
        Number(right.revision.slice(1)) - Number(left.revision.slice(1)) ||
        String(left.contentHash).localeCompare(String(right.contentHash)),
    )[0];
}

function bindingFor(item, binding, revisions) {
  const workflow = item.workflow ?? item;
  const metadata = workflow.metadata ?? {};
  if (binding === "current") {
    const supplied = item.bindings?.find((entry) => entry.binding === "current") ?? item.current;
    if (supplied && CURRENT_REVISION.test(supplied.revision ?? "")) return supplied;
    if (metadata.lifecycle !== "candidate" || !Number.isInteger(metadata.candidateRevision)) return null;
    return {
      revision: `candidate-r${metadata.candidateRevision}`,
      contentHash: sha256(workflow),
      workflow,
    };
  }
  return latest([
    ...(item.bindings?.filter((entry) => entry.binding === "latest") ?? []),
    ...(item.revisions ?? []),
    ...(revisions?.[metadata.id] ?? []),
  ]);
}

function candidateFrom(item, binding, revisions) {
  const workflow = item.workflow ?? item;
  const metadata = workflow.metadata ?? {};
  const bound = bindingFor(item, binding, revisions);
  if (!bound) return null;
  const contentHash = bound.contentHash ?? bound.workflow?.metadata?.contentHash;
  if (!/^sha256:[a-f0-9]{64}$/u.test(contentHash ?? "")) return null;
  const platforms = (workflow.target?.supportedPlatforms ?? [])
    .map((platform) => platform.id)
    .filter((platform) => typeof platform === "string")
    .sort();
  return {
    workflowId: metadata.id ?? item.id,
    name: text(metadata.name),
    purpose: text(metadata.description),
    platforms,
    tags: [...(metadata.tags ?? [])].sort(),
    binding,
    revision: bound.revision,
    contentHash,
    route: route(metadata.id ?? item.id, binding === "current" ? "/training" : "/release"),
    integrity: item.status === "verified" ? "verified" : "degraded",
  };
}

function sanitizeActivity(record) {
  const workflowId = record.workflowId ?? record.workflow?.id;
  if (!record.runId) return null;
  // Exploration has no journey binding or journey route. It is reviewed through
  // explore review; only verified exploration records may leave this projection.
  if (!workflowId && record.phase === "exploration" && record.integrity === "verified") return null;
  if (!workflowId) return { runId: record.runId, integrity: "degraded" };
  return {
    workflowId,
    runId: record.runId,
    platform: text(record.platform, "unknown"),
    phase: text(record.phase, "unknown"),
    status: text(record.status, "unavailable"),
    startedAt: timestamp(record.startedAt ?? record.createdAt, "1970-01-01T00:00:00.000Z"),
    ...(record.completedAt ? { completedAt: timestamp(record.completedAt, "1970-01-01T00:00:00.000Z") } : {}),
    route: route(
      workflowId,
      `/${record.phase === "training" ? "training-run" : "runs"}/${encodeURIComponent(record.runId)}`,
    ),
    integrity: record.integrity === "verified" ? "verified" : "degraded",
  };
}

function sanitizeFinding(record) {
  if (!record.findingId) return null;
  if (!record.workflowId) return { findingId: record.findingId, integrity: "degraded" };
  return {
    workflowId: record.workflowId,
    findingId: record.findingId,
    title: text(record.title),
    severity: text(record.severity, "unknown"),
    status: text(record.status, "unavailable"),
    createdAt: timestamp(record.createdAt, "1970-01-01T00:00:00.000Z"),
    route: route(record.workflowId, `/findings/${encodeURIComponent(record.findingId)}`),
    integrity: record.integrity === "verified" ? "verified" : "degraded",
  };
}

function sanitizeIntent(entry) {
  const record = entry.record ?? entry;
  const intentId = entry.intentId ?? record.intentId;
  if (!intentId) return null;
  if (entry.integrity !== undefined && entry.integrity !== "verified") {
    return { intentId, integrity: "degraded" };
  }
  if (!record.workflowId || !record.action?.kind || !record.action?.summary || !record.createdAt) {
    return { intentId, integrity: "degraded" };
  }
  const source =
    record.source &&
    ["training", "evaluation"].includes(record.source.phase) &&
    /^run_[A-Za-z0-9_-]+$/u.test(record.source.runId ?? "") &&
    /^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$/u.test(record.source.stepId ?? "")
      ? {
          phase: record.source.phase,
          runId: record.source.runId,
          stepId: record.source.stepId,
          ...(record.source.artifactId ? { artifactId: record.source.artifactId } : {}),
        }
      : null;
  return {
    intentId,
    workflowId: record.workflowId,
    kind: record.action.kind,
    summary: text(record.action.summary),
    authority: "none",
    createdAt: timestamp(record.createdAt, "1970-01-01T00:00:00.000Z"),
    provenance: {
      actorKind: record.provenance?.actorKind ?? "caller",
      channel: record.provenance?.channel ?? "cli",
    },
    ...(source ? { source } : {}),
    ...(record.supersedesIntentId ? { supersedesIntentId: record.supersedesIntentId } : {}),
    route: source
      ? route(
          record.workflowId,
          `/${source.phase === "training" ? "training-run" : "runs"}/${encodeURIComponent(source.runId)}`,
        )
      : route(record.workflowId, "/review"),
    integrity: "verified",
  };
}

function sanitizeAcceptance(entry) {
  const record = entry.record;
  if (!record) return { acceptanceId: entry.acceptanceId, integrity: "degraded", support: "unavailable" };
  return {
    acceptanceId: record.acceptanceId,
    workflowId: record.workflowId,
    revision: record.revision,
    decision: record.decision,
    acceptedAt: record.acceptedAt,
    actorKind: record.authority?.actorKind ?? "human",
    ...(record.supersedesAcceptanceId ? { supersedesAcceptanceId: record.supersedesAcceptanceId } : {}),
    route: route(record.workflowId, "/acceptance"),
    integrity: entry.integrity === "verified" ? "verified" : "degraded",
    support: entry.integrity === "verified" ? "supported" : "unavailable",
  };
}

function deterministic(items, fields) {
  return items.sort((left, right) => {
    for (const field of fields) {
      const comparison = String(left[field] ?? "").localeCompare(String(right[field] ?? ""));
      if (comparison) return comparison;
    }
    return 0;
  });
}

async function records(source, method) {
  if (!source) return [];
  if (Array.isArray(source)) return source;
  if (typeof source[method] === "function") return source[method]();
  return [];
}

function attention(activity, findings, intents, degradedRecords) {
  const items = [];
  for (const run of activity.filter((item) => !["completed", "passed"].includes(item.status))) {
    items.push({
      kind: "run",
      ...(run.workflowId ? { workflowId: run.workflowId } : {}),
      summary: run.integrity === "verified" ? `Run is ${run.status}.` : "Run activity is unavailable.",
      ...(run.route ? { route: run.route } : {}),
      integrity: run.integrity,
    });
  }
  for (const finding of findings.filter((item) => item.status !== "verified-resolved")) {
    items.push({
      kind: "finding",
      ...(finding.workflowId ? { workflowId: finding.workflowId } : {}),
      summary: finding.integrity === "verified" ? finding.title : "Finding details are unavailable.",
      ...(finding.route ? { route: finding.route } : {}),
      integrity: finding.integrity,
    });
  }
  for (const intent of intents.filter((item) => item.integrity === "verified")) {
    items.push({
      kind: "review-intent",
      workflowId: intent.workflowId,
      summary: intent.summary,
      route: intent.route,
      integrity: "verified",
    });
  }
  for (const record of degradedRecords) {
    items.push({
      kind: record.kind,
      summary: `${record.kind === "acceptance" ? "Acceptance" : "Review intent"} record ${record.id} is unavailable.`,
      integrity: "degraded",
    });
  }
  return deterministic(items, ["workflowId", "kind", "summary"]);
}

/** Build the one bounded ProjectContext-driven truth consumed by future CLI and Studio surfaces. */
export async function projectDiscoverySnapshot(projectContext, options = {}) {
  const registry = options.registry ?? (await createSchemaRegistry());
  registry.validate("projectContext", projectContext);
  const generatedAt = timestamp(options.now ?? new Date(), new Date(0).toISOString());
  const asOf = timestamp(options.asOf ?? generatedAt, generatedAt);
  const maxAgeSeconds = Math.max(0, Number.isSafeInteger(options.maxAgeSeconds) ? options.maxAgeSeconds : 5);
  const stale = new Date(generatedAt).valueOf() - new Date(asOf).valueOf() > maxAgeSeconds * 1000;
  const binding = options.binding === "latest" ? "latest" : "current";
  const queryTerms = text(options.terms, "");
  const targetTerms = text(options.targetTerms, "");
  const applicationTargetContext = projectContext.applicationTargets ?? { inventory: [], warnings: [] };
  const applicationTargets = {
    inventory: applicationTargetContext.inventory,
    selection: selectApplicationTarget(applicationTargetContext, targetTerms),
    warnings: applicationTargetContext.warnings,
  };
  const catalog = options.catalog ?? (await catalogProjectWorkflows(projectContext, { registry }));
  const issues = catalog.issues.map((item) => `A workflow definition is ${text(item.code, "unavailable")}.`);
  if (catalog.status !== "verified" && issues.length === 0) {
    issues.push("Workflow inventory could not be fully verified.");
  }

  const inventory = deterministic(
    catalog.workflows.map((item) => candidateFrom(item, binding, options.revisions)).filter(Boolean),
    ["workflowId"],
  );
  const candidates = inventory.filter((candidate) => semanticMatch(candidate, normalizeTerms(queryTerms)));

  let activityRecords = [];
  let findingRecords = [];
  let intentRecords = [];
  let acceptanceRecords = [];
  for (const [label, source, method, assign] of [
    ["run activity", options.activity, "listActivityRecords", (value) => (activityRecords = value)],
    ["findings", options.findings, "listFindingRecords", (value) => (findingRecords = value)],
    ["review intent", options.reviewIntents, "listIntentRecords", (value) => (intentRecords = value)],
    ["acceptance", options.acceptances, "listAcceptanceRecords", (value) => (acceptanceRecords = value)],
  ]) {
    try {
      assign(await records(source, method));
    } catch {
      issues.push(`${label[0].toUpperCase()}${label.slice(1)} could not be verified.`);
    }
  }

  const activity = deterministic(activityRecords.map(sanitizeActivity).filter(Boolean), [
    "workflowId",
    "startedAt",
    "runId",
  ]);
  const findings = deterministic(findingRecords.map(sanitizeFinding).filter(Boolean), [
    "workflowId",
    "createdAt",
    "findingId",
  ]);
  const reviewIntents = deterministic(intentRecords.map(sanitizeIntent).filter(Boolean), [
    "workflowId",
    "createdAt",
    "intentId",
  ]);
  const acceptances = deterministic(acceptanceRecords.map(sanitizeAcceptance).filter(Boolean), [
    "workflowId",
    "acceptedAt",
    "acceptanceId",
  ]);
  const degradedRecords = [
    ...reviewIntents
      .filter((item) => item.integrity !== "verified")
      .map((item) => ({ kind: "review-intent", id: item.intentId })),
    ...acceptances
      .filter((item) => item.integrity !== "verified")
      .map((item) => ({ kind: "acceptance", id: item.acceptanceId })),
  ];
  if (activity.some((item) => item.integrity !== "verified")) issues.push("Run activity contains unavailable records.");
  if (findings.some((item) => item.integrity !== "verified")) issues.push("Findings contain unavailable records.");
  if (degradedRecords.length) issues.push("Collaboration records contain unavailable records.");
  if (inventory.some((item) => item.integrity !== "verified")) issues.push("Workflow inventory is degraded.");
  const lifecycle = options.lifecycle ?? emptyLifecycleProjection();
  if (lifecycle.integrity.status !== "verified") issues.push("Lifecycle records could not be fully verified.");

  const pendingAttention = attention(activity, findings, reviewIntents, degradedRecords);
  const integrity = issues.length ? "degraded" : "verified";
  const verifiedAcceptances = acceptances.filter((item) => item.integrity === "verified");
  const supersededAcceptanceIds = new Set(
    verifiedAcceptances.map((item) => item.supersedesAcceptanceId).filter(Boolean),
  );
  const effectiveAcceptances = verifiedAcceptances.filter((item) => !supersededAcceptanceIds.has(item.acceptanceId));
  const effectiveAcceptance =
    effectiveAcceptances.length === 1 && effectiveAcceptances[0].actorKind === "human" ? effectiveAcceptances[0] : null;
  const acceptanceSupport = {
    creation: "optional-review-command",
    status:
      integrity === "verified" &&
      !stale &&
      effectiveAcceptance?.decision === "accepted" &&
      effectiveAcceptance.support === "supported"
        ? "supported"
        : "unavailable",
    reason:
      integrity !== "verified"
        ? "Project truth is degraded; acceptance cannot be supported."
        : stale
          ? "Project truth is stale; acceptance cannot be supported."
          : effectiveAcceptances.length > 1
            ? "Acceptance supersession is ambiguous; acceptance cannot be supported."
            : effectiveAcceptance?.decision === "rejected"
              ? "The current independently reverified human decision is rejected."
              : effectiveAcceptance?.support === "supported"
                ? "Stored acceptance and its exact evidence were independently reverified."
                : "No independently reverified human acceptance is recorded.",
    records: acceptances,
  };

  const selection =
    candidates.length === 0
      ? { status: "empty" }
      : candidates.length === 1
        ? {
            status: "selected",
            workflowId: candidates[0].workflowId,
            revision: candidates[0].revision,
            route: candidates[0].route,
          }
        : {
            status: "ambiguous",
            question: `Which journey do you mean: ${candidates
              .map((item) => `${item.name} — ${item.purpose}`)
              .join("; or ")}?`.slice(0, 500),
            candidateWorkflowIds: candidates.map((item) => item.workflowId),
          };

  return registry.validate("discoverySnapshot", {
    schema: "agent-workflow-discovery-snapshot/v2",
    generatedAt,
    freshness: { status: stale ? "stale" : "fresh", asOf, maxAgeSeconds },
    integrity: { status: integrity, issues: [...new Set(issues)].sort() },
    project: {
      ...(projectContext.project?.id ? { id: projectContext.project.id } : {}),
      ...(projectContext.project?.appName ? { name: text(projectContext.project.appName) } : {}),
    },
    applicationTargets,
    query: { terms: queryTerms, binding },
    inventory: { status: catalog.status, workflows: inventory },
    candidates,
    activity,
    findings,
    pendingAttention,
    reviewIntents,
    acceptanceSupport,
    lifecycle,
    ...(options.evaluationReadiness ? { evaluationReadiness: options.evaluationReadiness } : {}),
    selection,
  });
}
