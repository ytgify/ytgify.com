/* eslint-disable max-lines -- lifecycle mutation authority and its only command boundary stay colocated. */
import { randomUUID } from "node:crypto";
import { constants } from "node:fs";
import { link, lstat, mkdir, open, readdir, rename, rm, unlink, writeFile } from "node:fs/promises";
import { dirname, join, relative, resolve, sep } from "node:path";

import { readCliFixtureRecipe } from "./cli-training.js";
import { WorkflowError } from "./errors.js";
import { sha256Bytes } from "./evidence.js";
import {
  finalizeEvaluation,
  finalizeReplay,
  inspectEvaluationGroup,
  launchCandidateReplay,
  launchEvaluationGroup,
  launchPromotedReplay,
  promoteWorkflow,
  qualifyRevision,
} from "./lifecycle.js";
import { retirePendingApproval } from "./retire-pending-approval.js";
import { verifyCatalogWorkflowSource } from "./project-workflow-catalog.js";
import { RunControlStore } from "./run-control-store.js";
import { sha256 } from "./stable-json.js";

const WORKFLOW_ID = /^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$/;
const REVISION = /^v[1-9][0-9]*$/;
const RECORD_ID = /^[A-Za-z0-9_-]+$/;
const WRITE_AUTHORITY = Object.freeze({ boundary: "lifecycle-cli" });

function fail(code, message, details) {
  throw new WorkflowError(code, message, { exitCode: 3, details });
}

async function assertDirectory(path) {
  const entry = await lstat(path);
  if (!entry.isDirectory() || entry.isSymbolicLink())
    fail("LIFECYCLE_STORE_UNSAFE", "Lifecycle paths cannot be symlinks");
}

async function assertSafeAncestry(root, path) {
  const resolvedRoot = resolve(root);
  const resolvedPath = resolve(path);
  const suffix = relative(resolvedRoot, resolvedPath);
  if (suffix.startsWith("..") || resolve(resolvedRoot, suffix) !== resolvedPath)
    fail("PATH_TRAVERSAL", "Lifecycle path escapes its root");
  let cursor = resolvedRoot;
  await assertDirectory(cursor);
  for (const part of suffix.split(sep).filter(Boolean)) {
    cursor = join(cursor, part);
    try {
      const entry = await lstat(cursor);
      if (entry.isSymbolicLink()) fail("LIFECYCLE_STORE_UNSAFE", "Lifecycle path ancestry cannot contain symlinks");
      if (cursor !== resolvedPath && !entry.isDirectory())
        fail("LIFECYCLE_STORE_UNSAFE", "Lifecycle path ancestry must contain only directories");
    } catch (error) {
      if (error.code === "ENOENT") break;
      throw error;
    }
  }
}

async function pathExists(path) {
  try {
    await lstat(path);
    return true;
  } catch (error) {
    if (error.code === "ENOENT") return false;
    throw error;
  }
}

function requireAuthority(authority) {
  if (authority !== WRITE_AUTHORITY)
    fail(
      "LIFECYCLE_WRITE_FORBIDDEN",
      "Lifecycle records may only be committed by the provenance-verifying CLI boundary",
    );
}

function processAlive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch (error) {
    if (error.code === "ESRCH") return false;
    if (error.code === "EPERM") return true;
    throw error;
  }
}

async function acquireLock(path, trustedRoot) {
  for (;;) {
    await assertSafeAncestry(trustedRoot, path);
    try {
      const handle = await open(path, "wx", 0o600);
      await handle.writeFile(`${JSON.stringify({ pid: process.pid, token: randomUUID() })}\n`);
      await handle.sync();
      await syncDirectory(dirname(path));
      return handle;
    } catch (error) {
      if (error.code !== "EEXIST") throw error;
      const { bytes, stat } = await readRegular(path, "Lifecycle mutation lock", true);
      let owner;
      try {
        owner = JSON.parse(bytes);
      } catch {
        fail("LIFECYCLE_STORE_LOCK_CORRUPT", "Lifecycle mutation lock is invalid JSON");
      }
      if (!Number.isSafeInteger(owner?.pid) || owner.pid < 1 || typeof owner.token !== "string")
        fail("LIFECYCLE_STORE_LOCK_CORRUPT", "Lifecycle mutation lock identity is invalid");
      if (processAlive(owner.pid)) fail("LIFECYCLE_STORE_LOCKED", "Another lifecycle mutation is in progress");
      const current = await lstat(path).catch((caught) => {
        if (caught.code === "ENOENT") return null;
        throw caught;
      });
      if (current && current.dev === stat.dev && current.ino === stat.ino) {
        await unlink(path);
        await syncDirectory(dirname(path));
      }
    }
  }
}

async function withLock(path, trustedRoot, operation) {
  const handle = await acquireLock(path, trustedRoot);
  const identity = await handle.stat();
  try {
    return await operation();
  } finally {
    await handle.close();
    const current = await lstat(path).catch(() => null);
    if (current?.dev === identity.dev && current?.ino === identity.ino) {
      await unlink(path);
      await syncDirectory(dirname(path));
    }
  }
}

async function syncDirectory(path) {
  const handle = await open(path, "r");
  try {
    await handle.sync();
  } finally {
    await handle.close();
  }
}

async function readRegular(path, label, includeStat = false) {
  const parent = dirname(path);
  await assertDirectory(parent);
  const entry = await lstat(path);
  if (!entry.isFile() || entry.isSymbolicLink()) fail("LIFECYCLE_RECORD_CORRUPT", `${label} is not a regular file`);
  const handle = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    const opened = await handle.stat();
    if (opened.dev !== entry.dev || opened.ino !== entry.ino || opened.size !== entry.size) {
      fail("LIFECYCLE_RECORD_CORRUPT", `${label} changed while being read`);
    }
    const bytes = await handle.readFile();
    return includeStat ? { bytes, stat: opened } : bytes;
  } finally {
    await handle.close();
  }
}

async function safeRead(root, path, label) {
  await assertSafeAncestry(root, path);
  return readRegular(path, label);
}

async function immutableWrite(path, bytes) {
  await assertDirectory(dirname(path));
  const temporary = `${path}.${randomUUID()}.tmp`;
  const handle = await open(temporary, "wx", 0o600);
  try {
    await handle.writeFile(bytes);
    await handle.sync();
  } finally {
    await handle.close();
  }
  try {
    await link(temporary, path);
    await syncDirectory(dirname(path));
  } catch (error) {
    if (error.code === "EEXIST") {
      fail("IMMUTABLE_RECORD_EXISTS", "Lifecycle records cannot be replaced", { path });
    }
    throw error;
  } finally {
    await unlink(temporary).catch(() => {});
  }
}

async function safeImmutableWrite(root, path, bytes) {
  await assertSafeAncestry(root, path);
  return immutableWrite(path, bytes);
}

async function atomicJson(path, value) {
  const temporary = `${path}.${randomUUID()}.tmp`;
  const handle = await open(temporary, "wx", 0o600);
  try {
    await handle.writeFile(`${JSON.stringify(value, null, 2)}\n`);
    await handle.sync();
  } finally {
    await handle.close();
  }
  await rename(temporary, path);
  await syncDirectory(dirname(path));
}

async function safeAtomicJson(root, path, value) {
  await assertSafeAncestry(root, path);
  return atomicJson(path, value);
}

export class LifecycleStore {
  constructor(root, { registry, promotionInterruption } = {}) {
    this.root = resolve(root);
    this.lifecycleRoot = join(this.root, "lifecycle");
    this.workflowsRoot = join(this.lifecycleRoot, "workflows");
    this.replaysRoot = join(this.lifecycleRoot, "replays");
    this.qualificationsRoot = join(this.lifecycleRoot, "qualifications");
    this.groupsRoot = join(this.lifecycleRoot, "evaluation-groups");
    this.evaluationsRoot = join(this.lifecycleRoot, "evaluations");
    this.indexPath = join(this.lifecycleRoot, "index.json");
    this.transactionsRoot = join(this.lifecycleRoot, "transactions");
    this.promotionLockPath = join(this.lifecycleRoot, ".promotion.lock");
    this.registry = registry;
    this.promotionInterruption = promotionInterruption ?? this.testCrashInterruption();
  }

  testCrashInterruption() {
    const cut = process.env.NODE_ENV === "test" ? process.env.WORKFLOW_TEST_PROMOTION_CRASH_AT : null;
    if (!cut) return undefined;
    return async (name) => {
      if (name === cut) process.kill(process.pid, "SIGKILL");
    };
  }

  async init() {
    await mkdir(this.root, { recursive: true });
    await assertDirectory(this.root);
    for (const path of [
      this.lifecycleRoot,
      this.workflowsRoot,
      this.replaysRoot,
      this.qualificationsRoot,
      this.groupsRoot,
      this.evaluationsRoot,
      this.transactionsRoot,
    ]) {
      await mkdir(path, { recursive: true });
      await assertDirectory(path);
    }
    try {
      await writeFile(this.indexPath, "{}\n", { flag: "wx" });
    } catch (error) {
      if (error.code !== "EEXIST") throw error;
    }
    await this.recoverPromotions();
    return this;
  }

  async promotionCutPoint(name, context) {
    await this.promotionInterruption?.(name, context);
  }

  async recoverPromotions() {
    await assertSafeAncestry(this.lifecycleRoot, this.transactionsRoot);
    const names = (await readdir(this.transactionsRoot)).filter((name) => name.endsWith(".json")).sort();
    if (!names.length && !(await pathExists(this.promotionLockPath))) return;
    await withLock(this.promotionLockPath, this.lifecycleRoot, async () => {
      for (const name of names) {
        const path = join(this.transactionsRoot, name);
        let transaction;
        try {
          transaction = JSON.parse(await safeRead(this.lifecycleRoot, path, "Promotion transaction"));
        } catch (error) {
          if (error instanceof SyntaxError)
            fail("LIFECYCLE_TRANSACTION_CORRUPT", "Promotion transaction is invalid JSON");
          throw error;
        }
        const { workflowId, revision, stageName } = transaction;
        if (!WORKFLOW_ID.test(workflowId) || !REVISION.test(revision) || !RECORD_ID.test(stageName))
          fail("LIFECYCLE_TRANSACTION_CORRUPT", "Promotion transaction identity is invalid");
        const stage = join(this.transactionsRoot, stageName);
        const destination = this.workflowDirectory(workflowId, revision);
        await assertSafeAncestry(this.lifecycleRoot, stage);
        await assertSafeAncestry(this.lifecycleRoot, destination);
        let stageExists = true;
        let destinationExists = true;
        try {
          await lstat(stage);
        } catch (error) {
          if (error.code === "ENOENT") stageExists = false;
          else throw error;
        }
        try {
          await lstat(destination);
        } catch (error) {
          if (error.code === "ENOENT") destinationExists = false;
          else throw error;
        }
        if (stageExists && destinationExists)
          fail("LIFECYCLE_TRANSACTION_CORRUPT", "Promotion exists in both staged and published locations");
        if (!stageExists && !destinationExists) {
          await unlink(path);
          continue;
        }
        if (stageExists) {
          try {
            const snapshotBytes = await safeRead(
              this.lifecycleRoot,
              join(stage, "workflow.yaml"),
              "Staged workflow snapshot",
            );
            const record = this.validate(
              JSON.parse(await safeRead(this.lifecycleRoot, join(stage, "promotion.json"), "Staged promotion")),
            );
            if (
              record.workflowId !== workflowId ||
              record.revision !== revision ||
              record.snapshotHash !== transaction.snapshotHash ||
              record.snapshotHash !== sha256Bytes(snapshotBytes)
            )
              fail("LIFECYCLE_TRANSACTION_CORRUPT", "Staged promotion does not match its transaction");
          } catch {
            await rm(stage, { recursive: true });
            await unlink(path);
            await syncDirectory(this.transactionsRoot);
            continue;
          }
        }
        await mkdir(join(this.workflowsRoot, workflowId), { recursive: false }).catch((error) => {
          if (error.code !== "EEXIST") throw error;
        });
        await assertSafeAncestry(this.workflowsRoot, join(this.workflowsRoot, workflowId));
        if (stageExists) {
          await rename(stage, destination);
          await syncDirectory(dirname(destination));
        }
        const promoted = await this.readPromotion(workflowId, revision);
        if (promoted.record.snapshotHash !== transaction.snapshotHash)
          fail("LIFECYCLE_TRANSACTION_CORRUPT", "Recovered promotion hash does not match its transaction");
        const index = await this.readIndex();
        index[workflowId] ??= { revisions: [] };
        const revisions = index[workflowId].revisions;
        if (!revisions.includes(revision)) {
          const expected = `v${revisions.length + 1}`;
          if (revision !== expected) fail("LIFECYCLE_TRANSACTION_CORRUPT", `Recovered promotion must be ${expected}`);
          revisions.push(revision);
          await safeAtomicJson(this.lifecycleRoot, this.indexPath, index);
        }
        await unlink(path);
        await syncDirectory(this.transactionsRoot);
      }
    });
  }

  validate(record) {
    this.registry?.validate("lifecycle", record);
    return record;
  }

  workflowDirectory(workflowId, revision) {
    if (!WORKFLOW_ID.test(workflowId) || !REVISION.test(revision))
      fail("INVALID_LIFECYCLE_ID", "Invalid workflow revision identity");
    const path = resolve(this.workflowsRoot, workflowId, revision);
    if (!path.startsWith(`${this.workflowsRoot}${sep}`)) fail("PATH_TRAVERSAL", "Lifecycle path escapes its root");
    return path;
  }

  async readIndex() {
    const bytes = await safeRead(this.lifecycleRoot, this.indexPath, "Lifecycle index");
    let index;
    try {
      index = JSON.parse(bytes);
    } catch {
      fail("LIFECYCLE_INDEX_CORRUPT", "Lifecycle index is invalid JSON");
    }
    if (!index || Array.isArray(index) || typeof index !== "object")
      fail("LIFECYCLE_INDEX_CORRUPT", "Lifecycle index is invalid");
    return index;
  }

  async nextRevision(workflowId) {
    if (!WORKFLOW_ID.test(workflowId)) fail("INVALID_LIFECYCLE_ID", "Invalid workflow ID");
    const revisions = (await this.readIndex())[workflowId]?.revisions ?? [];
    return `v${revisions.length + 1}`;
  }

  async writePromotion(record, snapshotBytes, authority) {
    requireAuthority(authority);
    this.validate(record);
    if (record.snapshotHash !== sha256Bytes(snapshotBytes))
      fail("SNAPSHOT_HASH_MISMATCH", "Promoted snapshot bytes changed");
    return withLock(this.promotionLockPath, this.lifecycleRoot, async () => {
      const directory = this.workflowDirectory(record.workflowId, record.revision);
      const index = await this.readIndex();
      const expected = `v${(index[record.workflowId]?.revisions?.length ?? 0) + 1}`;
      if (record.revision !== expected) fail("REVISION_NOT_MONOTONIC", `Next promotion must be ${expected}`);
      const workflowRoot = join(this.workflowsRoot, record.workflowId);
      await assertSafeAncestry(this.workflowsRoot, workflowRoot);
      await mkdir(workflowRoot).catch((error) => {
        if (error.code !== "EEXIST") throw error;
      });
      await assertSafeAncestry(this.workflowsRoot, workflowRoot);
      const stageName = `promotion_${randomUUID().replaceAll("-", "")}`;
      const stage = join(this.transactionsRoot, stageName);
      const transactionPath = join(this.transactionsRoot, `${stageName}.json`);
      await safeAtomicJson(this.lifecycleRoot, transactionPath, {
        schema: "agent-workflow-promotion-transaction/v1",
        workflowId: record.workflowId,
        revision: record.revision,
        snapshotHash: record.snapshotHash,
        stageName,
      });
      await this.promotionCutPoint("journaled", { transactionPath, stage, directory });
      await mkdir(stage);
      await safeImmutableWrite(this.lifecycleRoot, join(stage, "workflow.yaml"), snapshotBytes);
      await this.promotionCutPoint("partial-stage", { transactionPath, stage, directory });
      await safeImmutableWrite(
        this.lifecycleRoot,
        join(stage, "promotion.json"),
        Buffer.from(`${JSON.stringify(record, null, 2)}\n`),
      );
      await syncDirectory(stage);
      await this.promotionCutPoint("staged", { transactionPath, stage, directory });
      await rename(stage, directory).catch((error) => {
        if (error.code === "EEXIST") fail("IMMUTABLE_RECORD_EXISTS", "Promoted revision already exists");
        throw error;
      });
      await syncDirectory(workflowRoot);
      await this.promotionCutPoint("published", { transactionPath, stage, directory });
      index[record.workflowId] ??= { revisions: [] };
      index[record.workflowId].revisions.push(record.revision);
      await safeAtomicJson(this.lifecycleRoot, this.indexPath, index);
      await this.promotionCutPoint("indexed", { transactionPath, stage, directory });
      await unlink(transactionPath);
      await syncDirectory(this.transactionsRoot);
      return structuredClone(record);
    });
  }

  async readPromotion(workflowId, revision) {
    const directory = this.workflowDirectory(workflowId, revision);
    await assertSafeAncestry(this.workflowsRoot, directory);
    const snapshotBytes = await safeRead(
      this.lifecycleRoot,
      join(directory, "workflow.yaml"),
      "Promoted workflow snapshot",
    );
    const record = this.validate(
      JSON.parse(await safeRead(this.lifecycleRoot, join(directory, "promotion.json"), "Promotion record")),
    );
    if (
      record.workflowId !== workflowId ||
      record.revision !== revision ||
      record.snapshotHash !== sha256Bytes(snapshotBytes)
    ) {
      fail("LIFECYCLE_RECORD_CORRUPT", "Promotion provenance does not match immutable snapshot");
    }
    return { record, snapshotBytes };
  }

  async listVersions(workflowId) {
    const index = await this.readIndex();
    return Promise.all(
      (index[workflowId]?.revisions ?? []).map(
        async (revision) => (await this.readPromotion(workflowId, revision)).record,
      ),
    );
  }

  recordPath(root, id) {
    if (!RECORD_ID.test(id)) fail("INVALID_LIFECYCLE_ID", "Invalid lifecycle record ID");
    const path = resolve(root, `${id}.json`);
    if (!path.startsWith(`${root}${sep}`)) fail("PATH_TRAVERSAL", "Lifecycle record escapes its root");
    return path;
  }

  async writeRecord(kind, id, record, authority) {
    requireAuthority(authority);
    const roots = {
      replay: this.replaysRoot,
      qualification: this.qualificationsRoot,
      group: this.groupsRoot,
      evaluation: this.evaluationsRoot,
    };
    const root = roots[kind];
    if (!root) fail("INVALID_LIFECYCLE_KIND", `Unknown lifecycle record kind: ${kind}`);
    this.validate(record);
    const boundId =
      kind === "replay" || kind === "evaluation"
        ? record.runId
        : kind === "qualification"
          ? record.qualificationId
          : record.groupId;
    if (boundId !== id) fail("LIFECYCLE_ID_MISMATCH", "Lifecycle filename does not match record identity");
    await safeImmutableWrite(
      this.lifecycleRoot,
      this.recordPath(root, id),
      Buffer.from(`${JSON.stringify(record, null, 2)}\n`),
    );
    return structuredClone(record);
  }

  async readRecord(kind, id) {
    const roots = {
      replay: this.replaysRoot,
      qualification: this.qualificationsRoot,
      group: this.groupsRoot,
      evaluation: this.evaluationsRoot,
    };
    const root = roots[kind];
    if (!root) fail("INVALID_LIFECYCLE_KIND", `Unknown lifecycle record kind: ${kind}`);
    const record = this.validate(
      JSON.parse(await safeRead(this.lifecycleRoot, this.recordPath(root, id), "Lifecycle record")),
    );
    const boundId =
      kind === "replay" || kind === "evaluation"
        ? record.runId
        : kind === "qualification"
          ? record.qualificationId
          : record.groupId;
    if (boundId !== id) fail("LIFECYCLE_ID_MISMATCH", "Lifecycle filename does not match record identity");
    return record;
  }

  async listRecords(kind) {
    return Promise.all((await this.listRecordIds(kind)).map((id) => this.readRecord(kind, id)));
  }

  async listRecordIds(kind) {
    const roots = {
      replay: this.replaysRoot,
      qualification: this.qualificationsRoot,
      group: this.groupsRoot,
      evaluation: this.evaluationsRoot,
    };
    const root = roots[kind];
    if (!root) fail("INVALID_LIFECYCLE_KIND", `Unknown lifecycle record kind: ${kind}`);
    await assertSafeAncestry(this.lifecycleRoot, root);
    const names = await readdir(root);
    return names
      .filter((name) => /^[A-Za-z0-9_-]+\.json$/.test(name))
      .sort()
      .map((name) => name.slice(0, -5));
  }

  hash(record) {
    return sha256(record);
  }
}

function invalidUsage(message) {
  throw new WorkflowError("INVALID_USAGE", message, { exitCode: 2 });
}

/** Compatibility entry point for old callers with a pending launch. */
export async function approveExistingLifecycleRun({ runId, runStore, now = () => new Date(), verifySource }) {
  await verifySource?.();
  return retirePendingApproval({ store: runStore, runId, now });
}

export async function executeLifecycleOperation({
  command,
  args,
  flags,
  registry,
  workflowSource,
  applicationTarget,
  projectContext,
  authSessionStore,
  storeRoot,
}) {
  if (workflowSource) await verifyCatalogWorkflowSource(workflowSource);
  const root = resolve(storeRoot ?? flags.get("store") ?? ".workflows/local");
  const runStore = await new RunControlStore(root, { registry }).init();
  const lifecycleStore = await new LifecycleStore(root, { registry }).init();
  const [operation, first, second] = args;
  if (command === "replay") {
    if (operation === "candidate" && (workflowSource ? !first && !second : first) && flags.get("platform")) {
      if (flags.has("approve")) invalidUsage("replay approval cannot be supplied by flag");
      const data = await launchCandidateReplay({
        ...(workflowSource ? { workflowSource } : { workflowPath: first }),
        platform: flags.get("platform"),
        profile: flags.get("profile"),
        runStore,
        registry,
        applicationTarget,
        targetUrl: flags.get("target-url"),
        projectContext,
        authSessionStore,
        fixtureRecipe: await readCliFixtureRecipe(flags, registry),
        fixtureProjectRoot: projectContext?.projectRoot ?? resolve(flags.get("root") ?? "."),
      });
      return {
        command: "replay candidate",
        data,
      };
    }
    if (operation === "promoted" && first && second && flags.get("platform")) {
      if (flags.has("approve")) invalidUsage("replay approval cannot be supplied by flag");
      const data = await launchPromotedReplay({
        workflowId: first,
        revision: second,
        platform: flags.get("platform"),
        profile: flags.get("profile"),
        lifecycleStore,
        runStore,
        registry,
        applicationTarget,
        targetUrl: flags.get("target-url"),
        projectContext,
        authSessionStore,
        fixtureRecipe: await readCliFixtureRecipe(flags, registry),
        fixtureProjectRoot: projectContext?.projectRoot ?? resolve(flags.get("root") ?? "."),
      });
      return {
        command: "replay promoted",
        data,
      };
    }
    if (operation === "finalize" && first && !second) {
      return {
        command: "replay finalize",
        data: { receipt: await finalizeReplay({ runId: first, lifecycleStore, runStore, authority: WRITE_AUTHORITY }) },
      };
    }
    invalidUsage("replay requires candidate PATH, promoted ID REV, or finalize RUN_ID");
  }
  if (command === "promote") {
    if (
      (!workflowSource && !operation) ||
      (workflowSource && operation) ||
      !flags.get("replay") ||
      flags.has("confirm")
    ) {
      invalidUsage("promote requires PATH --replay RUN_ID; verified evidence is required");
    }
    return {
      command: "promote",
      data: {
        promotion: await promoteWorkflow({
          ...(workflowSource ? { workflowSource } : { workflowPath: operation }),
          replayRunId: flags.get("replay"),
          lifecycleStore,
          runStore,
          registry,
          authority: WRITE_AUTHORITY,
        }),
      },
    };
  }
  if (command === "qualify") {
    if (!operation || !first || !flags.get("replay") || flags.has("confirm")) {
      invalidUsage("qualify requires ID REV --replay RUN_ID; verified evidence is required");
    }
    return {
      command: "qualify",
      data: {
        qualification: await qualifyRevision({
          workflowId: operation,
          revision: first,
          replayRunId: flags.get("replay"),
          lifecycleStore,
          runStore,
          authority: WRITE_AUTHORITY,
        }),
      },
    };
  }
  if (command === "evaluate") {
    if (
      operation === "launch" &&
      first &&
      second &&
      flags.get("desktop-qualification") &&
      flags.get("mobile-qualification")
    ) {
      if (flags.has("approve")) invalidUsage("evaluation approvals cannot be supplied by flag");
      return {
        command: "evaluate launch",
        data: await launchEvaluationGroup({
          workflowId: first,
          revision: second,
          qualifications: {
            "desktop-web": flags.get("desktop-qualification"),
            "mobile-web": flags.get("mobile-qualification"),
          },
          authority: WRITE_AUTHORITY,
          lifecycleStore,
          runStore,
          registry,
          applicationTarget,
          targetUrl: flags.get("target-url"),
          projectContext,
          authSessionStore,
          fixtureRecipe: await readCliFixtureRecipe(flags, registry),
          fixtureProjectRoot: projectContext?.projectRoot ?? resolve(flags.get("root") ?? "."),
        }),
      };
    }
    if (operation === "finalize" && first && second) {
      return {
        command: "evaluate finalize",
        data: {
          receipt: await finalizeEvaluation({
            groupId: first,
            runId: second,
            lifecycleStore,
            runStore,
            authority: WRITE_AUTHORITY,
          }),
        },
      };
    }
    if (operation === "inspect" && first && !second) {
      return {
        command: "evaluate inspect",
        data: { group: await inspectEvaluationGroup({ groupId: first, lifecycleStore, runStore }) },
      };
    }
    invalidUsage("evaluate requires launch ID REV, finalize GROUP RUN, or inspect GROUP");
  }
  if (command === "versions" && operation && args.length === 1) {
    return { command: "versions", data: { versions: await lifecycleStore.listVersions(operation) } };
  }
  invalidUsage("versions requires WORKFLOW_ID");
}
