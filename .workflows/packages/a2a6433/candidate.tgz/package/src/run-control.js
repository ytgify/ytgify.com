import { assertLocalDogfoodManifest, localDogfoodBatch } from "./local-dogfood.js";
/* eslint-disable max-lines -- reducer safety invariants stay centralized at the replay trust boundary. */
import { WorkflowError } from "./errors.js";
import { matchesExplorationFile } from "./exploration-fixtures.js";
import { matchesRepositoryFixtureUpload } from "./fixture-lifecycle.js";
import {
  assertLeasePolicySnapshot,
  deriveHeartbeatExpiry,
  deriveLeaseTimes,
  leasePolicyForManifest,
  leasePolicyHash,
} from "./lease-policy.js";
import { sha256 } from "./stable-json.js";
import { resolveFixtureRouteBinding } from "./run-route-binding.js";
import { assertPinnedFixtureContract } from "./fixture-lifecycle.js";

const TERMINAL_STATUSES = new Set(["completed", "blocked", "failed", "abandoned"]);

function transitionError(message, details = {}) {
  return new WorkflowError("ILLEGAL_TRANSITION", message, {
    exitCode: 4,
    details,
  });
}

function assertStatus(state, allowed, event) {
  if (!allowed.includes(state.status)) {
    throw transitionError(`Cannot apply ${event.type} while run is ${state.status}`, {
      allowed,
      sequence: event.sequence,
    });
  }
}

function assertSource(event, allowed) {
  if (!allowed.includes(event.source)) {
    throw transitionError(`${event.source} cannot emit ${event.type}`, { allowed });
  }
}

function assertOwner(state, hostId) {
  if (!state.ownerHostId || state.ownerHostId !== hostId) {
    throw transitionError("Event host does not own the run", {
      ownerHostId: state.ownerHostId,
      eventHostId: hostId,
    });
  }
}

function assertNoActiveLease(state) {
  if (state.activeLease) {
    throw transitionError("An action lease is still active", {
      leaseId: state.activeLease.leaseId,
    });
  }
}

function assertEventBeforeLeaseExpiry(state, event) {
  if (!state.activeLease || new Date(event.occurredAt).valueOf() >= new Date(state.activeLease.expiresAt).valueOf()) {
    throw transitionError(`${event.type} occurred at or after the active lease expiry`);
  }
}

function initialTraversal(workflow) {
  if (!workflow) return null;
  return {
    activeStepId: null,
    steps: Object.fromEntries(workflow.steps.map((step) => [step.id, { outcome: "pending", attempts: 0 }])),
    artifacts: {},
    journeyOutcome: null,
  };
}

function initialAuthentication(manifest) {
  if (!manifest.authentication) {
    return {
      required: false,
      status: "not-required",
      targetId: null,
      markerHash: null,
      lastVerifiedAt: null,
    };
  }
  return {
    required: true,
    status: "required",
    targetId: manifest.authentication.targetId,
    markerHash: manifest.authentication.markerHash,
    lastVerifiedAt: null,
  };
}

function nextRunnableStep(workflow, traversal) {
  return workflow.steps.find((step) => {
    if (traversal.steps[step.id].outcome !== "pending") return false;
    return (step.dependsOn ?? []).every((dependency) =>
      ["passed", "passed_with_deviation"].includes(traversal.steps[dependency].outcome),
    );
  });
}

function deriveJourneyOutcome(traversal) {
  const outcomes = Object.values(traversal.steps).map((step) => step.outcome);
  if (outcomes.includes("failed")) return "failed";
  if (outcomes.includes("blocked") || outcomes.includes("pending")) return "blocked";
  if (outcomes.includes("passed_with_deviation")) return "passed_with_deviation";
  return "passed";
}

function routineActionBatch(workflow, stepId, proposal) {
  if (
    proposal.actions.some(
      (action) => action.inputRef && !(action.kind === "upload-file" && action.inputRef.kind === "synthetic-file"),
    )
  )
    return null;
  const step = workflow.steps.find((item) => item.id === stepId);
  const proposed = { actions: proposal.actions, requestedCapabilities: proposal.requestedCapabilities };
  return (step?.routineActionBatches ?? []).find(
    (batch) =>
      sha256({ actions: batch.actions, requestedCapabilities: batch.requestedCapabilities }) === sha256(proposed),
  );
}

export function createRunControlState(manifest, workflow = null) {
  assertLocalDogfoodManifest(manifest);
  assertPinnedFixtureContract(manifest, workflow);
  const leasePolicy = leasePolicyForManifest(manifest);
  if (manifest.leasePolicy && manifest.policyHash !== leasePolicyHash(leasePolicy)) {
    throw transitionError("Manifest policy hash does not pin its lease policy");
  }
  return {
    manifest: structuredClone(manifest),
    runId: manifest.runId,
    phase: manifest.phase,
    status: "unstarted",
    sequence: 0,
    revision: 0,
    ownerHostId: null,
    capabilities: {},
    routeBindings: {},
    capabilityGaps: [],
    evidenceSlots: {},
    activeLease: null,
    activeLeaseRequestId: null,
    activeOptionalAuthorization: null,
    optionalApplications: {},
    uncertainLeaseId: null,
    handoffFromHostId: null,
    pendingApproval: null,
    approvedSafetyBoundary: null,
    approvalReturnStatus: null,
    pauseRequested: false,
    preflightOutcome: null,
    cleanupOutcome: null,
    terminalOutcome: null,
    authentication: initialAuthentication(manifest),
    traversal: initialTraversal(workflow),
    exploration:
      manifest.phase === "exploration"
        ? {
            actionsUsed: 0,
            capturesUsed: 0,
            branchesUsed: 0,
            artifacts: {},
            visits: [],
            gaps: [],
            finish: null,
          }
        : null,
    workflow: workflow ? structuredClone(workflow) : null,
  };
}

export function reduceRunControlEvent(previousState, event) {
  const state = structuredClone(previousState);
  if (TERMINAL_STATUSES.has(state.status)) {
    throw transitionError(`Run is already terminal: ${state.status}`);
  }
  if (event.runId !== state.runId) {
    throw transitionError("Event run ID changed", {
      expected: state.runId,
      actual: event.runId,
    });
  }
  if (event.sequence !== state.sequence + 1) {
    throw transitionError("Event sequence is not contiguous", {
      expected: state.sequence + 1,
      actual: event.sequence,
    });
  }

  const expectedRevision = event.type === "run.created" ? 0 : state.revision + 1;
  if (event.revision !== expectedRevision) {
    throw transitionError("Event revision is not the next expected value", {
      expected: expectedRevision,
      actual: event.revision,
    });
  }
  if (state.approvedSafetyBoundary && event.type !== "action.leased") {
    state.approvedSafetyBoundary = null;
  }
  if (state.activeOptionalAuthorization && !["optional-state.applied", "lease.expired"].includes(event.type)) {
    throw transitionError("Only the immediately adjacent optional-state application may consume its authority");
  }
  if (
    state.authentication.status === "verifying" &&
    !["authentication.verification_started", "authentication.verified", "authentication.required"].includes(event.type)
  ) {
    throw transitionError("Authentication verification outcome must be immediately adjacent");
  }

  switch (event.type) {
    case "run.created":
      assertSource(event, ["runner"]);
      assertStatus(state, ["unstarted"], event);
      state.status = "preparing";
      break;

    case "approval.retired":
      assertSource(event, ["runner"]);
      assertStatus(state, ["awaiting-approval"], event);
      assertNoActiveLease(state);
      state.status = state.approvalReturnStatus;
      state.pendingApproval = null;
      state.approvalReturnStatus = null;
      state.approvedSafetyBoundary = null;
      break;

    case "approval.requested":
      assertSource(event, ["runner"]);
      assertStatus(state, ["preparing", "active", "paused"], event);
      if (state.pendingApproval) throw transitionError("An approval is already pending");
      assertNoActiveLease(state);
      if (state.manifest.leasePolicy?.name === "routine-codex-browser-v1") {
        const binding = event.payload.binding;
        if (
          event.payload.kind !== "safety-boundary" ||
          !binding ||
          binding.runId !== state.runId ||
          binding.preApprovalRevision !== state.revision
        ) {
          throw transitionError("Routine safety approval is not bound to the exact pre-approval run revision");
        }
      }
      state.approvalReturnStatus = state.status;
      state.status = "awaiting-approval";
      state.pendingApproval = structuredClone(event.payload);
      break;

    case "approval.recorded": {
      assertSource(
        event,
        state.manifest.localDogfood ||
          (event.payload.kind === "launch" && state.manifest.leasePolicy?.name === "authorized-codex-browser-v1")
          ? ["runner"]
          : event.payload.kind === "launch"
            ? ["runner", "human"]
            : ["human"],
      );
      if (state.manifest.localDogfood && (event.payload.kind !== "launch" || event.payload.decision !== "allow-once")) {
        throw transitionError("Local synthetic policy only authorizes its initial training launch");
      }
      assertStatus(state, ["awaiting-approval"], event);
      if (event.payload.kind !== state.pendingApproval?.kind) {
        throw transitionError("Approval kind does not match the pending boundary");
      }
      if (state.manifest.leasePolicy?.name === "routine-codex-browser-v1") {
        if (
          event.payload.decision === "allow-rule" ||
          JSON.stringify(event.payload.binding) !== JSON.stringify(state.pendingApproval?.binding)
        ) {
          throw transitionError("Routine safety decision does not match its exact one-use boundary");
        }
      }
      const denied = event.payload.decision === "deny";
      state.status = denied && event.payload.kind === "launch" ? "abandoned" : state.approvalReturnStatus;
      state.pendingApproval = null;
      state.approvalReturnStatus = null;
      if (!denied && event.payload.kind === "safety-boundary") {
        state.approvedSafetyBoundary = {
          ...structuredClone(event.payload.binding),
          approvalRevision: event.revision,
        };
      }
      if (state.status === "abandoned") state.terminalOutcome = "abandoned";
      break;
    }

    case "preflight.started":
      assertSource(event, ["runner"]);
      assertStatus(state, ["preparing"], event);
      state.status = "preflight";
      break;

    case "preflight.completed":
      assertSource(event, ["runner"]);
      assertStatus(state, ["preflight"], event);
      state.preflightOutcome = event.payload.outcome;
      state.capabilityGaps = structuredClone(event.payload.missingCapabilities ?? []);
      state.status =
        event.payload.outcome === "passed"
          ? state.authentication.required
            ? "awaiting-authentication"
            : "active"
          : "cleanup";
      break;

    case "authentication.verification_started":
      assertSource(event, ["runner"]);
      assertStatus(state, ["awaiting-authentication", "active"], event);
      assertNoActiveLease(state);
      if (
        !state.authentication.required ||
        event.payload.targetId !== state.authentication.targetId ||
        event.payload.markerHash !== state.authentication.markerHash
      ) {
        throw transitionError("Authentication verification does not match the pinned target marker");
      }
      state.authentication.status = "verifying";
      state.status = "awaiting-authentication";
      break;

    case "authentication.verified":
      assertSource(event, ["runner"]);
      assertStatus(state, ["awaiting-authentication"], event);
      if (
        state.authentication.status !== "verifying" ||
        event.payload.targetId !== state.authentication.targetId ||
        event.payload.markerHash !== state.authentication.markerHash
      ) {
        throw transitionError("Authentication verification does not match the pinned target marker");
      }
      state.authentication.status = "verified";
      state.authentication.lastVerifiedAt = event.payload.verifiedAt;
      state.status = "active";
      break;

    case "authentication.required":
      assertSource(event, ["runner"]);
      assertStatus(state, ["awaiting-authentication", "active", "paused"], event);
      assertNoActiveLease(state);
      if (
        !state.authentication.required ||
        state.uncertainLeaseId ||
        event.payload.targetId !== state.authentication.targetId
      ) {
        throw transitionError("Authentication requirement does not match the pinned target");
      }
      state.authentication.status = "required";
      state.status = "awaiting-authentication";
      break;

    case "host.claimed": {
      assertSource(event, ["agent-host", "human"]);
      assertStatus(
        state,
        ["preparing", "awaiting-approval", "preflight", "awaiting-authentication", "active", "paused", "reconciling"],
        event,
      );
      const { hostId, previousHostId, reconciliationRequired } = event.payload;
      if (state.ownerHostId && state.ownerHostId !== hostId) {
        if (previousHostId !== state.ownerHostId) {
          throw transitionError("Host handoff does not name the current owner");
        }
        if (!reconciliationRequired) {
          throw transitionError("A host handoff must require reconciliation");
        }
      }
      if (reconciliationRequired && !previousHostId && !state.activeLease) {
        throw transitionError("Reconciliation requires a prior host or uncertain lease");
      }
      state.ownerHostId = hostId;
      if (reconciliationRequired) {
        state.handoffFromHostId = previousHostId ?? null;
        if (state.activeLease) {
          state.uncertainLeaseId = state.activeLease.leaseId;
          state.activeLease = null;
          state.activeLeaseRequestId = null;
        }
        state.status = "reconciling";
      }
      break;
    }

    case "host.released":
      assertSource(event, ["agent-host"]);
      assertOwner(state, event.payload.hostId);
      assertNoActiveLease(state);
      state.ownerHostId = null;
      if (state.status === "active") state.status = "paused";
      break;

    case "capabilities.registered":
      assertSource(event, ["agent-host"]);
      assertOwner(state, event.payload.hostId);
      if (new Set(event.payload.capabilities.map((item) => item.id)).size !== event.payload.capabilities.length) {
        throw transitionError("Capability IDs must be unique within a registration");
      }
      state.capabilities = Object.fromEntries(
        event.payload.capabilities.map((capability) => [capability.id, structuredClone(capability)]),
      );
      break;

    case "route.bound": {
      assertSource(event, ["agent-host"]);
      assertStatus(state, ["active"], event);
      assertOwner(state, event.payload.hostId);
      assertNoActiveLease(state);
      if (state.routeBindings[event.payload.bindingId]) {
        throw transitionError("Route binding ID is already present", { bindingId: event.payload.bindingId });
      }
      const resolved = resolveFixtureRouteBinding(state.workflow, {
        ...event.payload,
        target: `run-route:binding_${event.payload.routeId}`,
      });
      state.routeBindings[event.payload.bindingId] = {
        bindingId: event.payload.bindingId,
        routeId: resolved.routeId,
        path: resolved.path,
        readiness: structuredClone(resolved.readiness),
      };
      break;
    }

    case "action.leased": {
      assertSource(event, ["runner"]);
      assertStatus(state, ["active"], event);
      assertNoActiveLease(state);
      if (state.authentication.required && state.authentication.status !== "verified") {
        throw transitionError("Authentication must be freshly verified before an action lease");
      }
      const { lease } = event.payload;
      if (
        !state.exploration &&
        !state.manifest.authentication &&
        lease.proposal.actions.some((action) => action.kind === "upload-file") &&
        !matchesRepositoryFixtureUpload(state.manifest, lease.proposal)
      )
        throw transitionError("Anonymous file upload must match its pinned local fixture");
      if (state.exploration) {
        const elapsed = new Date(event.occurredAt).valueOf() - new Date(state.manifest.createdAt).valueOf();
        const action = lease.proposal.actions[0];
        const fixtureUpload = matchesExplorationFile(state.manifest, action, lease.proposal.requestedCapabilities);
        let navigationAllowed = true;
        if (action?.kind === "navigate") {
          navigationAllowed = false;
          if (action.target) {
            try {
              const destination = new URL(action.target, state.manifest.target.canonicalUrl);
              navigationAllowed =
                destination.origin === new URL(state.manifest.target.canonicalUrl).origin &&
                !destination.username &&
                !destination.password &&
                !destination.hash;
            } catch {
              navigationAllowed = false;
            }
          }
        }
        if (
          elapsed < 0 ||
          elapsed >= state.manifest.exploration.limits.minutes * 60_000 ||
          state.exploration.actionsUsed >= state.manifest.exploration.limits.actions ||
          state.exploration.capturesUsed >= state.manifest.exploration.limits.captures ||
          (event.payload.branchAttempt &&
            state.exploration.branchesUsed >= state.manifest.exploration.limits.branches) ||
          lease.proposal.actions.length !== 1 ||
          !navigationAllowed ||
          (!fixtureUpload &&
            !["observe", "activate-control", "enter-text", "navigate", "scroll", "wait", "capture-evidence"].includes(
              action.kind,
            )) ||
          !["observation-only", "reversible-ui"].includes(lease.proposal.risk.category) ||
          (fixtureUpload && lease.proposal.risk.category !== "reversible-ui") ||
          lease.proposal.risk.externallyVisible ||
          lease.proposal.risk.destructive ||
          (action.inputRef && !fixtureUpload) ||
          !lease.proposal.requestedCapabilities.includes("browser.control") ||
          lease.proposal.requestedCapabilities.some(
            (item) => !["browser.control", "screenshot", ...(fixtureUpload ? ["file-upload"] : [])].includes(item),
          )
        ) {
          throw transitionError("Exploration action exceeds its pinned budget");
        }
        state.exploration.actionsUsed += 1;
        if (event.payload.branchAttempt) state.exploration.branchesUsed += 1;
      }
      if (
        state.manifest.localDogfood &&
        (!localDogfoodBatch(
          state.manifest,
          state.workflow.steps.find((step) => step.id === event.payload.stepId),
          lease.proposal,
        ) ||
          lease.policy.decision !== "allowed")
      ) {
        throw transitionError("Local synthetic lease must match its pinned browser action batch");
      }
      const leasePolicy = assertLeasePolicySnapshot(lease.leasePolicy, state.manifest);
      assertOwner(state, lease.hostId);
      if (lease.runId !== state.runId || lease.revision !== event.revision) {
        throw transitionError("Lease identity does not match the run event");
      }
      const expectedTimes = deriveLeaseTimes(lease.authorizedAt, leasePolicy);
      if (
        new Date(lease.expiresAt).valueOf() !== new Date(expectedTimes.expiresAt).valueOf() ||
        new Date(lease.hardExpiresAt).valueOf() !== new Date(expectedTimes.hardExpiresAt).valueOf()
      ) {
        throw transitionError("Lease timestamps are not derived from the pinned policy");
      }
      if (state.traversal) {
        const next = nextRunnableStep(state.workflow, state.traversal);
        if (!next || next.id !== event.payload.stepId) {
          throw transitionError("Lease does not target the next legal workflow step", {
            expected: next?.id ?? null,
            actual: event.payload.stepId,
          });
        }
        state.traversal.activeStepId = next.id;
        state.traversal.steps[next.id].attempts += 1;
      }
      if (lease.extensions?.["routine.action"]) {
        const routineAction = routineActionBatch(state.workflow, event.payload.stepId, lease.proposal);
        if (!routineAction || lease.extensions["routine.action"].id !== routineAction.id)
          throw transitionError("Lease does not match its declared pinned action batch");
      }
      if (leasePolicy.name === "routine-codex-browser-v1" && lease.policy.decision === "human-approved") {
        const binding = state.approvedSafetyBoundary;
        if (
          !binding ||
          binding.runId !== state.runId ||
          binding.requestId !== event.transaction?.requestId ||
          binding.proposalHash !== sha256(lease.proposal) ||
          binding.stepId !== event.payload.stepId ||
          binding.approvalRevision !== event.revision - 1
        )
          throw transitionError("Historical sensitive lease is not adjacent to its recorded decision");
      }
      state.approvedSafetyBoundary = null;
      state.activeLease = structuredClone(lease);
      state.activeLeaseRequestId = event.transaction?.requestId ?? null;
      break;
    }

    case "action.rejected":
      assertSource(event, ["runner"]);
      assertStatus(state, ["active"], event);
      assertNoActiveLease(state);
      break;

    case "lease.heartbeat": {
      assertSource(event, ["agent-host"]);
      assertStatus(state, ["active"], event);
      if (!state.activeLease || state.activeLease.leaseId !== event.payload.leaseId) {
        throw transitionError("Heartbeat does not match the active lease");
      }
      assertEventBeforeLeaseExpiry(state, event);
      const leasePolicy = assertLeasePolicySnapshot(state.activeLease.leasePolicy, state.manifest);
      const expectedExpiry = deriveHeartbeatExpiry(event.occurredAt, state.activeLease.hardExpiresAt, leasePolicy);
      if (
        new Date(event.payload.expiresAt).valueOf() !== new Date(expectedExpiry).valueOf() ||
        new Date(event.payload.expiresAt).valueOf() < new Date(state.activeLease.expiresAt).valueOf()
      ) {
        throw transitionError("Heartbeat expiry is not the deterministic pinned-policy extension");
      }
      state.activeLease.expiresAt = event.payload.expiresAt;
      break;
    }

    case "lease.expired": {
      assertSource(event, ["runner"]);
      assertStatus(state, ["active"], event);
      const lease = state.activeLease;
      if (
        !lease ||
        lease.leaseId !== event.payload.leaseId ||
        lease.hostId !== event.payload.hostId ||
        event.payload.expiredAt !== lease.expiresAt
      ) {
        throw transitionError("Expired lease identity does not match the active lease");
      }
      if (new Date(event.occurredAt).valueOf() < new Date(lease.expiresAt).valueOf()) {
        throw transitionError("A lease cannot expire before its pinned expiry");
      }
      for (const [slotId, slot] of Object.entries(state.evidenceSlots)) {
        if (slot.leaseId === lease.leaseId) delete state.evidenceSlots[slotId];
      }
      state.uncertainLeaseId = lease.leaseId;
      state.activeLease = null;
      state.activeLeaseRequestId = null;
      state.activeOptionalAuthorization = null;
      state.pauseRequested = false;
      state.status = "reconciling";
      break;
    }

    case "evidence.slot-issued":
      assertSource(event, ["runner"]);
      assertStatus(state, ["active"], event);
      if (!state.activeLease || state.activeLease.leaseId !== event.payload.slot.leaseId) {
        throw transitionError("Evidence slot does not match the active lease");
      }
      assertEventBeforeLeaseExpiry(state, event);
      assertOwner(state, event.payload.slot.hostId);
      if (state.evidenceSlots[event.payload.slot.slotId]) {
        throw transitionError(`Evidence slot already exists: ${event.payload.slot.slotId}`);
      }
      if (state.exploration) {
        const slot = event.payload.slot;
        if (
          new Date(event.occurredAt).valueOf() - new Date(state.manifest.createdAt).valueOf() >=
            state.manifest.exploration.limits.minutes * 60_000 ||
          slot.stepId !== "explore" ||
          slot.checkpoint !== "visit" ||
          slot.type !== "screenshot" ||
          slot.leaseRequestId !== state.activeLeaseRequestId ||
          slot.optionalHandlerId !== undefined ||
          state.exploration.capturesUsed >= state.manifest.exploration.limits.captures
        ) {
          throw transitionError("Exploration capture exceeds its pinned evidence contract");
        }
        state.exploration.capturesUsed += 1;
      } else {
        {
          const slot = event.payload.slot;
          const step = state.workflow.steps.find((item) => item.id === state.traversal?.activeStepId);
          if (slot.stepId !== step?.id || slot.leaseRequestId !== state.activeLeaseRequestId) {
            throw transitionError("Evidence slot does not match the active step and lease request");
          }
          if (slot.optionalHandlerId !== undefined) {
            const handler = state.workflow.optionalStateHandlers.find((item) => item.id === slot.optionalHandlerId);
            const requirement = handler?.evidence?.[0];
            if (
              !step.optionalHandlers?.includes(handler?.id) ||
              handler.evidence?.length !== 1 ||
              typeof requirement !== "object" ||
              slot.type !== requirement.type ||
              slot.checkpoint !== requirement.checkpoint ||
              slot.capability.id !== handler.routineDismissal?.capabilityId
            ) {
              throw transitionError("Optional evidence slot does not match an attached pinned handler");
            }
          } else if (
            !(step.evidence ?? []).some(
              (requirement) =>
                typeof requirement === "object" &&
                requirement.type === (slot.type === "download-content" ? "download-artifact" : slot.type) &&
                (slot.type !== "download-content" || sha256(requirement.verify) === sha256(slot.download)) &&
                requirement.checkpoint === slot.checkpoint,
            )
          ) {
            throw transitionError("Ordinary evidence slot does not match a declared step checkpoint");
          }
        }
      }
      state.evidenceSlots[event.payload.slot.slotId] = structuredClone(event.payload.slot);
      break;

    case "evidence.registered": {
      assertSource(event, ["runner"]);
      assertStatus(state, ["active"], event);
      if (!state.activeLease) throw transitionError("Evidence requires an active lease");
      assertEventBeforeLeaseExpiry(state, event);
      const { artifact } = event.payload;
      const slot = state.evidenceSlots[event.payload.slotId];
      if (!slot || slot.leaseId !== state.activeLease.leaseId) {
        throw transitionError("Registered evidence does not match an issued active slot");
      }
      if (artifact.runId !== state.runId) {
        throw transitionError("Registered evidence run ID changed");
      }
      if (
        artifact.type !== slot.type ||
        artifact.relation.stepId !== slot.stepId ||
        artifact.relation.checkpoint !== slot.checkpoint ||
        artifact.relation.batchRequestId !== slot.leaseRequestId ||
        artifact.relation.optionalHandlerId !== slot.optionalHandlerId
      ) {
        throw transitionError("Registered evidence relation does not match its issued slot");
      }
      if (state.traversal?.artifacts[artifact.artifactId]) {
        throw transitionError(`Evidence artifact already exists: ${artifact.artifactId}`);
      }
      if (state.traversal) state.traversal.artifacts[artifact.artifactId] = structuredClone(artifact);
      if (state.exploration) {
        if (
          new Date(event.occurredAt).valueOf() - new Date(state.manifest.createdAt).valueOf() >=
          state.manifest.exploration.limits.minutes * 60_000
        ) {
          throw transitionError("Exploration time budget exhausted");
        }
        if (state.exploration.artifacts[artifact.artifactId])
          throw transitionError("Exploration evidence artifact already exists");
        state.exploration.artifacts[artifact.artifactId] = structuredClone(artifact);
      }
      delete state.evidenceSlots[event.payload.slotId];
      break;
    }

    case "optional-state.authorized": {
      assertSource(event, ["runner"]);
      assertStatus(state, ["active"], event);
      if (!state.activeLease || state.activeLease.leaseId !== event.payload.parentLeaseId) {
        throw transitionError("Optional-state authorization does not match the active parent lease");
      }
      assertEventBeforeLeaseExpiry(state, event);
      assertOwner(state, event.payload.hostId);
      if (
        state.manifest.leasePolicy?.name !== "routine-codex-browser-v1" ||
        state.activeLease.policy.decision !== "allowed" ||
        !state.activeLease.extensions?.["routine.action"]?.id
      ) {
        throw transitionError("Optional-state authorization requires an automatic routine parent lease");
      }
      const step = state.workflow.steps.find((item) => item.id === state.traversal?.activeStepId);
      const handler = state.workflow.optionalStateHandlers.find((item) => item.id === event.payload.handlerId);
      const requirement = handler?.evidence?.[0];
      const expectedHash = handler
        ? sha256({
            handlerId: handler.id,
            maxApplications: handler.maxApplications,
            evidence: handler.evidence,
            routineDismissal: handler.routineDismissal,
          })
        : null;
      if (
        !step?.optionalHandlers?.includes(handler?.id) ||
        handler.maxApplications !== 1 ||
        handler.evidence?.length !== 1 ||
        !requirement ||
        typeof requirement !== "object" ||
        requirement.type !== "screenshot" ||
        event.payload.stepId !== step.id ||
        event.payload.contractHash !== expectedHash ||
        JSON.stringify(event.payload.scope) !== JSON.stringify(handler.routineDismissal) ||
        event.payload.evidenceIds.length !== 1 ||
        (state.optionalApplications[step.id] ?? []).some((item) => item.handlerId === handler.id)
      ) {
        throw transitionError("Optional-state authorization does not match the pinned one-use handler contract");
      }
      const artifact = state.traversal.artifacts[event.payload.evidenceIds[0]];
      if (
        !artifact ||
        artifact.runId !== state.runId ||
        artifact.type !== "screenshot" ||
        artifact.relation.stepId !== step.id ||
        artifact.relation.checkpoint !== requirement.checkpoint ||
        artifact.relation.optionalHandlerId !== handler.id ||
        artifact.relation.batchRequestId !== state.activeLeaseRequestId ||
        artifact.capability.id !== handler.routineDismissal.capabilityId
      ) {
        throw transitionError("Optional-state authorization evidence is not the pinned before-state screenshot");
      }
      state.activeOptionalAuthorization = structuredClone(event.payload);
      break;
    }

    case "optional-state.applied": {
      assertSource(event, ["agent-host"]);
      assertStatus(state, ["active"], event);
      assertEventBeforeLeaseExpiry(state, event);
      assertOwner(state, event.payload.hostId);
      if (JSON.stringify(event.payload) !== JSON.stringify(state.activeOptionalAuthorization)) {
        throw transitionError("Optional-state application does not exactly consume the adjacent authorization");
      }
      const applications = state.optionalApplications[event.payload.stepId] ?? [];
      if (applications.some((item) => item.handlerId === event.payload.handlerId)) {
        throw transitionError("Optional-state handler was already applied");
      }
      applications.push({ ...structuredClone(event.payload), appliedAt: event.occurredAt });
      state.optionalApplications[event.payload.stepId] = applications;
      state.activeOptionalAuthorization = null;
      break;
    }

    case "action.committed":
      assertSource(event, ["agent-host"]);
      assertStatus(state, ["active"], event);
      if (!state.activeLease || state.activeLease.leaseId !== event.payload.result.leaseId) {
        throw transitionError("Committed result does not match the active lease");
      }
      assertEventBeforeLeaseExpiry(state, event);
      if (state.activeOptionalAuthorization) {
        throw transitionError("Optional-state authorization must be applied before commit");
      }
      if (state.exploration) {
        const observation = event.payload.exploration;
        const action = state.activeLease.proposal.actions[0];
        const declared = event.payload.result.declaredActions;
        const actual = event.payload.result.actualActions;
        if (
          new Date(event.occurredAt).valueOf() - new Date(state.manifest.createdAt).valueOf() >=
          state.manifest.exploration.limits.minutes * 60_000
        )
          throw transitionError("Exploration time budget exhausted");
        if (
          !observation ||
          event.payload.assessment ||
          event.payload.derivedOutcome ||
          !state.manifest.exploration.intents.includes(observation.intent) ||
          declared.length !== 1 ||
          declared[0] !== action.description ||
          actual.length > 1 ||
          actual.some((item) => item !== action.description) ||
          (observation.state === "visited" && actual.length !== 1)
        ) {
          throw transitionError("Exploration commit requires an in-scope observation");
        }
        const targetOrigin = new URL(state.manifest.target.canonicalUrl).origin;
        const reportedUrl = new URL(observation.url);
        if (reportedUrl.origin !== targetOrigin || reportedUrl.username || reportedUrl.password || reportedUrl.hash)
          throw transitionError("Exploration observation escaped target origin or carried credentials");
        if (
          observation.fromVisitId &&
          !state.exploration.visits.some((visit) => visit.visitId === observation.fromVisitId)
        ) {
          throw transitionError("Exploration transition source is not a verified visit");
        }
        if (
          observation.journey &&
          (!observation.fromVisitId ||
            observation.state !== "visited" ||
            (observation.journey.parentJourneyIds ?? []).some(
              (journeyId) =>
                !state.exploration.visits.some((visit) => `journey_${visit.visitId}` === journeyId && visit.journey),
            ))
        ) {
          throw transitionError(
            "Journey nomination requires a verified transition and explicit existing parent journeys",
          );
        }
        if (observation.state === "visited") {
          const artifact = state.exploration.artifacts[observation.evidenceId];
          if (
            !artifact ||
            artifact.relation.batchRequestId !== state.activeLeaseRequestId ||
            artifact.relation.stepId !== "explore" ||
            artifact.relation.checkpoint !== "visit"
          ) {
            throw transitionError("Exploration visit does not cite exact registered lease evidence");
          }
          state.exploration.visits.push({
            visitId: `visit_${event.sequence}`,
            ...structuredClone(observation),
            leaseId: state.activeLease.leaseId,
            commitEventId: event.eventId,
          });
        } else {
          state.exploration.gaps.push({
            gapId: `gap_${event.sequence}`,
            ...structuredClone(observation),
            leaseId: state.activeLease.leaseId,
            commitEventId: event.eventId,
          });
        }
      }
      if (state.traversal) {
        const { assessment, artifacts, derivedOutcome } = event.payload;
        if (assessment.stepId !== state.traversal.activeStepId) {
          throw transitionError("Commit does not match the active workflow step");
        }
        if (assessment.proposedOutcome !== derivedOutcome) {
          throw transitionError("Runner outcome does not match the validated assessment");
        }
        for (const artifact of artifacts) {
          const artifactId = typeof artifact === "string" ? artifact : artifact.artifactId;
          const registered = state.traversal.artifacts[artifactId];
          if (registered) {
            if (typeof artifact !== "string" && JSON.stringify(registered) !== JSON.stringify(artifact)) {
              throw transitionError(`Evidence artifact metadata changed: ${artifactId}`);
            }
            continue;
          }
          if (typeof artifact === "string") {
            throw transitionError(`Evidence artifact is not registered: ${artifactId}`);
          }
          state.traversal.artifacts[artifactId] = structuredClone(artifact);
        }
        const committedIds = new Set(
          artifacts.map((artifact) => (typeof artifact === "string" ? artifact : artifact.artifactId)),
        );
        for (const application of state.optionalApplications[assessment.stepId] ?? []) {
          if (application.evidenceIds.some((artifactId) => !committedIds.has(artifactId))) {
            throw transitionError("Applied optional-state evidence is missing from the step commit");
          }
        }
        state.traversal.steps[assessment.stepId].outcome = derivedOutcome;
        if (assessment.block) {
          state.traversal.steps[assessment.stepId].reason = assessment.block.code;
          state.traversal.steps[assessment.stepId].capability = assessment.block.capability;
        }
        state.traversal.activeStepId = null;
        const next = nextRunnableStep(state.workflow, state.traversal);
        if (!next) {
          for (const step of Object.values(state.traversal.steps)) {
            if (step.outcome === "pending") {
              step.outcome = "blocked";
              step.reason = "dependency_blocked";
            }
          }
          state.traversal.journeyOutcome = deriveJourneyOutcome(state.traversal);
          state.status = "cleanup";
        }
      }
      for (const [slotId, slot] of Object.entries(state.evidenceSlots)) {
        if (slot.leaseId === state.activeLease.leaseId) delete state.evidenceSlots[slotId];
      }
      state.activeLease = null;
      state.activeLeaseRequestId = null;
      if (state.pauseRequested && state.status === "active") {
        state.pauseRequested = false;
        state.status = "paused";
      }
      break;

    case "exploration.finished": {
      assertSource(event, ["agent-host"]);
      assertStatus(state, ["active", "paused"], event);
      assertNoActiveLease(state);
      if (!state.exploration || state.uncertainLeaseId)
        throw transitionError("Only a reconciled exploration may finish");
      assertOwner(state, event.payload.hostId);
      const coverage = event.payload.coverage;
      const intents = state.manifest.exploration.intents;
      const visited = new Set(state.exploration.visits.map((visit) => visit.intent));
      const uncovered = intents.filter((intent) => !visited.has(intent));
      if (
        coverage.length !== uncovered.length ||
        new Set(coverage.map((item) => item.intent)).size !== coverage.length ||
        coverage.some((item) => !uncovered.includes(item.intent)) ||
        (event.payload.disposition === "complete" && coverage.some((item) => item.state === "unvisited"))
      ) {
        throw transitionError("Exploration finish must explicitly account for every uncovered intent");
      }
      state.exploration.finish = {
        disposition: event.payload.disposition,
        reason: event.payload.reason,
        eventId: event.eventId,
        at: event.occurredAt,
      };
      state.exploration.gaps.push(
        ...coverage.map((item) => ({
          ...structuredClone(item),
          gapId: `gap_${event.sequence}_${intents.indexOf(item.intent)}`,
        })),
      );
      state.status = event.payload.disposition === "complete" ? "completed" : "blocked";
      state.terminalOutcome = state.status;
      break;
    }

    case "run.pause_requested":
      assertSource(event, ["adapter"]);
      assertStatus(state, ["active"], event);
      if (state.activeLease) state.pauseRequested = true;
      else state.status = "paused";
      break;

    case "run.paused":
      assertSource(event, ["runner"]);
      assertStatus(state, ["active"], event);
      assertNoActiveLease(state);
      state.pauseRequested = false;
      state.status = "paused";
      break;

    case "run.resumed":
      assertSource(event, ["human", "agent-host"]);
      assertStatus(state, ["paused"], event);
      if ((event.source === "agent-host") !== (event.payload.authority?.actorKind === "agent"))
        throw transitionError("Resume provenance must match the executing actor");
      if (state.manifest.nonResumable) throw transitionError("This evaluation is non-resumable");
      state.status = "active";
      break;

    case "run.emergency_stopped":
      assertSource(event, ["adapter"]);
      assertStatus(state, ["active"], event);
      if (!state.activeLease || state.activeLease.leaseId !== event.payload.leaseId) {
        throw transitionError("Emergency stop does not match the active lease");
      }
      state.uncertainLeaseId = state.activeLease.leaseId;
      state.activeLease = null;
      state.activeLeaseRequestId = null;
      state.pauseRequested = false;
      state.status = "reconciling";
      break;

    case "reconciliation.completed":
      assertSource(event, ["agent-host", "human"]);
      assertStatus(state, ["reconciling"], event);
      if (state.uncertainLeaseId && event.payload.leaseId !== state.uncertainLeaseId) {
        throw transitionError("Reconciliation does not match the uncertain lease");
      }
      if (state.handoffFromHostId && event.payload.previousHostId !== state.handoffFromHostId) {
        throw transitionError("Reconciliation does not match the host handoff");
      }
      state.uncertainLeaseId = null;
      state.handoffFromHostId = null;
      if (event.payload.classification === "indeterminate" && state.phase !== "training") {
        state.preflightOutcome = "blocked";
        state.status = "cleanup";
      } else {
        state.status = "paused";
      }
      break;

    case "cleanup.started":
      assertSource(event, ["runner"]);
      assertStatus(
        state,
        [
          "preparing",
          "preflight",
          "awaiting-authentication",
          "active",
          "paused",
          "reconciling",
          "awaiting-approval",
          "cleanup",
        ],
        event,
      );
      assertNoActiveLease(state);
      state.status = "cleanup";
      break;

    case "cleanup.completed":
      assertSource(event, ["runner"]);
      assertStatus(state, ["cleanup"], event);
      state.cleanupOutcome = event.payload.outcome;
      if (
        event.payload.outcome === "failed" ||
        state.preflightOutcome === "failed" ||
        state.traversal?.journeyOutcome === "failed"
      ) {
        state.status = "failed";
      } else if (state.preflightOutcome === "blocked" || state.traversal?.journeyOutcome === "blocked") {
        state.status = "blocked";
      } else {
        state.status = "completed";
      }
      state.terminalOutcome = state.status;
      break;

    case "run.abandoned":
      assertSource(event, ["adapter", "human", "runner"]);
      assertStatus(
        state,
        ["preparing", "awaiting-approval", "preflight", "awaiting-authentication", "active", "paused", "reconciling"],
        event,
      );
      assertNoActiveLease(state);
      state.status = "abandoned";
      state.terminalOutcome = "abandoned";
      break;

    default:
      throw transitionError(`Unknown run-control event: ${event.type}`);
  }

  state.sequence = event.sequence;
  state.revision = event.revision;
  return state;
}

export function replayRunControl(manifest, events, workflow = null) {
  return events.reduce(
    (state, event) => reduceRunControlEvent(state, event),
    createRunControlState(manifest, workflow),
  );
}
