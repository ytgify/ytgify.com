/* eslint-disable max-lines -- immutable assessment, question provenance, and coverage share one verification boundary. */
import { randomUUID } from "node:crypto";
import { constants } from "node:fs";
import { link, lstat, mkdir, open, readdir, unlink } from "node:fs/promises";
import { dirname, join, relative, resolve, sep } from "node:path";

import { WorkflowError } from "./errors.js";
import { FindingStore } from "./finding-store.js";
import { EvaluationQuestionStore } from "./evaluation-question-store.js";
import { buildRunReport } from "./run-report.js";
import { sha256 } from "./stable-json.js";

const RUN_ID = /^run_[A-Za-z0-9_-]+$/u;
const ASSESSMENT_ID = /^assessment_[a-f0-9]{32}$/u;
const OUTCOMES = new Set(["satisfied", "finding", "unassessed", "out-of-scope"]);
const WRITE_AUTHORITY = Symbol("perspective-assessment-write-authority");

function fail(code, message) {
  throw new WorkflowError(code, message, { exitCode: 3 });
}

function invalidAssessment(message, details = {}) {
  throw new WorkflowError("VALIDATION_FAILED", message, { exitCode: 3, details });
}

function missingOrInvalidReference(error, codes = []) {
  return error instanceof TypeError || ["ENOENT", "NOT_FOUND", "VALIDATION_FAILED", ...codes].includes(error?.code);
}

function assertInside(root, path) {
  const suffix = relative(resolve(root), resolve(path));
  if (suffix.startsWith("..") || resolve(root, suffix) !== resolve(path))
    fail("PATH_TRAVERSAL", "Assessment path escapes its root");
}

async function assertDirectory(path) {
  const entry = await lstat(path);
  if (!entry.isDirectory() || entry.isSymbolicLink())
    fail("ASSESSMENT_STORE_UNSAFE", "Assessment paths cannot be symlinks");
}

async function assertSafeAncestry(root, path) {
  assertInside(root, path);
  let cursor = resolve(root);
  await assertDirectory(cursor);
  for (const part of relative(cursor, resolve(path)).split(sep).filter(Boolean)) {
    cursor = join(cursor, part);
    try {
      const entry = await lstat(cursor);
      if (entry.isSymbolicLink()) fail("ASSESSMENT_STORE_UNSAFE", "Assessment ancestry cannot contain symlinks");
      if (cursor !== resolve(path) && !entry.isDirectory())
        fail("ASSESSMENT_STORE_UNSAFE", "Assessment ancestry must contain only directories");
    } catch (error) {
      if (error.code === "ENOENT") break;
      throw error;
    }
  }
}

async function syncDirectory(path) {
  const handle = await open(path, "r");
  try {
    await handle.sync();
  } finally {
    await handle.close();
  }
}

async function immutableWrite(path, bytes) {
  const temporary = `${path}.${randomUUID()}.tmp`;
  const handle = await open(temporary, "wx", 0o600);
  try {
    await handle.writeFile(bytes);
    await handle.sync();
  } finally {
    await handle.close();
  }
  try {
    await link(temporary, path);
    await syncDirectory(dirname(path));
  } catch (error) {
    if (error.code === "EEXIST") fail("IMMUTABLE_ASSESSMENT_EXISTS", "Assessment records cannot be replaced");
    throw error;
  } finally {
    await unlink(temporary).catch(() => {});
  }
}

async function readRegular(path) {
  await assertDirectory(dirname(path));
  const entry = await lstat(path);
  if (!entry.isFile() || entry.isSymbolicLink()) fail("ASSESSMENT_RECORD_CORRUPT", "Assessment is not a file");
  const handle = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    const opened = await handle.stat();
    if (opened.dev !== entry.dev || opened.ino !== entry.ino || opened.size !== entry.size)
      fail("ASSESSMENT_RECORD_CORRUPT", "Assessment changed while being read");
    return await handle.readFile("utf8");
  } finally {
    await handle.close();
  }
}

export class PerspectiveAssessmentStore {
  constructor(root, { registry, findingStore, questionStore } = {}) {
    this.root = resolve(root);
    this.assessmentsRoot = join(this.root, "perspective-assessments");
    this.registry = registry;
    this.findingStore = findingStore ?? new FindingStore(this.root, { registry });
    this.questionStore = questionStore ?? new EvaluationQuestionStore(this.root, { registry });
  }

  async init() {
    await mkdir(this.root, { recursive: true });
    await assertDirectory(this.root);
    await mkdir(this.assessmentsRoot, { recursive: true });
    await assertDirectory(this.assessmentsRoot);
    return this;
  }

  runRoot(runId) {
    if (!RUN_ID.test(runId)) fail("INVALID_ASSESSMENT_ID", "Invalid run ID");
    const path = resolve(this.assessmentsRoot, runId);
    assertInside(this.assessmentsRoot, path);
    return path;
  }

  recordPath(runId, assessmentId) {
    if (!ASSESSMENT_ID.test(assessmentId)) fail("INVALID_ASSESSMENT_ID", "Invalid assessment ID");
    const root = this.runRoot(runId);
    const path = resolve(root, `${assessmentId}.json`);
    assertInside(root, path);
    return path;
  }

  async writeAssessment(record, authority) {
    if (authority !== WRITE_AUTHORITY) fail("ASSESSMENT_WRITE_FORBIDDEN", "Assessments require verified run evidence");
    this.registry?.validate("perspectiveAssessment", record);
    const root = this.runRoot(record.runId);
    await assertSafeAncestry(this.assessmentsRoot, root);
    await mkdir(root).catch((error) => {
      if (error.code !== "EEXIST") throw error;
    });
    await assertDirectory(root);
    const path = this.recordPath(record.runId, record.assessmentId);
    await assertSafeAncestry(this.assessmentsRoot, path);
    await immutableWrite(path, Buffer.from(`${JSON.stringify(record, null, 2)}\n`));
    return structuredClone(record);
  }

  async readAssessment(runId, assessmentId) {
    const path = this.recordPath(runId, assessmentId);
    await assertSafeAncestry(this.assessmentsRoot, path);
    let record;
    try {
      record = JSON.parse(await readRegular(path));
    } catch (error) {
      if (error instanceof SyntaxError) fail("ASSESSMENT_RECORD_CORRUPT", "Assessment is invalid JSON");
      throw error;
    }
    this.registry?.validate("perspectiveAssessment", record);
    if (record.runId !== runId || record.assessmentId !== assessmentId)
      fail("ASSESSMENT_ID_MISMATCH", "Assessment path does not match record identity");
    return record;
  }

  async listAssessmentIds(runId) {
    const root = this.runRoot(runId);
    try {
      await assertSafeAncestry(this.assessmentsRoot, root);
      await assertDirectory(root);
    } catch (error) {
      if (error.code === "ENOENT") return [];
      throw error;
    }
    return (await readdir(root))
      .filter((name) => /^assessment_[a-f0-9]{32}\.json$/u.test(name))
      .sort()
      .map((name) => name.slice(0, -5));
  }

  async withCriterionLock(runId, criterionId, operation) {
    const lockPath = join(this.assessmentsRoot, `.${sha256({ runId, criterionId }).slice(7, 39)}.lock`);
    await assertSafeAncestry(this.assessmentsRoot, lockPath);
    const token = randomUUID();
    let acquired = false;
    for (let attempt = 0; attempt < 2 && !acquired; attempt += 1) {
      try {
        await immutableWrite(lockPath, `${JSON.stringify({ pid: process.pid, token })}\n`);
        acquired = true;
      } catch (error) {
        if (error.code !== "IMMUTABLE_ASSESSMENT_EXISTS") throw error;
        let owner;
        try {
          owner = JSON.parse(await readRegular(lockPath));
        } catch {
          fail("ASSESSMENT_CONFLICT", "Another correction owns an unreadable criterion lock");
        }
        if (!Number.isSafeInteger(owner.pid) || owner.pid <= 0 || typeof owner.token !== "string")
          fail("ASSESSMENT_CONFLICT", "Another correction owns an invalid criterion lock");
        try {
          process.kill(owner.pid, 0);
          fail("ASSESSMENT_CONFLICT", "Another correction for this criterion is in progress");
        } catch (ownerError) {
          if (ownerError.code !== "ESRCH") throw ownerError;
        }
        await unlink(lockPath).catch((unlinkError) => {
          if (unlinkError.code !== "ENOENT") throw unlinkError;
        });
      }
    }
    if (!acquired) fail("ASSESSMENT_CONFLICT", "Criterion lock could not be recovered");
    try {
      return await operation();
    } finally {
      try {
        const owner = JSON.parse(await readRegular(lockPath));
        if (owner.token === token) await unlink(lockPath);
      } catch {
        // A missing or replaced lock is never removed by the former owner.
      }
    }
  }
}

function requiredReason(value) {
  if (typeof value !== "string" || value.trim().length < 3 || value.length > 4000)
    invalidAssessment("Assessment reason must be specific");
  return value.trim();
}

async function activeRecords(store, runId) {
  const records = await Promise.all(
    (await store.listAssessmentIds(runId)).map((id) => store.readAssessment(runId, id)),
  );
  const superseded = new Set(records.map((record) => record.supersedesAssessmentId).filter(Boolean));
  return records.filter((record) => !superseded.has(record.assessmentId));
}

function scenarioStepIds(run, scenarioId) {
  if (scenarioId === "canonical-journey") return (run.workflow?.steps ?? []).map((step) => step.id);
  if (scenarioId === "reset") return [run.workflow?.evaluation?.resetStepId].filter(Boolean);
  if (scenarioId === "cleanup") return [run.workflow?.evaluation?.cleanupStepId].filter(Boolean);
  return run.workflow?.evaluation?.perspectiveScenarios?.find((scenario) => scenario.id === scenarioId)?.stepIds ?? [];
}

async function validateObservation({ observation, criterion, report, run, runStore, findingStore, outcome }) {
  if (!observation || typeof observation !== "object" || Array.isArray(observation))
    invalidAssessment("Assessment observation is invalid");
  const step = report.steps.find((item) => item.id === observation.stepId);
  if (!step) invalidAssessment("Assessment observation step is unavailable for this run");
  if (!criterion.scenarioIds.includes(observation.scenarioId))
    invalidAssessment("Assessment observation uses a scenario absent from the pinned criterion");
  if (!scenarioStepIds(run, observation.scenarioId).includes(observation.stepId))
    invalidAssessment("Assessment observation step is not mapped to its declared scenario");
  if (observation.noteIndex !== undefined && !step.notes[observation.noteIndex])
    invalidAssessment("Assessment observation note is unavailable for this run");
  if (observation.artifactId !== undefined) {
    const artifact = step.evidence.find((item) => item.artifactId === observation.artifactId);
    if (!artifact) invalidAssessment("Assessment evidence belongs to a different run or step");
    try {
      await runStore.readVerifiedEvidence(run.manifest.runId, observation.artifactId);
    } catch (error) {
      if (!missingOrInvalidReference(error)) throw error;
      invalidAssessment("Assessment evidence is missing or corrupt");
    }
  }
  if (observation.noteIndex === undefined && observation.artifactId === undefined)
    invalidAssessment("Assessment observation must reference a note or evidence artifact");
  if (outcome === "finding") {
    if (!observation.findingId) invalidAssessment("Finding assessment requires a native finding");
    const workflowId = run.manifest.workflowRef?.id ?? run.workflow?.metadata?.id;
    let finding;
    try {
      finding = await findingStore.readFinding(workflowId, observation.findingId);
    } catch (error) {
      if (!missingOrInvalidReference(error, ["FINDING_RECORD_CORRUPT", "FINDING_ID_MISMATCH"])) throw error;
      invalidAssessment("Assessment finding is missing or corrupt");
    }
    const matchesArtifact =
      observation.artifactId === undefined ||
      finding.evidence.some((item) => item.artifactId === observation.artifactId);
    if (
      finding.runId !== run.manifest.runId ||
      finding.step.id !== observation.stepId ||
      (observation.noteIndex !== undefined && finding.source.noteIndex !== observation.noteIndex) ||
      !matchesArtifact
    )
      invalidAssessment("Assessment finding does not match the run observation");
    const sourceStep = report.steps.find((item) => item.id === finding.step.id);
    const sourceNote = sourceStep?.notes?.[finding.source.noteIndex];
    if (
      finding.source.reportHash !== sha256(report) ||
      sourceNote?.kind !== finding.source.kind ||
      sourceNote?.text !== finding.source.text
    )
      invalidAssessment("Assessment finding source report or note is no longer verified");
    for (const pinned of finding.evidence) {
      const artifact = sourceStep?.evidence.find((item) => item.artifactId === pinned.artifactId);
      if (
        pinned.integrityAtCreation !== "verified" ||
        artifact?.integrity !== "verified" ||
        artifact.contentHash !== pinned.contentHash ||
        artifact.checkpoint !== pinned.checkpoint
      )
        invalidAssessment("Assessment finding evidence snapshot is missing or corrupt");
      try {
        await runStore.readVerifiedEvidence(run.manifest.runId, pinned.artifactId);
      } catch (error) {
        if (!missingOrInvalidReference(error)) throw error;
        invalidAssessment("Assessment finding evidence snapshot is missing or corrupt");
      }
    }
  } else if (observation.findingId !== undefined) {
    invalidAssessment("Only finding outcomes may reference a finding");
  }
}

async function validateRecordEvidence({ record, run, report, runStore, store }) {
  for (const observation of record.observations) {
    await validateObservation({
      observation,
      criterion: record.criterion,
      report,
      run,
      runStore,
      findingStore: store.findingStore,
      outcome: record.outcome,
    });
  }
}

async function validateAssessmentQuestions({ questionIds, criterion, perspective, run, report, runStore, store }) {
  for (const questionId of questionIds) {
    let question;
    try {
      question = await store.questionStore.readQuestion(run.manifest.runId, questionId);
    } catch (error) {
      if (!missingOrInvalidReference(error, ["QUESTION_RECORD_CORRUPT", "QUESTION_ID_MISMATCH"])) throw error;
      invalidAssessment("Assessment question is missing or corrupt", { questionId });
    }
    if (
      question.runId !== run.manifest.runId ||
      question.perspectiveId !== perspective.id ||
      question.rubricHash !== perspective.rubricHash ||
      question.effectiveRubricHash !== (perspective.effectiveRubricHash ?? perspective.rubricHash) ||
      question.criterionId !== criterion.id ||
      !criterion.scenarioIds.includes(question.scenarioId) ||
      !scenarioStepIds(run, question.scenarioId).includes(question.stepId)
    )
      invalidAssessment("Assessment question does not match its run, perspective, rubric, criterion, or step", {
        questionId,
      });
    if (criterion.requirementKeys?.length && !criterion.requirementKeys.includes(question.requirementKey))
      invalidAssessment("Assessment question requirement key is absent from the pinned criterion", { questionId });
    for (const observation of question.observations)
      await validateObservation({
        observation,
        criterion,
        report,
        run,
        runStore,
        findingStore: store.findingStore,
        outcome: "unassessed",
      });
  }
}

export async function recordPerspectiveAssessment({
  store,
  runStore,
  runId,
  criterionId,
  outcome,
  reason,
  observations = [],
  unassessedReason,
  questionIds = [],
  supersedesAssessmentId,
}) {
  if (!OUTCOMES.has(outcome)) invalidAssessment("Assessment outcome is invalid", { outcome });
  if (!Array.isArray(observations)) invalidAssessment("Assessment observations must be an array");
  if (!Array.isArray(questionIds) || new Set(questionIds).size !== questionIds.length)
    invalidAssessment("Assessment question IDs must be a unique array");
  const [run, report] = await Promise.all([
    runStore.readRun(runId),
    buildRunReport(runStore, runId, { skipPerspective: true }),
  ]);
  const perspective = run.manifest.evaluationPerspective;
  if (!perspective) fail("PERSPECTIVE_NOT_RECORDED", "Evaluation perspective is not recorded for this run");
  const criterion = perspective.criteria.find((item) => item.id === criterionId);
  if (!criterion) invalidAssessment("Criterion is absent from the run's pinned rubric", { criterionId });
  const normalizedReason = requiredReason(reason);
  if (outcome !== "unassessed" && (unassessedReason !== undefined || questionIds.length))
    invalidAssessment("Only unassessed outcomes may record an unassessed reason or questions");
  if (unassessedReason === "undefined-product-intent" && questionIds.length === 0)
    invalidAssessment("Undefined product intent requires a verified open question", { criterionId });
  if (questionIds.length && unassessedReason !== "undefined-product-intent")
    invalidAssessment("Assessment questions require the undefined-product-intent reason", { criterionId });
  if ((outcome === "satisfied" || outcome === "finding") && observations.length === 0)
    invalidAssessment("Assessment outcome requires verified evidence", { criterionId, outcome });
  if (outcome === "satisfied" || outcome === "finding") {
    const unsupported = criterion.scenarioIds.filter((scenarioId) => scenarioStepIds(run, scenarioId).length === 0);
    if (unsupported.length)
      invalidAssessment(`Assessment criterion has no declared workflow mapping for: ${unsupported.join(", ")}`, {
        criterionId,
        scenarioIds: unsupported,
      });
    const unobserved = criterion.scenarioIds.filter(
      (scenarioId) => !observations.some((observation) => observation.scenarioId === scenarioId),
    );
    if (unobserved.length)
      invalidAssessment(`Assessment criterion lacks evidence for declared scenarios: ${unobserved.join(", ")}`, {
        criterionId,
        scenarioIds: unobserved,
      });
  }
  const recordBasis = {
    runId,
    perspectiveId: perspective.id,
    rubricHash: perspective.rubricHash,
    criterion: structuredClone(criterion),
    outcome,
    reason: normalizedReason,
    observations: structuredClone(observations),
    ...(unassessedReason ? { unassessedReason } : {}),
    ...(questionIds.length ? { questionIds: structuredClone(questionIds) } : {}),
    ...(supersedesAssessmentId ? { supersedesAssessmentId } : {}),
  };
  await validateRecordEvidence({ record: recordBasis, run, report, runStore, store });
  await validateAssessmentQuestions({ questionIds, criterion, perspective, run, report, runStore, store });
  return store.withCriterionLock(runId, criterionId, async () => {
    const assessmentId = `assessment_${sha256(recordBasis).slice(7, 39)}`;
    try {
      const existing = await store.readAssessment(runId, assessmentId);
      const existingBasis = structuredClone(existing);
      delete existingBasis.assessmentId;
      delete existingBasis.schema;
      delete existingBasis.createdAt;
      if (sha256(existingBasis) !== sha256(recordBasis))
        fail("ASSESSMENT_ID_COLLISION", "Assessment identity does not match its immutable request");
      return existing;
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
    }
    const current = (await activeRecords(store, runId)).filter((item) => item.criterion.id === criterionId);
    if (current.length > 1) fail("ASSESSMENT_CONFLICT", "Criterion has divergent active assessment branches");
    const [active] = current;
    if (active && supersedesAssessmentId !== active.assessmentId)
      fail("ASSESSMENT_CONFLICT", "Changed assessment must explicitly supersede the current record");
    if (!active && supersedesAssessmentId)
      fail("ASSESSMENT_SUPERSESSION_MISMATCH", "Superseded assessment is not current for this criterion");
    const record = {
      schema: "agent-workflow-perspective-assessment/v1",
      assessmentId,
      ...recordBasis,
      createdAt: new Date().toISOString(),
    };
    try {
      return await store.writeAssessment(record, WRITE_AUTHORITY);
    } catch (error) {
      if (error.code !== "IMMUTABLE_ASSESSMENT_EXISTS") throw error;
      const existing = await store.readAssessment(runId, assessmentId);
      if (sha256(existing) !== sha256(record)) throw error;
      return existing;
    }
  });
}

export async function projectPerspectiveCoverage({ runStore, assessmentStore, runId }) {
  const run = await runStore.readRun(runId);
  const perspective = run.manifest.evaluationPerspective;
  if (!perspective)
    return { perspective: "not-recorded", coverage: "not-recorded", qualityOutcome: "unavailable", criteria: [] };
  const report = await buildRunReport(runStore, runId, { skipPerspective: true });
  const perspectiveSummary = {
    id: perspective.id,
    version: perspective.version,
    rubricHash: perspective.rubricHash,
    ...(perspective.effectiveRubricHash ? { effectiveRubricHash: perspective.effectiveRubricHash } : {}),
    ...(perspective.inquiryPolicy ? { inquiryPolicy: structuredClone(perspective.inquiryPolicy) } : {}),
    ...(perspective.requirementSnapshot
      ? { requirementSnapshot: structuredClone(perspective.requirementSnapshot) }
      : {}),
    batchId: perspective.batchId,
    controlRunId: perspective.controlRunId,
  };
  const active = await activeRecords(assessmentStore, runId);
  const branched = perspective.criteria.some(
    (criterion) => active.filter((record) => record.criterion.id === criterion.id).length > 1,
  );
  if (branched)
    return {
      perspective: perspectiveSummary,
      coverage: { status: "unavailable", criteria: [] },
      qualityOutcome: "unavailable",
      criteria: [],
    };
  const criteria = [];
  for (const criterion of perspective.criteria) {
    const record = active.find((item) => item.criterion.id === criterion.id);
    if (!record) {
      criteria.push({ ...structuredClone(criterion), outcome: "unassessed", assessmentId: null, reason: null });
      continue;
    }
    if (
      record.perspectiveId !== perspective.id ||
      record.rubricHash !== perspective.rubricHash ||
      sha256(record.criterion) !== sha256(criterion)
    )
      fail("ASSESSMENT_RUBRIC_MISMATCH", "Assessment no longer matches the run's pinned rubric");
    await validateRecordEvidence({ record, run, report, runStore, store: assessmentStore });
    criteria.push({
      ...structuredClone(criterion),
      outcome: record.outcome,
      assessmentId: record.assessmentId,
      reason: record.reason,
      observations: structuredClone(record.observations),
      ...(record.unassessedReason ? { unassessedReason: record.unassessedReason } : {}),
      ...(record.questionIds ? { questionIds: structuredClone(record.questionIds) } : {}),
    });
  }
  const assessed = criteria.filter((criterion) => criterion.assessmentId !== null).length;
  const required = criteria.filter((criterion) => criterion.required);
  const requiredIncomplete = required.some(
    (criterion) => criterion.outcome === "unassessed" || criterion.outcome === "out-of-scope",
  );
  const qualityOutcome = criteria.some((criterion) => criterion.outcome === "finding")
    ? "findings"
    : requiredIncomplete
      ? "unassessed"
      : "clear";
  return {
    perspective: perspectiveSummary,
    coverage: {
      status: assessed === criteria.length && !requiredIncomplete ? "complete" : "incomplete",
      assessed,
      total: criteria.length,
      requiredAssessed: required.filter(
        (criterion) =>
          criterion.assessmentId !== null && criterion.outcome !== "unassessed" && criterion.outcome !== "out-of-scope",
      ).length,
      requiredTotal: required.length,
      criteria: structuredClone(criteria),
    },
    qualityOutcome,
    criteria,
  };
}
