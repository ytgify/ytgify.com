import { retirePendingApproval } from "./retire-pending-approval.js";
import { randomUUID } from "node:crypto";

import { WorkflowError } from "./errors.js";
import { resolveLocalDogfood } from "./local-dogfood.js";
import { leasePolicyHash, selectLeasePolicy } from "./lease-policy.js";
import { verifyCatalogWorkflowSource } from "./project-workflow-catalog.js";
import { readYaml } from "./schema-registry.js";
import { resolveLaunchAuthentication } from "./run-launch.js";
import { resolveRunTarget } from "./run-target.js";
import { resolveWorkflow } from "./workflow.js";
import { resolvePlatformViewport } from "./platform-viewport.js";
import { assertCurrentFixtureUploadOrigin, pinFixtureContract, verifyFixtureBinding } from "./fixture-lifecycle.js";

function id(prefix) {
  return `${prefix}_${randomUUID().replaceAll("-", "")}`;
}

export async function launchTrainingRun(options) {
  if (Object.hasOwn(options, "approved")) {
    throw new WorkflowError("INVALID_USAGE", "Training approval cannot be supplied as an option", { exitCode: 2 });
  }
  const {
    workflowPath,
    workflowSource,
    workflowDefinition,
    platform,
    profile = "default",
    store,
    registry,
    now = () => new Date(),
    leasePolicy: leasePolicyName = "authorized-codex-browser-v1",
    leasePolicySelectedByHuman = false,
    applicationTarget,
    targetUrl,
    projectContext,
    authSessionStore,
    fixtureRecipe,
    fixtureProjectRoot,
  } = options;
  if ([workflowPath, workflowSource, workflowDefinition].filter((value) => value !== undefined).length !== 1) {
    throw new WorkflowError("INVALID_USAGE", "Training requires exactly one workflow source", { exitCode: 2 });
  }
  const source = registry.validate(
    "workflow",
    workflowDefinition ?? workflowSource?.workflow ?? (await readYaml(workflowPath)),
  );
  const resolved = resolveWorkflow(source, platform);
  registry.validate("workflow", resolved.workflow);
  const viewport = resolvePlatformViewport(resolved.workflow, platform);
  const createdAt = now().toISOString();
  const runId = id("run");
  const leasePolicy = selectLeasePolicy(leasePolicyName, {
    phase: "training",
    humanSelected: leasePolicySelectedByHuman,
  });
  const target = resolveRunTarget(resolved.workflow, { applicationTarget, targetUrl });
  const reviewedRecipe = fixtureRecipe ? registry.validate("fixtureRecipe", fixtureRecipe) : null;
  const fixtureContract = reviewedRecipe
    ? pinFixtureContract({
        recipe: reviewedRecipe,
        compatibilityVersion: resolved.workflow.fixtureRequirement?.compatibilityVersion,
        childRevision: resolved.effectiveHash,
        journeyId: source.metadata.id,
        target,
        identity: resolved.workflow.target.identity,
      })
    : null;
  const localDogfood = await resolveLocalDogfood(projectContext, target, source.metadata.id, registry);
  const authentication = await resolveLaunchAuthentication({
    identityRequirement: resolved.workflow.target.identity.requirement,
    projectContext,
    applicationTarget,
    storeRoot: store.root,
    authSessionStore,
    registry,
  });
  if (workflowSource) {
    await verifyCatalogWorkflowSource(workflowSource);
    await store.init();
  }
  const manifest = {
    schema: "agent-workflow-run-manifest/v1",
    runId,
    createdAt,
    phase: "training",
    workflowRef: {
      id: source.metadata.id,
      sourceKind: "candidate",
      ...(workflowSource ? { sourceBytesHash: workflowSource.sourceBytesHash } : {}),
      contentHash: resolved.sourceHash,
      platform,
      effectiveHash: resolved.effectiveHash,
    },
    profile,
    platform,
    target,
    identity: structuredClone(resolved.workflow.target.identity),
    ...(fixtureContract ? { fixtureContract } : {}),
    viewport,
    ...(localDogfood
      ? {
          localDogfood,
        }
      : {}),
    ...(authentication ? { authentication } : {}),
    leasePolicy,
    policyHash: leasePolicyHash(leasePolicy),
    eventSchema: "agent-workflow-run-event/v1",
  };
  if (reviewedRecipe?.kind === "repository-file") {
    if (
      manifest.target.source !== "application-target" ||
      manifest.target.environment !== "local" ||
      manifest.identity.requirement !== "anonymous" ||
      manifest.authentication ||
      manifest.localDogfood
    ) {
      throw new WorkflowError("FIXTURE_INCOMPATIBLE", "Repository file Training needs an anonymous local target", {
        exitCode: 4,
      });
    }
    assertCurrentFixtureUploadOrigin(manifest, manifest.target.effectiveUrl);
  }
  if (reviewedRecipe?.kind === "repository-file" && fixtureProjectRoot) {
    await verifyFixtureBinding(fixtureProjectRoot, manifest);
  }
  let transaction;
  try {
    transaction = await store.createRun(manifest, {
      eventId: id("evt"),
      workflow: resolved.workflow,
    });
  } catch (error) {
    if (!reviewedRecipe) throw error;
    const known = error instanceof WorkflowError;
    const failure = new WorkflowError(known ? error.code : "INTERNAL_ERROR", error?.message ?? String(error), {
      exitCode: known ? error.exitCode : 1,
      details: { ...error?.details, runId, runPublication: "unknown" },
    });
    failure.cause = error;
    throw failure;
  }
  if (reviewedRecipe?.kind === "repository-file" && fixtureProjectRoot) {
    try {
      await store.bindRepositoryFixture(runId, { projectRoot: fixtureProjectRoot });
    } catch (error) {
      const known = error instanceof WorkflowError;
      const failure = new WorkflowError(known ? error.code : "INTERNAL_ERROR", error?.message ?? String(error), {
        exitCode: known ? error.exitCode : 1,
        details: { ...error?.details, runId, runPublication: "confirmed" },
      });
      failure.cause = error;
      throw failure;
    }
  }
  const launchCard = {
    runId,
    workflow: { id: source.metadata.id, name: source.metadata.name },
    goal: source.metadata.description,
    successOutcome: source.completion.successRequires,
    platform,
    viewport,
    profile,
    start: resolved.workflow.start,
    steps: resolved.workflow.steps.map(({ id: stepId, name }) => ({ id: stepId, name })),
    safetyPolicy: "Execute requested workflow actions with validated leases and evidence.",
    leasePolicy,
    sourceHash: resolved.sourceHash,
    effectiveHash: resolved.effectiveHash,
    target,
    overrides: target.source === "human-override" ? { targetUrl: target.effectiveUrl ?? target.url } : {},
  };
  return { launchCard: { ...launchCard, ...(localDogfood ? { localDogfood } : {}) }, state: transaction.state };
}

/** Compatibility entry point: retire historical waiting state; never request approval. */
export async function approveTrainingRun({ runId, store, now = () => new Date() }) {
  const run = await store.readRun(runId);
  if (run.manifest.phase !== "training")
    throw new WorkflowError("INVALID_RUN_PHASE", "Training continuation requires a training run", { exitCode: 4 });
  return retirePendingApproval({ store, runId, now });
}
