import { constants } from "node:fs";
import { mkdir, open, readFile } from "node:fs/promises";
import { dirname, join } from "node:path";

import { revalidateLocalDogfood } from "./local-dogfood.js";
import { authSessionBindingHash, authSessionScope } from "./auth-session-store.js";
import { WorkflowError } from "./errors.js";
import { inspectScreenshotBytes } from "./evidence.js";
import { assertSafeProjectPath } from "./project-path-safety.js";
import { consumeAuthenticatedUploads, loadAuthenticatedUploads } from "./authenticated-upload-artifact.js";
import { buildRunReport } from "./run-report.js";
import { runRouteBindingId } from "./run-route-binding.js";

function reject(message, code = "CAPABILITY_UNAVAILABLE") {
  throw new WorkflowError(code, message, { exitCode: 4 });
}

async function assertNamedProfilePerspectiveTurn(store, run) {
  const perspective = run.manifest.evaluationPerspective;
  if (run.manifest.identity?.requirement !== "named-profile" || !perspective) return;
  if (!Object.hasOwn(perspective, "sessionPredecessorRunId")) {
    reject("Named-profile perspective session order is not pinned");
  }
  const predecessorRunId = perspective.sessionPredecessorRunId;
  if (predecessorRunId === null) return;
  let predecessor;
  try {
    predecessor = await store.readRun(predecessorRunId);
  } catch {
    reject("Previous named-profile perspective member is unavailable");
  }
  let report;
  try {
    report = await buildRunReport(store, predecessorRunId, { skipPerspective: true });
  } catch {
    reject("Previous named-profile perspective member has not completed cleanup");
  }
  if (
    predecessor.manifest.evaluationPerspective?.batchId !== perspective.batchId ||
    predecessor.manifest.authentication?.sessionBindingHash !== run.manifest.authentication?.sessionBindingHash ||
    !["completed", "failed", "blocked"].includes(report.status) ||
    report.cleanupOutcome !== "passed" ||
    report.integrity.cleanup !== "verified"
  ) {
    reject("Previous named-profile perspective member has not completed cleanup");
  }
}

export function sanitizeExecutionDiagnostic(value) {
  if (!["preparation", "action", "readiness", "capture"].includes(value?.phase)) return undefined;
  if (value.phase === "action") {
    if (!Number.isInteger(value.actionIndex) || value.actionIndex < 0 || value.actionIndex > 2) return undefined;
    const diagnostic = { phase: value.phase, actionIndex: value.actionIndex };
    if (
      ["ambiguity", "actionability", "interception", "navigation", "timeout", "unknown"].includes(value.failureCategory)
    )
      diagnostic.failureCategory = value.failureCategory;
    const locatorCountIsValid =
      Number.isInteger(value.locatorCount) && value.locatorCount >= 0 && value.locatorCount <= 2;
    if (locatorCountIsValid) diagnostic.locatorCount = value.locatorCount;
    if (value.locatorCount === 1 && typeof value.visible === "boolean") diagnostic.visible = value.visible;
    if (value.locatorCount === 1 && typeof value.enabled === "boolean") diagnostic.enabled = value.enabled;
    return diagnostic;
  }
  return { phase: value.phase };
}

export function compileAuthenticatedActions(
  actions,
  startUrl,
  { uploads = new Map(), routeBindings = {}, validateOnly = false } = {},
) {
  if (!Array.isArray(actions) || !actions.length || actions.length > 3) reject("Unsupported action batch");
  const uploadInputNames = actions
    .filter((action) => action.kind === "upload-file")
    .map((action) => action.inputRef?.name);
  if (new Set(uploadInputNames).size !== uploadInputNames.length)
    reject("Authenticated upload input names must be unique within a batch");
  return actions.map((action) => {
    if (action.kind === "upload-file") {
      const target = /^label:([^\r\n]{1,200})$/u.exec(action.target ?? "");
      const input = action.inputRef;
      if (
        !target ||
        !input ||
        Object.keys(input).length !== 6 ||
        input.kind !== "synthetic-file" ||
        !/^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$/u.test(input.name ?? "") ||
        !/^dogfood-[A-Za-z0-9][A-Za-z0-9._-]{0,99}\.csv$/u.test(input.filename ?? "") ||
        !Number.isSafeInteger(input.sizeBytes) ||
        input.sizeBytes < 1 ||
        input.sizeBytes > 1024 * 1024 ||
        input.mimeType !== "text/csv" ||
        !/^sha256:[a-f0-9]{64}$/u.test(input.sha256 ?? "") ||
        action.textInput
      )
        reject("Only a runner-approved synthetic file and exact named upload control are supported");
      if (validateOnly) return { kind: "upload", label: target[1], inputName: input.name };
      const approved = uploads.get(input.name);
      if (
        !approved ||
        approved.record.filename !== input.filename ||
        approved.record.sizeBytes !== input.sizeBytes ||
        approved.record.mimeType !== input.mimeType ||
        approved.record.sha256 !== input.sha256
      )
        reject("The approved upload artifact is unavailable");
      return {
        kind: "upload",
        label: target[1],
        file: {
          name: approved.record.filename,
          mimeType: approved.record.mimeType,
          buffer: approved.bytes,
        },
      };
    }
    if (action.inputRef) reject("Authenticated execution does not accept unrestricted input references");
    if (action.textInput) {
      const input = action.textInput;
      const field = /^role:(textbox|searchbox):([^\r\n]{1,200})$/u.exec(action.target ?? "");
      if (
        action.kind !== "enter-text" ||
        !field ||
        Object.keys(input).length !== 2 ||
        input.kind !== "synthetic" ||
        typeof input.value !== "string" ||
        input.value.length > 120 ||
        /[\r\n]/u.test(input.value) ||
        !/^(?:dogfood-[A-Za-z0-9 -]+)?$/u.test(input.value)
      )
        reject("Only bounded synthetic text for an exact named field is supported");
      return { kind: "fill", role: field[1], name: field[2], value: input.value };
    }
    if (action.kind === "observe") return { kind: "observe" };
    if (action.kind === "navigate" && action.target === "declared-start-url") {
      return { kind: "navigate", url: startUrl };
    }
    const bindingId = action.kind === "navigate" ? runRouteBindingId(action.target) : null;
    if (bindingId) {
      const binding = routeBindings?.[bindingId];
      if (!binding || typeof binding.path !== "string")
        reject("The approved action has no supported authenticated executor");
      const resolvedUrl = new URL(binding.path, startUrl);
      if (resolvedUrl.origin !== new URL(startUrl).origin)
        reject("The approved action has no supported authenticated executor");
      return {
        kind: "navigate",
        url: resolvedUrl.href,
        readiness: { routePath: binding.path, ...binding.readiness },
      };
    }
    const match = /^role:(button|link|radio|menuitem):([^\r\n]{1,200})$/u.exec(action.target ?? "");
    if (action.kind === "activate-control" && match) return { kind: "click", role: match[1], name: match[2] };
    reject("The approved action has no supported authenticated executor");
  });
}

export function validateAuthenticatedActions(actions, { routeBindings = {} } = {}) {
  return compileAuthenticatedActions(actions, "https://workflows.invalid/", { routeBindings, validateOnly: true });
}

export function validateBrowserExecutionRequest(request) {
  const keys = ["runId", "hostId", "leaseId", "slotId", "expectedRevision"];
  if (!request || Object.keys(request).length !== keys.length || keys.some((key) => !Object.hasOwn(request, key))) {
    reject("Browser execution accepts only run, host, lease, slot, and revision", "INVALID_REQUEST");
  }
  for (const [key, prefix] of [
    ["runId", "run"],
    ["hostId", "host"],
    ["leaseId", "lease"],
    ["slotId", "slot"],
  ]) {
    if (!new RegExp(`^${prefix}_[A-Za-z0-9_-]+$`, "u").test(request[key]))
      reject("Invalid execution identity", "INVALID_REQUEST");
  }
  if (!Number.isSafeInteger(request.expectedRevision) || request.expectedRevision < 0)
    reject("Invalid revision", "INVALID_REQUEST");
  return request;
}

function executionPath(run, leaseId) {
  if (!/^lease_[A-Za-z0-9_-]+$/u.test(leaseId)) reject("Invalid lease");
  return join(run.directory, "adapter", "browser-executions", `${leaseId}.json`);
}

async function durableExclusive(path, bytes) {
  const handle = await open(
    path,
    constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW,
    0o600,
  );
  try {
    await handle.writeFile(bytes);
    await handle.sync();
  } finally {
    await handle.close();
  }
  const directory = await open(dirname(path), "r");
  try {
    await directory.sync();
  } finally {
    await directory.close();
  }
}

/** Read only bounded recovery information; never infer that an attempted action is safe to repeat. */
export async function authenticatedExecutionRecovery(run) {
  const leaseId = run.state.activeLease?.leaseId ?? run.state.uncertainLeaseId;
  if (!run.manifest.authentication || !leaseId) return null;
  const path = executionPath(run, leaseId);
  await assertSafeProjectPath(run.directory, path, "Browser execution receipt", {
    finalType: "file",
    allowMissing: true,
  });
  let record;
  try {
    record = JSON.parse(await readFile(path, "utf8"));
  } catch (error) {
    if (error.code === "ENOENT") return null;
    if (!(error instanceof SyntaxError)) throw error;
  }
  if (record?.status === "completed" && record.leaseId === leaseId) {
    return "Browser execution completed. Do not execute this lease again. Retrieve its existing screenshot slot, register the staged evidence, and commit while the lease is valid. If expired, inspect and reconcile without replaying the action.";
  }
  if (
    run.state.activeLease &&
    record?.status === "started" &&
    record.leaseId === leaseId &&
    !sanitizeExecutionDiagnostic(record.executionDiagnostic)
  ) {
    return "A browser execution attempt is recorded and may still be running. Wait for the current command to finish; do not start another execution. If the command was interrupted, inspect and use the supported interruption recovery path without replaying a possibly completed action.";
  }
  return run.state.activeLease
    ? "Browser execution is uncertain although the lease remains active. Do not retry or heartbeat it. Use run emergency-stop with the current revision and lease, then inspect and reconcile; alternatively inspect after the reported lease expiry. Classify not-executed only with evidence that no action occurred."
    : "Browser execution is uncertain. Reconcile the uncertain lease using observed evidence; never replay a possibly completed action. If unresolved, safely stop and start a fresh run after checking owned fixture cleanup.";
}

export async function assertAuthenticatedExecutionCompleted(run, leaseId) {
  if (!run.manifest.authentication) return;
  const path = executionPath(run, leaseId);
  await assertSafeProjectPath(run.directory, path, "Browser execution receipt", {
    finalType: "file",
    allowMissing: true,
  });
  try {
    const record = JSON.parse(await readFile(path, "utf8"));
    if (record.status !== "completed" || record.leaseId !== leaseId)
      reject("Browser execution is uncertain; reconcile before continuing", "RECONCILIATION_REQUIRED");
  } catch (error) {
    if (error.code === "ENOENT")
      reject("Authenticated browser execution has no durable completion receipt", "RECONCILIATION_REQUIRED");
    throw error;
  }
}

/** Execute once, using only durable runner bindings, never caller-supplied browser actions. */
export async function executeAuthenticatedBrowser({
  store,
  request,
  sessionService,
  projectContext,
  now = () => new Date(),
}) {
  validateBrowserExecutionRequest(request);
  return store.withExclusiveRun(request.runId, async (run) => {
    const lease = run.state.activeLease;
    const slot = run.state.evidenceSlots?.[request.slotId];
    if (run.state.revision !== request.expectedRevision) reject("Run revision changed", "REVISION_CONFLICT");
    if (
      !["active", "cleanup"].includes(run.state.status) ||
      run.state.activeOptionalAuthorization ||
      run.state.ownerHostId !== request.hostId ||
      lease?.hostId !== request.hostId ||
      lease?.leaseId !== request.leaseId ||
      !run.manifest.authentication ||
      !/^usersession_[A-Za-z0-9_-]+$/u.test(lease.target?.adapterSessionId ?? "")
    )
      reject("Execution does not match the active authenticated lease");
    if (
      !slot ||
      slot.hostId !== request.hostId ||
      slot.runId !== request.runId ||
      slot.leaseId !== lease.leaseId ||
      slot.leaseRequestId !== run.state.activeLeaseRequestId ||
      slot.optionalHandlerId ||
      slot.type !== "screenshot" ||
      slot.fullPage !== false ||
      JSON.stringify(slot.viewport) !== JSON.stringify(run.manifest.viewport)
    )
      reject("Screenshot slot does not match the lease");
    await assertNamedProfilePerspectiveTurn(store, run);
    const checkTime = () => {
      const remaining =
        Math.min(Date.parse(lease.expiresAt), Date.parse(lease.hardExpiresAt), Date.parse(slot.expiresAt)) -
        now().valueOf();
      if (!Number.isFinite(remaining) || remaining <= 0) reject("Execution lease expired", "LEASE_EXPIRED");
      return remaining;
    };
    checkTime();
    const target = projectContext?.applicationTargets?.inventory?.find(
      (item) => item.id === run.manifest.authentication.targetId,
    );
    const pinned = run.manifest.target;
    if (
      !target ||
      target.authentication?.mode !== "user-session" ||
      target.provenance !== "configured-v1" ||
      pinned.source !== "application-target" ||
      pinned.provenance !== "configured-v1" ||
      target.id !== pinned.targetId ||
      target.environment !== pinned.environment ||
      new URL(target.baseUrl).origin !== new URL(pinned.canonicalUrl).origin
    )
      reject("Configured target no longer matches the run");
    const scope = authSessionScope(projectContext, target);
    const record = await sessionService.verify(scope);
    if (
      record.state !== "ready" ||
      record.targetId !== target.id ||
      !record.lastVerifiedAt ||
      record.markerHash !== run.manifest.authentication.markerHash ||
      (record.sessionBindingHash ?? authSessionBindingHash(record)) !==
        run.manifest.authentication.sessionBindingHash ||
      record.browserSessionRef !== lease.target.adapterSessionId
    )
      reject("Authenticated session changed");
    const uploads = await loadAuthenticatedUploads(run, {
      hostId: request.hostId,
      leaseId: request.leaseId,
      expectedRevision: request.expectedRevision,
      now,
    });
    const actions = compileAuthenticatedActions(lease.proposal.actions, pinned.effectiveUrl, {
      uploads,
      routeBindings: run.state.routeBindings,
    });
    const path = executionPath(run, lease.leaseId);
    await assertSafeProjectPath(run.directory, path, "Browser execution receipt", {
      finalType: "file",
      allowMissing: true,
    });
    await mkdir(dirname(path), { recursive: true });
    const expectedStaging = join(run.directory, "adapter", "evidence-slots", `${slot.slotId}.screenshot`);
    if (slot.stagingPath !== expectedStaging) reject("Invalid runner screenshot path");
    await assertSafeProjectPath(run.directory, expectedStaging, "Screenshot slot", {
      finalType: "file",
      allowMissing: true,
    });
    checkTime();
    await revalidateLocalDogfood(projectContext, run.manifest, store.registry);
    try {
      await durableExclusive(path, JSON.stringify({ status: "started", leaseId: lease.leaseId }));
    } catch (error) {
      if (error.code === "EEXIST") {
        await consumeAuthenticatedUploads(uploads, { outcome: "uncertain", now });
        reject(
          (await authenticatedExecutionRecovery(run)) ?? "This lease was already attempted; inspect before continuing",
          "RECONCILIATION_REQUIRED",
        );
      }
      throw error;
    }
    // A crash or any failure leaves a durable started record and may not replay.
    let diagnostic = { phase: "preparation" };
    let bytes;
    const hasBoundNavigation = actions.some((action) => action.kind === "navigate" && action.readiness);
    const operationLimit = hasBoundNavigation ? 15_000 : 5_000;
    const timeout = Math.max(
      1,
      Math.min(
        operationLimit,
        Date.parse(lease.expiresAt) - now().valueOf(),
        Date.parse(lease.hardExpiresAt) - now().valueOf(),
        Date.parse(slot.expiresAt) - now().valueOf(),
      ),
    );
    try {
      bytes = await sessionService.adapter.executeBatch({
        sessionRef: record.browserSessionRef,
        origin: scope.origin,
        actions,
        viewport: run.manifest.viewport,
        checkTime,
        onProgress: (value) => {
          diagnostic = sanitizeExecutionDiagnostic(value) ?? diagnostic;
        },
        timeout,
      });
    } catch {
      await consumeAuthenticatedUploads(uploads, { outcome: "uncertain", now }).catch(() => {});
      const receipt = await open(path, constants.O_WRONLY | constants.O_TRUNC | constants.O_NOFOLLOW);
      try {
        await receipt.writeFile(
          JSON.stringify({ status: "started", leaseId: lease.leaseId, executionDiagnostic: diagnostic }),
        );
        await receipt.sync();
      } finally {
        await receipt.close();
      }
      throw new WorkflowError(
        "RECONCILIATION_REQUIRED",
        "Browser execution failed. Do not retry this lease. Inspect, then use run emergency-stop with its current revision and lease to reconcile without waiting for expiry.",
        {
          exitCode: 4,
          details: { executionDiagnostic: diagnostic },
        },
      );
    }
    await consumeAuthenticatedUploads(uploads, { outcome: "executed", now });
    checkTime();
    inspectScreenshotBytes(bytes, slot.maximumBytes);
    await durableExclusive(expectedStaging, bytes);
    checkTime();
    const receipt = await open(path, constants.O_WRONLY | constants.O_TRUNC | constants.O_NOFOLLOW);
    try {
      await receipt.writeFile(JSON.stringify({ status: "completed", leaseId: lease.leaseId }));
      await receipt.sync();
    } finally {
      await receipt.close();
    }
    return {
      status: "completed",
      runId: request.runId,
      leaseId: lease.leaseId,
      slotId: slot.slotId,
      revision: run.state.revision,
    };
  });
}
