import { WorkflowError } from "./errors.js";
import { sha256, stableStringify } from "./stable-json.js";

export const MAX_ROLLING_LEASE_SECONDS = 120;
export const MAX_HARD_LEASE_SECONDS = 300;

const POLICIES = Object.freeze({
  standard: Object.freeze({
    name: "standard",
    rollingSeconds: 30,
    hardSeconds: 120,
    heartbeatThresholdSeconds: 15,
  }),
  "supervised-codex-browser": Object.freeze({
    name: "supervised-codex-browser",
    rollingSeconds: 120,
    hardSeconds: 300,
    heartbeatThresholdSeconds: 90,
  }),
  "authorized-codex-browser-v1": Object.freeze({
    name: "authorized-codex-browser-v1",
    rollingSeconds: 120,
    hardSeconds: 300,
    heartbeatThresholdSeconds: 90,
  }),
  "human-approved-codex-browser-v1": Object.freeze({
    name: "human-approved-codex-browser-v1",
    rollingSeconds: 120,
    hardSeconds: 300,
    heartbeatThresholdSeconds: 90,
  }),
  "routine-codex-browser-v1": Object.freeze({
    name: "routine-codex-browser-v1",
    rollingSeconds: 120,
    hardSeconds: 300,
    heartbeatThresholdSeconds: 90,
  }),
});

function policyError(message) {
  return new WorkflowError("VALIDATION_FAILED", message, { exitCode: 3 });
}

function canonicalPolicy(name) {
  const policy = POLICIES[name];
  if (!policy) throw policyError(`Unknown lease policy: ${name}`);
  return structuredClone(policy);
}

export function selectLeasePolicy(name = "standard", { phase = "training" } = {}) {
  const policy = canonicalPolicy(name);
  if (name === "authorized-codex-browser-v1" && !["training", "replay", "evaluation"].includes(phase))
    throw policyError("authorized-codex-browser-v1 requires training, replay, or evaluation");
  if (policy.name === "supervised-codex-browser" && phase !== "training") {
    throw policyError("supervised-codex-browser requires a training run");
  }
  if (policy.name === "human-approved-codex-browser-v1" && !["replay", "evaluation"].includes(phase)) {
    throw policyError("human-approved-codex-browser-v1 requires a replay or evaluation run");
  }
  if (policy.name === "routine-codex-browser-v1" && phase !== "evaluation") {
    throw policyError("routine-codex-browser-v1 is runner-selected only for routine evaluation");
  }
  return policy;
}

export function leasePolicyForManifest(manifest) {
  if (!manifest.leasePolicy) return canonicalPolicy("standard");
  const expected = canonicalPolicy(manifest.leasePolicy.name);
  if (
    stableStringify(manifest.leasePolicy) !== stableStringify(expected) ||
    expected.rollingSeconds > MAX_ROLLING_LEASE_SECONDS ||
    expected.hardSeconds > MAX_HARD_LEASE_SECONDS ||
    expected.heartbeatThresholdSeconds >= expected.rollingSeconds ||
    (expected.name === "authorized-codex-browser-v1" &&
      !["training", "replay", "evaluation"].includes(manifest.phase)) ||
    (expected.name === "supervised-codex-browser" && manifest.phase !== "training") ||
    (expected.name === "human-approved-codex-browser-v1" && !["replay", "evaluation"].includes(manifest.phase)) ||
    (expected.name === "routine-codex-browser-v1" && manifest.phase !== "evaluation")
  ) {
    throw policyError("Pinned lease policy is not a canonical finite policy for this phase");
  }
  return expected;
}

export function leasePolicyHash(policy) {
  return sha256({ policy: "reversible-ui/v1", leasePolicy: policy });
}

export function assertLeasePolicySnapshot(snapshot, manifest) {
  const expected = leasePolicyForManifest(manifest);
  if (snapshot && stableStringify(snapshot) !== stableStringify(expected)) {
    throw policyError("Action lease policy snapshot differs from the pinned manifest policy");
  }
  if (manifest.leasePolicy && !snapshot) {
    throw policyError("New pinned manifests require a lease policy snapshot on every action lease");
  }
  return expected;
}

export function deriveLeaseTimes(authorizedAt, policy) {
  const start = new Date(authorizedAt).valueOf();
  if (!Number.isFinite(start)) throw policyError("Lease authorization time is invalid");
  return {
    expiresAt: new Date(start + policy.rollingSeconds * 1000).toISOString(),
    hardExpiresAt: new Date(start + policy.hardSeconds * 1000).toISOString(),
  };
}

export function deriveHeartbeatExpiry(heartbeatAt, hardExpiresAt, policy) {
  const now = new Date(heartbeatAt).valueOf();
  const hard = new Date(hardExpiresAt).valueOf();
  if (!Number.isFinite(now) || !Number.isFinite(hard)) throw policyError("Heartbeat time is invalid");
  return new Date(Math.min(now + policy.rollingSeconds * 1000, hard)).toISOString();
}
