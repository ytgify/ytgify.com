/* eslint-disable max-lines -- Fixture receipts use the same run lock and atomic write boundary as run-control state. */
import { execFile as execFileCallback } from "node:child_process";
import { randomUUID } from "node:crypto";
import { constants } from "node:fs";
import { link, lstat, mkdir, open, readFile, readdir, rename, unlink, writeFile } from "node:fs/promises";
import { dirname, join, relative, resolve, sep } from "node:path";
import { promisify } from "node:util";

import { WorkflowError } from "./errors.js";
import { verifyDownload } from "./download-evidence.js";
import {
  assertSafeDirectory,
  artifactIdForEvidence,
  evidenceId,
  preserveVerifiedScreenshot,
  readRegisteredArtifact,
  readStagedEvidence,
  readPreservedEvidence,
  sha256Bytes,
} from "./evidence.js";
import { replayRunControl } from "./run-control.js";
import { sha256 } from "./stable-json.js";
import {
  assertCurrentFixtureUploadOrigin,
  assertFixtureHandoff,
  createFixtureInstance,
  matchesRepositoryFixtureUpload,
  verifyFixtureBinding,
} from "./fixture-lifecycle.js";

const RUN_ID_PATTERN = /^run_[A-Za-z0-9_-]+$/;
const RUN_ENTRY_PATTERN = /^runs\/[0-9]{4}-[0-9]{2}-[0-9]{2}\/run_[A-Za-z0-9_-]+$/;
const execFile = promisify(execFileCallback);

async function processStartMarker(pid) {
  try {
    const { stdout } = await execFile("ps", ["-o", "lstart=", "-p", String(pid)], {
      timeout: 3000,
      env: { ...process.env, LC_ALL: "C", TZ: "UTC" },
    });
    return stdout.trim().replace(/\s+/gu, " ") || null;
  } catch {
    return null;
  }
}

async function readRegularFileNoFollow(path, message) {
  const directory = dirname(path);
  const directoryEntry = await lstat(directory);
  if (directoryEntry.isSymbolicLink() || !directoryEntry.isDirectory()) {
    throw new WorkflowError("VALIDATION_FAILED", message, { exitCode: 3 });
  }
  const entry = await lstat(path);
  if (entry.isSymbolicLink() || !entry.isFile()) {
    throw new WorkflowError("VALIDATION_FAILED", message, { exitCode: 3 });
  }
  let handle;
  try {
    handle = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW);
    const opened = await handle.stat();
    if (!opened.isFile() || opened.dev !== entry.dev || opened.ino !== entry.ino || opened.size !== entry.size) {
      throw new WorkflowError("VALIDATION_FAILED", message, { exitCode: 3 });
    }
    return await handle.readFile("utf8");
  } catch (error) {
    if (error.code === "ELOOP") {
      throw new WorkflowError("VALIDATION_FAILED", message, { exitCode: 3 });
    }
    throw error;
  } finally {
    await handle?.close();
  }
}

function validateRunIndex(index) {
  if (!index || Array.isArray(index) || typeof index !== "object") {
    throw new WorkflowError("RUN_INDEX_CORRUPT", "Run index is not an object", { exitCode: 3 });
  }
  for (const [runId, entry] of Object.entries(index)) {
    if (
      !RUN_ID_PATTERN.test(runId) ||
      typeof entry !== "string" ||
      !RUN_ENTRY_PATTERN.test(entry) ||
      entry.split("/").at(-1) !== runId
    ) {
      throw new WorkflowError("RUN_INDEX_CORRUPT", "Run index contains an invalid entry", {
        exitCode: 3,
      });
    }
  }
  return index;
}

function assertInside(root, path) {
  const resolvedRoot = resolve(root);
  const resolvedPath = resolve(path);
  if (resolvedPath !== resolvedRoot && !resolvedPath.startsWith(`${resolvedRoot}${sep}`)) {
    throw new WorkflowError("PATH_TRAVERSAL", "Resolved path escapes the run-control store", {
      exitCode: 3,
    });
  }
  return resolvedPath;
}

async function atomicWriteJson(path, value, { exclusive = false } = {}) {
  const temporary = `${path}.${randomUUID()}.tmp`;
  const handle = await open(temporary, "wx");
  try {
    await handle.writeFile(`${JSON.stringify(value, null, 2)}\n`);
    await handle.sync();
  } finally {
    await handle.close();
  }
  try {
    if (exclusive) await link(temporary, path);
    else await rename(temporary, path);
    await syncDirectory(dirname(path));
  } finally {
    await unlink(temporary).catch(() => {});
  }
}

async function syncDirectory(path) {
  const handle = await open(path, "r");
  try {
    await handle.sync();
  } finally {
    await handle.close();
  }
}

async function pathExists(path) {
  try {
    await lstat(path);
    return true;
  } catch (error) {
    if (error.code === "ENOENT") return false;
    throw error;
  }
}

async function acquireLock(path) {
  try {
    const handle = await open(path, "wx");
    await handle.writeFile(`${JSON.stringify({ acquiredAt: new Date().toISOString() })}\n`);
    return handle;
  } catch (error) {
    if (error.code === "EEXIST") {
      throw new WorkflowError("RUN_STORE_LOCKED", "Run store is locked by another writer", {
        exitCode: 6,
      });
    }
    throw error;
  }
}

async function withLock(path, operation) {
  const handle = await acquireLock(path);
  try {
    return await operation();
  } finally {
    await handle.close();
    await unlink(path).catch(() => {});
  }
}

async function withFixtureRecoveryClaim(root, operation, afterClaim) {
  const claimName = `.fixture-recovery.${randomUUID()}.lock`;
  const claimPath = join(root, claimName);
  const temporary = `${claimPath}.tmp`;
  const handle = await open(temporary, "wx");
  try {
    await handle.writeFile(
      `${JSON.stringify({ pid: process.pid, processStart: await processStartMarker(process.pid), acquiredAt: new Date().toISOString() })}\n`,
    );
    await handle.sync();
  } finally {
    await handle.close();
  }
  let published = false;
  try {
    await link(temporary, claimPath);
    published = true;
    await syncDirectory(root);
    await afterClaim?.();
    for (const name of await readdir(root)) {
      if (!name.startsWith(".fixture-recovery.") || !name.endsWith(".lock") || name === claimName) continue;
      let owner;
      try {
        owner = JSON.parse(await readRegularFileNoFollow(join(root, name), "Fixture recovery claim is invalid"));
      } catch (error) {
        if (error.code === "ENOENT") continue;
        throw new WorkflowError("RUN_STORE_LOCKED", "Fixture recovery claim ownership is uncertain", { exitCode: 6 });
      }
      if (!Number.isSafeInteger(owner.pid) || owner.pid < 1)
        throw new WorkflowError("RUN_STORE_LOCKED", "Fixture recovery claim ownership is uncertain", { exitCode: 6 });
      try {
        process.kill(owner.pid, 0);
      } catch (error) {
        if (error.code === "ESRCH") {
          await unlink(join(root, name)).catch(() => {});
          continue;
        }
      }
      const currentStart = await processStartMarker(owner.pid);
      if (owner.processStart && currentStart && owner.processStart !== currentStart) {
        await unlink(join(root, name)).catch(() => {});
        continue;
      }
      throw new WorkflowError("RUN_STORE_LOCKED", "Fixture recovery is held by another process", { exitCode: 6 });
    }
    return await operation();
  } finally {
    try {
      if (published) await unlink(claimPath);
    } finally {
      await unlink(temporary).catch(() => {});
    }
  }
}

function receiptFromEvent(event) {
  return {
    schema: "agent-workflow-run-receipt/v1",
    receiptId: event.transaction.receiptId,
    requestId: event.transaction.requestId,
    requestHash: event.transaction.requestHash,
    resultHash: event.transaction.resultHash,
    operation: event.transaction.operation,
    runId: event.runId,
    eventId: event.eventId,
    previousRevision: event.revision - 1,
    revision: event.revision,
    recordedAt: event.occurredAt,
  };
}

export class RunControlStore {
  constructor(root, { registry, evidenceInterruption } = {}) {
    this.root = resolve(root);
    this.runsRoot = join(this.root, "runs");
    this.indexPath = join(this.root, "index.json");
    this.registry = registry;
    this.evidenceInterruption = evidenceInterruption;
  }

  async evidenceCutPoint(name, context = {}) {
    await this.evidenceInterruption?.(name, context);
  }

  async init() {
    await mkdir(this.runsRoot, { recursive: true });
    try {
      await writeFile(this.indexPath, "{}\n", { flag: "wx" });
    } catch (error) {
      if (error.code !== "EEXIST") throw error;
    }
    return this;
  }

  validate(value) {
    if (this.registry) this.registry.validate("runControl", value);
    return value;
  }

  async readIndex() {
    let index;
    try {
      index = JSON.parse(await readRegularFileNoFollow(this.indexPath, "Run index is not a regular file"));
    } catch (error) {
      if (error instanceof SyntaxError) {
        throw new WorkflowError("RUN_INDEX_CORRUPT", "Run index is not valid JSON", { exitCode: 3 });
      }
      throw error;
    }
    return validateRunIndex(index);
  }

  async listRunIds() {
    try {
      return Object.keys(await this.readIndex());
    } catch (error) {
      if (error.code === "ENOENT") return [];
      throw error;
    }
  }

  async locateRun(runId) {
    if (!RUN_ID_PATTERN.test(runId)) {
      throw new WorkflowError("INVALID_RUN_ID", `Invalid run ID: ${runId}`, { exitCode: 3 });
    }
    const entry = (await this.readIndex())[runId];
    if (!entry) {
      throw new WorkflowError("RUN_NOT_FOUND", `Run not found: ${runId}`, { exitCode: 8 });
    }
    return assertInside(this.root, join(this.root, entry));
  }

  async createRun(manifest, { eventId, occurredAt = manifest.createdAt, workflow = null } = {}) {
    this.validate(manifest);
    const date = new Date(manifest.createdAt);
    if (Number.isNaN(date.valueOf())) {
      throw new WorkflowError("INVALID_DATE", `Invalid run creation date: ${manifest.createdAt}`, {
        exitCode: 3,
      });
    }
    if (!eventId) {
      throw new WorkflowError("EVENT_ID_REQUIRED", "Creating a run requires an event ID", {
        exitCode: 2,
      });
    }

    const directory = assertInside(this.root, join(this.runsRoot, date.toISOString().slice(0, 10), manifest.runId));
    const createdEvent = this.validate({
      schema: "agent-workflow-run-event/v1",
      eventId,
      runId: manifest.runId,
      sequence: 1,
      revision: 0,
      occurredAt,
      type: "run.created",
      source: "runner",
      payload: {},
    });
    // Validate semantic launch invariants before publishing any durable run files.
    const state = replayRunControl(manifest, [createdEvent], workflow);

    return withLock(join(this.root, ".index.lock"), async () => {
      const index = await this.readIndex();
      if (index[manifest.runId]) {
        throw new WorkflowError("RUN_EXISTS", `Run already exists: ${manifest.runId}`, {
          exitCode: 4,
        });
      }

      await mkdir(dirname(directory), { recursive: true });
      try {
        await mkdir(directory);
      } catch (error) {
        if (error.code === "EEXIST") {
          throw new WorkflowError("RUN_EXISTS", `Run already exists: ${manifest.runId}`, {
            exitCode: 4,
          });
        }
        throw error;
      }
      await mkdir(join(directory, "evidence"));
      await mkdir(join(directory, "adapter"));
      await mkdir(join(directory, "adapter", "evidence-slots"));
      await mkdir(join(directory, "receipts"));
      await mkdir(join(directory, "protocol-responses"));
      await mkdir(join(directory, "registered-evidence"));
      await atomicWriteJson(join(directory, "manifest.json"), manifest);
      if (workflow) await atomicWriteJson(join(directory, "workflow.json"), workflow);
      const eventHandle = await open(join(directory, "events.jsonl"), "wx");
      try {
        await eventHandle.writeFile(`${JSON.stringify(createdEvent)}\n`);
        await eventHandle.sync();
      } finally {
        await eventHandle.close();
      }

      index[manifest.runId] = relative(this.root, directory);
      await atomicWriteJson(this.indexPath, index);
      return {
        directory,
        manifest,
        workflow,
        events: [createdEvent],
        state,
      };
    });
  }

  async readEvents(directory) {
    const safeDirectory = assertInside(this.root, directory);
    const content = await readFile(join(safeDirectory, "events.jsonl"), "utf8");
    return content
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter(Boolean)
      .map((line) => JSON.parse(line));
  }

  async readRun(runId) {
    const directory = await this.locateRun(runId);
    const manifest = this.validate(JSON.parse(await readFile(join(directory, "manifest.json"), "utf8")));
    const events = await this.readEvents(directory);
    let workflow = null;
    try {
      workflow = JSON.parse(await readFile(join(directory, "workflow.json"), "utf8"));
      if (this.registry) this.registry.validate("workflow", workflow);
      const actualEffectiveHash =
        manifest.workflowRef?.effectiveHashVersion === "platform-v2"
          ? sha256({ platform: manifest.platform, workflow })
          : sha256(workflow);
      if (manifest.workflowRef && actualEffectiveHash !== manifest.workflowRef.effectiveHash) {
        throw new WorkflowError("WORKFLOW_HASH_MISMATCH", "Pinned workflow content does not match the run manifest", {
          exitCode: 3,
        });
      }
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
    }
    for (const event of events) this.validate(event);
    return {
      directory,
      manifest,
      workflow,
      events,
      state: replayRunControl(manifest, events, workflow),
    };
  }

  /** Serialize external execution with all journal writers for this run. */
  async withExclusiveRun(runId, operation) {
    const directory = await this.locateRun(runId);
    return withLock(join(directory, ".write.lock"), async () => operation(await this.readRun(runId)));
  }

  /** Serialize fixture operations and handoffs across every run in this store. */
  async withExclusiveFixtures(operation) {
    const lockPath = join(this.root, ".fixture.lock");
    const temporary = `${lockPath}.${randomUUID()}.tmp`;
    const handle = await open(temporary, "wx");
    try {
      await handle.writeFile(
        `${JSON.stringify({ pid: process.pid, processStart: await processStartMarker(process.pid), acquiredAt: new Date().toISOString() })}\n`,
      );
      await handle.sync();
    } finally {
      await handle.close();
    }
    let published = false;
    try {
      await this.evidenceCutPoint("fixture-lock-before-publish", { lockPath });
      try {
        await link(temporary, lockPath);
      } catch (error) {
        if (error.code !== "EEXIST") throw error;
        await withFixtureRecoveryClaim(
          this.root,
          async () => {
            let owner;
            try {
              owner = JSON.parse(await readRegularFileNoFollow(lockPath, "Fixture lock is not a regular file"));
            } catch {
              throw new WorkflowError("RUN_STORE_LOCKED", "Fixture lock ownership is uncertain", { exitCode: 6 });
            }
            if (!Number.isSafeInteger(owner.pid) || owner.pid < 1)
              throw new WorkflowError("RUN_STORE_LOCKED", "Fixture lock ownership is uncertain", { exitCode: 6 });
            let ownerAlive = true;
            try {
              process.kill(owner.pid, 0);
            } catch (probeError) {
              if (probeError.code !== "ESRCH") throw probeError;
              ownerAlive = false;
            }
            if (ownerAlive) {
              const currentStart = await processStartMarker(owner.pid);
              if (!owner.processStart || !currentStart || owner.processStart === currentStart)
                throw new WorkflowError("RUN_STORE_LOCKED", "Fixture store is held by a live process", { exitCode: 6 });
            }
            await unlink(lockPath);
            await this.evidenceCutPoint("fixture-lock-after-stale-unlink", { lockPath });
            try {
              await link(temporary, lockPath);
              published = true;
            } catch (publishError) {
              if (publishError.code !== "EEXIST") throw publishError;
              throw new WorkflowError("RUN_STORE_LOCKED", "Fixture store is held by another writer", { exitCode: 6 });
            }
          },
          () => this.evidenceCutPoint("fixture-recovery-after-claim"),
        );
      }
      published = true;
      await syncDirectory(this.root);
      return await operation();
    } finally {
      try {
        if (published) await unlink(lockPath);
      } finally {
        await unlink(temporary).catch(() => {});
      }
    }
  }

  async readFixtureTransitions(runId) {
    const directory = await this.locateRun(runId);
    let content;
    try {
      content = await readRegularFileNoFollow(
        join(directory, "fixture-transitions.jsonl"),
        "Fixture journal is not a regular file",
      );
    } catch (error) {
      if (error.code === "ENOENT") return [];
      throw error;
    }
    const transitions = content
      .split(/\r?\n/u)
      .filter(Boolean)
      .map((line) => JSON.parse(line));
    for (const [index, transition] of transitions.entries()) {
      this.registry?.validate("fixtureTransition", transition);
      if (transition.runId !== runId || transition.sequence !== index + 1) {
        throw new WorkflowError("FIXTURE_JOURNAL_CORRUPT", "Fixture journal sequence differs", { exitCode: 3 });
      }
    }
    return transitions;
  }

  /** Caller holds the store-wide fixture lock before appending. */
  async appendFixtureTransition(runId, transition) {
    const directory = await this.locateRun(runId);
    const existing = await this.readFixtureTransitions(runId);
    const record = {
      schema: "agent-workflow-fixture-transition/v1",
      runId,
      sequence: existing.length + 1,
      ...transition,
    };
    this.registry?.validate("fixtureTransition", record);
    const handle = await open(join(directory, "fixture-transitions.jsonl"), "a");
    try {
      await handle.writeFile(`${JSON.stringify(record)}\n`);
      await handle.sync();
    } finally {
      await handle.close();
    }
    if (existing.length === 0) {
      await this.evidenceCutPoint("fixture-journal-before-first-directory-sync", { runId, directory });
      await syncDirectory(directory);
      await this.evidenceCutPoint("fixture-journal-after-first-directory-sync", { runId, directory });
    }
    return record;
  }

  async readFixtureInstance(runId, { projectRoot, ancestry = [] } = {}) {
    if (ancestry.includes(runId))
      throw new WorkflowError("FIXTURE_INCOMPATIBLE", "Fixture lineage cycle", { exitCode: 4 });
    const run = await this.readRun(runId);
    const path = join(run.directory, "fixture-binding.json");
    let binding;
    try {
      binding = JSON.parse(await readRegularFileNoFollow(path, "Fixture receipt is not a regular file"));
    } catch (error) {
      if (error.code === "ENOENT") return null;
      throw error;
    }
    const { instance, handoff } = binding;
    this.registry?.validate("fixtureInstance", instance);
    if (handoff) this.registry?.validate("fixtureHandoff", handoff);
    if (instance.runId !== runId || instance.recipeHash !== run.manifest.fixtureContract?.recipeHash) {
      throw new WorkflowError("FIXTURE_INCOMPATIBLE", "Fixture receipt differs from its run manifest", { exitCode: 4 });
    }
    if (!projectRoot)
      throw new WorkflowError("FIXTURE_PROJECT_REQUIRED", "Fixture verification needs a project root", { exitCode: 2 });
    await verifyFixtureBinding(projectRoot, run.manifest, instance);
    if (instance.lineage) {
      if (instance.lineage.parentRunId !== run.manifest.parentRunId)
        throw new WorkflowError("FIXTURE_INCOMPATIBLE", "Fixture lineage differs from the pinned parent run", {
          exitCode: 4,
        });
      const parent = await this.readRun(instance.lineage.parentRunId);
      const source = await this.readFixtureInstance(parent.manifest.runId, {
        projectRoot,
        ancestry: [...ancestry, runId],
      });
      if (
        !source ||
        !handoff ||
        handoff.sourceReceiptHash !== sha256(source) ||
        handoff.parentRunId !== parent.manifest.runId ||
        handoff.childRunId !== runId ||
        handoff.instanceId !== instance.instanceId ||
        handoff.sourceInstanceId !== source.instanceId ||
        instance.lineage.sourceInstanceId !== source.instanceId ||
        handoff.cleanupOwnerRunId !== instance.cleanupOwnerRunId ||
        handoff.recipeHash !== run.manifest.fixtureContract.recipeHash ||
        handoff.childRevision !== run.manifest.fixtureContract.childRevision ||
        handoff.compatibilityVersion !== run.manifest.fixtureContract.compatibilityVersion ||
        instance.creatorRunId !== source.creatorRunId ||
        instance.cleanupOwnerRunId !== source.cleanupOwnerRunId
      ) {
        throw new WorkflowError("FIXTURE_INCOMPATIBLE", "Fixture handoff lineage differs", { exitCode: 4 });
      }
      assertFixtureHandoff(parent.manifest, run.manifest, source);
    } else if (
      run.manifest.parentRunId ||
      handoff ||
      instance.cleanupOwnerRunId !== runId ||
      instance.creatorRunId !== runId
    ) {
      throw new WorkflowError("FIXTURE_INCOMPATIBLE", "Standalone fixture ownership differs", { exitCode: 4 });
    }
    return instance;
  }

  /** Upload fresh verified bytes through the retained browser page under the exact host lease. */
  async uploadFixtureForLease(runId, { projectRoot, hostId, leaseId, browser } = {}) {
    if (
      !projectRoot ||
      !hostId ||
      !leaseId ||
      typeof browser?.url !== "function" ||
      typeof browser?.getByLabel !== "function"
    )
      throw new WorkflowError(
        "FIXTURE_LEASE_REQUIRED",
        "Project root, exact host lease, and browser handle are required",
        {
          exitCode: 4,
        },
      );
    return this.withExclusiveRun(runId, async (run) => {
      const lease = run.state.activeLease;
      if (
        run.state.status !== "active" ||
        run.state.ownerHostId !== hostId ||
        !lease ||
        lease.hostId !== hostId ||
        lease.leaseId !== leaseId ||
        !matchesRepositoryFixtureUpload(run.manifest, lease.proposal) ||
        !run.state.capabilities["browser.control"]?.constraints?.platforms?.includes(run.manifest.platform) ||
        !run.state.capabilities["browser.control"]?.operations?.includes("browser.control") ||
        !run.state.capabilities["file-upload"]?.constraints?.platforms?.includes(run.manifest.platform) ||
        !run.state.capabilities["file-upload"]?.operations?.includes("upload-file") ||
        Date.now() >= new Date(lease.expiresAt).valueOf() ||
        Date.now() >= new Date(lease.hardExpiresAt).valueOf()
      )
        throw new WorkflowError("FIXTURE_LEASE_REQUIRED", "Current exact upload lease is required", { exitCode: 4 });
      const instance = await this.readFixtureInstance(runId, { projectRoot });
      if (!instance)
        throw new WorkflowError("FIXTURE_NOT_FOUND", "Verified fixture receipt is absent", { exitCode: 8 });
      const verified = await verifyFixtureBinding(projectRoot, run.manifest, instance);
      if (Date.now() >= new Date(lease.expiresAt).valueOf())
        throw new WorkflowError("FIXTURE_LEASE_REQUIRED", "Upload lease expired during byte verification", {
          exitCode: 4,
        });
      const origin = assertCurrentFixtureUploadOrigin(run.manifest, await browser.url());
      const label = run.manifest.fixtureContract.recipe.uploadTarget.slice("label:".length);
      const input = browser.getByLabel(label, { exact: true });
      if (
        typeof input?.count !== "function" ||
        typeof input?.elementHandle !== "function" ||
        (await input.count()) !== 1
      )
        throw new WorkflowError("FIXTURE_INCOMPATIBLE", "Exact browser upload input is missing or ambiguous", {
          exitCode: 4,
        });
      const fixedInput = await input.elementHandle();
      if (typeof fixedInput?.setInputFiles !== "function")
        throw new WorkflowError("FIXTURE_INCOMPATIBLE", "Exact browser upload input cannot be fixed", { exitCode: 4 });
      assertCurrentFixtureUploadOrigin(run.manifest, await browser.url());
      if (Date.now() >= new Date(lease.expiresAt).valueOf() || Date.now() >= new Date(lease.hardExpiresAt).valueOf())
        throw new WorkflowError("FIXTURE_LEASE_REQUIRED", "Upload lease expired before browser upload", {
          exitCode: 4,
        });
      await fixedInput.setInputFiles({
        name: run.manifest.fixtureContract.recipe.filename,
        mimeType: verified.mimeType,
        buffer: verified.bytes,
      });
      assertCurrentFixtureUploadOrigin(run.manifest, await browser.url());
      if (Date.now() >= new Date(lease.expiresAt).valueOf() || Date.now() >= new Date(lease.hardExpiresAt).valueOf())
        throw new WorkflowError("FIXTURE_LEASE_REQUIRED", "Upload lease expired during browser upload", {
          exitCode: 4,
        });
      return {
        runId,
        leaseId,
        instanceId: instance.instanceId,
        origin,
        sizeBytes: verified.sizeBytes,
        sha256: verified.sha256,
      };
    });
  }

  async bindRepositoryFixture(runId, { projectRoot, now = new Date() }) {
    if (!projectRoot)
      throw new WorkflowError("FIXTURE_PROJECT_REQUIRED", "Fixture binding needs a project root", { exitCode: 2 });
    return this.withExclusiveRun(runId, async (run) => {
      if (run.manifest.parentRunId)
        throw new WorkflowError("FIXTURE_INCOMPATIBLE", "A parent-pinned run requires a verified fixture handoff", {
          exitCode: 4,
        });
      const existing = await this.readFixtureInstance(runId, { projectRoot });
      if (existing) return existing;
      const verified = await verifyFixtureBinding(projectRoot, run.manifest);
      const instance = createFixtureInstance(run.manifest, verified, { now });
      this.registry?.validate("fixtureInstance", instance);
      await atomicWriteJson(
        join(run.directory, "fixture-binding.json"),
        { instance, handoff: null },
        { exclusive: true },
      );
      return instance;
    });
  }

  async acceptParentFixture(parentRunId, childRunId, { projectRoot, now = new Date() }) {
    if (!projectRoot)
      throw new WorkflowError("FIXTURE_PROJECT_REQUIRED", "Fixture handoff needs a project root", { exitCode: 2 });
    if (parentRunId === childRunId)
      throw new WorkflowError("FIXTURE_INCOMPATIBLE", "A run cannot hand off to itself", { exitCode: 4 });
    return this.withExclusiveRun(childRunId, async (child) => {
      const existing = await this.readFixtureInstance(childRunId, { projectRoot });
      if (existing) throw new WorkflowError("FIXTURE_ALREADY_BOUND", "Child fixture is already bound", { exitCode: 4 });
      const parent = await this.readRun(parentRunId);
      const source = await this.readFixtureInstance(parentRunId, { projectRoot });
      if (!source) throw new WorkflowError("FIXTURE_NOT_FOUND", "Parent has no verified fixture", { exitCode: 8 });
      assertFixtureHandoff(parent.manifest, child.manifest, source);
      const verified = await verifyFixtureBinding(projectRoot, child.manifest);
      const instance = createFixtureInstance(child.manifest, verified, { parentRunId, sourceInstance: source, now });
      const handoff = {
        schema: "agent-workflow-fixture-handoff/v1",
        parentRunId,
        childRunId,
        sourceInstanceId: source.instanceId,
        instanceId: instance.instanceId,
        sourceReceiptHash: sha256(source),
        recipeHash: child.manifest.fixtureContract.recipeHash,
        childRevision: child.manifest.fixtureContract.childRevision,
        compatibilityVersion: child.manifest.fixtureContract.compatibilityVersion,
        cleanupOwnerRunId: parentRunId,
        decision: "borrow-parent-owned",
        verifiedAt: now.toISOString(),
      };
      this.registry?.validate("fixtureInstance", instance);
      this.registry?.validate("fixtureHandoff", handoff);
      await atomicWriteJson(join(child.directory, "fixture-binding.json"), { instance, handoff }, { exclusive: true });
      return { instance, handoff };
    });
  }

  async readTransaction(runId, requestId) {
    const run = await this.readRun(runId);
    const index = run.events.findIndex((event) => event.transaction?.requestId === requestId);
    if (index === -1) return null;
    return {
      event: run.events[index],
      receipt: this.validate(receiptFromEvent(run.events[index])),
      state: replayRunControl(run.manifest, run.events.slice(0, index + 1), run.workflow),
    };
  }

  async readEvidenceSlot(runId, slotId) {
    if (!/^slot_[A-Za-z0-9_-]+$/.test(slotId)) {
      throw new WorkflowError("INVALID_REQUEST", "Invalid evidence slot ID", { exitCode: 2 });
    }
    const directory = await this.locateRun(runId);
    try {
      return JSON.parse(await readFile(join(directory, "adapter", "evidence-slots", `${slotId}.json`), "utf8"));
    } catch (error) {
      if (error.code === "ENOENT") {
        throw new WorkflowError("NOT_FOUND", `Evidence slot not found: ${slotId}`, { exitCode: 8 });
      }
      throw error;
    }
  }

  async prepareEvidenceSlot(directory, binding) {
    await mkdir(join(directory, "adapter", "evidence-slots"), { recursive: true });
    await assertSafeDirectory(join(directory, "adapter"));
    await assertSafeDirectory(join(directory, "adapter", "evidence-slots"));
    const slotId = evidenceId("slot");
    const stagingPath = assertInside(
      directory,
      join(
        directory,
        "adapter",
        "evidence-slots",
        `${slotId}.${binding.type === "download-content" ? "download" : "screenshot"}`,
      ),
    );
    const slot = { ...binding, slotId, stagingPath };
    await atomicWriteJson(join(directory, "adapter", "evidence-slots", `${slotId}.json`), slot);
    return slot;
  }

  async ingestEvidenceSlot(directory, slot, { requestId, requestHash, observedAt }) {
    await mkdir(join(directory, "registered-evidence"), { recursive: true });
    await assertSafeDirectory(join(directory, "registered-evidence"));
    const recordPath = join(directory, "registered-evidence", `${requestId}.json`);
    let record = await readRegisteredArtifact(recordPath);
    if (record) {
      if (record.requestHash !== requestHash || record.slotId !== slot.slotId) {
        throw new WorkflowError("IDEMPOTENCY_CONFLICT", "Evidence registration record does not match the request", {
          exitCode: 4,
        });
      }
    }

    const neutralStagingPath = assertInside(
      directory,
      join(
        directory,
        "adapter",
        "evidence-slots",
        `${slot.slotId}.${slot.type === "download-content" ? "download" : "screenshot"}`,
      ),
    );
    const legacyStagingPath = assertInside(
      directory,
      join(directory, "adapter", "evidence-slots", `${slot.slotId}.png`),
    );
    if (
      !(slot.type === "download-content" ? [neutralStagingPath] : [neutralStagingPath, legacyStagingPath]).includes(
        slot.stagingPath,
      )
    ) {
      throw new WorkflowError("VALIDATION_FAILED", "Evidence slot path does not match its runner-issued identity", {
        exitCode: 3,
      });
    }
    const stagingPath = slot.stagingPath;
    await assertSafeDirectory(join(directory, "adapter"));
    const existingArtifact = record?.artifact;
    const relativePath = existingArtifact?.relativePath;
    const destination = relativePath ? assertInside(directory, join(directory, relativePath)) : null;
    const stagingExists = await pathExists(stagingPath);
    const destinationExists = destination ? await pathExists(destination) : false;
    if (stagingExists && destinationExists && !record) {
      throw new WorkflowError("VALIDATION_FAILED", "Evidence exists in both staging and durable storage", {
        exitCode: 3,
      });
    }
    if (!stagingExists && !destinationExists) {
      throw new WorkflowError("NOT_FOUND", "Neither staged nor durable evidence bytes exist", {
        exitCode: 8,
      });
    }
    const verified = await readStagedEvidence(
      destinationExists ? destination : stagingPath,
      slot.maximumBytes,
      slot.type,
    );
    const { bytes } = verified;
    if (slot.type === "download-content") verifyDownload(verified.format, bytes.length, slot.download);
    const contentHash = sha256Bytes(bytes);
    const artifactId = existingArtifact?.artifactId ?? artifactIdForEvidence(slot, contentHash);
    const durableRelativePath = existingArtifact?.relativePath ?? `evidence/${artifactId}.${verified.format.extension}`;
    const durableDestination = assertInside(directory, join(directory, durableRelativePath));
    const artifact = existingArtifact ?? {
      schema: "agent-workflow-evidence-artifact/v1",
      artifactId,
      runId: slot.runId,
      type: slot.type,
      mimeType: verified.format.mimeType,
      dimensions: { width: verified.format.width, height: verified.format.height },
      ...(slot.type === "download-content"
        ? {
            download: {
              filename: slot.download.filename,
              frameCount: verified.format.frameCount,
              durationMs: verified.format.durationMs,
            },
          }
        : {
            captureGeometry: !slot.viewport
              ? "unbound"
              : verified.format.width === slot.viewport.width && verified.format.height === slot.viewport.height
                ? "viewport-match"
                : "viewport-mismatch",
          }),
      ...(slot.fullPage === false ? { fullPage: false } : {}),
      observedAt,
      capability: structuredClone(slot.capability),
      relativePath: durableRelativePath,
      contentHash,
      sizeBytes: bytes.length,
      sensitivity: "unknown",
      relation: {
        stepId: slot.stepId,
        checkpoint: slot.checkpoint,
        batchRequestId: slot.leaseRequestId,
        ...(slot.optionalHandlerId ? { optionalHandlerId: slot.optionalHandlerId } : {}),
      },
    };
    if (this.registry) this.registry.validate("protocol", artifact);
    if (
      artifact.contentHash !== contentHash ||
      artifact.sizeBytes !== bytes.length ||
      artifact.runId !== slot.runId ||
      artifact.type !== slot.type ||
      artifact.capability.id !== slot.capability.id ||
      artifact.capability.contractVersion !== slot.capability.contractVersion ||
      artifact.capability.adapterId !== slot.capability.adapterId ||
      artifact.relation.stepId !== slot.stepId ||
      artifact.relation.checkpoint !== slot.checkpoint ||
      artifact.relation.batchRequestId !== slot.leaseRequestId ||
      artifact.relation.optionalHandlerId !== slot.optionalHandlerId ||
      artifact.artifactId !== artifactIdForEvidence(slot, contentHash) ||
      artifact.observedAt !== observedAt ||
      (slot.type === "download-content" &&
        (artifact.download?.filename !== slot.download.filename ||
          artifact.download?.frameCount !== verified.format.frameCount ||
          artifact.download?.durationMs !== verified.format.durationMs)) ||
      artifact.dimensions?.width !== verified.format.width ||
      artifact.dimensions?.height !== verified.format.height ||
      (artifact.captureGeometry !== undefined &&
        artifact.captureGeometry !==
          (!slot.viewport
            ? "unbound"
            : verified.format.width === slot.viewport.width && verified.format.height === slot.viewport.height
              ? "viewport-match"
              : "viewport-mismatch")) ||
      (slot.fullPage === false && artifact.fullPage !== false) ||
      (artifact.mimeType !== undefined &&
        (artifact.mimeType !== verified.format.mimeType ||
          !artifact.relativePath.endsWith(`.${verified.format.extension}`))) ||
      (artifact.mimeType === undefined &&
        (verified.format.mimeType !== "image/png" || !artifact.relativePath.endsWith(".png")))
    ) {
      throw new WorkflowError("VALIDATION_FAILED", "Recovered evidence registration is inconsistent", {
        exitCode: 3,
      });
    }
    await this.evidenceCutPoint("after-validated", { artifact: structuredClone(artifact) });

    if (!record) {
      record = { artifact, slotId: slot.slotId, requestHash, state: "prepared" };
      await atomicWriteJson(recordPath, record);
      await this.evidenceCutPoint("after-prepared-record", { artifact: structuredClone(artifact) });
    }

    if (
      record?.state === "moved" &&
      (record.durableIdentity?.device !== verified.identity.device ||
        record.durableIdentity?.inode !== verified.identity.inode)
    ) {
      throw new WorkflowError("VALIDATION_FAILED", "Durable evidence identity changed after preservation", {
        exitCode: 3,
      });
    }

    if (!destinationExists) {
      await assertSafeDirectory(join(directory, "evidence"));
      await preserveVerifiedScreenshot(durableDestination, bytes);
    }
    const durable = await readStagedEvidence(durableDestination, slot.maximumBytes, slot.type);
    if (sha256Bytes(durable.bytes) !== artifact.contentHash || durable.bytes.length !== artifact.sizeBytes) {
      throw new WorkflowError("VALIDATION_FAILED", "Durable evidence differs from the verified bytes", {
        exitCode: 3,
      });
    }
    if (
      record.state === "moved" &&
      (record.durableIdentity?.device !== durable.identity.device ||
        record.durableIdentity?.inode !== durable.identity.inode)
    ) {
      throw new WorkflowError("VALIDATION_FAILED", "Durable evidence identity does not match its journal", {
        exitCode: 3,
      });
    }
    await unlink(stagingPath).catch((error) => {
      if (error.code !== "ENOENT") throw error;
    });
    await this.evidenceCutPoint("after-move", { artifact: structuredClone(artifact) });
    await syncDirectory(join(directory, "evidence"));
    await this.evidenceCutPoint("after-directory-sync", { artifact: structuredClone(artifact) });

    if (record.state !== "moved") {
      record = { ...record, state: "moved", durableIdentity: durable.identity };
      await atomicWriteJson(recordPath, record);
    }
    await this.evidenceCutPoint("after-moved-record", { artifact: structuredClone(artifact) });
    await unlink(join(directory, "adapter", "evidence-slots", `${slot.slotId}.json`)).catch((error) => {
      if (error.code !== "ENOENT") throw error;
    });
    await this.evidenceCutPoint("after-slot-cleanup", { artifact: structuredClone(artifact) });
    await this.verifyEvidenceRecord(directory, {
      requestId,
      requestHash,
      slotId: slot.slotId,
      artifact,
    });
    return record;
  }

  async verifyEvidenceRecord(directory, { requestId, requestHash, slotId, artifact }) {
    await assertSafeDirectory(join(directory, "evidence"));
    await assertSafeDirectory(join(directory, "registered-evidence"));
    const recordPath = join(directory, "registered-evidence", `${requestId}.json`);
    let record;
    try {
      record = JSON.parse(await readRegularFileNoFollow(recordPath, "Durable evidence journals must be regular files"));
    } catch (error) {
      if (error.code === "ENOENT") record = null;
      else if (error instanceof SyntaxError) {
        throw new WorkflowError("VALIDATION_FAILED", "Durable evidence journal is invalid", {
          exitCode: 3,
        });
      } else throw error;
    }
    if (
      !record ||
      record.state !== "moved" ||
      record.requestHash !== requestHash ||
      record.slotId !== slotId ||
      sha256(record.artifact) !== sha256(artifact) ||
      !record.durableIdentity
    ) {
      throw new WorkflowError("VALIDATION_FAILED", "Durable evidence journal binding is inconsistent", {
        exitCode: 3,
      });
    }
    if (this.registry) this.registry.validate("protocol", artifact);
    const destination = assertInside(directory, join(directory, artifact.relativePath));
    // The moved journal is published only after file and directory durability barriers.
    // Device numbers can change across mounts; retain the inode and content binding.
    // The reader still checks device/inode consistency within this read, without flushing.
    const verified = await readPreservedEvidence(destination, artifact.sizeBytes, artifact.type);
    if (
      (artifact.type === "download-content" &&
        (artifact.download?.frameCount !== verified.format.frameCount ||
          artifact.download?.durationMs !== verified.format.durationMs)) ||
      verified.identity.inode !== record.durableIdentity.inode ||
      verified.bytes.length !== artifact.sizeBytes ||
      sha256Bytes(verified.bytes) !== artifact.contentHash ||
      (artifact.dimensions !== undefined &&
        (artifact.dimensions.width !== verified.format.width ||
          artifact.dimensions.height !== verified.format.height)) ||
      (artifact.mimeType !== undefined &&
        (artifact.mimeType !== verified.format.mimeType ||
          !artifact.relativePath.endsWith(`.${verified.format.extension}`))) ||
      (artifact.mimeType === undefined &&
        (verified.format.mimeType !== "image/png" || !artifact.relativePath.endsWith(".png")))
    ) {
      throw new WorkflowError("VALIDATION_FAILED", "Durable evidence identity or bytes changed", {
        exitCode: 3,
      });
    }
    return verified;
  }

  async readVerifiedEvidenceFromRun(run, artifactId) {
    const runId = run.manifest?.runId;
    const artifact = (run.state.traversal?.artifacts ?? run.state.exploration?.artifacts)?.[artifactId];
    if (!artifact || artifact.runId !== runId || !["screenshot", "download-content"].includes(artifact.type)) {
      throw new WorkflowError("NOT_FOUND", "Evidence artifact is not registered for this run", {
        exitCode: 8,
      });
    }
    const registration = run.events.find(
      (event) =>
        event.type === "evidence.registered" &&
        event.payload?.artifact?.artifactId === artifactId &&
        event.payload.artifact.runId === runId,
    );
    if (!registration?.transaction) {
      throw new WorkflowError("VALIDATION_FAILED", "Evidence registration journal is missing", {
        exitCode: 3,
      });
    }
    const relativeDirectory = relative(this.root, run.directory);
    if (!RUN_ENTRY_PATTERN.test(relativeDirectory) || relativeDirectory.split(sep).at(-1) !== runId) {
      throw new WorkflowError("VALIDATION_FAILED", "Run directory identity is invalid", {
        exitCode: 3,
      });
    }
    const rootEntry = await lstat(this.root);
    if (rootEntry.isSymbolicLink() || !rootEntry.isDirectory()) {
      throw new WorkflowError("VALIDATION_FAILED", "Run store cannot be a symlink", {
        exitCode: 3,
      });
    }
    let cursor = this.root;
    for (const part of relativeDirectory.split(sep)) {
      cursor = join(cursor, part);
      const entry = await lstat(cursor);
      if (entry.isSymbolicLink() || !entry.isDirectory()) {
        throw new WorkflowError("VALIDATION_FAILED", "Run directories cannot be symlinks", {
          exitCode: 3,
        });
      }
    }
    const verified = await this.verifyEvidenceRecord(run.directory, {
      requestId: registration.transaction.requestId,
      requestHash: registration.transaction.requestHash,
      slotId: registration.payload.slotId,
      artifact,
    });
    return { artifact: structuredClone(artifact), bytes: verified.bytes };
  }

  async verifyRegisteredEvidenceFromRun(run, artifactId) {
    const verified = await this.readVerifiedEvidenceFromRun(run, artifactId);
    return { artifact: verified.artifact };
  }

  async readVerifiedEvidence(runId, artifactId) {
    const run = await this.readRun(runId);
    return this.readVerifiedEvidenceFromRun(run, artifactId);
  }

  async readRegisteredEvidence(runId, artifactId) {
    const run = await this.readRun(runId);
    const artifact = (run.state.traversal?.artifacts ?? run.state.exploration?.artifacts)?.[artifactId];
    if (!artifact) {
      throw new WorkflowError("NOT_FOUND", `Evidence artifact is not registered: ${artifactId}`, {
        exitCode: 8,
      });
    }
    return structuredClone(artifact);
  }

  async readProtocolResponse(runId, requestId) {
    const directory = await this.locateRun(runId);
    try {
      const cached = JSON.parse(await readFile(join(directory, "protocol-responses", `${requestId}.json`), "utf8"));
      if (sha256(cached.response) !== cached.responseHash) {
        throw new WorkflowError("PROTOCOL_RESPONSE_CORRUPT", "Cached protocol response hash changed", {
          exitCode: 3,
        });
      }
      if (this.registry) this.registry.validate("protocol", cached.response);
      return cached;
    } catch (error) {
      if (error.code === "ENOENT") return null;
      throw error;
    }
  }

  async writeProtocolResponse(runId, requestId, requestHash, response) {
    const directory = await this.locateRun(runId);
    await mkdir(join(directory, "protocol-responses"), { recursive: true });
    const path = join(directory, "protocol-responses", `${requestId}.json`);
    const value = { requestHash, responseHash: sha256(response), response };
    try {
      await atomicWriteJson(path, value, { exclusive: true });
      return value;
    } catch (error) {
      if (error.code !== "EEXIST") throw error;
    }
    const cached = await this.readProtocolResponse(runId, requestId);
    if (cached.requestHash !== requestHash) {
      throw new WorkflowError(
        "IDEMPOTENCY_CONFLICT",
        `Request ID was already used with different input: ${requestId}`,
        {
          exitCode: 4,
          details: { requestId },
        },
      );
    }
    return cached;
  }

  async appendTransaction(
    runId,
    {
      operation,
      requestId,
      request,
      result,
      receiptId,
      eventId,
      occurredAt,
      type,
      source,
      payload,
      beforeAppend,
      expectedRevision = request?.expectedRevision,
    },
  ) {
    const directory = await this.locateRun(runId);
    return withLock(join(directory, ".write.lock"), async () => {
      const current = await this.readRun(runId);
      const requestHash = sha256(request);
      const existingEvent = current.events.find((event) => event.transaction?.requestId === requestId);

      if (existingEvent) {
        if (existingEvent.transaction.requestHash !== requestHash) {
          throw new WorkflowError(
            "IDEMPOTENCY_CONFLICT",
            `Request ID was already used with different input: ${requestId}`,
            { exitCode: 4, details: { requestId } },
          );
        }
        const receipt = this.validate(receiptFromEvent(existingEvent));
        const receiptPath = join(directory, "receipts", `${requestId}.json`);
        await atomicWriteJson(receiptPath, receipt).catch((error) => {
          if (error.code !== "EEXIST") throw error;
        });
        return { replay: true, receipt, state: current.state, event: existingEvent };
      }

      if (expectedRevision !== current.state.revision) {
        throw new WorkflowError("REVISION_CONFLICT", "The run revision has changed", {
          exitCode: 4,
          details: {
            expected: expectedRevision ?? null,
            current: current.state.revision,
          },
        });
      }
      if (current.events.some((item) => item.eventId === eventId)) {
        throw new WorkflowError("EVENT_ID_DUPLICATE", `Duplicate event ID: ${eventId}`, {
          exitCode: 3,
        });
      }
      if (current.events.some((item) => item.transaction?.receiptId === receiptId)) {
        throw new WorkflowError("RECEIPT_ID_DUPLICATE", `Duplicate receipt ID: ${receiptId}`, {
          exitCode: 3,
        });
      }

      let preparedResult = result;
      let preparedPayload = payload;
      if (beforeAppend) {
        const prepared = await beforeAppend({ current, directory });
        if (prepared?.result !== undefined) preparedResult = prepared.result;
        if (prepared?.payload !== undefined) preparedPayload = prepared.payload;
      }

      const event = this.validate({
        schema: "agent-workflow-run-event/v1",
        eventId,
        runId,
        sequence: current.state.sequence + 1,
        revision: current.state.revision + 1,
        occurredAt,
        type,
        source,
        transaction: {
          operation,
          requestId,
          requestHash,
          receiptId,
          resultHash: sha256(preparedResult),
        },
        payload: preparedPayload,
      });
      const nextState = replayRunControl(current.manifest, [...current.events, event], current.workflow);

      if (type === "evidence.registered") {
        await this.verifyEvidenceRecord(directory, {
          requestId,
          requestHash,
          slotId: event.payload.slotId,
          artifact: event.payload.artifact,
        });
      }
      if (type === "action.committed") {
        for (const artifact of event.payload.artifacts) {
          const registration = current.events.find(
            (item) => item.type === "evidence.registered" && item.payload.artifact.artifactId === artifact.artifactId,
          );
          if (!registration) {
            throw new WorkflowError("NOT_FOUND", "Committed evidence has no registration event", {
              exitCode: 8,
            });
          }
          await this.verifyEvidenceRecord(directory, {
            requestId: registration.transaction.requestId,
            requestHash: registration.transaction.requestHash,
            slotId: registration.payload.slotId,
            artifact: registration.payload.artifact,
          });
        }
      }

      const handle = await open(join(directory, "events.jsonl"), "a");
      try {
        await handle.writeFile(`${JSON.stringify(event)}\n`);
        await handle.sync();
      } finally {
        await handle.close();
      }

      if (type === "evidence.registered") {
        await this.evidenceCutPoint("after-event-append", {
          artifact: structuredClone(event.payload.artifact),
        });
      }

      const receipt = this.validate(receiptFromEvent(event));
      await atomicWriteJson(join(directory, "receipts", `${requestId}.json`), receipt);
      if (type === "evidence.registered") {
        await this.evidenceCutPoint("after-receipt-write", {
          artifact: structuredClone(event.payload.artifact),
        });
      }
      return { replay: false, receipt, state: nextState, event, result: preparedResult };
    });
  }
}
