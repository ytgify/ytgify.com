import { createReadStream } from "node:fs";
import { resolve } from "node:path";

import { AgentService } from "./agent-service.js";
export { agentUsage } from "./agent-command-registry.js";
import { isAgentOperation } from "./agent-command-registry.js";
import { agentProtocolErrorCode, agentRecoveryAction, agentRecoveryPolicy } from "./agent-recovery-policy.js";
import { asWorkflowError, WorkflowError } from "./errors.js";
import { assertSupportedProtocolVersion, responseProtocolVersion, validateProtocolMessage } from "./protocol.js";
import { BrokeredAuthSessionService } from "./user-session-browser-broker.js";

const MAX_AGENT_REQUEST_BYTES = 1024 * 1024;

async function readBoundedInput(source) {
  const chunks = [];
  let byteLength = 0;
  for await (const chunk of source) {
    const bytes = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
    const remaining = MAX_AGENT_REQUEST_BYTES - byteLength;
    if (remaining > 0) chunks.push(bytes.subarray(0, remaining));
    byteLength += bytes.length;
    if (byteLength > MAX_AGENT_REQUEST_BYTES) {
      throw new WorkflowError("VALIDATION_FAILED", "Agent request exceeds the 1 MiB input limit", {
        exitCode: 2,
        details: { maxBytes: MAX_AGENT_REQUEST_BYTES },
      });
    }
  }
  return { text: Buffer.concat(chunks).toString("utf8"), byteLength };
}

async function readJsonInput(flags) {
  const source = flags.get("file")
    ? createReadStream(resolve(flags.get("file")), { highWaterMark: 64 * 1024 })
    : process.stdin;
  const { text, byteLength } = await readBoundedInput(source);
  if (!text.trim()) {
    throw new WorkflowError("INVALID_USAGE", "Agent commands require JSON on stdin or --file", {
      exitCode: 2,
    });
  }
  try {
    return { request: JSON.parse(text), byteLength };
  } catch (error) {
    throw new WorkflowError("INVALID_JSON", "Could not parse agent request JSON", {
      exitCode: 2,
      details: { cause: error.message },
    });
  }
}

function validateFlags(flags) {
  const allowed = new Set(["config", "file", "json", "root", "store"]);
  const unsupported = [...flags.keys()].find((name) => !allowed.has(name));
  if (unsupported) {
    throw new WorkflowError("INVALID_USAGE", `agent does not accept --${unsupported}`, { exitCode: 2 });
  }
}

function authenticationOptions(run, store) {
  if (!run.manifest.authentication) return {};
  return {
    authSessionService: new BrokeredAuthSessionService({ storeRoot: store.root }),
  };
}

function correlatableRequest(request) {
  return (
    request &&
    typeof request === "object" &&
    /^req_[A-Za-z0-9_-]+$/u.test(request.requestId) &&
    /^run_[A-Za-z0-9_-]+$/u.test(request.runId)
  );
}

function protocolFailure(error, request, revision) {
  const code = agentProtocolErrorCode(error.code);
  const policy = agentRecoveryPolicy(code);
  const protocolVersion = responseProtocolVersion(request.protocolVersion);
  return {
    protocolFailure: true,
    exitCode: error.exitCode,
    response: {
      schema: "agent-workflow-protocol-response/v1",
      ok: false,
      protocolVersion,
      requestId: request.requestId,
      runId: request.runId,
      revision,
      error: {
        code,
        message: error.message,
        retryable: policy.retryable,
        recovery: policy.recovery,
        details: error.details,
        ...(protocolVersion === "1.1" ? { recoveryAction: agentRecoveryAction(error.code) } : {}),
      },
    },
  };
}

/** Execute one agent protocol request with configured project truth when the pinned run requires it. */
export async function executeAgentCommand(args, flags, registry, resolvers) {
  const [operation] = args;
  if (!operation) throw new WorkflowError("INVALID_USAGE", "agent requires a command", { exitCode: 2 });
  let request;
  let store;
  let authSessionService;
  try {
    ({ request } = await readJsonInput(flags));
    if (!isAgentOperation(operation)) {
      throw new WorkflowError("INVALID_USAGE", `Unknown agent command: ${operation}`, { exitCode: 2 });
    }
    if (request.command !== `agent.${operation}`) {
      throw new WorkflowError("INVALID_REQUEST", "CLI command and request command do not match", { exitCode: 2 });
    }
    validateFlags(flags);
    assertSupportedProtocolVersion(request.protocolVersion);
    validateProtocolMessage(request, registry, { expectedType: "request" });
    store = await resolvers.controlStore();
    // AgentService verifies the request hash before replaying a cached proposal.
    // A replay must not depend on project files that may have since disappeared.
    if (request.command === "agent.propose" && (await store.readProtocolResponse(request.runId, request.requestId))) {
      return await new AgentService(store, registry).handle(request);
    }
    const run = await store.readRun(request.runId);
    const projectContext =
      run.manifest.authentication ||
      run.manifest.localDogfood ||
      run.manifest.fixtureContract?.recipe.kind === "repository-file" ||
      (run.manifest.phase === "exploration" && run.manifest.exploration.fixtures?.length)
        ? await resolvers.projectContext()
        : undefined;
    const authOptions = authenticationOptions(run, store);
    authSessionService = authOptions.authSessionService;
    const fixtureService = await resolvers.fixtureService?.();
    return await new AgentService(store, registry, {
      ...authOptions,
      ...(projectContext ? { projectContext } : {}),
      ...(fixtureService ? { fixtureService } : {}),
    }).handle(request);
  } catch (caught) {
    const error = asWorkflowError(caught);
    request ??= caught?.correlation;
    if (!correlatableRequest(request)) throw error;
    let revision = request.expectedRevision ?? 0;
    if (!Number.isSafeInteger(revision) || revision < 0) revision = 0;
    if (store) {
      try {
        revision = (await store.readRun(request.runId)).state.revision;
      } catch {}
    }
    return protocolFailure(error, request, revision);
  } finally {
    await authSessionService?.dispose?.();
  }
}
