/* eslint-disable max-lines -- lifecycle lineage checks remain centralized for one trust boundary. */
import { randomUUID } from "node:crypto";
import { readFile } from "node:fs/promises";
import { relative, sep } from "node:path";

import { parse as parseYaml } from "yaml";

import { WorkflowError } from "./errors.js";
import { sha256Bytes } from "./evidence.js";
import { verifyCatalogWorkflowSource } from "./project-workflow-catalog.js";
import { launchPinnedRun, resolveLaunchAuthentication } from "./run-launch.js";
import { sha256 } from "./stable-json.js";
import { verifyRunEvidence } from "./studio-evidence-verifier.js";
import { resolveWorkflow, validateWorkflowSemantics } from "./workflow.js";
import { resolvePlatformViewport } from "./platform-viewport.js";

function id(prefix) {
  return `${prefix}_${randomUUID().replaceAll("-", "")}`;
}

function fail(code, message, details) {
  throw new WorkflowError(code, message, { exitCode: code === "INVALID_USAGE" ? 2 : 4, details });
}

function canonicalSource(workflow) {
  validateWorkflowSemantics(workflow);
  return sha256(workflow);
}

function resetContractHash(workflow) {
  if (!workflow.evaluation?.resetStepId || !workflow.evaluation?.cleanupStepId) {
    fail("EVALUATION_CONTRACT_REQUIRED", "Lifecycle runs require explicit reset and cleanup proof steps");
  }
  return sha256(workflow.evaluation);
}

function proofArtifact(artifact) {
  return {
    artifactId: artifact.artifactId,
    stepId: artifact.relation.stepId,
    contentHash: artifact.contentHash,
    mimeType: artifact.mimeType ?? "image/png",
    width: artifact.dimensions.width,
    height: artifact.dimensions.height,
    ...(artifact.fullPage === false ? { fullPage: false } : {}),
  };
}

const TRUST_TAINT_EVENTS = new Set([
  "action.rejected",
  "run.pause_requested",
  "run.paused",
  "run.resumed",
  "run.emergency_stopped",
  "reconciliation.completed",
  "run.abandoned",
]);

async function verifyCleanLifecycleRun({ runStore, runId, phase, expected = {} }) {
  const run = await runStore.readRun(runId);
  if (run.manifest.localDogfood)
    fail("LOCAL_DOGFOOD_NOT_ACCEPTANCE", "Local synthetic training is not human lifecycle acceptance evidence");
  if (
    run.manifest.phase !== phase ||
    run.state.status !== "completed" ||
    run.state.preflightOutcome !== "passed" ||
    run.state.traversal?.journeyOutcome !== "passed" ||
    run.state.cleanupOutcome !== "passed" ||
    Object.values(run.state.traversal?.steps ?? {}).some((step) => step.outcome !== "passed")
  ) {
    fail("RUN_NOT_CLEAN", `Run ${runId} is not a clean ${phase}`);
  }
  const taint = run.events.find(
    (event) =>
      TRUST_TAINT_EVENTS.has(event.type) ||
      (event.type === "host.claimed" && (event.payload.previousHostId || event.payload.reconciliationRequired)) ||
      (event.type === "action.committed" &&
        (event.payload.derivedOutcome !== "passed" ||
          event.payload.result?.unexpectedStates?.length ||
          event.payload.result?.uncertainty?.length ||
          event.payload.assessment?.unexpectedStates?.length ||
          event.payload.assessment?.uncertainty?.length)),
  );
  if (
    taint ||
    run.state.capabilityGaps?.length ||
    Object.values(run.state.traversal?.steps ?? {}).some((step) => step.attempts !== 1) ||
    run.events.filter((event) => event.type === "host.claimed").length !== 1
  ) {
    fail("RUN_TRUST_TAINTED", `Run ${runId} contains retry, intervention, uncertainty, or capability-gap taint`, {
      eventType: taint?.type,
    });
  }
  const ref = run.manifest.workflowRef;
  for (const key of [
    "id",
    "sourceKind",
    "sourceBytesHash",
    "revision",
    "contentHash",
    "platform",
    "effectiveHash",
    "effectiveHashVersion",
  ]) {
    if (expected[key] !== undefined && ref?.[key] !== expected[key])
      fail("RUN_REFERENCE_DIVERGED", `Run ${runId} changed ${key}`);
  }
  if (ref?.effectiveHashVersion !== "platform-v2")
    fail("LEGACY_HASH_NOT_ALLOWED", "Lifecycle proof requires platform-v2 hashing");
  if (run.manifest.resetContractHash !== resetContractHash(run.workflow))
    fail("RESET_CONTRACT_DIVERGED", "Reset contract hash changed");
  const resetStep = run.workflow.evaluation.resetStepId;
  const cleanupStep = run.workflow.evaluation.cleanupStepId;
  const artifacts = Object.values(run.state.traversal.artifacts ?? {});
  for (const artifact of artifacts.filter((item) => ["screenshot", "download-content"].includes(item.type))) {
    await verifyRunEvidence({ store: runStore, run, artifact });
  }
  const proof = {};
  for (const stepId of [resetStep, cleanupStep]) {
    const screenshots = artifacts.filter(
      (artifact) => artifact.type === "screenshot" && artifact.relation?.stepId === stepId,
    );
    if (!screenshots.length) fail("PROOF_SCREENSHOT_REQUIRED", `${stepId} requires verified screenshot evidence`);
    proof[stepId] = screenshots;
  }
  const viewport = resolvePlatformViewport(run.workflow, run.manifest.platform);
  if (run.manifest.viewport?.width !== viewport.width || run.manifest.viewport?.height !== viewport.height) {
    fail(
      "TRUSTED_VIEWPORT_REQUIRED",
      `${run.manifest.platform} lifecycle proof must pin ${viewport.width}x${viewport.height}`,
    );
  }
  {
    for (const artifact of artifacts.filter((item) => item.type === "screenshot")) {
      const exactViewport = run.workflow.steps
        .find((step) => step.id === artifact.relation.stepId)
        ?.evidence?.some(
          (requirement) =>
            requirement.type === "screenshot" &&
            requirement.checkpoint === artifact.relation.checkpoint &&
            requirement.exactViewport === true,
        );
      if (
        artifact.fullPage !== false ||
        (exactViewport &&
          (artifact.dimensions?.width !== viewport.width || artifact.dimensions?.height !== viewport.height))
      ) {
        fail(
          "TRUSTED_SCREENSHOT_MISMATCH",
          `Screenshot evidence must be runner-derived ${viewport.width}x${viewport.height} and non-full-page`,
        );
      }
    }
  }
  return { run, artifacts, proof };
}

function assertExactRecord(actual, expected, code, message) {
  for (const [key, value] of Object.entries(expected)) {
    if (JSON.stringify(actual?.[key]) !== JSON.stringify(value)) fail(code, message, { field: key });
  }
}

async function verifyReplayTruth({ runId, runStore, lifecycleStore, expected = {} }) {
  let replay;
  try {
    replay = await lifecycleStore.readRecord("replay", runId);
  } catch (error) {
    if (error instanceof SyntaxError) {
      fail(
        "REPLAY_RECEIPT_CORRUPT",
        "Replay receipt contains malformed JSON. Preserve the receipt and inspect the saved replay proof; restore only from a verified backup before retrying.",
        { runId, store: lifecycleStore.root },
      );
    }
    if (error?.code !== "ENOENT") throw error;
    fail(
      "REPLAY_NOT_FINALIZED",
      "Replay receipt is missing. Finalize the completed replay with workflow replay finalize RUN_ID --store STORE --json, then retry.",
      { runId, store: lifecycleStore.root },
    );
  }
  const checked = await verifyCleanLifecycleRun({ runStore, runId, phase: "replay", expected });
  const ref = checked.run.manifest.workflowRef;
  const proofArtifacts = Object.values(checked.proof).flat().map(proofArtifact);
  assertExactRecord(
    replay,
    {
      runId,
      workflowId: ref.id,
      sourceKind: ref.sourceKind,
      ...(ref.revision ? { revision: ref.revision } : {}),
      contentHash: ref.contentHash,
      ...(ref.sourceBytesHash ? { sourceBytesHash: ref.sourceBytesHash } : {}),
      platform: ref.platform,
      effectiveHash: ref.effectiveHash,
      effectiveHashVersion: ref.effectiveHashVersion,
      resetContractHash: checked.run.manifest.resetContractHash,
      proofArtifacts,
      outcome: "passed",
    },
    "REPLAY_RECEIPT_STALE",
    "Replay receipt no longer matches its complete clean run",
  );
  return { replay, checked };
}

function promotionChallenge(record) {
  return `Promote ${record.workflowId} ${record.revision} ${record.contentHash} from ${record.replayRunId}`;
}

function qualificationChallenge(record) {
  return `Qualify ${record.workflowId} ${record.revision} ${record.platform} ${record.effectiveHash} from ${record.replayRunId}`;
}

export async function verifyPromotionTruth({ workflowId, revision, lifecycleStore, runStore }) {
  const promoted = await lifecycleStore.readPromotion(workflowId, revision);
  const { record, snapshotBytes } = promoted;
  const source = lifecycleStore.registry?.validate("workflow", parseYaml(snapshotBytes.toString("utf8")));
  if (!source) fail("PROMOTION_VALIDATOR_REQUIRED", "Promotion verification requires the lifecycle schema registry");
  const contentHash = canonicalSource(source);
  const replayTruth = await verifyReplayTruth({
    runId: record.replayRunId,
    lifecycleStore,
    runStore,
    expected: { id: workflowId, sourceKind: "candidate", contentHash },
  });
  assertExactRecord(
    record,
    {
      workflowId,
      revision,
      contentHash,
      snapshotHash: sha256Bytes(snapshotBytes),
      ...(record.validation
        ? { validation: { actor: "runner", evidenceBinding: promotionChallenge(record) } }
        : {
            approval: {
              actor:
                replayTruth.checked.run.manifest.leasePolicy?.name === "authorized-codex-browser-v1"
                  ? "runner"
                  : record.approval.actor,
              interactive:
                replayTruth.checked.run.manifest.leasePolicy?.name !== "authorized-codex-browser-v1" &&
                record.approval.actor === "human",
              confirmation: promotionChallenge(record),
            },
          }),
    },
    "PROMOTION_STALE",
    "Promotion no longer matches its immutable snapshot, candidate replay, or exact approval challenge",
  );
  assertExactRecord(
    replayTruth.replay,
    {
      workflowId,
      sourceKind: "candidate",
      contentHash,
      resetContractHash: resetContractHash(source),
    },
    "PROMOTION_STALE",
    "Promotion candidate replay no longer proves the immutable snapshot",
  );
  return { promoted, promotion: record, source, ...replayTruth };
}

export async function verifyQualificationTruth({
  qualificationId,
  qualification,
  lifecycleStore,
  runStore,
  expected = {},
}) {
  const record = qualification ?? (await lifecycleStore.readRecord("qualification", qualificationId));
  const promotionTruth = await verifyPromotionTruth({
    workflowId: record.workflowId,
    revision: record.revision,
    lifecycleStore,
    runStore,
  });
  const { promoted, source } = promotionTruth;
  const resolved = resolveWorkflow(source, record.platform, "platform-v2");
  const replayTruth = await verifyReplayTruth({
    runId: record.replayRunId,
    lifecycleStore,
    runStore,
    expected: {
      id: record.workflowId,
      sourceKind: "promoted",
      revision: record.revision,
      contentHash: record.contentHash,
      platform: record.platform,
      effectiveHash: record.effectiveHash,
      effectiveHashVersion: "platform-v2",
    },
  });
  const viewport = resolvePlatformViewport(source, record.platform);
  const capabilities = Object.values(replayTruth.checked.run.state.capabilities);
  assertExactRecord(
    record,
    {
      qualificationId: qualificationId ?? record.qualificationId,
      contentHash: promoted.record.contentHash,
      effectiveHash: resolved.effectiveHash,
      effectiveHashVersion: "platform-v2",
      resetContractHash: resetContractHash(source),
      capabilityHash: sha256(capabilities),
      capabilitySnapshot: capabilities,
      viewport,
      ...(record.validation
        ? { validation: { actor: "runner", evidenceBinding: qualificationChallenge(record) } }
        : {
            approval: {
              actor:
                replayTruth.checked.run.manifest.leasePolicy?.name === "authorized-codex-browser-v1"
                  ? "runner"
                  : record.approval.actor,
              interactive:
                replayTruth.checked.run.manifest.leasePolicy?.name !== "authorized-codex-browser-v1" &&
                record.approval.actor === "human",
              confirmation: qualificationChallenge(record),
            },
          }),
      ...expected,
    },
    "QUALIFICATION_STALE",
    "Qualification no longer matches its promotion, replay, capabilities, viewport, or clean evidence",
  );
  return { qualification: record, ...promotionTruth, ...replayTruth };
}

export async function launchCandidateReplay({
  workflowPath,
  workflowSource,
  platform,
  profile = "promotion-replay",
  runStore,
  registry,
  applicationTarget,
  targetUrl,
  projectContext,
  authSessionStore,
  fixtureRecipe,
  fixtureProjectRoot,
  now,
}) {
  const bytes = workflowSource?.bytes ?? (await readFile(workflowPath));
  const workflow = registry.validate("workflow", workflowSource?.workflow ?? parseYaml(bytes.toString("utf8")));
  resetContractHash(workflow);
  const resolved = resolveWorkflow(workflow, platform, "platform-v2");
  if (workflowSource) {
    await verifyCatalogWorkflowSource(workflowSource);
    await runStore.init();
  }
  const authenticationSession = await resolveLaunchAuthentication({
    identityRequirement: resolved.workflow.target.identity.requirement,
    projectContext,
    applicationTarget,
    storeRoot: runStore.root,
    authSessionStore,
    registry,
  });
  return launchPinnedRun({
    phase: "replay",
    workflow: resolved.workflow,
    platform,
    profile,
    store: runStore,
    now,
    viewport: resolvePlatformViewport(resolved.workflow, platform),
    applicationTarget,
    targetUrl,
    authenticationSession,
    fixtureRecipe,
    fixtureProjectRoot,
    fixtureCompatibilityVersion: resolved.workflow.fixtureRequirement?.compatibilityVersion,
    workflowRef: {
      id: workflow.metadata.id,
      sourceKind: "candidate",
      ...(workflowSource ? { sourceBytesHash: workflowSource.sourceBytesHash } : {}),
      contentHash: resolved.sourceHash,
      platform,
      effectiveHash: resolved.effectiveHash,
      effectiveHashVersion: resolved.effectiveHashVersion,
    },
  });
}

export async function launchPromotedReplay({
  workflowId,
  revision,
  platform,
  profile = "qualification-replay",
  lifecycleStore,
  runStore,
  applicationTarget,
  targetUrl,
  projectContext,
  authSessionStore,
  fixtureRecipe,
  fixtureProjectRoot,
  now,
}) {
  const { promoted, source } = await verifyPromotionTruth({
    workflowId,
    revision,
    lifecycleStore,
    runStore,
  });
  const resolved = resolveWorkflow(source, platform, "platform-v2");
  const authenticationSession = await resolveLaunchAuthentication({
    identityRequirement: resolved.workflow.target.identity.requirement,
    projectContext,
    applicationTarget,
    storeRoot: runStore.root,
    authSessionStore,
    registry: runStore.registry,
  });
  return launchPinnedRun({
    phase: "replay",
    workflow: resolved.workflow,
    platform,
    profile,
    store: runStore,
    now,
    viewport: resolvePlatformViewport(resolved.workflow, platform),
    applicationTarget,
    targetUrl,
    authenticationSession,
    fixtureRecipe,
    fixtureProjectRoot,
    fixtureCompatibilityVersion: resolved.workflow.fixtureRequirement?.compatibilityVersion,
    workflowRef: {
      id: workflowId,
      sourceKind: "promoted",
      revision,
      contentHash: promoted.record.contentHash,
      platform,
      effectiveHash: resolved.effectiveHash,
      effectiveHashVersion: resolved.effectiveHashVersion,
    },
  });
}

export async function finalizeReplay({ runId, runStore, lifecycleStore, authority, now = () => new Date() }) {
  const { run, proof } = await verifyCleanLifecycleRun({ runStore, runId, phase: "replay" });
  const ref = run.manifest.workflowRef;
  const receipt = {
    schema: "agent-workflow-replay-receipt/v1",
    runId,
    workflowId: ref.id,
    sourceKind: ref.sourceKind,
    ...(ref.revision ? { revision: ref.revision } : {}),
    contentHash: ref.contentHash,
    ...(ref.sourceBytesHash ? { sourceBytesHash: ref.sourceBytesHash } : {}),
    platform: ref.platform,
    effectiveHash: ref.effectiveHash,
    effectiveHashVersion: ref.effectiveHashVersion,
    resetContractHash: run.manifest.resetContractHash,
    proofArtifacts: Object.values(proof).flat().map(proofArtifact),
    outcome: "passed",
    verifiedAt: now().toISOString(),
  };
  return lifecycleStore.writeRecord("replay", runId, receipt, authority);
}

export async function promoteWorkflow({
  workflowPath,
  workflowSource,
  replayRunId,
  lifecycleStore,
  runStore,
  registry,
  authority,
  now = () => new Date(),
}) {
  const snapshotBytes = workflowSource?.bytes ?? (await readFile(workflowPath));
  const workflow = registry.validate("workflow", workflowSource?.workflow ?? parseYaml(snapshotBytes.toString("utf8")));
  if (workflowSource) await verifyCatalogWorkflowSource(workflowSource);
  const workflowId = workflow.metadata.id;
  const contentHash = canonicalSource(workflow);
  const revision = await lifecycleStore.nextRevision(workflowId);
  const { replay } = await verifyReplayTruth({
    runId: replayRunId,
    lifecycleStore,
    runStore,
    expected: {
      id: workflowId,
      sourceKind: "candidate",
      contentHash,
      ...(workflowSource ? { sourceBytesHash: workflowSource.sourceBytesHash } : {}),
    },
  });
  if (replay.sourceKind !== "candidate" || replay.workflowId !== workflowId || replay.contentHash !== contentHash) {
    fail("REPLAY_NOT_PROMOTABLE", "Candidate replay does not match the exact workflow bytes");
  }
  const expectedConfirmation = promotionChallenge({ workflowId, revision, contentHash, replayRunId });
  const confirmation = expectedConfirmation;
  if (workflowSource) await verifyCatalogWorkflowSource(workflowSource);
  const record = {
    schema: "agent-workflow-promotion/v1",
    workflowId,
    revision,
    contentHash,
    snapshotHash: sha256Bytes(snapshotBytes),
    replayRunId,
    promotedAt: now().toISOString(),
    validation: { actor: "runner", evidenceBinding: confirmation },
  };
  return lifecycleStore.writePromotion(record, snapshotBytes, authority);
}

export async function qualifyRevision({
  workflowId,
  revision,
  replayRunId,
  lifecycleStore,
  runStore,
  authority,
  now = () => new Date(),
}) {
  const { promoted } = await verifyPromotionTruth({ workflowId, revision, lifecycleStore, runStore });
  const { replay, checked } = await verifyReplayTruth({
    runId: replayRunId,
    lifecycleStore,
    runStore,
    expected: {
      id: workflowId,
      sourceKind: "promoted",
      revision,
      contentHash: promoted.record.contentHash,
    },
  });
  if (
    replay.sourceKind !== "promoted" ||
    replay.workflowId !== workflowId ||
    replay.revision !== revision ||
    replay.contentHash !== promoted.record.contentHash
  ) {
    fail("REPLAY_NOT_QUALIFIABLE", "Promoted replay does not match the requested revision");
  }
  const expectedConfirmation = qualificationChallenge({
    workflowId,
    revision,
    platform: replay.platform,
    effectiveHash: replay.effectiveHash,
    replayRunId,
  });
  const confirmation = expectedConfirmation;
  const capabilitySnapshot = Object.values(checked.run.state.capabilities);
  const capabilityHash = sha256(capabilitySnapshot);
  const qualificationId = id("qualification");
  const record = {
    schema: "agent-workflow-qualification/v1",
    qualificationId,
    workflowId,
    revision,
    contentHash: promoted.record.contentHash,
    platform: replay.platform,
    effectiveHash: replay.effectiveHash,
    effectiveHashVersion: "platform-v2",
    replayRunId,
    resetContractHash: replay.resetContractHash,
    capabilityHash,
    capabilitySnapshot,
    ...(checked.run.manifest.viewport ? { viewport: checked.run.manifest.viewport } : {}),
    qualifiedAt: now().toISOString(),
    validation: { actor: "runner", evidenceBinding: confirmation },
  };
  return lifecycleStore.writeRecord("qualification", qualificationId, record, authority);
}

export async function launchEvaluationGroup({
  workflowId,
  revision,
  qualifications,
  profiles = {},
  lifecycleStore,
  runStore,
  applicationTarget,
  targetUrl,
  projectContext,
  authSessionStore,
  fixtureRecipe,
  fixtureProjectRoot,
  authority,
  now = () => new Date(),
}) {
  const { promoted, source } = await verifyPromotionTruth({
    workflowId,
    revision,
    lifecycleStore,
    runStore,
  });
  const required = ["desktop-web", "mobile-web"];
  const authenticationSession = await resolveLaunchAuthentication({
    identityRequirement: source.target.identity.requirement,
    projectContext,
    applicationTarget,
    storeRoot: runStore.root,
    authSessionStore,
    registry: runStore.registry,
  });
  const qualificationRecords = {};
  for (const platform of required) {
    const record = await lifecycleStore.readRecord("qualification", qualifications[platform]);
    if (
      record.workflowId !== workflowId ||
      record.revision !== revision ||
      record.platform !== platform ||
      record.contentHash !== promoted.record.contentHash
    ) {
      fail("QUALIFICATION_MISMATCH", `Qualification does not match ${platform}`);
    }
    await verifyQualificationTruth({
      qualificationId: record.qualificationId,
      qualification: record,
      lifecycleStore,
      runStore,
      expected: {
        workflowId,
        revision,
        contentHash: promoted.record.contentHash,
        platform,
        effectiveHash: record.effectiveHash,
      },
    });
    qualificationRecords[platform] = record;
  }
  const groupId = id("group");
  const launched = [];
  for (const platform of required) {
    const resolved = resolveWorkflow(source, platform, "platform-v2");
    if (resolved.effectiveHash !== qualificationRecords[platform].effectiveHash)
      fail("QUALIFICATION_STALE", `${platform} qualification hash is stale`);
    const viewport = resolvePlatformViewport(resolved.workflow, platform);
    const member = await launchPinnedRun({
      phase: "evaluation",
      workflow: resolved.workflow,
      workflowRef: {
        id: workflowId,
        sourceKind: "promoted",
        revision,
        contentHash: promoted.record.contentHash,
        platform,
        effectiveHash: resolved.effectiveHash,
        effectiveHashVersion: "platform-v2",
      },
      platform,
      profile: profiles[platform] ?? (platform === "desktop-web" ? "evaluation-desktop" : "evaluation-mobile"),
      store: runStore,
      now,
      evaluationGroupId: groupId,
      qualificationId: qualificationRecords[platform].qualificationId,
      viewport,
      capabilitySnapshot: qualificationRecords[platform].capabilitySnapshot,
      sourceReplayRunId: qualificationRecords[platform].replayRunId,
      applicationTarget,
      targetUrl,
      authenticationSession,
      fixtureRecipe,
      fixtureProjectRoot,
      fixtureCompatibilityVersion: resolved.workflow.fixtureRequirement?.compatibilityVersion,
    });
    launched.push(member);
  }
  const members = [];
  for (const item of launched) {
    const directory = await runStore.locateRun(item.launchCard.runId);
    const evidenceDirectory = `${relative(runStore.root, directory).split(sep).join("/")}/evidence`;
    members.push({
      runId: item.launchCard.runId,
      platform: item.manifest.platform,
      profile: item.manifest.profile,
      effectiveHash: item.manifest.workflowRef.effectiveHash,
      qualificationId: item.manifest.qualificationId,
      evidenceDirectory,
      ...(item.manifest.viewport ? { viewport: item.manifest.viewport } : {}),
    });
  }
  if (
    new Set(members.map((member) => member.runId)).size !== 2 ||
    new Set(members.map((member) => member.evidenceDirectory)).size !== 2 ||
    new Set(launched.map((item) => JSON.stringify(item.manifest.target))).size !== 1
  ) {
    fail(
      "EVALUATION_NOT_INDEPENDENT",
      "Evaluation members must use independent run and evidence identities with one immutable target",
    );
  }
  const group = {
    schema: "agent-workflow-evaluation-group/v1",
    groupId,
    workflowId,
    revision,
    contentHash: promoted.record.contentHash,
    resetContractHash: resetContractHash(source),
    createdAt: now().toISOString(),
    members,
  };
  await lifecycleStore.writeRecord("group", groupId, group, authority);
  for (const member of launched) {
    member.state = (await runStore.readRun(member.launchCard.runId)).state;
  }
  return { group, runs: launched };
}

async function verifyEvaluationBasis({ groupId, runId, lifecycleStore, runStore }) {
  const group = await lifecycleStore.readRecord("group", groupId);
  const member = group.members.find((item) => item.runId === runId);
  if (!member) fail("EVALUATION_MEMBER_MISMATCH", "Run is not a member of the immutable evaluation group");
  const checked = await verifyCleanLifecycleRun({
    runStore,
    runId,
    phase: "evaluation",
    expected: {
      id: group.workflowId,
      sourceKind: "promoted",
      revision: group.revision,
      contentHash: group.contentHash,
      platform: member.platform,
      effectiveHash: member.effectiveHash,
    },
  });
  if (
    checked.run.manifest.evaluationGroupId !== groupId ||
    checked.run.manifest.qualificationId !== member.qualificationId ||
    checked.run.manifest.nonResumable !== true ||
    checked.run.manifest.resetContractHash !== group.resetContractHash
  ) {
    fail("EVALUATION_MANIFEST_DIVERGED", "Evaluation manifest no longer matches its immutable group");
  }
  const qualificationTruth = await verifyQualificationTruth({
    qualificationId: member.qualificationId,
    lifecycleStore,
    runStore,
    expected: {
      workflowId: group.workflowId,
      revision: group.revision,
      contentHash: group.contentHash,
      platform: member.platform,
      effectiveHash: member.effectiveHash,
      resetContractHash: group.resetContractHash,
    },
  });
  if (
    sha256(Object.values(checked.run.state.capabilities)) !== qualificationTruth.qualification.capabilityHash ||
    sha256(checked.run.manifest.capabilitySnapshot) !== qualificationTruth.qualification.capabilityHash
  ) {
    fail("EVALUATION_CAPABILITY_DIVERGED", "Evaluation capabilities differ from the qualified snapshot");
  }
  const artifacts = checked.artifacts
    .filter((item) => ["screenshot", "download-content"].includes(item.type))
    .map(proofArtifact);
  if (new Set(artifacts.map((item) => item.artifactId)).size < 2)
    fail("INDEPENDENT_PROOF_REQUIRED", "Evaluation requires fresh reset and cleanup artifacts");
  return { group, member, checked, qualificationTruth, artifacts };
}

export async function verifyEvaluationTruth({ groupId, runId, lifecycleStore, runStore }) {
  const basis = await verifyEvaluationBasis({ groupId, runId, lifecycleStore, runStore });
  const receipt = await lifecycleStore.readRecord("evaluation", runId);
  assertExactRecord(
    receipt,
    {
      groupId,
      runId,
      workflowId: basis.group.workflowId,
      revision: basis.group.revision,
      contentHash: basis.group.contentHash,
      platform: basis.member.platform,
      effectiveHash: basis.member.effectiveHash,
      effectiveHashVersion: "platform-v2",
      qualificationId: basis.member.qualificationId,
      resetContractHash: basis.group.resetContractHash,
      outcome: "passed",
      viewport: basis.member.viewport,
      artifactHashes: basis.artifacts.map((item) => item.contentHash),
      artifacts: basis.artifacts,
    },
    "EVALUATION_RECEIPT_STALE",
    "Evaluation receipt no longer matches its complete clean run and qualification lineage",
  );
  return { ...basis, receipt };
}

export async function finalizeEvaluation({
  groupId,
  runId,
  lifecycleStore,
  runStore,
  authority,
  now = () => new Date(),
}) {
  const { group, member, artifacts } = await verifyEvaluationBasis({
    groupId,
    runId,
    lifecycleStore,
    runStore,
  });
  const artifactHashes = artifacts.map((item) => item.contentHash);
  const receipt = {
    schema: "agent-workflow-evaluation-receipt/v1",
    groupId,
    runId,
    workflowId: group.workflowId,
    revision: group.revision,
    contentHash: group.contentHash,
    platform: member.platform,
    effectiveHash: member.effectiveHash,
    effectiveHashVersion: "platform-v2",
    qualificationId: member.qualificationId,
    resetContractHash: group.resetContractHash,
    outcome: "passed",
    ...(member.viewport ? { viewport: member.viewport } : {}),
    artifactHashes,
    artifacts,
    verifiedAt: now().toISOString(),
  };
  return lifecycleStore.writeRecord("evaluation", runId, receipt, authority);
}

export async function inspectEvaluationGroup({ groupId, lifecycleStore, runStore }) {
  const group = await lifecycleStore.readRecord("group", groupId);
  const members = await Promise.all(
    group.members.map(async (member) => {
      try {
        const run = await runStore.readRun(member.runId);
        let receipt = null;
        try {
          receipt = await lifecycleStore.readRecord("evaluation", member.runId);
        } catch (error) {
          if (error.code !== "ENOENT") throw error;
        }
        return { ...member, status: run.state.status, receipt };
      } catch {
        return { ...member, status: "unavailable", receipt: null };
      }
    }),
  );
  return { ...group, members };
}
