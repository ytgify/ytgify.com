import { createHash, randomUUID } from "node:crypto";
import { constants } from "node:fs";
import { lstat, open, readFile, rename, unlink } from "node:fs/promises";
import { dirname } from "node:path";

import { WorkflowError } from "./errors.js";
export { DEFAULT_SCREENSHOT_MAX_BYTES, inspectScreenshotBytes } from "./screenshot-evidence.js";
import { inspectScreenshotBytes } from "./screenshot-evidence.js";
import { inspectGifBytes } from "./download-evidence.js";

export async function assertSafeDirectory(path) {
  const entry = await lstat(path);
  if (entry.isSymbolicLink() || !entry.isDirectory()) {
    throw new WorkflowError("VALIDATION_FAILED", "Evidence directories cannot be symlinks", {
      exitCode: 3,
    });
  }
}

export const readStagedScreenshot = (path, maxBytes) => readScreenshot(path, maxBytes, true);
export const readPreservedScreenshot = (path, maxBytes) => readScreenshot(path, maxBytes, false);

export const readStagedEvidence = (path, maxBytes, type) => readScreenshot(path, maxBytes, true, type);
export const readPreservedEvidence = (path, maxBytes, type) => readScreenshot(path, maxBytes, false, type);

async function readScreenshot(path, maxBytes, flush, type = "screenshot") {
  await assertSafeDirectory(dirname(path));
  let entry;
  try {
    entry = await lstat(path);
  } catch (error) {
    if (error.code === "ENOENT") {
      throw new WorkflowError("NOT_FOUND", "The issued evidence slot has not been written", {
        exitCode: 8,
      });
    }
    throw error;
  }
  if (entry.isSymbolicLink() || !entry.isFile()) {
    throw new WorkflowError("VALIDATION_FAILED", "Evidence slots must contain one regular file", {
      exitCode: 3,
    });
  }
  if (entry.size === 0 || entry.size > maxBytes) {
    throw new WorkflowError("VALIDATION_FAILED", "Evidence size is outside the issued slot limit", {
      exitCode: 3,
      details: { maximumBytes: maxBytes, actualBytes: entry.size },
    });
  }

  let handle;
  try {
    handle = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW);
    const opened = await handle.stat();
    if (!opened.isFile() || opened.size !== entry.size || opened.dev !== entry.dev || opened.ino !== entry.ino) {
      throw new WorkflowError("VALIDATION_FAILED", "Evidence slot changed while it was being verified", {
        exitCode: 3,
      });
    }
    const bytes = await handle.readFile();
    const format =
      type === "download-content" ? inspectGifBytes(bytes, maxBytes) : inspectScreenshotBytes(bytes, maxBytes);
    if (flush) await handle.sync();
    const identity = { device: String(opened.dev), inode: String(opened.ino) };
    return { bytes, identity, format };
  } catch (error) {
    if (error.code === "ELOOP") {
      throw new WorkflowError("VALIDATION_FAILED", "Evidence slots cannot be symlinks", {
        exitCode: 3,
      });
    }
    throw error;
  } finally {
    await handle?.close();
  }
}

export async function preserveVerifiedScreenshot(path, bytes) {
  await assertSafeDirectory(dirname(path));
  const temporary = `${path}.${randomUUID()}.tmp`;
  let handle;
  try {
    handle = await open(temporary, constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL, 0o600);
    await handle.writeFile(bytes);
    await handle.sync();
    await handle.close();
    handle = null;
    await rename(temporary, path);
  } catch (error) {
    await handle?.close().catch(() => {});
    await unlink(temporary).catch(() => {});
    throw error;
  }
}

export async function readRegisteredArtifact(path) {
  try {
    return JSON.parse(await readFile(path, "utf8"));
  } catch (error) {
    if (error.code === "ENOENT") return null;
    throw error;
  }
}

export function evidenceId(prefix) {
  return `${prefix}_${randomUUID().replaceAll("-", "")}`;
}

export function sha256Bytes(bytes) {
  return `sha256:${createHash("sha256").update(bytes).digest("hex")}`;
}

export function artifactIdForEvidence(slot, contentHash) {
  const digest = createHash("sha256")
    .update(`${slot.runId}\0${slot.slotId}\0${slot.leaseId}\0${contentHash}`)
    .digest("hex");
  return `artifact_${digest}`;
}
