import { WorkflowError } from "./errors.js";

const EMAIL = /\b[^\s@]+@[^\s@]+\.[^\s@]+\b/u;
const TOKEN = /[A-Za-z0-9_-]{32,}/u;
const URL_CREDENTIALS = /(?:https?:)?\/\/[^/\s:@]+:[^/\s@]+@/iu;
// The marker contract explicitly rejects every ASCII control character.
// eslint-disable-next-line no-control-regex
const CONTROL = /[\u0000-\u001f\u007f]/u;
const ROLES = new Set(["heading", "link", "button", "navigation", "main"]);
const METHODS = ["open", "proposeMarkers", "verify", "clear"];

function unsafeMarker() {
  return new WorkflowError("AUTH_MARKER_UNSAFE", "The proposed sign-in marker is not safe to store", {
    exitCode: 3,
  });
}

function safeRoutePath(value) {
  if (typeof value !== "string" || !/^\/(?!\/)/u.test(value) || value.length > 500) return false;

  let parsed;
  try {
    parsed = new URL(value, "https://marker.invalid");
  } catch {
    return false;
  }
  if (parsed.origin !== "https://marker.invalid" || parsed.pathname !== value || parsed.search || parsed.hash) {
    return false;
  }

  const forms = [value];
  try {
    for (let index = 0; index < 2; index += 1) {
      const decoded = decodeURIComponent(forms.at(-1));
      if (decoded === forms.at(-1)) break;
      forms.push(decoded);
    }
  } catch {
    return false;
  }
  return forms.every(
    (form) =>
      !EMAIL.test(form) &&
      !TOKEN.test(form) &&
      !CONTROL.test(form) &&
      !URL_CREDENTIALS.test(form) &&
      !/[?#]/u.test(form),
  );
}

function safeMarkerName(value) {
  if (typeof value !== "string" || value.length === 0 || value.length > 200) return false;
  const forms = [value];
  try {
    for (let index = 0; index < 2; index += 1) {
      const decoded = decodeURIComponent(forms.at(-1));
      if (decoded === forms.at(-1)) break;
      forms.push(decoded);
    }
  } catch {
    return false;
  }
  return forms.every(
    (form) => !EMAIL.test(form) && !TOKEN.test(form) && !CONTROL.test(form) && !URL_CREDENTIALS.test(form),
  );
}

/** Validate a non-secret accessibility name shared by reviewed runner boundaries. */
export function assertSafeReadinessName(value) {
  if (!safeMarkerName(value)) throw unsafeMarker();
  return value;
}

function capabilityUnavailable() {
  return new WorkflowError("AUTH_SESSION_CAPABILITY_UNAVAILABLE", "Browser user-session capability is unavailable", {
    exitCode: 3,
  });
}

/** Validate the narrow browser boundary before any session metadata is created. */
export function assertUserSessionAdapter(adapter) {
  if (!adapter || typeof adapter !== "object" || Array.isArray(adapter)) {
    throw capabilityUnavailable();
  }
  try {
    if (METHODS.some((method) => typeof adapter[method] !== "function")) {
      throw capabilityUnavailable();
    }
  } catch {
    throw capabilityUnavailable();
  }
  return adapter;
}

/** Clone and reduce a proposed accessible marker to its safe persisted fields. */
export function assertSafeAuthMarker(value) {
  let marker;
  try {
    marker = structuredClone(value);
  } catch {
    throw unsafeMarker();
  }
  if (
    !marker ||
    typeof marker !== "object" ||
    Array.isArray(marker) ||
    !safeRoutePath(marker.routePath) ||
    !ROLES.has(marker.role)
  ) {
    throw unsafeMarker();
  }
  assertSafeReadinessName(marker.name);
  return {
    routePath: marker.routePath,
    role: marker.role,
    name: marker.name,
  };
}

export function sanitizeMarkerCandidate(value) {
  return assertSafeAuthMarker(value);
}

export function authSessionCapabilityUnavailable() {
  return capabilityUnavailable();
}
