import { randomUUID } from "node:crypto";
import { mkdir, readFile, rename, unlink, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";

import { parse as parseYaml, stringify as stringifyYaml } from "yaml";

import { WorkflowError } from "./errors.js";
import { assertSafeProjectPath } from "./project-path-safety.js";
import { sha256 } from "./stable-json.js";

const DEFAULT_PATH = ".workflows/requirements.yaml";

function fail(code, message, details = {}, exitCode = 3) {
  throw new WorkflowError(code, message, { details, exitCode });
}

function emptyCatalog(projectId) {
  return { schema: "agent-workflow-requirements/v1", projectId, requirements: [] };
}

function catalogPath(projectContext) {
  const logical = projectContext?.paths?.evaluationRequirements ?? DEFAULT_PATH;
  return resolve(projectContext.projectRoot, ...logical.split("/"));
}

function sorted(values = []) {
  return [...values].sort();
}

function normalizedScope(scope) {
  return {
    kind: scope.kind,
    ...(scope.workflowIds ? { workflowIds: sorted(scope.workflowIds) } : {}),
    ...(scope.platforms ? { platforms: sorted(scope.platforms) } : {}),
    ...(scope.perspectiveIds ? { perspectiveIds: sorted(scope.perspectiveIds) } : {}),
    ...(scope.criterionIds ? { criterionIds: sorted(scope.criterionIds) } : {}),
  };
}

function normalizedEntry(entry) {
  return {
    key: entry.key,
    label: entry.label.trim(),
    answer: structuredClone(entry.answer),
    scope: normalizedScope(entry.scope),
  };
}

function identity(entry) {
  return sha256({ key: entry.key, scope: normalizedScope(entry.scope) });
}

function normalizeCatalog(catalog, registry) {
  registry.validate("evaluationRequirements", catalog);
  const requirements = catalog.requirements.map(normalizedEntry).sort((left, right) => {
    const keyOrder = left.key.localeCompare(right.key);
    return keyOrder || identity(left).localeCompare(identity(right));
  });
  const identities = requirements.map(identity);
  if (new Set(identities).size !== identities.length) {
    fail("REQUIREMENT_SCOPE_CONFLICT", "Evaluation requirements contain duplicate keys at the same scope");
  }
  const normalized = { schema: catalog.schema, projectId: catalog.projectId, requirements };
  registry.validate("evaluationRequirements", normalized);
  return normalized;
}

function matches(values, value) {
  return values === undefined || values.includes(value);
}

function specificity(entry) {
  return (
    Number(entry.scope.kind === "journey") * 8 +
    Number(Boolean(entry.scope.platforms)) * 4 +
    Number(Boolean(entry.scope.perspectiveIds)) * 2 +
    Number(Boolean(entry.scope.criterionIds))
  );
}

export async function readEvaluationRequirements(projectContext, { registry }) {
  if (!projectContext?.project?.id) {
    fail("REQUIREMENTS_PROJECT_UNAVAILABLE", "Evaluation requirements require a configured project");
  }
  const path = catalogPath(projectContext);
  await assertSafeProjectPath(projectContext.projectRoot, path, "Evaluation requirements catalog", {
    finalType: "file",
    allowMissing: true,
  });
  let catalog;
  let recorded = true;
  try {
    catalog = parseYaml(await readFile(path, "utf8"));
  } catch (error) {
    if (error.code === "ENOENT") {
      catalog = emptyCatalog(projectContext.project.id);
      recorded = false;
    } else if (error.name === "YAMLParseError") {
      fail("REQUIREMENTS_INVALID", "Evaluation requirements catalog is invalid YAML");
    } else throw error;
  }
  const normalized = normalizeCatalog(catalog, registry);
  if (normalized.projectId !== projectContext.project.id) {
    fail("REQUIREMENTS_PROJECT_MISMATCH", "Evaluation requirements belong to another project");
  }
  return { catalog: normalized, catalogHash: sha256(normalized), recorded };
}

export function resolveApplicableRequirements({ catalog, workflowId, platform, perspectiveId, criterionIds = [] }) {
  const grouped = new Map();
  for (const requirement of catalog.requirements) {
    if (requirement.scope.kind === "journey" && !matches(requirement.scope.workflowIds, workflowId)) continue;
    if (!matches(requirement.scope.platforms, platform)) continue;
    if (!matches(requirement.scope.perspectiveIds, perspectiveId)) continue;
    if (requirement.scope.criterionIds && !requirement.scope.criterionIds.some((id) => criterionIds.includes(id)))
      continue;
    const current = grouped.get(requirement.key) ?? [];
    current.push(requirement);
    grouped.set(requirement.key, current);
  }
  const requirements = [];
  for (const [key, candidates] of grouped) {
    const maximum = Math.max(...candidates.map(specificity));
    const selected = candidates.filter((entry) => specificity(entry) === maximum);
    if (selected.length !== 1) {
      fail("REQUIREMENT_SCOPE_AMBIGUOUS", `Evaluation requirement ${key} has ambiguous applicable values`);
    }
    requirements.push(structuredClone(selected[0]));
  }
  requirements.sort((left, right) => left.key.localeCompare(right.key));
  const snapshot = { requirements };
  return { ...snapshot, requirementsHash: sha256(snapshot) };
}

export async function writeEvaluationRequirement({ projectContext, expectedHash, entry, registry }) {
  const current = await readEvaluationRequirements(projectContext, { registry });
  if (current.catalogHash !== expectedHash) {
    fail(
      "REQUIREMENTS_REVISION_CONFLICT",
      "Evaluation requirements changed; reload and retry",
      { expectedHash, actualHash: current.catalogHash },
      6,
    );
  }
  const normalized = normalizedEntry(entry);
  registry.validate("evaluationRequirements", {
    schema: "agent-workflow-requirements/v1",
    projectId: projectContext.project.id,
    requirements: [normalized],
  });
  const targetIdentity = identity(normalized);
  const requirements = current.catalog.requirements.filter((candidate) => identity(candidate) !== targetIdentity);
  requirements.push(normalized);
  const catalog = normalizeCatalog({ ...current.catalog, requirements }, registry);
  const path = catalogPath(projectContext);
  const temporary = `${path}.${randomUUID()}.tmp`;
  await assertSafeProjectPath(projectContext.projectRoot, path, "Evaluation requirements catalog", {
    finalType: "file",
    allowMissing: true,
  });
  await mkdir(dirname(path), { recursive: true });
  await assertSafeProjectPath(projectContext.projectRoot, dirname(path), "Evaluation requirements directory", {
    finalType: "directory",
    allowMissing: false,
  });
  await assertSafeProjectPath(projectContext.projectRoot, temporary, "Evaluation requirements temporary file", {
    finalType: "file",
    allowMissing: true,
  });
  let published = false;
  try {
    await writeFile(temporary, stringifyYaml(catalog), { flag: "wx", mode: 0o600 });
    await rename(temporary, path);
    published = true;
  } finally {
    if (!published) await unlink(temporary).catch(() => {});
  }
  return { catalog, catalogHash: sha256(catalog), previousCatalogHash: current.catalogHash };
}
