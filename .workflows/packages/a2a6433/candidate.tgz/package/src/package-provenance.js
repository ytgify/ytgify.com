import { createHash } from "node:crypto";
import { lstatSync, readdirSync, readFileSync, writeFileSync } from "node:fs";
import { join, relative, resolve, sep } from "node:path";

import {
  computePackageInventoryDigest,
  computePackageProvenanceDigest,
  verifyPackageProvenance,
  verifyStudioAssetManifest,
} from "./artifact-digests.js";

const PACKAGE_PROVENANCE_FILE = "package-provenance.json";
export const STUDIO_MANIFEST_FILE = "dist/studio-next/asset-manifest.json";

const INVENTORY_SCHEMA = "agent-workflow-package-inventory/v1";
const PROVENANCE_SCHEMA = "agent-workflow-package-provenance/v1";
const RELEASE_TARGET = "0.4.0";

function compareUtf8(left, right) {
  return Buffer.compare(Buffer.from(left, "utf8"), Buffer.from(right, "utf8"));
}

function digest(bytes) {
  return `sha256:${createHash("sha256").update(bytes).digest("hex")}`;
}

function portablePath(root, path) {
  return relative(root, path).split(sep).join("/");
}

function excluded(path) {
  return path === PACKAGE_PROVENANCE_FILE || path.split("/").some((part) => part === ".git" || part === "node_modules");
}

export function createPackageInventory(packageRoot) {
  const root = resolve(packageRoot);
  const files = [];

  function walk(directory) {
    for (const entry of readdirSync(directory, { withFileTypes: true })) {
      const path = join(directory, entry.name);
      const packagePath = portablePath(root, path);
      if (excluded(packagePath)) continue;

      const stats = lstatSync(path);
      if (stats.isSymbolicLink()) throw new Error(`package payload contains a symbolic link: ${packagePath}`);
      if (stats.isDirectory()) {
        walk(path);
      } else if (stats.isFile()) {
        if (stats.size < 1) throw new Error(`package payload contains an empty file: ${packagePath}`);
        files.push({ path: packagePath, size: stats.size, sha256: digest(readFileSync(path)) });
      } else {
        throw new Error(`package payload contains an unsupported file type: ${packagePath}`);
      }
    }
  }

  walk(root);
  files.sort((left, right) => compareUtf8(left.path, right.path));
  const inventory = { schema: INVENTORY_SCHEMA, files };
  computePackageInventoryDigest(inventory);
  return inventory;
}

export function createPackageProvenance(packageRoot, { source, commit }) {
  const root = resolve(packageRoot);
  const packageInfo = JSON.parse(readFileSync(join(root, "package.json"), "utf8"));
  const studioManifest = JSON.parse(readFileSync(join(root, STUDIO_MANIFEST_FILE), "utf8"));
  const packageInventory = createPackageInventory(root);
  const provenance = {
    schema: PROVENANCE_SCHEMA,
    package: { name: packageInfo.name, version: packageInfo.version, releaseTarget: RELEASE_TARGET },
    source,
    commit,
    packageDigest: computePackageInventoryDigest(packageInventory),
    studioManifestDigest: verifyStudioAssetManifest(studioManifest),
    verified: true,
  };
  provenance.provenanceDigest = computePackageProvenanceDigest(provenance);
  verifyPackageProvenance(provenance, { studioManifest, packageInventory });
  return { packageInventory, provenance };
}

export function writePackageProvenance(packageRoot, options) {
  const { provenance } = createPackageProvenance(packageRoot, options);
  writeFileSync(join(resolve(packageRoot), PACKAGE_PROVENANCE_FILE), `${JSON.stringify(provenance, null, 2)}\n`);
  return provenance;
}

export function verifyInstalledPackage(packageRoot) {
  const root = resolve(packageRoot);
  const provenance = JSON.parse(readFileSync(join(root, PACKAGE_PROVENANCE_FILE), "utf8"));
  const studioManifest = JSON.parse(readFileSync(join(root, STUDIO_MANIFEST_FILE), "utf8"));
  const packageInventory = createPackageInventory(root);
  return verifyPackageProvenance(provenance, { studioManifest, packageInventory });
}
