import { readFile } from "node:fs/promises";

import { WorkflowError } from "./errors.js";
import { sha256 } from "./stable-json.js";

export const SUPPORTED_PROTOCOL_VERSIONS = Object.freeze(["1.0", "1.1"]);
export const PREFERRED_PROTOCOL_VERSION = SUPPORTED_PROTOCOL_VERSIONS.at(-1);

export const PROTOCOL_SCHEMAS = Object.freeze({
  request: "agent-workflow-protocol-request/v1",
  response: "agent-workflow-protocol-response/v1",
  capability: "agent-workflow-capability/v1",
  actionProposal: "agent-workflow-action-proposal/v1",
  actionLease: "agent-workflow-action-lease/v1",
  committedResult: "agent-workflow-committed-result/v1",
  approval: "agent-workflow-approval/v1",
  evidenceArtifact: "agent-workflow-evidence-artifact/v1",
  receipt: "agent-workflow-receipt/v1",
});

const MUTATING_COMMANDS = new Set([
  "agent.claim",
  "agent.route.bind",
  "agent.capabilities",
  "agent.authentication.verify",
  "agent.propose",
  "agent.evidence",
  "agent.commit",
  "agent.heartbeat",
  "agent.reconcile",
  "agent.exploration.finish",
  "agent.release",
]);

export function protocolRequestHash(request) {
  return sha256(request);
}

export function responseProtocolVersion(requestedVersion) {
  return SUPPORTED_PROTOCOL_VERSIONS.includes(requestedVersion) ? requestedVersion : PREFERRED_PROTOCOL_VERSION;
}

export function assertSupportedProtocolVersion(version) {
  if (typeof version !== "string") return version;
  if (SUPPORTED_PROTOCOL_VERSIONS.includes(version)) return version;
  throw new WorkflowError("PROTOCOL_VERSION_UNSUPPORTED", "The requested agent protocol version is unsupported", {
    exitCode: 3,
    details: {
      requestedVersion: typeof version === "string" ? version : null,
      supportedVersions: SUPPORTED_PROTOCOL_VERSIONS,
    },
  });
}

export function validateProtocolMessage(message, registry, { expectedType } = {}) {
  if (message === null || typeof message !== "object" || Array.isArray(message)) {
    registry.validate("protocol", message);
  }
  if (expectedType) {
    const expectedSchema = PROTOCOL_SCHEMAS[expectedType];
    if (!expectedSchema) {
      throw new WorkflowError("UNKNOWN_PROTOCOL_TYPE", `Unknown protocol type: ${expectedType}`, {
        exitCode: 2,
      });
    }
    if (message.schema !== expectedSchema) {
      throw new WorkflowError(
        "PROTOCOL_TYPE_MISMATCH",
        `Expected ${expectedSchema}, received ${message.schema ?? "no schema"}`,
        {
          exitCode: 3,
          details: { expected: expectedSchema, actual: message.schema ?? null },
        },
      );
    }
  }

  if (expectedType === "request" && typeof message?.protocolVersion === "string") {
    assertSupportedProtocolVersion(message.protocolVersion);
  }
  registry.validate("protocol", message);

  return message;
}

export function validateProtocolRequest(request, registry, { currentRevision, existingRequestHash } = {}) {
  validateProtocolMessage(request, registry, { expectedType: "request" });

  const requestHash = protocolRequestHash(request);
  if (existingRequestHash !== undefined) {
    if (existingRequestHash !== requestHash) {
      throw new WorkflowError(
        "IDEMPOTENCY_CONFLICT",
        `Request ID was already used with different input: ${request.requestId}`,
        {
          exitCode: 4,
          details: { requestId: request.requestId },
        },
      );
    }

    return { request, requestHash, replay: true };
  }

  if (
    currentRevision !== undefined &&
    MUTATING_COMMANDS.has(request.command) &&
    request.expectedRevision !== currentRevision
  ) {
    throw new WorkflowError("REVISION_CONFLICT", "The run revision has changed", {
      exitCode: 4,
      details: {
        expected: request.expectedRevision,
        current: currentRevision,
      },
    });
  }

  return {
    request,
    requestHash,
    replay: false,
  };
}

export async function validateProtocolFile(path, registry, options = {}) {
  let message;
  try {
    message = JSON.parse(await readFile(path, "utf8"));
  } catch (error) {
    throw new WorkflowError("INVALID_JSON", `Could not parse JSON: ${path}`, {
      exitCode: 3,
      details: { cause: error.message },
    });
  }

  validateProtocolMessage(message, registry, options);
  return { kind: "protocol", path, schema: message.schema };
}
