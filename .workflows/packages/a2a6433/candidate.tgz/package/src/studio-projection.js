import { projectStudioPerspectiveBatches } from "./studio-perspectives.js";
/* eslint-disable max-lines -- Studio truth projections share one read-only reconstruction boundary. */
import { authenticatedExecutionRecovery } from "./authenticated-browser-execution.js";
import { verifyEvaluationTruth, verifyQualificationTruth } from "./lifecycle.js";
import { projectLifecycleProjection } from "./lifecycle-projection.js";
import { buildRunReport } from "./run-report.js";
import {
  artifactVerdict,
  groupReviewSummary,
  requiredEvidenceReview,
  runEvidenceExplanation,
} from "./studio-evidence-summary.js";
import { classifyStudioRunDispositions } from "./studio-run-disposition.js";
import { verifyRunEvidenceBatch } from "./studio-evidence-verifier.js";
import { paginateStudioCollections } from "./studio-pagination.js";
import {
  projectEvaluationGroupSummary,
  projectTrainingRunSummary,
  trainingSummaryDecision,
} from "./studio-summary-projection.js";

const text = (value) => (typeof value === "string" ? value : null);

function memoizedMethod(target, receiver, method, keyFor = (...args) => JSON.stringify(args)) {
  const cache = new Map();
  return (...args) => {
    const key = keyFor(...args);
    if (!cache.has(key)) cache.set(key, Reflect.apply(target[method], receiver, args));
    return cache.get(key);
  };
}

/**
 * Reuse immutable, verified reads only for the lifetime of one HTTP request.
 * Rejections remain rejections for that request, and no result survives into a
 * later request where durable state may have changed.
 */
export function createStudioProjectionContext(runStore, lifecycleStore = null) {
  const scopedRunStore = Object.create(runStore);
  scopedRunStore.readIndex = memoizedMethod(runStore, scopedRunStore, "readIndex", () => "run-index");
  scopedRunStore.listRunIds = memoizedMethod(runStore, scopedRunStore, "listRunIds", () => "run-ids");
  scopedRunStore.locateRun = memoizedMethod(runStore, scopedRunStore, "locateRun", (runId) => runId);
  scopedRunStore.readRun = memoizedMethod(runStore, scopedRunStore, "readRun", (runId) => runId);
  const explicitLegacyVerifier =
    Object.hasOwn(runStore, "readVerifiedEvidence") && !Object.hasOwn(runStore, "verifyRegisteredEvidenceFromRun");
  if (explicitLegacyVerifier) {
    scopedRunStore.readVerifiedEvidence = (...args) =>
      Reflect.apply(runStore.readVerifiedEvidence, scopedRunStore, args);
  } else if (typeof runStore.verifyRegisteredEvidenceFromRun === "function") {
    scopedRunStore.verifyRegisteredEvidenceFromRun = memoizedMethod(
      runStore,
      scopedRunStore,
      "verifyRegisteredEvidenceFromRun",
      (run, artifactId) =>
        `${run.manifest.runId}:${artifactId}:${run.state.traversal?.artifacts?.[artifactId]?.contentHash}`,
    );
  }

  let scopedLifecycleStore = lifecycleStore;
  if (lifecycleStore) {
    scopedLifecycleStore = Object.create(lifecycleStore);
    for (const method of ["readIndex", "listRecordIds", "listRecords", "readRecord", "readPromotion"]) {
      if (typeof lifecycleStore[method] === "function") {
        scopedLifecycleStore[method] = memoizedMethod(lifecycleStore, scopedLifecycleStore, method);
      }
    }
  }

  return {
    runStore: scopedRunStore,
    lifecycleStore: scopedLifecycleStore,
    projectedRuns: new Map(),
    runReports: new Map(),
    projectedGroups: new Map(),
  };
}

const missing = (error) => ["ENOENT", "RUN_NOT_FOUND", "NOT_FOUND", "REPLAY_NOT_FINALIZED"].includes(error?.code);

function integrityFromError(error) {
  if (missing(error)) return "missing";
  if (
    error instanceof SyntaxError ||
    /(?:CORRUPT|UNSAFE|HASH_MISMATCH|VALIDATION_FAILED|INDEX_|INVALID_LIFECYCLE_ID)/.test(error?.code ?? "")
  )
    return "corrupt";
  return "stale";
}

async function classifiedRead(read) {
  try {
    return { value: await read(), integrity: "verified" };
  } catch (error) {
    return { value: null, integrity: integrityFromError(error) };
  }
}

async function qualificationProjection(runStore, lifecycleStore, id) {
  const loaded = await classifiedRead(() => lifecycleStore.readRecord("qualification", id));
  if (!loaded.value) return { qualificationId: id, integrity: loaded.integrity };
  const qualification = loaded.value;
  let integrity = "verified";
  try {
    await verifyQualificationTruth({ qualificationId: id, qualification, lifecycleStore, runStore });
  } catch (error) {
    integrity = integrityFromError(error);
  }
  return {
    qualificationId: id,
    workflowId: qualification.workflowId,
    revision: qualification.revision,
    platform: qualification.platform,
    replayRunId: qualification.replayRunId,
    effectiveHash: qualification.effectiveHash,
    qualifiedAt: qualification.qualifiedAt,
    integrity,
  };
}

function workflowIdentity(run) {
  return {
    id: text(run.manifest.workflowRef?.id) ?? text(run.workflow?.metadata?.id),
    name: text(run.workflow?.metadata?.name),
  };
}

export function classifyStudioRunManifest(manifest) {
  if (manifest.phase === "training") return "training";
  if (manifest.phase === "evaluation") {
    return manifest.evaluationGroupId ? "qualified-evaluation" : "candidate-evaluation";
  }
  if (manifest.phase === "replay") {
    return manifest.workflowRef?.sourceKind === "promoted" ? "qualification-replay" : "candidate-replay";
  }
  return "unknown";
}

function summary(run) {
  const target = run.manifest.target ? structuredClone(run.manifest.target) : null;
  return {
    runId: run.manifest.runId,
    createdAt: run.manifest.createdAt,
    phase: run.state.phase,
    status: run.state.status,
    journeyOutcome: run.state.traversal?.journeyOutcome ?? null,
    revision: run.state.revision,
    platform: run.manifest.platform,
    profile: run.manifest.profile,
    workflow: workflowIdentity(run),
    classification: classifyStudioRunManifest(run.manifest),
    workflowRevision: text(run.manifest.workflowRef?.revision),
    candidateRevision: Number.isInteger(run.workflow?.metadata?.candidateRevision)
      ? run.workflow.metadata.candidateRevision
      : null,
    sourceKind: text(run.manifest.workflowRef?.sourceKind),
    evaluationGroupId: text(run.manifest.evaluationGroupId),
    qualificationId: text(run.manifest.qualificationId),
    target,
    targetIntegrity: target ? "verified" : "missing",
    replay: "reconstructed",
  };
}

function evaluationRunSummary(run) {
  const perspective = run.manifest.evaluationPerspective;
  const artifacts = Object.values(run.state.traversal?.artifacts ?? {}).filter((artifact) =>
    ["screenshot", "download-content"].includes(artifact.type),
  );
  return {
    ...summary(run),
    perspective: perspective
      ? {
          id: perspective.id,
          version: perspective.version,
          rubricHash: perspective.rubricHash,
          ...(perspective.effectiveRubricHash ? { effectiveRubricHash: perspective.effectiveRubricHash } : {}),
          batchId: perspective.batchId,
          controlRunId: perspective.controlRunId,
        }
      : "not-recorded",
    coverage: "not-loaded",
    qualityOutcome: "unavailable",
    viewport: run.manifest.viewport ?? null,
    preflightOutcome: run.state.preflightOutcome,
    cleanupOutcome: run.state.cleanupOutcome,
    terminalOutcome: run.state.terminalOutcome,
    artifactSummary: { total: artifacts.length, verified: 0, failed: 0 },
  };
}

function trainingBinding(run, candidateRevision) {
  if (!Number.isInteger(candidateRevision) || !Number.isInteger(run.candidateRevision)) return "unknown";
  return run.candidateRevision === candidateRevision ? "current" : "historical";
}

function trainingDispositions(runs) {
  return runs.map((run) => {
    if (run.status === "unavailable") {
      return { ...run, disposition: "unavailable", dispositionReason: "The run could not be reconstructed safely." };
    }
    if (["completed", "blocked", "failed", "abandoned"].includes(run.status)) {
      return {
        ...run,
        disposition: "evidence",
        dispositionReason: "This terminal run remains available as immutable evidence.",
      };
    }
    return { ...run, disposition: "unfinished", dispositionReason: "This run has not reached a terminal outcome." };
  });
}

function trainingAssessment(step) {
  if (!step.expectation.length) return "unavailable";
  if (step.outcome === "passed") return "met";
  if (step.outcome === "failed") return "not-met";
  if (["blocked", "pending", "active"].includes(step.outcome)) return "incomplete";
  return "unavailable";
}

function trainingObservation(step) {
  if (step.outcome === "passed") return "The durable step assessment records a passed outcome.";
  if (step.outcome === "failed") {
    return step.reason
      ? `The durable step assessment records failure: ${step.reason}.`
      : "The durable step assessment records a failed outcome.";
  }
  if (step.outcome === "blocked") {
    return step.reason
      ? `The durable step assessment records a block: ${step.reason}.`
      : "The durable step assessment records a blocked outcome.";
  }
  if (step.attempts > 0)
    return `The durable record contains ${step.attempts} attempt${step.attempts === 1 ? "" : "s"}, without a terminal step outcome.`;
  return "No durable attempt observation is available for this step.";
}

export function trainingEvidence(step, requirements) {
  const relevant = requirements.filter((item) => item.stepId === step.id);
  if (!relevant.length) {
    return { state: "not-required", states: [], summary: "No required evidence is declared for this step." };
  }
  const states = relevant.map((item) => item.state);
  const distinctStates = [...new Set(states)];
  const state = states.every((item) => item === "verified")
    ? "verified"
    : (states.find((item) => item !== "verified") ?? "unavailable");
  const verified = states.filter((item) => item === "verified").length;
  const integritySummary = distinctStates
    .map((item) => `${states.filter((state) => state === item).length} ${item}`)
    .join(", ");
  const sourceStates = [
    ...new Set(
      (step.evidence ?? [])
        .map((artifact) => artifact.sourceIntegrity)
        .filter((state) => state && state !== "verified"),
    ),
  ];
  const sourceSummary = sourceStates.length ? ` Durable source state: ${sourceStates.join(", ")}.` : "";
  return {
    state,
    states: distinctStates,
    sourceStates,
    summary: `${verified}/${relevant.length} required evidence item${relevant.length === 1 ? "" : "s"} verified; integrity states: ${integritySummary}.${sourceSummary}`,
  };
}

function projectTrainingSteps(run) {
  const requirements = run.evidenceReview?.required?.requirements ?? [];
  return run.steps.map((step) => {
    const expectation = Array.isArray(step.expectation) ? step.expectation : [];
    const projected = { ...step, expectation };
    return {
      ...projected,
      observation: trainingObservation(projected),
      assessment: trainingAssessment(projected),
      supportingEvidence: trainingEvidence(projected, requirements),
    };
  });
}

function supervisionSummary(run) {
  const types = [
    { type: "approval.retired", label: "Legacy approval requirement removed" },
    { type: "approval.requested", label: "Approval requested" },
    { type: "approval.recorded", label: "Human approval recorded", predicate: (event) => event.source === "human" },
    {
      type: "approval.recorded",
      label: "Runner authorization recorded",
      predicate: (event) => event.source === "runner",
    },
    { type: "run.pause_requested", label: "Pause requested" },
    { type: "run.paused", label: "Run paused" },
    { type: "host.claimed", label: "Ownership recorded" },
    { type: "host.claimed", label: "Host handoff", predicate: (event) => text(event.payload?.previousHostId) !== null },
    { type: "reconciliation.completed", label: "Run reconciled" },
  ];
  const events = [];
  for (const { type, label, predicate = () => true } of types) {
    const count = run.events.filter((event) => event.type === type && predicate(event)).length;
    if (count) events.push({ type, label, count });
  }
  const attempts = run.steps.reduce((total, step) => total + step.attempts, 0);
  const retries = run.steps.reduce((total, step) => total + Math.max(0, step.attempts - 1), 0);
  const optionalStates = run.steps.reduce((total, step) => total + step.optionalStates.length, 0);
  const reasons = [...new Set(run.steps.map((step) => step.reason).filter(Boolean))];
  return {
    attempts,
    retries,
    optionalStates,
    reasons,
    capabilityGaps: structuredClone(run.capabilityGaps),
    terminalOutcome: run.terminalOutcome ?? null,
    cleanupOutcome: run.cleanupOutcome ?? null,
    events,
    established:
      events.length > 0 || retries > 0 || optionalStates > 0 || reasons.length > 0 || run.capabilityGaps.length > 0,
  };
}

export function trainingProof(run) {
  const evidenceOutcome = run.evidenceReview?.outcome ?? "unavailable";
  const decisionReady =
    run.status === "completed" &&
    run.journeyOutcome === "passed" &&
    run.cleanupOutcome === "passed" &&
    ["passed", "completed"].includes(run.terminalOutcome) &&
    run.disposition === "evidence" &&
    evidenceOutcome === "passed";
  return {
    state: decisionReady ? "verified" : evidenceOutcome,
    decisionReady,
    evidenceOutcome,
    replay: run.replay,
    required: structuredClone(run.evidenceReview?.required ?? null),
    reasons: structuredClone(run.evidenceReview?.reasons ?? []),
  };
}

function trainingOutcome(run) {
  if (["failed", "blocked", "abandoned"].includes(run.status)) return run.status;
  if (run.terminalOutcome === "failed" || run.journeyOutcome === "failed" || run.cleanupOutcome === "failed") {
    return "failed";
  }
  if (run.terminalOutcome === "blocked" || run.journeyOutcome === "blocked") return "blocked";
  if (["active", "preparing", "paused", "awaiting-approval"].includes(run.status)) return "incomplete";
  return run.status ?? "unavailable";
}

function trainingDecision(run, inventoryTrusted) {
  if (!inventoryTrusted) {
    return {
      state: "unavailable",
      reason: "Training inventory is partial, so a newer or current candidate attempt may be unreadable.",
      action: "Refresh review data",
      destination: "refresh",
    };
  }
  if (!run) {
    return {
      state: "no-current-proof",
      reason: "Trusted inventory contains no Training attempt bound to the current candidate.",
      action: "Review current candidate Training prerequisites and history",
      destination: "training-history",
    };
  }
  const outcome = run.outcome;
  if (run.proof.decisionReady) {
    return {
      state: "ready",
      reason: "The current candidate completed its supervised walkthrough with required proof verified.",
      action: "Review evaluation readiness",
      destination: "evaluation",
    };
  }
  if (["failed", "blocked", "incomplete"].includes(outcome)) {
    const recordedReason = run.supervision.reasons[0];
    const capabilityGap = run.supervision.capabilityGaps.find((gap) => gap.reason)?.reason;
    const durableCause = recordedReason
      ? `Recorded step reason: ${recordedReason}.`
      : capabilityGap
        ? `Recorded capability gap: ${capabilityGap}.`
        : `The durable run status is ${run.status}, with journey ${run.journeyOutcome ?? "unavailable"}, terminal ${run.terminalOutcome ?? "unavailable"}, and cleanup ${run.cleanupOutcome ?? "unavailable"}.`;
    return {
      state: outcome,
      reason: durableCause,
      action: "Review decisive evidence",
      destination: "training-step",
    };
  }
  const proofReason = run.proof.reasons[0];
  return {
    state: outcome === "completed" ? "proof-unavailable" : (outcome ?? "unavailable"),
    reason: proofReason
      ? `Required proof is not decision-ready: ${proofReason}`
      : `The durable run status is ${run.status ?? "unavailable"}, and proof integrity is ${run.proof.state}.`,
    action: "Review decisive evidence",
    destination: "training-step",
  };
}

export async function listStudioRuns(store, { cache = null } = {}) {
  const runIds = await store.listRunIds();
  await cache?.retainRunIds?.(runIds);
  const runs = await Promise.all(
    runIds.map(async (runId) => {
      try {
        return cache
          ? await cache.readRunSummary(store, runId, (run) => summary(run))
          : summary(await store.readRun(runId));
      } catch {
        return { runId, status: "unavailable", replay: "failed" };
      }
    }),
  );
  const projected = classifyStudioRunDispositions(
    runs.sort(
      (left, right) =>
        String(right.createdAt ?? "").localeCompare(String(left.createdAt ?? "")) ||
        left.runId.localeCompare(right.runId),
    ),
  );
  return projected;
}

async function projectStudioRunUncached(store, runId, context = null) {
  const run = await store.readRun(runId);
  const state = run.state;
  let recoveryWarning;
  try {
    recoveryWarning = await authenticatedExecutionRecovery(run);
  } catch {
    recoveryWarning =
      "Execution recovery details are unavailable. Do not repeat a possibly attempted action; refresh or inspect the run before continuing.";
  }
  const artifacts = Object.values(state.traversal?.artifacts ?? {}).filter((artifact) =>
    ["screenshot", "download-content"].includes(artifact.type),
  );
  const integrity = new Map();
  const verdicts = await verifyRunEvidenceBatch({ store, run, artifacts });
  for (const [index, verdict] of verdicts.entries()) {
    const artifact = artifacts[index];
    if (verdict.status === "fulfilled") {
      integrity.set(artifact.artifactId, { state: "verified", source: "verified" });
    } else {
      const source = integrityFromError(verdict.reason);
      integrity.set(artifact.artifactId, {
        state: source === "corrupt" ? "failed" : artifactVerdict(verdict.reason),
        source,
      });
    }
  }
  const artifactDtos = artifacts.map((artifact) => ({
    artifactId: artifact.artifactId,
    type: artifact.type,
    mimeType: artifact.mimeType ?? "image/png",
    extension: artifact.mimeType === "image/gif" ? "gif" : artifact.mimeType === "image/jpeg" ? "jpg" : "png",
    download: artifact.download ?? null,
    observedAt: artifact.observedAt,
    contentHash: artifact.contentHash,
    sizeBytes: artifact.sizeBytes,
    dimensions: artifact.dimensions ?? null,
    captureGeometry: artifact.captureGeometry ?? "unbound",
    fullPage: artifact.fullPage ?? null,
    checkpoint: artifact.relation?.checkpoint ?? null,
    stepId: artifact.relation?.stepId ?? null,
    optionalHandlerId: artifact.relation?.optionalHandlerId ?? null,
    integrity: integrity.get(artifact.artifactId)?.state ?? "unavailable",
    sourceIntegrity: integrity.get(artifact.artifactId)?.source ?? "stale",
    url: `/api/runs/${encodeURIComponent(runId)}/artifacts/${encodeURIComponent(artifact.artifactId)}`,
  }));
  const byStep = new Map();
  for (const artifact of artifactDtos) {
    const values = byStep.get(artifact.stepId) ?? [];
    values.push(artifact);
    byStep.set(artifact.stepId, values);
  }
  const workflowSteps = Array.isArray(run.workflow?.steps) ? run.workflow.steps : [];
  const steps = workflowSteps.map((step) => {
    const replayed = state.traversal?.steps?.[step.id] ?? {};
    return {
      id: step.id,
      name: text(step.name) ?? step.id,
      outcome: replayed.outcome ?? "pending",
      attempts: replayed.attempts ?? 0,
      reason: text(replayed.reason),
      capability: text(replayed.capability),
      expectation: Array.isArray(step.expected) ? step.expected.filter((item) => typeof item === "string") : [],
      dependsOn: Array.isArray(step.dependsOn) ? step.dependsOn.filter((item) => typeof item === "string") : [],
      evidence: byStep.get(step.id) ?? [],
      optionalStates: structuredClone(state.optionalApplications?.[step.id] ?? []),
    };
  });
  const requiredEvidence = requiredEvidenceReview(workflowSteps, steps);
  const evidenceReview = {
    ...runEvidenceExplanation(run, requiredEvidence, artifactDtos),
    required: requiredEvidence,
    observed: {
      total: artifactDtos.length,
      verified: artifactDtos.filter((item) => item.integrity === "verified").length,
      failed: artifactDtos.filter((item) => item.integrity === "failed").length,
      unavailable: artifactDtos.filter((item) => item.integrity === "unavailable").length,
    },
  };
  const perspectiveReport = run.manifest.evaluationPerspective
    ? await projectStudioReport(store, runId, context)
    : { perspective: "not-recorded", coverage: "not-recorded", qualityOutcome: "unavailable" };
  const allVerified = artifactDtos.every((artifact) => artifact.integrity === "verified");
  return {
    ...summary(run),
    perspective: perspectiveReport.perspective,
    coverage: perspectiveReport.coverage,
    qualityOutcome: perspectiveReport.qualityOutcome,
    viewport: run.manifest.viewport ?? null,
    ...(recoveryWarning ? { recoveryWarning } : {}),
    replay: allVerified ? "verified" : "degraded",
    preflightOutcome: state.preflightOutcome,
    journeyOutcome: state.traversal?.journeyOutcome ?? null,
    cleanupOutcome: state.cleanupOutcome,
    terminalOutcome: state.terminalOutcome,
    stopReason: [...run.events].reverse().find((event) => event.type === "run.abandoned")?.payload?.reason ?? null,
    capabilityGaps: state.capabilityGaps.map((gap) =>
      typeof gap === "string"
        ? { id: gap, reason: null }
        : {
            id: text(gap.id) ?? text(gap.capability) ?? "unavailable capability",
            reason: text(gap.reason),
          },
    ),
    artifactSummary: {
      total: artifactDtos.length,
      verified: artifactDtos.filter((item) => item.integrity === "verified").length,
      failed: artifactDtos.filter((item) => item.integrity === "failed").length,
    },
    evidenceReview,
    artifacts: artifactDtos,
    steps,
  };
}

export async function projectStudioRun(store, runId, context = null) {
  if (!context) {
    const requestContext = createStudioProjectionContext(store);
    return projectStudioRun(requestContext.runStore, runId, requestContext);
  }
  if (!context.projectedRuns.has(runId)) {
    context.projectedRuns.set(runId, projectStudioRunUncached(context.runStore, runId, context));
  }
  return context.projectedRuns.get(runId);
}

export async function projectStudioReport(store, runId, context = null, options = {}) {
  if (!context) return buildRunReport(store, runId, options);
  const variant = options.skipPerspective ? "without-perspective" : "with-perspective";
  const cacheKey = `${runId}:${variant}`;
  if (!context.runReports.has(cacheKey)) {
    context.runReports.set(cacheKey, buildRunReport(context.runStore, runId, options));
  }
  return context.runReports.get(cacheKey);
}

export async function listStudioLifecycle(runStore, lifecycleStore) {
  return projectLifecycleProjection(runStore, lifecycleStore);
}

function exactCatalogReceipt(receipt, group, member) {
  return (
    receipt?.groupId === group.groupId &&
    receipt.runId === member.runId &&
    receipt.workflowId === group.workflowId &&
    receipt.revision === group.revision &&
    receipt.contentHash === group.contentHash &&
    receipt.platform === member.platform &&
    receipt.effectiveHash === member.effectiveHash &&
    receipt.qualificationId === member.qualificationId &&
    receipt.resetContractHash === group.resetContractHash &&
    receipt.outcome === "passed"
  );
}

/**
 * Catalog status is reconstructed from small immutable lifecycle receipts and
 * run summaries. Exact detail remains responsible for re-reading every
 * screenshot byte, keeping the initial journey list independent of evidence
 * volume without turning missing or mismatched receipts into a pass.
 */
export async function projectStudioEvaluationCatalogReview(lifecycleStore, workflowId, runs, lifecycle) {
  const qualifications = new Map((lifecycle.qualifications ?? []).map((item) => [item.qualificationId, item]));
  const byRunId = new Map(runs.map((run) => [run.runId, run]));
  const groups = await Promise.all(
    (lifecycle.groups ?? [])
      .filter((group) => group.workflowId === workflowId)
      .map(async (group) => {
        const members = await Promise.all(
          (group.members ?? []).map(async (member) => {
            const run = byRunId.get(member.runId) ?? null;
            const qualification = qualifications.get(member.qualificationId) ?? null;
            const receiptRead = await classifiedRead(() => lifecycleStore.readRecord("evaluation", member.runId));
            const receipt = receiptRead.value;
            const exactRun =
              run?.phase === "evaluation" &&
              run.evaluationGroupId === group.groupId &&
              run.qualificationId === member.qualificationId &&
              run.workflow?.id === group.workflowId &&
              run.workflowRevision === group.revision &&
              run.platform === member.platform;
            const failed = exactRun && run.journeyOutcome === "failed" && ["completed", "failed"].includes(run.status);
            const passed =
              exactRun &&
              run.status === "completed" &&
              run.journeyOutcome === "passed" &&
              receiptRead.integrity === "verified" &&
              exactCatalogReceipt(receipt, group, member);
            const integrity = qualification?.integrity === "verified" && (failed || passed) ? "verified" : "degraded";
            return {
              ...member,
              integrity,
              qualification: qualification ? { integrity: qualification.integrity } : null,
              receipt: receipt ? { outcome: receipt.outcome, verifiedAt: receipt.verifiedAt } : null,
              run: run ? { status: run.status, journeyOutcome: run.journeyOutcome } : null,
            };
          }),
        );
        const verified = members.length > 0 && members.every((member) => member.integrity === "verified");
        const failed = verified && members.some((member) => member.run?.journeyOutcome === "failed");
        const passed =
          verified &&
          members.every((member) => member.run?.journeyOutcome === "passed" && member.receipt?.outcome === "passed");
        return {
          ...group,
          integrity: verified ? "verified" : "degraded",
          outcome: failed ? "failed" : passed ? "passed" : verified ? "incomplete" : "degraded",
          members,
        };
      }),
  );
  return { workflowId, groups, sources: { runs: "verified", lifecycle: "verified" } };
}

async function projectStudioEvaluationGroupUncached(runStore, lifecycleStore, groupId, context) {
  const group = await lifecycleStore.readRecord("group", groupId);
  const members = await Promise.all(
    group.members.map(async (member) => {
      try {
        const run = await projectStudioRun(runStore, member.runId, context);
        const receiptRead = await classifiedRead(() => lifecycleStore.readRecord("evaluation", member.runId));
        const qualificationRead = await classifiedRead(() =>
          lifecycleStore.readRecord("qualification", member.qualificationId),
        );
        const qualificationStatus = await qualificationProjection(runStore, lifecycleStore, member.qualificationId);
        const receipt = receiptRead.value;
        const failedRun = run.journeyOutcome === "failed" && ["completed", "failed"].includes(run.status);
        const dependencyIntegrity = [
          ...(failedRun ? [] : [receiptRead.integrity]),
          qualificationRead.integrity,
          qualificationStatus.integrity,
        ].find((value) => value !== "verified");
        let integrity = dependencyIntegrity;
        if (!integrity) {
          if (
            failedRun &&
            (!receipt || receipt.outcome === "failed") &&
            run.phase === "evaluation" &&
            run.evaluationGroupId === groupId &&
            run.qualificationId === member.qualificationId &&
            run.workflow.id === group.workflowId &&
            run.workflowRevision === group.revision &&
            run.platform === member.platform &&
            run.replay === "verified" &&
            run.artifactSummary.total > 0 &&
            run.artifactSummary.verified === run.artifactSummary.total &&
            run.artifactSummary.failed === 0 &&
            run.evidenceReview.outcome === "failed"
          ) {
            integrity = "verified";
          } else {
            try {
              await verifyEvaluationTruth({ groupId, runId: member.runId, lifecycleStore, runStore });
              integrity = "verified";
            } catch (error) {
              integrity = integrityFromError(error);
            }
          }
        }
        return {
          ...member,
          run,
          receipt: receipt ? { outcome: receipt.outcome, verifiedAt: receipt.verifiedAt } : null,
          qualification: qualificationStatus,
          integrity,
        };
      } catch (error) {
        return { ...member, run: null, receipt: null, integrity: integrityFromError(error) };
      }
    }),
  );
  return {
    groupId,
    workflowId: group.workflowId,
    revision: group.revision,
    contentHash: group.contentHash,
    resetContractHash: group.resetContractHash,
    createdAt: group.createdAt,
    members,
  };
}

export async function projectStudioEvaluationGroup(runStore, lifecycleStore, groupId, context = null) {
  const requestContext = context ?? createStudioProjectionContext(runStore, lifecycleStore);
  if (!requestContext.projectedGroups.has(groupId)) {
    requestContext.projectedGroups.set(
      groupId,
      projectStudioEvaluationGroupUncached(
        requestContext.runStore,
        requestContext.lifecycleStore,
        groupId,
        requestContext,
      ),
    );
  }
  return requestContext.projectedGroups.get(groupId);
}

export async function projectStudioEvaluationGroupReview(runStore, lifecycleStore, groupId, context = null) {
  const group = await projectStudioEvaluationGroup(runStore, lifecycleStore, groupId, context);
  const summary = groupReviewSummary(group);
  return {
    ...group,
    integrity: summary.integrity,
    outcome: summary.outcome,
    headline: summary.headline,
    reasons: summary.reasons,
  };
}

function comparisonDuration(report) {
  const start = Date.parse(report.timestamps.createdAt ?? "");
  const end = Date.parse(report.timestamps.completedAt ?? "");
  return Number.isFinite(start) && Number.isFinite(end) && end >= start ? end - start : null;
}

function comparisonSide(step, reportStep, run) {
  if (!step) return null;
  return {
    ...structuredClone(step),
    startedAt: reportStep?.startedAt ?? null,
    completedAt: reportStep?.completedAt ?? null,
    notes: structuredClone(reportStep?.notes ?? []),
    optionalStates: structuredClone(reportStep?.optionalStates ?? step.optionalStates ?? []),
    requiredEvidence: structuredClone(
      run.evidenceReview.required.requirements.filter((requirement) => requirement.stepId === step.id),
    ),
  };
}

function normalizedEvidence(side) {
  return (side?.evidence ?? [])
    .map((item) => `${item.checkpoint ?? ""}:${item.optionalHandlerId ?? ""}:${item.contentHash}:${item.integrity}`)
    .sort();
}

const normalizedNotes = (side) => (side?.notes ?? []).map((item) => `${item.kind}:${item.text}`).sort();

const COMPARISON_PRIORITY = ["explicit-failure", "required-gap", "unmatched", "changed", "unchanged"];

function comparisonPriority(step) {
  const sides = [step.left, step.right].filter(Boolean);
  const requirements = sides.flatMap((side) => side.requiredEvidence);
  if (
    sides.some((side) => side.outcome === "failed" || side.evidence.some((item) => item.integrity === "failed")) ||
    requirements.some((item) => item.state === "failed")
  )
    return "explicit-failure";
  if (requirements.some((item) => ["missing", "unverified", "unavailable"].includes(item.state))) return "required-gap";
  if (step.presence !== "both") return "unmatched";
  return Object.values(step.changes).some(Boolean) ? "changed" : "unchanged";
}

export function prioritizeComparisonSteps(steps) {
  return steps
    .map((step, sourceIndex) => ({ ...step, priority: comparisonPriority(step), sourceIndex }))
    .sort(
      (left, right) =>
        COMPARISON_PRIORITY.indexOf(left.priority) - COMPARISON_PRIORITY.indexOf(right.priority) ||
        left.sourceIndex - right.sourceIndex,
    )
    .map(({ sourceIndex: _sourceIndex, ...step }) => step);
}

export async function projectStudioRunComparison(store, leftRunId, rightRunId) {
  const context = createStudioProjectionContext(store);
  const [leftRun, rightRun, leftReport, rightReport] = await Promise.all([
    projectStudioRun(context.runStore, leftRunId, context),
    projectStudioRun(context.runStore, rightRunId, context),
    projectStudioReport(context.runStore, leftRunId, context),
    projectStudioReport(context.runStore, rightRunId, context),
  ]);
  if (!leftRun.workflow.id || leftRun.workflow.id !== rightRun.workflow.id) {
    const error = new Error("Runs belong to different workflows");
    error.code = "COMPARISON_INCOMPATIBLE";
    throw error;
  }
  const leftSteps = new Map(leftRun.steps.map((step) => [step.id, step]));
  const rightSteps = new Map(rightRun.steps.map((step) => [step.id, step]));
  const order = [...leftRun.steps.map((step) => step.id)];
  for (const step of rightRun.steps) if (!leftSteps.has(step.id)) order.push(step.id);
  const steps = order.map((stepId) => {
    const left = comparisonSide(
      leftSteps.get(stepId),
      leftReport.steps.find((step) => step.id === stepId),
      leftRun,
    );
    const right = comparisonSide(
      rightSteps.get(stepId),
      rightReport.steps.find((step) => step.id === stepId),
      rightRun,
    );
    return {
      id: stepId,
      presence: left && right ? "both" : left ? "left-only" : "right-only",
      left,
      right,
      changes: {
        outcome: left?.outcome !== right?.outcome,
        notes: JSON.stringify(normalizedNotes(left)) !== JSON.stringify(normalizedNotes(right)),
        evidence: JSON.stringify(normalizedEvidence(left)) !== JSON.stringify(normalizedEvidence(right)),
      },
    };
  });
  const prioritized = prioritizeComparisonSteps(steps);
  const summary = Object.fromEntries(
    COMPARISON_PRIORITY.map((priority) => [priority, prioritized.filter((step) => step.priority === priority).length]),
  );
  const leftDurationMs = comparisonDuration(leftReport);
  const rightDurationMs = comparisonDuration(rightReport);
  return {
    workflowId: leftRun.workflow.id,
    left: {
      ...leftRun,
      report: leftReport,
      reportIntegrity: leftReport.integrity.overall,
      durationMs: leftDurationMs,
    },
    right: {
      ...rightRun,
      report: rightReport,
      reportIntegrity: rightReport.integrity.overall,
      durationMs: rightDurationMs,
    },
    durationDeltaMs: leftDurationMs === null || rightDurationMs === null ? null : rightDurationMs - leftDurationMs,
    summary,
    steps: prioritized,
  };
}

export async function projectStudioEvaluationReview(
  runStore,
  lifecycleStore,
  workflowId,
  context = null,
  { detailedRunIds = null, pagination = null, cache = null } = {},
) {
  const requestContext = context ?? createStudioProjectionContext(runStore, lifecycleStore);
  const scopedRunStore = requestContext.runStore;
  const scopedLifecycleStore = requestContext.lifecycleStore;
  const runIds = await scopedRunStore.listRunIds();
  const detailSet = detailedRunIds === null ? null : new Set(detailedRunIds);
  const entries = await Promise.all(
    runIds.map(async (runId) => {
      try {
        if (cache && detailSet !== null && !detailSet.has(runId)) {
          const projected = await cache.readRunSummary(
            scopedRunStore,
            runId,
            (run) => (workflowIdentity(run).id === workflowId ? evaluationRunSummary(run) : null),
            { namespace: `evaluation:${workflowId}` },
          );
          return { projected, unavailable: false };
        }
        const run = await scopedRunStore.readRun(runId);
        if (workflowIdentity(run).id !== workflowId) return { projected: null, unavailable: false };
        const projected =
          detailSet === null || detailSet.has(runId)
            ? await projectStudioRun(scopedRunStore, runId, requestContext)
            : evaluationRunSummary(run);
        return { projected, unavailable: false };
      } catch {
        return { projected: null, unavailable: true };
      }
    }),
  );
  const projectedRuns = entries.map((entry) => entry.projected).filter(Boolean);
  const runs = classifyStudioRunDispositions(
    projectedRuns
      .filter((run) => run?.workflow?.id === workflowId)
      .sort(
        (left, right) =>
          String(right.createdAt ?? "").localeCompare(String(left.createdAt ?? "")) ||
          left.runId.localeCompare(right.runId),
      ),
  );
  const unavailableRuns = entries.filter((entry) => entry.unavailable).length;
  let groups = [];
  let lifecycle = "verified";
  try {
    const summaries = (await scopedLifecycleStore.listRecords("group")).filter(
      (group) => group.workflowId === workflowId,
    );
    groups =
      detailSet !== null
        ? summaries.map((group) => projectEvaluationGroupSummary(group, runs))
        : await Promise.all(
            summaries.map(async (group) => {
              try {
                return groupReviewSummary(
                  await projectStudioEvaluationGroup(
                    scopedRunStore,
                    scopedLifecycleStore,
                    group.groupId,
                    requestContext,
                  ),
                );
              } catch (error) {
                return {
                  groupId: group.groupId,
                  workflowId,
                  revision: group.revision,
                  createdAt: group.createdAt,
                  integrity: integrityFromError(error),
                  members: group.members.map((member) => ({
                    runId: member.runId,
                    platform: member.platform,
                    viewport: member.viewport ?? null,
                    integrity: "unavailable",
                    qualification: null,
                    receipt: null,
                    run: null,
                  })),
                };
              }
            }),
          );
  } catch {
    lifecycle = "unavailable";
  }
  const perspectives = await projectStudioPerspectiveBatches(scopedRunStore, workflowId, { detailedRunIds });
  const orderedGroups = groups.sort(
    (left, right) =>
      String(right.createdAt ?? "").localeCompare(String(left.createdAt ?? "")) ||
      left.groupId.localeCompare(right.groupId),
  );
  let returnedRuns = runs;
  let returnedGroups = orderedGroups;
  let returnedBatches = perspectives.batches;
  let page;
  if (pagination) {
    const paged = paginateStudioCollections({
      kind: `evaluation:${workflowId}`,
      cursor: pagination.cursor ?? null,
      collections: {
        runs: { items: runs, idField: "runId" },
        groups: { items: orderedGroups, idField: "groupId" },
        perspectiveBatches: { items: perspectives.batches, idField: "batchId" },
      },
    });
    returnedRuns = paged.values.runs;
    returnedGroups = paged.values.groups;
    returnedBatches = paged.values.perspectiveBatches;
    if (detailSet?.size) {
      for (const run of runs) {
        if (detailSet.has(run.runId) && !returnedRuns.some((item) => item.runId === run.runId)) {
          returnedRuns.push(run);
        }
      }
    }
    const grouped = new Set(orderedGroups.flatMap((group) => group.members.map((member) => member.runId)));
    const totalHistoryRecords =
      orderedGroups.length +
      runs.filter(
        (run) =>
          run.phase === "evaluation" &&
          ["candidate-evaluation", "qualified-evaluation"].includes(run.classification) &&
          !grouped.has(run.runId),
      ).length;
    page = {
      ...paged.page,
      returned: { ...paged.page.returned, runs: returnedRuns.length },
      totalHistoryRecords,
    };
  }
  const values = (key) => [...new Set(runs.map((run) => run[key]).filter(Boolean))].sort();
  const grouped = new Set(orderedGroups.flatMap((group) => group.members.map((member) => member.runId)));
  return {
    workflowId,
    runs: returnedRuns,
    perspectiveBatches: returnedBatches,
    perspectiveBatchIntegrity: perspectives.integrity,
    groups: returnedGroups,
    groupedRunIds: returnedRuns.filter((run) => grouped.has(run.runId)).map((run) => run.runId),
    filters: {
      platforms: values("platform"),
      classifications: values("classification"),
      workflowRevisions: values("workflowRevision"),
      statuses: values("status"),
      dispositions: values("disposition"),
    },
    inventory: {
      readable: runs.length,
      unavailable: unavailableRuns,
    },
    sources: { runs: unavailableRuns ? "partial" : "verified", lifecycle },
    ...(page ? { page } : {}),
  };
}

export async function projectStudioTrainingReview(
  runStore,
  workflowId,
  candidateRevision,
  { detailedRunIds = null, context = null, pagination = null, cache = null } = {},
) {
  const requestContext = context ?? createStudioProjectionContext(runStore);
  const scopedRunStore = requestContext.runStore;
  const detailSet = detailedRunIds === null ? null : new Set(detailedRunIds);
  let runIds;
  try {
    runIds = await scopedRunStore.listRunIds();
  } catch {
    return {
      workflowId,
      candidateRevision: Number.isInteger(candidateRevision) ? candidateRevision : null,
      state: "unavailable",
      decision: trainingDecision(null, false),
      selectedRun: null,
      runs: [],
      inventory: { integrity: "unavailable", readable: 0, unreadable: 0, unavailableRuns: [] },
      supersession: {
        supported: false,
        state: "unavailable",
        reason: "Durable Training records do not encode supersession; unfinished attempts remain unfinished.",
      },
    };
  }
  const entries = await Promise.all(
    runIds.map(async (runId) => {
      try {
        if (cache && detailSet !== null && !detailSet.has(runId)) {
          const projected = await cache.readRunSummary(
            scopedRunStore,
            runId,
            (run) =>
              run.manifest.phase === "training" && workflowIdentity(run).id === workflowId
                ? projectTrainingRunSummary(run, candidateRevision)
                : null,
            { namespace: `training:${workflowId}:${candidateRevision ?? "unknown"}` },
          );
          return projected ? { projected, events: [] } : null;
        }
        const source = await scopedRunStore.readRun(runId);
        if (source.manifest.phase !== "training" || workflowIdentity(source).id !== workflowId) return null;
        const projected =
          detailSet === null || detailSet.has(runId)
            ? await projectStudioRun(scopedRunStore, runId, requestContext)
            : projectTrainingRunSummary(source, candidateRevision);
        return { projected, events: source.events ?? [] };
      } catch {
        return { unavailable: { runId, integrity: "unavailable" } };
      }
    }),
  );
  const unavailableRuns = entries.filter((entry) => entry?.unavailable).map((entry) => entry.unavailable);
  const readable = trainingDispositions(
    entries
      .filter((entry) => entry?.projected)
      .map((entry) => entry.projected)
      .sort(
        (left, right) =>
          String(right.createdAt ?? "").localeCompare(String(left.createdAt ?? "")) ||
          left.runId.localeCompare(right.runId),
      ),
  ).map((run) => {
    const source = entries.find((entry) => entry?.projected?.runId === run.runId);
    const binding = trainingBinding(run, candidateRevision);
    if (!Object.hasOwn(run, "steps")) return { ...run, binding };
    const detailed = { ...run, binding, steps: projectTrainingSteps(run) };
    detailed.outcome = trainingOutcome(detailed);
    detailed.proof = trainingProof(detailed);
    detailed.supervision = supervisionSummary({ ...detailed, events: source.events });
    return detailed;
  });
  const inventoryTrusted = unavailableRuns.length === 0;
  const selectedSummary = inventoryTrusted ? (readable.find((run) => run.binding === "current") ?? null) : null;
  const selectedRun = selectedSummary && Object.hasOwn(selectedSummary, "steps") ? selectedSummary : null;
  const selectedRunId = selectedSummary?.runId ?? null;
  const decision = selectedRun
    ? trainingDecision(selectedRun, inventoryTrusted)
    : trainingSummaryDecision(selectedSummary, inventoryTrusted);
  let returnedRuns = readable;
  let page;
  if (pagination) {
    const paged = paginateStudioCollections({
      kind: `training:${workflowId}`,
      cursor: pagination.cursor ?? null,
      collections: { runs: { items: readable, idField: "runId" } },
    });
    returnedRuns = paged.values.runs;
    if (detailSet?.size) {
      for (const run of readable) {
        if (detailSet.has(run.runId) && !returnedRuns.some((item) => item.runId === run.runId)) returnedRuns.push(run);
      }
    }
    page = {
      ...paged.page,
      returned: { ...paged.page.returned, runs: returnedRuns.length },
      totalHistoryRecords: readable.length,
    };
  }
  return {
    workflowId,
    candidateRevision: Number.isInteger(candidateRevision) ? candidateRevision : null,
    state: decision.state,
    decision,
    selectedRunId,
    selectedRun,
    runs: returnedRuns,
    inventory: {
      integrity: inventoryTrusted ? "verified" : "partial",
      readable: readable.length,
      unreadable: unavailableRuns.length,
      unavailableRuns,
    },
    supersession: {
      supported: false,
      state: "unavailable",
      reason: "Durable Training records do not encode supersession; unfinished attempts remain unfinished.",
    },
    ...(page ? { page } : {}),
  };
}

const AUTH_SESSION_ACTIONS = {
  "not-set-up": ["open"],
  "sign-in-needed": ["reauthenticate", "verify", "clear"],
  verifying: [],
  ready: ["open", "verify", "reauthenticate", "clear"],
  "needs-attention": ["open", "verify", "clear"],
};

/** Project local authentication coordination without exposing profile or marker data. */
export function projectStudioAuthSession(target, record, statusOverride, actionsOverride) {
  const status =
    statusOverride ??
    (record?.state === "ready"
      ? "ready"
      : record?.state === "setup" || record?.state === "needs-login"
        ? "sign-in-needed"
        : record?.state === "clear-failed"
          ? "needs-attention"
          : "not-set-up");
  return {
    status,
    targetId: target.id,
    environment: target.environment,
    origin: target.baseUrl,
    lastVerifiedAt: record?.lastVerifiedAt ?? null,
    revision: record?.revision ?? 0,
    actions: actionsOverride ?? AUTH_SESSION_ACTIONS[status],
  };
}
