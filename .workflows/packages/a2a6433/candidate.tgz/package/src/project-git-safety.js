import { execFile } from "node:child_process";
import { lstat, realpath } from "node:fs/promises";
import { isAbsolute, join, relative, resolve, sep } from "node:path";
import { promisify } from "node:util";

import { WorkflowError } from "./errors.js";

const execute = promisify(execFile);

function fail(code, message, details = {}) {
  throw new WorkflowError(code, message, { exitCode: 3, details });
}

function localPath(context) {
  const root = resolve(context?.projectRoot ?? "");
  const logical = context?.paths?.localStore;
  if (!logical || isAbsolute(logical) || logical.split(/[\\/]+/u).some((part) => !part || part === "..")) {
    fail("PROJECT_CONTEXT_INVALID", "ProjectContext local store must be repository-relative");
  }
  const absolute = resolve(root, ...logical.split(/[\\/]+/u));
  const suffix = relative(root, absolute);
  if (suffix === ".." || suffix.startsWith(`..${sep}`) || isAbsolute(suffix)) {
    fail("PATH_TRAVERSAL", "ProjectContext local store escapes the repository");
  }
  return { root, logical: logical.split(/\\/u).join("/"), absolute };
}

async function assertNoSymlinks(root, target) {
  let cursor = root;
  for (const part of relative(root, target).split(sep).filter(Boolean)) {
    cursor = join(cursor, part);
    try {
      if ((await lstat(cursor)).isSymbolicLink()) {
        fail("PROJECT_PATH_UNSAFE", "Local store ancestry cannot contain symlinks", {
          path: relative(root, cursor).split(sep).join("/"),
        });
      }
    } catch (error) {
      if (error.code === "ENOENT") return;
      throw error;
    }
  }
}

async function git(root, args) {
  try {
    return await execute("git", ["-C", root, ...args], { encoding: "utf8" });
  } catch (error) {
    return error;
  }
}

/** Inspect whether the ProjectContext local store is ignored and wholly untracked. */
export async function inspectProjectGitSafety(projectContext) {
  const path = localPath(projectContext);
  const rootStat = await lstat(path.root).catch(() => null);
  if (!rootStat?.isDirectory() || rootStat.isSymbolicLink()) {
    fail("PROJECT_ROOT_INVALID", "ProjectContext root must be a real directory");
  }
  await assertNoSymlinks(path.root, path.absolute);
  const repository = await git(path.root, ["rev-parse", "--show-toplevel"]);
  if (repository.code) fail("PROJECT_GIT_UNAVAILABLE", "Project root is not an inspectable Git repository");
  if ((await realpath(repository.stdout.trim())) !== (await realpath(path.root))) {
    fail("PROJECT_ROOT_AMBIGUOUS", "ProjectContext root does not match the Git repository root");
  }

  const trackedResult = await git(path.root, ["ls-files", "-z", "--", path.logical]);
  if (trackedResult.code) fail("PROJECT_GIT_UNAVAILABLE", "Could not inspect tracked local state");
  const tracked = trackedResult.stdout.length > 0;
  const ignoredResult = await git(path.root, ["check-ignore", "--no-index", "-q", "--", path.logical]);
  if (![0, 1].includes(ignoredResult.code ?? 0)) {
    fail("PROJECT_GIT_UNAVAILABLE", "Could not inspect ignore status for local state");
  }
  const ignored = !ignoredResult.code;

  return {
    projectRoot: path.root,
    localStore: path.logical,
    ignored,
    tracked,
    status: ignored && !tracked ? "safe" : "unsafe",
  };
}
