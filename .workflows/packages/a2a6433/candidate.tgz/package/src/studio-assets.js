import { createHash } from "node:crypto";
import { constants } from "node:fs";
import { lstat, open, realpath } from "node:fs/promises";
import { extname, join, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";

import { verifyStudioAssetManifest } from "./artifact-digests.js";

const MANIFEST_NAME = "asset-manifest.json";
const MIME = new Map([
  [".css", "text/css; charset=utf-8"],
  [".html", "text/html; charset=utf-8"],
  [".ico", "image/x-icon"],
  [".js", "text/javascript; charset=utf-8"],
  [".json", "application/json; charset=utf-8"],
  [".png", "image/png"],
  [".svg", "image/svg+xml"],
  [".txt", "text/plain; charset=utf-8"],
  [".woff2", "font/woff2"],
]);

export class StudioAssetError extends Error {
  constructor() {
    super("Packaged Studio assets are unavailable or invalid.");
    this.name = "StudioAssetError";
    this.code = "STUDIO_ASSETS_UNAVAILABLE";
  }
}

function unavailable() {
  throw new StudioAssetError();
}

async function regularFileBytes(path) {
  let handle;
  try {
    const entry = await lstat(path);
    if (!entry.isFile() || entry.isSymbolicLink()) unavailable();
    handle = await open(path, constants.O_RDONLY | (constants.O_NOFOLLOW ?? 0));
    const opened = await handle.stat();
    if (!opened.isFile() || opened.dev !== entry.dev || opened.ino !== entry.ino) unavailable();
    return { bytes: await handle.readFile(), stat: opened };
  } catch (error) {
    if (error instanceof StudioAssetError) throw error;
    unavailable();
  } finally {
    await handle?.close();
  }
}

async function assertRealDirectories(root, segments) {
  let current = root;
  for (const segment of segments) {
    current = join(current, segment);
    try {
      const entry = await lstat(current);
      if (!entry.isDirectory() || entry.isSymbolicLink()) unavailable();
    } catch (error) {
      if (error instanceof StudioAssetError) throw error;
      unavailable();
    }
  }
}

function assertSafeHtml(bytes) {
  const html = bytes.toString("utf8");
  if (Buffer.byteLength(html, "utf8") !== bytes.length) unavailable();
  if (/<style\b|\sstyle\s*=/iu.test(html)) unavailable();
  if (/\son[a-z0-9_-]+\s*=/iu.test(html)) unavailable();
  if (/<(?:base|frame|frameset|iframe|object|embed)\b/iu.test(html)) unavailable();
  if (/\s(?:srcdoc|srcset)\s*=/iu.test(html) || /<meta\b[^>]*http-equiv\s*=\s*["']?refresh/iu.test(html)) {
    unavailable();
  }
  if (/unsafe-inline|unsafe-eval/iu.test(html)) unavailable();
  const urlAttribute = /\s(?:href|src|data|action|formaction|poster|xlink:href)\s*=\s*(["']?)([^"'\s>]+)\1/giu;
  for (const match of html.matchAll(urlAttribute)) {
    const value = match[2];
    if (/^(?:javascript|data|blob):/iu.test(value)) unavailable();
    if (value.includes("&") || value.includes("\\") || value.startsWith("//")) unavailable();
    if (!value.startsWith("/") && !value.startsWith("#")) unavailable();
  }
  for (const match of html.matchAll(/<script\b[^>]*\bsrc\s*=\s*(["']?)([^"'\s>]+)\1/giu)) {
    if (!match[2].startsWith("/_next/static/")) unavailable();
  }
  return html;
}

function inlineScriptHashes(html) {
  const hashes = [];
  for (const match of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/giu)) {
    if (/\bsrc\s*=/iu.test(match[1]) || match[2].length === 0) continue;
    hashes.push(`sha256-${createHash("sha256").update(match[2], "utf8").digest("base64")}`);
  }
  return hashes;
}

function securityHeaders(scriptHashes) {
  const scriptSources = ["'self'", ...scriptHashes.map((hash) => `'${hash}'`)].join(" ");
  return Object.freeze({
    "cache-control": "no-store",
    "content-security-policy": `default-src 'none'; script-src ${scriptSources}; style-src 'self'; img-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'`,
    "referrer-policy": "no-referrer",
    "x-content-type-options": "nosniff",
    "x-frame-options": "DENY",
  });
}

export async function loadStudioAssets(assetRoot = new URL("../dist/studio-next/", import.meta.url)) {
  try {
    const requestedRoot = resolve(assetRoot instanceof URL ? fileURLToPath(assetRoot) : assetRoot);
    const rootEntry = await lstat(requestedRoot);
    if (!rootEntry.isDirectory() || rootEntry.isSymbolicLink()) unavailable();
    const root = await realpath(requestedRoot);

    const manifestRecord = await regularFileBytes(join(root, MANIFEST_NAME));
    let manifest;
    try {
      manifest = JSON.parse(manifestRecord.bytes.toString("utf8"));
      verifyStudioAssetManifest(manifest);
    } catch {
      unavailable();
    }

    const assets = new Map();
    const scriptHashes = new Set();
    for (const asset of manifest.assets) {
      const segments = asset.path.split("/");
      await assertRealDirectories(root, segments.slice(0, -1));
      const file = resolve(root, ...segments);
      if (!file.startsWith(`${root}${sep}`)) unavailable();
      const resolvedFile = await realpath(file);
      if (resolvedFile !== file || !resolvedFile.startsWith(`${root}${sep}`)) unavailable();
      const type = MIME.get(extname(asset.path));
      if (!type) unavailable();
      const record = await regularFileBytes(file);
      if (record.stat.size !== asset.size || record.bytes.length !== asset.size) unavailable();
      const digest = `sha256:${createHash("sha256").update(record.bytes).digest("hex")}`;
      if (digest !== asset.sha256) unavailable();
      if (type.startsWith("text/html")) {
        for (const hash of inlineScriptHashes(assertSafeHtml(record.bytes))) scriptHashes.add(hash);
      }
      assets.set(`/${asset.path}`, Object.freeze({ bytes: record.bytes, type }));
    }
    assets.set("/", assets.get(`/${manifest.entrypoint}`));
    return Object.freeze({
      assets,
      manifest: Object.freeze(structuredClone(manifest)),
      securityHeaders: securityHeaders([...scriptHashes].sort()),
    });
  } catch (error) {
    if (error instanceof StudioAssetError) throw error;
    unavailable();
  }
}
