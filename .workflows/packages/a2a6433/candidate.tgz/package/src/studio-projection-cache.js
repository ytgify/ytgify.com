import { lstat, realpath } from "node:fs/promises";
import { join, relative, resolve, sep } from "node:path";

import { WorkflowError } from "./errors.js";

function cacheError(message) {
  return new WorkflowError("VALIDATION_FAILED", message, { exitCode: 3 });
}

function statIdentity(stat) {
  return {
    device: stat.dev.toString(),
    inode: stat.ino.toString(),
    size: stat.size.toString(),
    modifiedNs: stat.mtimeNs.toString(),
    changedNs: stat.ctimeNs.toString(),
  };
}

async function regularFileIdentity(path, { optional = false } = {}) {
  try {
    const stat = await lstat(path, { bigint: true });
    if (!stat.isFile() || stat.isSymbolicLink()) throw cacheError("Studio projection source must be a regular file");
    return statIdentity(stat);
  } catch (error) {
    if (optional && error?.code === "ENOENT") return null;
    throw error;
  }
}

async function runFingerprint(store, runId) {
  const directory = await store.locateRun(runId);
  const root = resolve(store.root);
  const resolvedDirectory = resolve(directory);
  const suffix = relative(root, resolvedDirectory);
  if (!suffix || suffix.startsWith("..") || suffix.split(sep).includes("..")) {
    throw cacheError("Studio projection source escapes the run store");
  }

  // The configured root may itself pass through an operating-system alias
  // (macOS exposes /var as /private/var). Inspect only entries owned by the
  // run store, then compare canonical paths relative to the canonical root.
  let cursor = root;
  const rootStat = await lstat(cursor, { bigint: true });
  if (!rootStat.isDirectory() || rootStat.isSymbolicLink()) {
    throw cacheError("Studio projection root must be a directory");
  }
  for (const segment of suffix.split(sep)) {
    cursor = join(cursor, segment);
    const directoryStat = await lstat(cursor, { bigint: true });
    if (!directoryStat.isDirectory() || directoryStat.isSymbolicLink()) {
      throw cacheError("Studio projection source cannot contain symlinks");
    }
  }
  const canonicalRoot = await realpath(root);
  const canonicalDirectory = await realpath(resolvedDirectory);
  if (canonicalDirectory !== resolve(canonicalRoot, suffix)) {
    throw cacheError("Studio projection source escapes the run store");
  }
  return {
    runId,
    directory: suffix.split(sep).join("/"),
    manifest: await regularFileIdentity(join(resolvedDirectory, "manifest.json")),
    workflow: await regularFileIdentity(join(resolvedDirectory, "workflow.json"), { optional: true }),
    events: await regularFileIdentity(join(resolvedDirectory, "events.jsonl")),
  };
}

/**
 * Process-local read-through cache for sanitized run projections.
 *
 * Every hit first compares authoritative file identities. Cached values never
 * include reconstructed runs, event journals, evidence bytes, or verified
 * evidence claims. Every hit still compares the authoritative source
 * fingerprint; summaries are never loaded from a separately writable file.
 */
export class StudioProjectionCache {
  constructor() {
    this.entries = new Map();
    this.inflight = new Map();
    this.stats = { hits: 0, misses: 0 };
  }

  clear() {
    this.entries.clear();
    this.inflight.clear();
  }

  async retainRunIds(runIds) {
    const retained = new Set(runIds);
    for (const [entryKey, entry] of this.entries) {
      let runId;
      try {
        runId = JSON.parse(entry.key).runId;
      } catch {}
      if (!retained.has(runId)) this.entries.delete(entryKey);
    }
  }

  async readRunSummary(store, runId, project, { namespace = "catalog" } = {}) {
    if (!store.root || typeof store.locateRun !== "function") return project(await store.readRun(runId));
    const before = await runFingerprint(store, runId);
    const key = JSON.stringify(before);
    const entryKey = `${namespace}:${runId}`;
    const cached = this.entries.get(entryKey);
    if (cached?.key === key) {
      this.stats.hits += 1;
      return structuredClone(cached.value);
    }
    this.stats.misses += 1;
    const inflightKey = `${entryKey}:${key}`;
    if (!this.inflight.has(inflightKey)) {
      this.inflight.set(
        inflightKey,
        (async () => {
          const value = await project(await store.readRun(runId));
          const after = await runFingerprint(store, runId);
          if (value !== null && value !== undefined && JSON.stringify(after) === key) {
            this.entries.set(entryKey, { key, value: structuredClone(value) });
          }
          return value;
        })().finally(() => this.inflight.delete(inflightKey)),
      );
    }
    return structuredClone(await this.inflight.get(inflightKey));
  }
}
