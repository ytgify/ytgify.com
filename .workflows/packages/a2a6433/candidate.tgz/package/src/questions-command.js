import { readFile } from "node:fs/promises";
import { resolve } from "node:path";

import { WorkflowError } from "./errors.js";
import { EvaluationQuestionStore } from "./evaluation-question-store.js";
import { listEvaluationQuestions, proposeEvaluationQuestion } from "./evaluation-questions.js";
import { PerspectiveBatchStore } from "./perspective-batch-store.js";
import { RequirementDecisionStore } from "./requirement-decision-store.js";
import { RunControlStore } from "./run-control-store.js";

function success(command, data) {
  return { ok: true, command, data, warnings: [] };
}

function studioRoute(question) {
  return `#/journeys/${encodeURIComponent(question.workflowId)}/questions/question/${encodeURIComponent(question.questionId)}`;
}

async function readStandardInput() {
  let input = "";
  for await (const chunk of process.stdin) input += chunk;
  return input;
}

async function readInput(flags) {
  const text = flags.get("file") ? await readFile(resolve(flags.get("file")), "utf8") : await readStandardInput();
  if (!text.trim())
    throw new WorkflowError("INVALID_USAGE", "questions propose requires JSON on stdin or --file", { exitCode: 2 });
  try {
    return JSON.parse(text);
  } catch (error) {
    throw new WorkflowError("INVALID_JSON", "Could not parse evaluation question JSON", {
      exitCode: 2,
      details: { cause: error.message },
    });
  }
}

export async function executeQuestionsCommand(args, flags, registry) {
  const [operation, first, second] = args;
  const allowed = operation === "propose" ? ["store", "json", "file"] : ["store", "json"];
  if (!operation || [...flags.keys()].some((name) => !allowed.includes(name)))
    throw new WorkflowError("INVALID_USAGE", "questions accepts propose, list, or show with documented flags", {
      exitCode: 2,
    });
  const root = resolve(flags.get("store") ?? ".workflows/local");
  const questionStore = await new EvaluationQuestionStore(root, { registry }).init();
  const decisionStore = await new RequirementDecisionStore(root, { registry }).init();
  if (operation === "propose") {
    if (!first || second || args.length !== 2)
      throw new WorkflowError("INVALID_USAGE", "questions propose requires RUN_ID", { exitCode: 2 });
    const question = await proposeEvaluationQuestion({
      questionStore,
      runStore: new RunControlStore(root, { registry }),
      batchStore: new PerspectiveBatchStore(root, { registry }),
      runId: first,
      input: await readInput(flags),
    });
    return success("questions propose", { question, studioRoute: studioRoute(question) });
  }
  if (operation === "list") {
    if (!first || second || args.length !== 2)
      throw new WorkflowError("INVALID_USAGE", "questions list requires WORKFLOW_ID", { exitCode: 2 });
    const questions = await listEvaluationQuestions({ questionStore, workflowId: first });
    return success("questions list", {
      workflowId: first,
      questions,
      discussionResponses: (
        await Promise.all(questions.map((question) => decisionStore.list(question.questionId)))
      ).flatMap((records) =>
        records.filter((record) => record.schema === "agent-workflow-evaluation-question-response/v1"),
      ),
    });
  }
  if (operation === "show") {
    if (!first || !second || args.length !== 3)
      throw new WorkflowError("INVALID_USAGE", "questions show requires RUN_ID QUESTION_ID", { exitCode: 2 });
    const question = await questionStore.readQuestion(first, second);
    return success("questions show", {
      question,
      studioRoute: studioRoute(question),
      discussionResponses: (await decisionStore.list(question.questionId)).filter(
        (record) => record.schema === "agent-workflow-evaluation-question-response/v1",
      ),
    });
  }
  throw new WorkflowError("INVALID_USAGE", "questions accepts propose, list, or show", { exitCode: 2 });
}
