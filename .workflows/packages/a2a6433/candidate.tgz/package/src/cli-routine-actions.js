import { writeFile } from "node:fs/promises";
import { resolve } from "node:path";

import { WorkflowError } from "./errors.js";
import { selectedStoreRoot } from "./cli-journey-source.js";
import { applyReviewedRoutineActions, exportSupervisedRoutineActions } from "./routine-action-authoring.js";
import { RunControlStore } from "./run-control-store.js";

export async function executeRoutineActionsCommand(args, flags, registry, resolveProjectContext) {
  const unsupported = [...flags.keys()].filter(
    (name) => !["root", "config", "store", "json", "output", "review"].includes(name),
  );
  if (unsupported.length)
    throw new WorkflowError("INVALID_USAGE", `routine-actions does not support --${unsupported[0]}`, { exitCode: 2 });
  const [operation, value] = args;
  const output = flags.get("output");
  const validExport =
    operation === "export" && args.length === 2 && Boolean(value) && Boolean(output) && !flags.has("review");
  const validApply =
    operation === "apply" && args.length === 2 && Boolean(value) && Boolean(output) && Boolean(flags.get("review"));
  if (!validExport && !validApply) {
    throw new WorkflowError(
      "INVALID_USAGE",
      "routine-actions requires export RUN_ID --output PATH or apply WORKFLOW_PATH --review PATH --output PATH",
      { exitCode: 2 },
    );
  }
  const context = !flags.has("store") && resolveProjectContext ? await resolveProjectContext() : null;
  const storeRoot = flags.has("store")
    ? resolve(flags.get("store"))
    : context
      ? selectedStoreRoot(context)
      : resolve(".workflows/local");
  const runStore = await new RunControlStore(storeRoot, {
    registry,
  }).init();
  if (validExport) {
    const review = await exportSupervisedRoutineActions({ runStore, runId: value });
    await writeFile(resolve(output), `${JSON.stringify(review, null, 2)}\n`, { flag: "wx", mode: 0o600 });
    return {
      command: "routine-actions export",
      data: {
        output: resolve(output),
        sourceRunId: value,
        reviewed: false,
        batchCount: review.batches.length,
      },
    };
  }
  if (validApply) {
    return {
      command: "routine-actions apply",
      data: await applyReviewedRoutineActions({
        runStore,
        workflowPath: value,
        reviewPath: flags.get("review"),
        outputPath: output,
        registry,
      }),
    };
  }
  throw new TypeError("Unreachable routine-actions operation");
}
