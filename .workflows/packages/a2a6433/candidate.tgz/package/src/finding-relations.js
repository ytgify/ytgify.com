import { randomUUID } from "node:crypto";
import { constants } from "node:fs";
import { link, lstat, mkdir, open, readdir, unlink } from "node:fs/promises";
import { dirname, join, relative, resolve, sep } from "node:path";

import { WorkflowError } from "./errors.js";
import { sha256 } from "./stable-json.js";

const FINDING_ID = /^finding_[a-f0-9]{32}$/;
const WORKFLOW_ID = /^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$/;
const RELATION_ID = /^relation_[a-f0-9]{32}$/;
const AUTHORITY = Symbol("finding-relation-authority");

function fail(code, message) {
  throw new WorkflowError(code, message, { exitCode: 3 });
}
function inside(root, path) {
  const suffix = relative(resolve(root), resolve(path));
  if (suffix.startsWith("..") || resolve(root, suffix) !== resolve(path))
    fail("PATH_TRAVERSAL", "Finding relation path escapes its root");
}
async function directory(path) {
  const entry = await lstat(path);
  if (!entry.isDirectory() || entry.isSymbolicLink())
    fail("FINDING_RELATION_STORE_UNSAFE", "Finding relation paths cannot be symlinks");
}
async function safe(root, path) {
  inside(root, path);
  let cursor = resolve(root);
  await directory(cursor);
  for (const part of relative(cursor, resolve(path)).split(sep).filter(Boolean)) {
    cursor = join(cursor, part);
    try {
      const entry = await lstat(cursor);
      if (entry.isSymbolicLink())
        fail("FINDING_RELATION_STORE_UNSAFE", "Finding relation ancestry cannot contain symlinks");
    } catch (error) {
      if (error.code === "ENOENT") break;
      throw error;
    }
  }
}
async function sync(path) {
  const handle = await open(path, "r");
  try {
    await handle.sync();
  } finally {
    await handle.close();
  }
}
async function immutableWrite(path, bytes) {
  const temp = `${path}.${randomUUID()}.tmp`;
  const handle = await open(temp, "wx", 0o600);
  try {
    await handle.writeFile(bytes);
    await handle.sync();
  } finally {
    await handle.close();
  }
  try {
    await link(temp, path);
    await sync(dirname(path));
  } catch (error) {
    if (error.code === "EEXIST") fail("IMMUTABLE_FINDING_RELATION_EXISTS", "Finding relations cannot be replaced");
    throw error;
  } finally {
    await unlink(temp).catch(() => {});
  }
}

export class FindingRelationStore {
  constructor(root, { registry } = {}) {
    this.root = resolve(root);
    this.relationsRoot = join(this.root, "finding-relations");
    this.registry = registry;
  }
  async init() {
    await mkdir(this.root, { recursive: true });
    await directory(this.root);
    await mkdir(this.relationsRoot, { recursive: true });
    await directory(this.relationsRoot);
    return this;
  }
  workflowRoot(workflowId) {
    if (!WORKFLOW_ID.test(workflowId)) fail("INVALID_FINDING_RELATION_ID", "Invalid workflow ID");
    const path = resolve(this.relationsRoot, workflowId);
    inside(this.relationsRoot, path);
    return path;
  }
  recordPath(workflowId, relationId) {
    if (!RELATION_ID.test(relationId)) fail("INVALID_FINDING_RELATION_ID", "Invalid relation ID");
    return resolve(this.workflowRoot(workflowId), `${relationId}.json`);
  }
  async writeRelation(record, authority) {
    if (authority !== AUTHORITY)
      fail("FINDING_RELATION_WRITE_FORBIDDEN", "Finding relations require validated finding identities");
    this.registry?.validate("findingRelation", record);
    const root = this.workflowRoot(record.workflowId);
    await safe(this.relationsRoot, root);
    await mkdir(root, { recursive: true });
    await immutableWrite(
      this.recordPath(record.workflowId, record.relationId),
      Buffer.from(`${JSON.stringify(record, null, 2)}\n`),
    );
    return structuredClone(record);
  }
  async readRelation(workflowId, relationId) {
    const path = this.recordPath(workflowId, relationId);
    await safe(this.relationsRoot, path);
    const entry = await lstat(path);
    if (!entry.isFile() || entry.isSymbolicLink())
      fail("FINDING_RELATION_RECORD_CORRUPT", "Finding relation is not a regular file");
    const handle = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW);
    let record;
    try {
      record = JSON.parse(await handle.readFile("utf8"));
    } catch (error) {
      if (error instanceof SyntaxError) fail("FINDING_RELATION_RECORD_CORRUPT", "Finding relation is invalid JSON");
      throw error;
    } finally {
      await handle.close();
    }
    this.registry?.validate("findingRelation", record);
    if (
      record.workflowId !== workflowId ||
      record.relationId !== relationId ||
      record.relationHash !== sha256({ ...record, relationHash: undefined })
    )
      fail("FINDING_RELATION_RECORD_CORRUPT", "Finding relation identity or hash is invalid");
    return structuredClone(record);
  }
  async listRelations(workflowId, findingId) {
    if (!FINDING_ID.test(findingId)) fail("INVALID_FINDING_RELATION_ID", "Invalid finding ID");
    const root = this.workflowRoot(workflowId);
    try {
      await safe(this.relationsRoot, root);
      await directory(root);
    } catch (error) {
      if (error.code === "ENOENT") return [];
      throw error;
    }
    const records = await Promise.all(
      (await readdir(root))
        .filter((name) => /^relation_[a-f0-9]{32}\.json$/.test(name))
        .sort()
        .map((name) => this.readRelation(workflowId, name.slice(0, -5))),
    );
    return records.filter((record) => record.findingIds.includes(findingId));
  }
}

export async function relateFindings({ relationStore, findingStore, workflowId, findingIds, reason }) {
  if (!Array.isArray(findingIds) || new Set(findingIds).size < 2 || findingIds.some((id) => !FINDING_ID.test(id)))
    throw new TypeError("findingIds must contain at least two distinct findings");
  if (typeof reason !== "string" || !reason.trim()) throw new TypeError("reason is required");
  const ids = [...new Set(findingIds)].sort();
  if (!findingStore) throw new TypeError("findingStore is required to verify related finding identities");
  await Promise.all(ids.map((id) => findingStore.readFinding(workflowId, id)));
  const identity = { workflowId, findingIds: ids, reason: reason.trim() };
  const record = {
    schema: "agent-workflow-finding-relation/v1",
    relationId: `relation_${sha256(identity).slice(7, 39)}`,
    ...identity,
  };
  record.relationHash = sha256({ ...record, relationHash: undefined });
  try {
    return await relationStore.writeRelation(record, AUTHORITY);
  } catch (error) {
    if (error.code !== "IMMUTABLE_FINDING_RELATION_EXISTS") throw error;
    const existing = await relationStore.readRelation(workflowId, record.relationId);
    if (sha256(existing) !== sha256(record)) throw error;
    return existing;
  }
}
