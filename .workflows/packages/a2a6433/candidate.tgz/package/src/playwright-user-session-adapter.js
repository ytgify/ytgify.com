/* eslint-disable max-lines -- persistent session ownership and bounded click diagnostics share one adapter boundary. */
import { randomUUID } from "node:crypto";
import { mkdir, rm } from "node:fs/promises";
import { join, resolve } from "node:path";

import { chromium as playwrightChromium } from "playwright";

import { assertSafeAuthMarker, assertSafeReadinessName, sanitizeMarkerCandidate } from "./auth-session-adapter.js";
import { WorkflowError } from "./errors.js";
import { assertSafeProjectPath } from "./project-path-safety.js";

const ROLES = new Set(["heading", "link", "button", "navigation", "main"]);
const SEMANTIC_ELEMENTS = [
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "a",
  "button",
  '[role="heading"]',
  '[role="link"]',
  '[role="button"]',
  "nav",
  '[role="navigation"]',
  "main",
  '[role="main"]',
].join(",");

const TAG_ROLES = new Map([
  ["A", "link"],
  ["BUTTON", "button"],
  ["NAV", "navigation"],
  ["MAIN", "main"],
  ["H1", "heading"],
  ["H2", "heading"],
  ["H3", "heading"],
  ["H4", "heading"],
  ["H5", "heading"],
  ["H6", "heading"],
]);

function escapedProfile() {
  return new WorkflowError("PATH_TRAVERSAL", "Browser profile escapes the local store", { exitCode: 3 });
}

function pageAtOrigin(context, origin) {
  return context.pages().find((page) => pageLocation(page, origin));
}

function pageLocation(page, origin, routePath) {
  try {
    const location = new URL(page.url());
    if (location.origin !== new URL(origin).origin) return null;
    if (routePath !== undefined && location.pathname !== routePath) return null;
    return location;
  } catch {
    return null;
  }
}

function normalizedName(value) {
  return value?.replace(/\s+/gu, " ").trim() ?? "";
}

function assertRouteReadiness(marker, origin) {
  if (!marker || typeof marker !== "object" || Array.isArray(marker) || !ROLES.has(marker.role)) {
    throw new WorkflowError("AUTH_SESSION_STALE", "Bound route readiness is invalid", { exitCode: 3 });
  }
  assertSafeReadinessName(marker.name);
  let route;
  try {
    route = new URL(marker.routePath, origin);
  } catch {
    throw new WorkflowError("AUTH_SESSION_STALE", "Bound route readiness is invalid", { exitCode: 3 });
  }
  if (route.origin !== new URL(origin).origin || route.pathname !== marker.routePath || route.search || route.hash) {
    throw new WorkflowError("AUTH_SESSION_STALE", "Bound route readiness is invalid", { exitCode: 3 });
  }
  return { routePath: marker.routePath, role: marker.role, name: marker.name };
}

async function exactClickFacts(locator) {
  try {
    const locatorCount = Math.min(2, await locator.count());
    if (locatorCount !== 1) return { locatorCount };
    const [visible, enabled] = await Promise.all([locator.isVisible(), locator.isEnabled()]);
    return { locatorCount, visible, enabled };
  } catch {
    return {};
  }
}

function exactClickFailureCategory(error, facts, navigated) {
  if (navigated) return "navigation";
  if (facts.locatorCount === 2) return "ambiguity";
  if ([facts.visible, facts.enabled].includes(false)) return "actionability";
  const message = typeof error?.message === "string" ? error.message : "";
  const callLog = message
    .split(String.fromCharCode(27))
    .map((fragment) => fragment.replace(/^\[[0-9;]*m/u, ""))
    .join("");
  if (/\n\s*-\s+.*\bintercepts pointer events\s*$/imu.test(callLog)) return "interception";
  if (
    /\n\s*-\s+(?:element is not (?:visible|enabled|stable)|element is outside of the viewport|element was detached)/iu.test(
      callLog,
    )
  )
    return "actionability";
  if (/navigation|net::ERR_/iu.test(message.split(/\r?\n/u, 1)[0])) return "navigation";
  if (error?.name === "TimeoutError" || /timeout(?: of)? \d+ms exceeded/iu.test(message)) return "timeout";
  return "unknown";
}

/** A persistent Playwright adapter whose browser state stays under one ignored local-store root. */
export class PlaywrightUserSessionAdapter {
  constructor({ localStoreRoot, chromium = playwrightChromium, executablePath, headless = false } = {}) {
    if (typeof localStoreRoot !== "string" || localStoreRoot.length === 0) {
      throw new TypeError("localStoreRoot is required");
    }
    if (!chromium || typeof chromium.launchPersistentContext !== "function") {
      throw new TypeError("chromium.launchPersistentContext is required");
    }
    if (typeof headless !== "boolean") throw new TypeError("headless must be a boolean");
    this.headless = headless;
    this.localStoreRoot = resolve(localStoreRoot);
    this.profilesRoot = join(this.localStoreRoot, "browser-profiles");
    this.chromium = chromium;
    this.executablePath = executablePath;
    this.contexts = new Map();
    this.sessions = new Map();
    this.launches = new Map();
    this.disposing = false;
    this.operations = new Map();
  }

  profilePath(browserProfileId) {
    if (typeof browserProfileId !== "string" || browserProfileId.length === 0) throw escapedProfile();
    const path = resolve(this.profilesRoot, browserProfileId);
    if (path === this.profilesRoot) throw escapedProfile();
    return path;
  }

  async assertProfilePath(browserProfileId, allowMissing) {
    const profilePath = this.profilePath(browserProfileId);
    await assertSafeProjectPath(this.localStoreRoot, this.profilesRoot, "Browser profile root", {
      finalType: "directory",
      allowMissing,
    });
    await assertSafeProjectPath(this.profilesRoot, profilePath, "Browser profile", {
      finalType: "directory",
      allowMissing,
    });
    return profilePath;
  }

  async prepareProfile(browserProfileId) {
    const profilePath = await this.assertProfilePath(browserProfileId, true);
    await mkdir(this.profilesRoot, { recursive: true });
    await assertSafeProjectPath(this.localStoreRoot, this.profilesRoot, "Browser profile root", {
      finalType: "directory",
      allowMissing: false,
    });
    await mkdir(profilePath, { recursive: true });
    await this.assertProfilePath(browserProfileId, false);
    return profilePath;
  }

  async contextFor(browserProfileId) {
    if (this.disposing)
      throw new WorkflowError("AUTH_SESSION_CAPABILITY_UNAVAILABLE", "Browser user-session capability is unavailable", {
        exitCode: 3,
      });
    const existing = this.contexts.get(browserProfileId);
    if (existing) return existing.context;
    const pending = this.launches.get(browserProfileId);
    if (pending) return pending;

    const launch = this.launchContext(browserProfileId);
    this.launches.set(browserProfileId, launch);
    try {
      return await launch;
    } finally {
      if (this.launches.get(browserProfileId) === launch) this.launches.delete(browserProfileId);
    }
  }

  async launchContext(browserProfileId) {
    const profilePath = await this.prepareProfile(browserProfileId);
    // The owning Studio process coordinates signals, evidence cleanup, and browser disposal.
    const options = { headless: this.headless, handleSIGINT: false, handleSIGTERM: false };
    if (this.executablePath !== undefined) options.executablePath = this.executablePath;
    const context = await this.chromium.launchPersistentContext(profilePath, options);
    if (this.disposing) {
      await context.close().catch(() => {});
      throw new WorkflowError("AUTH_SESSION_CAPABILITY_UNAVAILABLE", "Browser user-session capability is unavailable", {
        exitCode: 3,
      });
    }
    const sessionRef = `usersession_${randomUUID().replaceAll("-", "")}`;
    this.contexts.set(browserProfileId, { context, sessionRef });
    this.sessions.set(sessionRef, browserProfileId);
    context.on?.("close", () => {
      if (this.contexts.get(browserProfileId)?.context === context) this.contexts.delete(browserProfileId);
      if (this.sessions.get(sessionRef) === browserProfileId) this.sessions.delete(sessionRef);
    });
    return context;
  }

  sessionRef(browserProfileId) {
    return this.contexts.get(browserProfileId)?.sessionRef;
  }

  queued(browserProfileId, operation) {
    const previous = this.operations.get(browserProfileId) ?? Promise.resolve();
    const current = previous.catch(() => {}).then(operation);
    this.operations.set(browserProfileId, current);
    return current.finally(() => {
      if (this.operations.get(browserProfileId) === current) this.operations.delete(browserProfileId);
    });
  }

  async open({ browserProfileId, origin, marker }) {
    const safeMarker = marker === undefined ? undefined : assertSafeAuthMarker(marker);
    return this.queued(browserProfileId, () => this.openProfile({ browserProfileId, origin, marker: safeMarker }));
  }

  async openProfile({ browserProfileId, origin, marker }) {
    const context = await this.contextFor(browserProfileId);
    const pages = context.pages();
    const page = pages[0] ?? (await context.newPage());
    const destination = marker ? new URL(marker.routePath, origin).href : origin;
    if (!pageLocation(page, origin, marker?.routePath)) await page.goto(destination);
    await page.bringToFront();
    return { opened: true, sessionRef: this.sessionRef(browserProfileId) };
  }

  async proposeMarkers({ browserProfileId, origin, limit }) {
    return this.queued(browserProfileId, () => this.proposeMarkersInProfile({ browserProfileId, origin, limit }));
  }

  async proposeMarkersInProfile({ browserProfileId, origin, limit }) {
    const context = await this.contextFor(browserProfileId);
    const page = pageAtOrigin(context, origin);
    if (!page) return { candidates: [] };

    const initialLocation = pageLocation(page, origin);
    if (!initialLocation) return { candidates: [] };
    const routePath = initialLocation.pathname;
    const elements = page.locator(SEMANTIC_ELEMENTS);
    const count = Math.min(await elements.count(), 100);
    const maximum = Math.min(5, Number.isInteger(limit) && limit >= 0 ? limit : 5);
    if (maximum === 0) return { candidates: [] };
    const candidates = [];
    const seen = new Set();
    // Inspect a bounded pool before choosing: navigation often precedes useful page headings.
    for (let index = 0; index < count; index += 1) {
      const element = elements.nth(index);
      if (!(await element.isVisible())) continue;

      const roleAttribute = await element.getAttribute("role");
      const explicitRole = roleAttribute?.toLowerCase();
      const semantics = await element.evaluate((node) => {
        // This callback runs in the inspected browser document.
        const labelledBy = node
          .getAttribute("aria-labelledby")
          ?.split(/\s+/u)
          // eslint-disable-next-line no-undef
          .map((id) => document.getElementById(id)?.textContent ?? "")
          .join(" ");
        const imageAlternative = ["A", "BUTTON"].includes(node.tagName)
          ? [...node.querySelectorAll("img[alt]")].map((image) => image.getAttribute("alt")).join(" ")
          : "";
        return {
          tagName: node.tagName,
          name:
            node.getAttribute("aria-label") ??
            labelledBy ??
            (imageAlternative || undefined) ??
            node.textContent ??
            node.innerText,
        };
      });
      const tagName = typeof semantics === "string" ? semantics : semantics.tagName;
      const role = roleAttribute === null ? TAG_ROLES.get(tagName) : ROLES.has(explicitRole) ? explicitRole : undefined;
      if (!role) continue;
      const ariaLabel = await element.getAttribute("aria-label");
      const name = normalizedName(
        typeof semantics === "string" ? (ariaLabel ?? (await element.innerText())) : semantics.name,
      );
      if (!name) continue;

      let marker;
      try {
        marker = sanitizeMarkerCandidate({ routePath, role, name });
      } catch (error) {
        if (error.code === "AUTH_MARKER_UNSAFE") continue;
        throw error;
      }
      const key = JSON.stringify([marker.routePath, marker.role, marker.name]);
      if (seen.has(key)) continue;
      seen.add(key);
      candidates.push(marker);
    }
    if (!pageLocation(page, origin, routePath)) return { candidates: [] };
    candidates.sort((left, right) => Number(right.role === "heading") - Number(left.role === "heading"));
    return { candidates: candidates.slice(0, maximum) };
  }

  async verify({ browserProfileId, origin, marker }) {
    const safeMarker = assertSafeAuthMarker(marker);
    return this.queued(browserProfileId, () => this.verifyInProfile({ browserProfileId, origin, marker: safeMarker }));
  }

  async verifyInProfile({ browserProfileId, origin, marker }) {
    const context = await this.contextFor(browserProfileId);
    const page = pageAtOrigin(context, origin);
    const entry = this.contexts.get(browserProfileId);
    if (entry) entry.verifiedMarker = undefined;
    let probe;
    let retainProbe = false;
    try {
      let verificationPage = page;
      if (!page || !pageLocation(page, origin, marker.routePath)) {
        // Check the confirmed marker without moving the workflow's active page.
        try {
          probe = await context.newPage();
          verificationPage = probe;
          const response = await probe.goto(new URL(marker.routePath, origin).href, {
            timeout: 5000,
            waitUntil: "domcontentloaded",
          });
          if (response && !response.ok()) return { outcome: "unavailable" };
        } catch {
          return { outcome: "unavailable" };
        }
      }
      if (!pageLocation(verificationPage, origin, marker.routePath)) return { outcome: "needs-login" };
      const match = verificationPage.getByRole(marker.role, { name: marker.name, exact: true });
      if (probe) await match.waitFor({ state: "visible", timeout: 5000 });
      const matched = (await match.count()) === 1 && (await match.isVisible());
      const verified =
        matched && pageLocation(verificationPage, origin, marker.routePath) && (!page || pageLocation(page, origin));
      // A restored profile needs a live app page for subsequent session actions.
      retainProbe = Boolean(verified && !page);
      if (entry) entry.verifiedMarker = verified ? { ...marker, origin } : undefined;
      return verified
        ? { outcome: "verified", sessionRef: this.sessionRef(browserProfileId) }
        : { outcome: "needs-login" };
    } catch {
      return { outcome: "needs-login" };
    } finally {
      if (probe && !retainProbe) await probe.close();
    }
  }

  sessionContext(sessionRef, origin) {
    const browserProfileId = this.sessions.get(sessionRef);
    const entry = browserProfileId && this.contexts.get(browserProfileId);
    const page = entry && pageAtOrigin(entry.context, origin);
    if (!page)
      throw new WorkflowError("AUTH_SESSION_CAPABILITY_UNAVAILABLE", "Browser user-session capability is unavailable", {
        exitCode: 3,
      });
    return { entry, page };
  }

  async act({ sessionRef, origin, action }) {
    const browserProfileId = this.sessions.get(sessionRef);
    if (!browserProfileId)
      throw new WorkflowError("AUTH_SESSION_CAPABILITY_UNAVAILABLE", "Browser user-session capability is unavailable", {
        exitCode: 3,
      });
    return this.queued(browserProfileId, () => this.actInSession({ sessionRef, origin, action }));
  }

  /** Run one runner-authorized batch and capture the same owned page. */
  async executeBatch({ sessionRef, origin, actions, viewport, checkTime, timeout, onProgress = () => {} }) {
    const profile = this.sessions.get(sessionRef);
    if (!profile)
      throw new WorkflowError("AUTH_SESSION_CAPABILITY_UNAVAILABLE", "Session is unavailable", { exitCode: 3 });
    return this.queued(profile, async () => {
      const { page } = this.sessionContext(sessionRef, origin);
      const readiness = this.contexts.get(profile)?.verifiedMarker;
      if (!readiness || readiness.origin !== origin)
        throw new WorkflowError("AUTH_SESSION_STALE", "Session readiness has not been verified", { exitCode: 3 });
      const assertOrigin = () => {
        checkTime();
        if (!pageLocation(page, origin))
          throw new WorkflowError("AUTH_SESSION_STALE", "Session left its bound origin", { exitCode: 3 });
      };
      const budget = (deadline) =>
        Math.max(1, Math.min(timeout, checkTime(), deadline === undefined ? Infinity : deadline - performance.now()));
      const guardCredentials = async () => {
        if (
          await page
            .locator('input[type="password"], input[name="password"], input[autocomplete="one-time-code"]')
            .count()
        ) {
          throw new WorkflowError("AUTH_SESSION_STALE", "Authentication challenge requires user attention", {
            exitCode: 3,
          });
        }
      };
      const waitForMarker = async (marker, deadline) => {
        assertOrigin();
        if (!pageLocation(page, origin, marker.routePath))
          throw new WorkflowError("AUTH_SESSION_STALE", "Confirmed page readiness changed", { exitCode: 3 });
        const match = page.getByRole(marker.role, { name: marker.name, exact: true });
        await match.waitFor({ state: "visible", timeout: budget(deadline) });
        assertOrigin();
        if (!pageLocation(page, origin, marker.routePath) || (await match.count()) !== 1)
          throw new WorkflowError("AUTH_SESSION_STALE", "Confirmed page readiness changed", { exitCode: 3 });
        await guardCredentials();
      };
      assertOrigin();
      await guardCredentials();
      await page.setViewportSize(viewport);
      let boundReadiness;
      for (const [actionIndex, action] of actions.entries()) {
        onProgress({ phase: "action", actionIndex });
        assertOrigin();
        await guardCredentials();
        if (action.kind === "navigate") {
          if (new URL(action.url).origin !== new URL(origin).origin)
            throw new WorkflowError("AUTH_SESSION_STALE", "Navigation left its bound origin", { exitCode: 3 });
          const routeReadiness =
            action.readiness === undefined ? undefined : assertRouteReadiness(action.readiness, origin);
          const routeReadinessDeadline = routeReadiness === undefined ? undefined : performance.now() + budget();
          await page.goto(action.url, { timeout: budget(routeReadinessDeadline), waitUntil: "domcontentloaded" });
          await page.setViewportSize(viewport);
          if (routeReadiness) {
            boundReadiness = routeReadiness;
            await waitForMarker(routeReadiness, routeReadinessDeadline);
          } else if (new URL(action.url).pathname === readiness.routePath) await waitForMarker(readiness);
        } else if (action.kind === "click") {
          const target = page.getByRole(action.role, { name: action.name, exact: true });
          const locationBeforeClick = page.url();
          try {
            await target.click({ timeout: budget() });
            assertOrigin();
          } catch (error) {
            const facts = await exactClickFacts(target);
            onProgress({
              phase: "action",
              actionIndex,
              failureCategory: exactClickFailureCategory(error, facts, page.url() !== locationBeforeClick),
              ...facts,
            });
            throw error;
          }
        } else if (action.kind === "fill") {
          const field = page.getByRole(action.role, { name: action.name, exact: true });
          await field.waitFor({ state: "visible", timeout: budget() });
          const safe = await field.evaluate((node) => {
            const type = (node.getAttribute("type") || "text").toLowerCase();
            const autocomplete = (node.getAttribute("autocomplete") || "off").toLowerCase();
            const hints = ["name", "id", "aria-label", "placeholder"]
              .map((key) => node.getAttribute(key) || "")
              .join(" ");
            return (
              ((node.tagName === "INPUT" && ["text", "search"].includes(type)) || node.tagName === "TEXTAREA") &&
              autocomplete === "off" &&
              !/pass(?:word|code)?|secret|token|credential|api.?key|email|one.?time|otp|card|cvv|ssn/iu.test(hints)
            );
          });
          if (
            !safe ||
            /pass(?:word|code)?|secret|token|credential|api.?key|email|one.?time|otp|card|cvv|ssn/iu.test(action.name)
          )
            throw new WorkflowError("CAPABILITY_UNAVAILABLE", "Synthetic text cannot enter this field", {
              exitCode: 3,
            });
          assertOrigin();
          await guardCredentials();
          await field.fill(action.value, { timeout: budget() });
          if ((await field.inputValue({ timeout: budget() })) !== action.value)
            throw new WorkflowError("CAPABILITY_UNAVAILABLE", "Field did not retain the approved text", {
              exitCode: 3,
            });
        } else if (action.kind === "upload") {
          const control = page.getByLabel(action.label, { exact: true });
          await control.waitFor({ state: "attached", timeout: budget() });
          const approved = await control.evaluate(
            (node) => node.tagName === "INPUT" && node.getAttribute("type")?.toLowerCase() === "file" && !node.multiple,
          );
          if (!approved || !action.file || !Buffer.isBuffer(action.file.buffer))
            throw new WorkflowError("CAPABILITY_UNAVAILABLE", "Approved file-upload control is unavailable", {
              exitCode: 3,
            });
          assertOrigin();
          await guardCredentials();
          await control.setInputFiles(action.file, { timeout: budget() });
        } else if (action.kind === "observe") {
          await page.locator("body").count();
        } else {
          throw new WorkflowError("CAPABILITY_UNAVAILABLE", "Unsupported authenticated action", { exitCode: 3 });
        }
        assertOrigin();
      }
      onProgress({ phase: "readiness" });
      if (boundReadiness) await waitForMarker(boundReadiness);
      if (pageLocation(page, origin, readiness.routePath)) await waitForMarker(readiness);
      await guardCredentials();
      assertOrigin();
      onProgress({ phase: "capture" });
      const bytes = await page.screenshot({ fullPage: false, timeout: budget() });
      assertOrigin();
      return bytes;
    });
  }

  async actInSession({ sessionRef, origin, action }) {
    const { page } = this.sessionContext(sessionRef, origin);
    if (!action || action.kind !== "click" || !ROLES.has(action.role) || typeof action.name !== "string") {
      throw new WorkflowError("AUTH_SESSION_CAPABILITY_UNAVAILABLE", "Browser user-session capability is unavailable", {
        exitCode: 3,
      });
    }
    await page.getByRole(action.role, { name: action.name, exact: true }).click();
    if (!pageLocation(page, origin))
      throw new WorkflowError("AUTH_SESSION_CAPABILITY_UNAVAILABLE", "Browser user-session capability is unavailable", {
        exitCode: 3,
      });
    return { outcome: "completed" };
  }

  async captureEvidence({ sessionRef, origin, evidence }) {
    const browserProfileId = this.sessions.get(sessionRef);
    if (!browserProfileId)
      throw new WorkflowError("AUTH_SESSION_CAPABILITY_UNAVAILABLE", "Browser user-session capability is unavailable", {
        exitCode: 3,
      });
    return this.queued(browserProfileId, () => this.captureEvidenceInSession({ sessionRef, origin, evidence }));
  }

  async captureEvidenceInSession({ sessionRef, origin, evidence }) {
    const { page } = this.sessionContext(sessionRef, origin);
    if (!evidence || evidence.kind !== "attribute" || typeof evidence.name !== "string") {
      throw new WorkflowError("AUTH_SESSION_CAPABILITY_UNAVAILABLE", "Browser user-session capability is unavailable", {
        exitCode: 3,
      });
    }
    const value = await page.locator("body").getAttribute(evidence.name);
    if (!pageLocation(page, origin))
      throw new WorkflowError("AUTH_SESSION_CAPABILITY_UNAVAILABLE", "Browser user-session capability is unavailable", {
        exitCode: 3,
      });
    return { outcome: "captured", value };
  }

  async dispose() {
    this.disposing = true;
    await Promise.allSettled(this.launches.values());
    await Promise.allSettled(this.operations.values());
    const contexts = [...this.contexts.values()].map(({ context }) => context);
    this.contexts.clear();
    this.sessions.clear();
    this.launches.clear();
    this.operations.clear();
    await Promise.allSettled(contexts.map((context) => context.close()));
  }

  async clear({ browserProfileId }) {
    return this.queued(browserProfileId, () => this.clearProfile({ browserProfileId }));
  }

  async clearProfile({ browserProfileId }) {
    try {
      const profilePath = await this.assertProfilePath(browserProfileId, true);
      const entry = this.contexts.get(browserProfileId);
      if (entry) await entry.context.close();
      if (this.contexts.get(browserProfileId) === entry) this.contexts.delete(browserProfileId);
      if (entry && this.sessions.get(entry.sessionRef) === browserProfileId) this.sessions.delete(entry.sessionRef);
      await this.assertProfilePath(browserProfileId, true);
      await rm(profilePath, { recursive: true, force: true });
      return { outcome: "cleared" };
    } catch {
      return { outcome: "unavailable" };
    }
  }
}
