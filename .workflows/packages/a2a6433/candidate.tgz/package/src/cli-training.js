import { resolve } from "node:path";
import { readYaml } from "./schema-registry.js";
import { WorkflowError } from "./errors.js";
import { resolveCurrentJourneySource, selectedStoreRoot } from "./cli-journey-source.js";
import { RunControlStore } from "./run-control-store.js";
import { launchTrainingRun } from "./training.js";

function invalid(message) {
  throw new WorkflowError("INVALID_USAGE", message, { exitCode: 2 });
}

function result(launched) {
  return {
    launchCard: launched.launchCard,
    state: {
      phase: launched.state.phase,
      status: launched.state.status,
      revision: launched.state.revision,
    },
  };
}

/** Dispatch legacy PATH or verified language-first training without rediscovering CLI context. */
export async function executeTrainingCommand(args, flags, registry, resolvers) {
  if (flags.has("approve")) invalid("train approval cannot be supplied by flag");
  const platform = flags.get("platform");
  const fixtureRecipe = await readCliFixtureRecipe(flags, registry);
  if (flags.has("journey")) {
    if (args.length || !flags.get("journey").trim()) {
      invalid("train --journey requires product words without PATH");
    }
    const unsupported = [...flags.keys()].filter(
      (name) =>
        ![
          "config",
          "fixture-recipe",
          "journey",
          "json",
          "lease-policy",
          "platform",
          "profile",
          "root",
          "store",
          "target",
          "target-url",
        ].includes(name),
    );
    if (unsupported.length) invalid(`train does not accept --${unsupported[0]}`);
    if (flags.has("target") && !flags.get("target").trim()) invalid("train --target requires product words");
    if (flags.has("target") && flags.has("target-url")) {
      invalid("train cannot combine --target with --target-url");
    }
    const selected = await resolveCurrentJourneySource({
      journey: flags.get("journey"),
      target: flags.get("target"),
      selectTarget: !flags.has("target-url"),
      registry,
      resolveProjectContext: resolvers.projectContext,
    });
    const options = {
      workflowSource: selected.source,
      platform,
      profile: flags.get("profile") ?? "default",
      leasePolicy: flags.get("lease-policy") ?? "authorized-codex-browser-v1",
      leasePolicySelectedByHuman: flags.has("lease-policy"),
      applicationTarget: selected.applicationTarget,
      projectContext: selected.projectContext,
      targetUrl: flags.get("target-url"),
      fixtureRecipe,
      fixtureProjectRoot: selected.projectContext.projectRoot,
      store: new RunControlStore(selectedStoreRoot(selected.projectContext, flags.get("store")), { registry }),
      registry,
    };
    if (platform) return result(await launchTrainingRun(options));
    const config = selected.projectContext.resolution.configPath
      ? registry.validate(
          "config",
          await readYaml(resolve(selected.projectContext.projectRoot, selected.projectContext.resolution.configPath)),
        )
      : null;
    const platforms = selected.source.workflow.target.supportedPlatforms
      .map(({ id }) => id)
      .filter((id) => !config || (config.platforms[id] && config.platforms[id].enabled !== false));
    if (!platforms.length) invalid("No supported platforms are enabled for this journey");
    const runs = [];
    let failureExitCode = 1;
    for (const selectedPlatform of platforms) {
      try {
        runs.push({
          platform: selectedPlatform,
          status: "launched",
          ...result(await launchTrainingRun({ ...options, platform: selectedPlatform })),
        });
      } catch (error) {
        failureExitCode = error.exitCode ?? 1;
        runs.push({
          platform: selectedPlatform,
          status: "failed",
          error: { code: error.code ?? "TRAINING_LAUNCH_FAILED", message: error.message },
        });
      }
    }
    const launchedCount = runs.filter((run) => run.status === "launched").length;
    const summary = {
      selection: "all-enabled-platforms",
      status: launchedCount === runs.length ? "launched" : launchedCount ? "partial" : "failed",
      runs,
      nextAction:
        "Execute each launched run and report Training outcomes separately for every platform. Launching is not completion or human acceptance.",
    };
    if (launchedCount !== runs.length) {
      throw new WorkflowError("TRAINING_LAUNCH_FAILED", "Training did not launch on every selected platform", {
        exitCode: failureExitCode,
        details: summary,
      });
    }
    return summary;
  }

  const [workflowPath] = args;
  if (!workflowPath || !platform) invalid("train requires PATH and --platform");
  return result(
    await launchTrainingRun({
      workflowPath,
      platform,
      profile: flags.get("profile") ?? "default",
      leasePolicy: flags.get("lease-policy") ?? "authorized-codex-browser-v1",
      leasePolicySelectedByHuman: flags.has("lease-policy"),
      targetUrl: flags.get("target-url"),
      fixtureRecipe,
      fixtureProjectRoot: resolve(flags.get("root") ?? "."),
      store: await resolvers.controlStore(),
      registry,
    }),
  );
}

export async function readCliFixtureRecipe(flags, registry) {
  const fixtureRecipe = flags.has("fixture-recipe")
    ? registry.validate("fixtureRecipe", await readYaml(resolve(flags.get("fixture-recipe"))))
    : null;
  if (fixtureRecipe && fixtureRecipe.kind !== "repository-file") {
    invalid("--fixture-recipe requires a repository-file recipe; application records need a registered host adapter");
  }
  return fixtureRecipe;
}
