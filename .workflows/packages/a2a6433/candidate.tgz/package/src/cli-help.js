import { createRequire } from "node:module";

import { WorkflowError } from "./errors.js";
import { agentOperationsForHelp } from "./agent-command-registry.js";
import { agentRecoveryAction } from "./agent-recovery-policy.js";
import { PREFERRED_PROTOCOL_VERSION, SUPPORTED_PROTOCOL_VERSIONS } from "./protocol.js";

const packageInfo = createRequire(import.meta.url)("../package.json");
const AGENT_REQUEST_FIELDS = Object.freeze([
  "schema",
  "protocolVersion",
  "requestId",
  "command",
  "runId",
  "actor",
  "issuedAt",
  "payload",
]);

function agentHelpContract(operations) {
  return {
    packageVersion: packageInfo.version,
    supportedProtocolVersions: SUPPORTED_PROTOCOL_VERSIONS,
    preferredProtocolVersion: PREFERRED_PROTOCOL_VERSION,
    requestSchema: "agent-workflow-protocol-request/v1",
    responseSchema: "agent-workflow-protocol-response/v1",
    requiredEnvelopeFields: AGENT_REQUEST_FIELDS,
    operations: operations.map((operation) => ({
      ...operation,
      recoveryActions: Object.fromEntries(operation.commonFailures.map((code) => [code, agentRecoveryAction(code)])),
    })),
  };
}

const COMMON_COMMANDS = [
  "workflow list [TERMS...]",
  "workflow status [TERMS...]",
  "workflow train --journey PRODUCT_WORDS",
  "workflow explore start --target WORDS --route /PATH --intent INTENT --platform PLATFORM",
  "workflow fixture-needs review RUN_ID",
  "workflow runs [TERMS...]",
  "workflow studio",
];

const SECTION_RULES = [
  {
    title: "Discover and inspect",
    commands: [
      "workflow list [TERMS...] [--binding current|latest] [--root PATH] [--config PATH] [--json]",
      "workflow status [TERMS...] [--binding current|latest] [--root PATH] [--config PATH] [--json]",
      "workflow runs [TERMS...] [--binding current|latest] [--root PATH] [--config PATH] [--json]",
      "workflow pending [TERMS...] [--binding current|latest] [--root PATH] [--config PATH] [--json]",
    ],
  },
  {
    title: "Train and operate",
    commands: [
      "workflow explore start --target WORDS --route /PATH --intent 'INTENT[;INTENT]' --platform PLATFORM [--fixture 'NAME=RELATIVE_PATH=CONTROL_LABEL[;...]'] [--root PATH] [--config PATH] [--store PATH] [--json]",
      "workflow explore review RUN_ID [--root PATH] [--config PATH] [--store PATH] [--json]",
      "workflow fixture-needs review RUN_ID [--root PATH] [--config PATH] [--store PATH] [--json]",
      "workflow fixture-needs decide RUN_ID --file JSON_PATH [--root PATH] [--config PATH] [--store PATH] [--json]",
      "workflow fixture-needs import-supervised RUN_ID --file JSON_PATH [--root PATH] [--config PATH] [--store PATH] [--json]",
      "workflow fixture-needs import-ytgify RUN_ID --file JSON_PATH [--root PATH] [--config PATH] [--store PATH] [--json]",
      "workflow fixture-needs compile --file JSON_PATH [--output PATH] [--root PATH] [--config PATH] [--store PATH] [--json]",
      "workflow train --journey PRODUCT_WORDS [--platform PLATFORM] [--target PRODUCT_WORDS | --target-url URL] [--profile PROFILE] [--lease-policy standard|supervised-codex-browser] [--root PATH] [--config PATH] [--store PATH] [--json]",
      "workflow replay candidate --journey PRODUCT_WORDS --platform PLATFORM [--target PRODUCT_WORDS | --target-url URL] [--profile PROFILE] [--root PATH] [--config PATH] [--store PATH] [--json]",
      "workflow promote --journey PRODUCT_WORDS --replay RUN_ID [--root PATH] [--config PATH] [--store PATH] [--json] (verified state; no approval required)",
    ],
  },
  {
    title: "Review and evaluate",
    commands: [
      "workflow evaluate desktop --journey PRODUCT_WORDS [--target PRODUCT_WORDS | --target-url URL] [--root PATH] [--config PATH] [--store PATH] [--json]",
      "workflow evaluate mobile --journey PRODUCT_WORDS [--target PRODUCT_WORDS | --target-url URL] [--root PATH] [--config PATH] [--store PATH] [--json]",
      "workflow evaluate perspectives --journey PRODUCT_WORDS --selection PATH --source candidate|promoted [--inquiry-depth focused|balanced|exploratory] [--batch BATCH_ID] [--target PRODUCT_WORDS | --target-url URL] [--root PATH] [--config PATH] [--store PATH] [--json]",
      "workflow studio [--root PATH] [--config PATH] [--store PATH] [--definitions PATH] [--port PORT] [--headless]",
    ],
  },
  {
    title: "Findings and feedback",
    commands: [
      "workflow questions list WORKFLOW_ID [--store PATH] [--json]",
      "workflow findings list WORKFLOW_ID [--store PATH] [--json]",
      "workflow review-intent list [WORKFLOW_ID] [--root PATH] [--config PATH] [--json]",
    ],
  },
  {
    title: "App map and administration",
    commands: [
      "workflow app-map registry | proposals [--root PATH] [--json]",
      "workflow doctor [--registry] [--root PATH] [--config PATH] [--json]",
      "workflow validate PATH [PATH...] [--json]",
    ],
  },
];

function matchesPrefix(usage, prefix) {
  return usage === prefix || usage.startsWith(`${prefix} `);
}

function topicUsage(usage, topic) {
  const prefix = `workflow ${topic}`;
  return usage.filter((line) => matchesPrefix(line, prefix));
}

export function createHelpData(usage, topicParts = []) {
  const topic = topicParts.join(" ").trim();
  if (topic) {
    const matches = topicUsage(usage, topic);
    if (!matches.length) {
      throw new WorkflowError("INVALID_USAGE", `Unknown help topic: ${topic}`, { exitCode: 2 });
    }
    const agentOperations = agentOperationsForHelp(topic);
    return {
      topic,
      usage,
      sections: [{ title: "Usage", commands: matches }],
      ...(agentOperations.length ? { agentOperations, agentProtocol: agentHelpContract(agentOperations) } : {}),
    };
  }

  return { topic: null, usage, commonCommands: COMMON_COMMANDS, sections: SECTION_RULES };
}

export function presentHelp(data) {
  const lines = ["Workflows CLI", "Agent-led application workflows with durable evidence and review.", ""];
  if (!data.topic) {
    lines.push(
      "Daily loop",
      "  1. Discover a journey.",
      "  2. Train or resume the requested work.",
      "  3. Record exact evidence.",
      "  4. Review the exact record in Studio.",
      "  5. Record feedback and rerun when needed.",
      "",
      "Common commands",
      ...data.commonCommands.map((command) => `  ${command}`),
      "",
    );
  } else {
    lines.push(`Help topic: ${data.topic}`, "");
  }
  for (const section of data.sections) {
    lines.push(section.title, ...section.commands.map((command) => `  ${command}`), "");
  }
  lines.push("Use `workflow help <command>` for complete command usage.");
  return `${lines.join("\n")}\n`;
}
