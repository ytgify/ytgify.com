import { execFile as execFileCallback } from "node:child_process";
import { createHash, randomUUID } from "node:crypto";
import { constants } from "node:fs";
import { link, lstat, mkdir, open, readdir, realpath, unlink } from "node:fs/promises";
import { dirname, isAbsolute, join, relative, sep } from "node:path";
import { promisify } from "node:util";

import { WorkflowError } from "./errors.js";
import { verifyExplorationFile } from "./exploration-fixtures.js";
import { matchesRepositoryFixtureUpload } from "./fixture-lifecycle.js";
import { buildRunReport } from "./run-report.js";
import { sha256 } from "./stable-json.js";

const execFile = promisify(execFileCallback);
const directoryName = "ytgify-fixture-sources";
const runPattern = /^run_[A-Za-z0-9_-]+$/u;
const temporarySourcePattern =
  /^run_[A-Za-z0-9_-]+\.json\.[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}\.tmp$/u;
const hashPattern = /^sha256:[a-f0-9]{64}$/u;
const commitPattern = /^[a-f0-9]{40}$/u;
const artifactPattern = /^artifact_[A-Za-z0-9_-]+$/u;
const fail = (message) => {
  throw new WorkflowError("YTGIFY_FIXTURE_SOURCE_INVALID", message, { exitCode: 3 });
};
const digest = (bytes) => `sha256:${createHash("sha256").update(bytes).digest("hex")}`;

function exactKeys(value, names) {
  return (
    value &&
    !Array.isArray(value) &&
    typeof value === "object" &&
    Object.keys(value).sort().join() === [...names].sort().join()
  );
}

function assertSource(source, runId) {
  if (
    !exactKeys(source, [
      "schema",
      "runId",
      "consumerRoot",
      "appCommitClaim",
      "receiptPath",
      "receiptSha256",
      "generatorReceiptPath",
      "generatorReceiptSha256",
    ]) ||
    source.schema !== "agent-workflow-ytgify-fixture-source/v1" ||
    source.runId !== runId ||
    !runPattern.test(runId) ||
    !isAbsolute(source.consumerRoot ?? "") ||
    !commitPattern.test(source.appCommitClaim ?? "") ||
    !isAbsolute(source.receiptPath ?? "") ||
    !hashPattern.test(source.receiptSha256 ?? "") ||
    !isAbsolute(source.generatorReceiptPath ?? "") ||
    !hashPattern.test(source.generatorReceiptSha256 ?? "")
  )
    fail("YTgify source must pin a run, consumer, app revision claim, and both raw receipt hashes");
}

async function regularBytes(path, maximum = 1024 * 1024) {
  let file;
  try {
    const entry = await lstat(path);
    if (!entry.isFile() || entry.isSymbolicLink() || entry.size > maximum) fail("Source is not a bounded regular file");
    file = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW);
    const opened = await file.stat();
    if (!opened.isFile() || opened.dev !== entry.dev || opened.ino !== entry.ino || opened.size !== entry.size)
      fail("Source file changed during verification");
    return await file.readFile();
  } finally {
    await file?.close();
  }
}

async function parsePinnedJson(path, expectedHash) {
  const bytes = await regularBytes(path);
  if (digest(bytes) !== expectedHash) fail("Pinned receipt bytes changed");
  try {
    return JSON.parse(bytes);
  } catch {
    fail("Pinned receipt JSON is invalid");
  }
}

async function sourcePath(store, runId, { create = false } = {}) {
  if (!runPattern.test(runId)) fail("Invalid YTgify run ID");
  const root = await lstat(store.root);
  if (!root.isDirectory() || root.isSymbolicLink()) fail("Run store root is unavailable");
  const directory = join(store.root, directoryName);
  if (create)
    await mkdir(directory, { mode: 0o700 }).catch((error) => {
      if (error.code !== "EEXIST") throw error;
    });
  const entry = await lstat(directory);
  if (!entry.isDirectory() || entry.isSymbolicLink()) fail("YTgify source directory is invalid");
  return join(directory, `${runId}.json`);
}

async function readSource(store, runId) {
  const path = await sourcePath(store, runId);
  let source;
  try {
    source = JSON.parse(await regularBytes(path));
  } catch (error) {
    if (error instanceof SyntaxError) fail("YTgify source JSON is invalid");
    throw error;
  }
  assertSource(source, runId);
  return source;
}

export async function hasYtgifyFixtureSource(store, runId) {
  try {
    const entry = await lstat(await sourcePath(store, runId));
    if (!entry.isFile() || entry.isSymbolicLink()) fail("YTgify source file is invalid");
    return true;
  } catch (error) {
    if (error.code === "ENOENT") return false;
    throw error;
  }
}

export async function listYtgifyFixtureSources(store) {
  const directory = join(store.root, directoryName);
  let names;
  try {
    const entry = await lstat(directory);
    if (!entry.isDirectory() || entry.isSymbolicLink()) fail("YTgify source directory is invalid");
    names = await readdir(directory);
  } catch (error) {
    if (error.code === "ENOENT") return [];
    throw error;
  }
  const runs = [];
  for (const name of names.sort()) {
    if (temporarySourcePattern.test(name)) {
      const entry = await lstat(join(directory, name)).catch((error) => {
        if (error.code === "ENOENT") return null;
        throw error;
      });
      if (!entry) continue;
      if (!entry.isFile() || entry.isSymbolicLink()) fail("YTgify source temporary file is invalid");
      continue;
    }
    const match = name.match(/^(run_[A-Za-z0-9_-]+)\.json$/u);
    if (!match) fail("YTgify source directory contains an unexpected entry");
    await readSource(store, match[1]);
    runs.push({ runId: match[1] });
  }
  return runs;
}

async function checkedInReceipt(path, expectedHash) {
  const bytes = await regularBytes(path);
  if (digest(bytes) !== expectedHash) fail("Pinned shared receipt bytes changed");
  const { stdout: rootOutput } = await execFile("git", ["-C", dirname(path), "rev-parse", "--show-toplevel"], {
    timeout: 5000,
  });
  const root = rootOutput.trim();
  const name = relative(root, await realpath(path));
  if (!name || name.startsWith(`..${sep}`) || isAbsolute(name)) fail("Shared receipt is outside its Git repository");
  const { stdout: index } = await execFile("git", ["-C", root, "ls-files", "-z", "--error-unmatch", "--", name], {
    timeout: 5000,
    encoding: "buffer",
  });
  if (!index.equals(Buffer.from(`${name}\0`))) fail("Shared receipt is not Git-indexed at its exact path");
  const { stdout: headBytes } = await execFile("git", ["-C", root, "show", `HEAD:${name}`], {
    timeout: 5000,
    encoding: "buffer",
  });
  if (!headBytes.equals(bytes)) fail("Shared receipt differs from its checked-in HEAD bytes");
  try {
    return JSON.parse(bytes);
  } catch {
    fail("Shared receipt JSON is invalid");
  }
}

function assertReceipt(receipt, generator, source) {
  if (
    !exactKeys(receipt, [
      "schema",
      "sourceSha",
      "candidateTarballSha256",
      "recipeRevision",
      "recipeHash",
      "fixture",
      "standalone",
      "parent",
      "borrowedChild",
      "handoff",
      "retention",
      "target",
    ]) ||
    receipt.schema !== "workflows-ytgify-fixture-child-dogfood/v1" ||
    receipt.sourceSha !== source.appCommitClaim ||
    !hashPattern.test(receipt.recipeHash ?? "") ||
    !/^v[1-9][0-9]*$/u.test(receipt.recipeRevision ?? "") ||
    !/^[a-f0-9]{64}$/u.test(receipt.candidateTarballSha256 ?? "") ||
    !exactKeys(receipt.fixture, ["path", "sha256", "sizeBytes"]) ||
    !hashPattern.test(receipt.fixture.sha256 ?? "") ||
    !Number.isSafeInteger(receipt.fixture.sizeBytes) ||
    receipt.fixture.sizeBytes < 1 ||
    !exactKeys(receipt.retention, ["fixtureDigestUnchanged", "sentinelDigestUnchanged"]) ||
    receipt.retention.fixtureDigestUnchanged !== true ||
    receipt.retention.sentinelDigestUnchanged !== true ||
    typeof receipt.target !== "string" ||
    !/^http:\/\/workflows\.localhost:[0-9]+$/u.test(receipt.target)
  )
    fail("Shared YTgify receipt is incomplete or has unreviewed fields");
  if (
    generator?.schema !== "workflows-ytgify-generation-dogfood/v1" ||
    generator.appSourceCommit !== source.appCommitClaim ||
    generator.fixturePath !== receipt.fixture.path ||
    generator.stableBytes !== receipt.fixture.sizeBytes ||
    `sha256:${generator.stableDigest}` !== receipt.fixture.sha256 ||
    generator.attemptCount !== 3 ||
    !Array.isArray(generator.attempts) ||
    generator.attempts.length !== 3 ||
    generator.attempts.some(
      (attempt) =>
        attempt.schema !== "workflows-ytgify-generated-fixture/v1" ||
        attempt.sha256 !== generator.stableDigest ||
        attempt.bytes !== generator.stableBytes ||
        attempt.generatorSha256 !== generator.attempts[0].generatorSha256 ||
        attempt.ffmpegVersion !== generator.attempts[0].ffmpegVersion ||
        attempt.mimeType !== "video/webm",
    )
  )
    fail("Generator receipt differs from the selected shared candidate fixture");
}

function receiptRuns(receipt) {
  const items = [receipt.standalone, receipt.parent, receipt.borrowedChild];
  if (
    items.some(
      (item) =>
        !exactKeys(item, [
          "runId",
          "status",
          "instanceId",
          "creatorRunId",
          "cleanupOwnerRunId",
          "lineage",
          "evidence",
          ...(item?.gif ? ["gif"] : []),
        ]) ||
        !runPattern.test(item.runId ?? "") ||
        item.status !== "completed" ||
        !Array.isArray(item.evidence) ||
        item.evidence.length === 0 ||
        new Set(item.evidence).size !== item.evidence.length ||
        item.evidence.some((id) => !artifactPattern.test(id)),
    ) ||
    new Set(items.map((item) => item.runId)).size !== 3 ||
    !receipt.parent.gif ||
    receipt.standalone.gif ||
    receipt.borrowedChild.gif ||
    receipt.standalone.lineage !== null ||
    receipt.parent.lineage !== null ||
    receipt.borrowedChild.lineage?.parentRunId !== receipt.parent.runId ||
    receipt.borrowedChild.lineage?.sourceInstanceId !== receipt.parent.instanceId ||
    receipt.borrowedChild.creatorRunId !== receipt.parent.runId ||
    receipt.borrowedChild.cleanupOwnerRunId !== receipt.parent.runId ||
    receipt.parent.creatorRunId !== receipt.parent.runId ||
    receipt.parent.cleanupOwnerRunId !== receipt.parent.runId ||
    receipt.standalone.creatorRunId !== receipt.standalone.runId ||
    receipt.standalone.cleanupOwnerRunId !== receipt.standalone.runId ||
    !exactKeys(receipt.handoff, ["sourceInstanceId", "instanceId", "cleanupOwnerRunId", "sourceReceiptHash"]) ||
    receipt.handoff.sourceInstanceId !== receipt.parent.instanceId ||
    receipt.handoff.instanceId !== receipt.borrowedChild.instanceId ||
    receipt.handoff.cleanupOwnerRunId !== receipt.parent.runId ||
    !hashPattern.test(receipt.handoff.sourceReceiptHash ?? "")
  )
    fail("Shared receipt run or parent/child lineage is incomplete");
  return items;
}

function verifiedUploadAction(run, item, evidence) {
  const leases = run.events.filter((event) => event.type === "action.leased" && event.payload?.stepId === "load-video");
  const commits = run.events.filter(
    (event) => event.type === "action.committed" && event.payload?.assessment?.stepId === "load-video",
  );
  const uploadEvidence = evidence.filter((artifact) => artifact.stepId === "load-video");
  const [leased] = leases;
  const [committed] = commits;
  const lease = leased?.payload?.lease;
  const proposal = lease?.proposal;
  const result = committed?.payload?.result;
  const capture = run.state.traversal?.artifacts?.[uploadEvidence[0]?.artifactId];
  if (
    leases.length !== 1 ||
    commits.length !== 1 ||
    uploadEvidence.length !== 1 ||
    leased.runId !== item.runId ||
    committed.runId !== item.runId ||
    leased.sequence >= committed.sequence ||
    leased.transaction?.operation !== "agent.propose" ||
    committed.transaction?.operation !== "agent.commit" ||
    lease?.runId !== item.runId ||
    lease?.policy?.decision !== "allowed" ||
    !proposal ||
    !matchesRepositoryFixtureUpload(run.manifest, proposal) ||
    result?.leaseId !== lease.leaseId ||
    committed.payload.assessment?.proposedOutcome !== "passed" ||
    result?.actualActions?.length !== 1 ||
    result.actualActions[0] !== proposal.actions[0].description ||
    result.declaredActions?.length !== 1 ||
    result.declaredActions[0] !== proposal.actions[0].description ||
    result.evidence?.length !== 1 ||
    result.evidence[0] !== uploadEvidence[0].artifactId ||
    capture?.relation?.stepId !== "load-video" ||
    capture.relation.batchRequestId !== leased.transaction.requestId ||
    capture.contentHash !== uploadEvidence[0].contentHash
  )
    fail("YTgify run lacks an exact committed fixture upload and capture");
}

async function verifiedRun(store, source, receipt, item) {
  const run = await store.readRun(item.runId);
  const recipe = run.manifest.fixtureContract?.recipe;
  const report = await buildRunReport(store, item.runId, { skipPerspective: true });
  if (
    run.manifest.phase !== "training" ||
    run.manifest.workflowRef?.id !==
      (item.runId === receipt.parent.runId ? "ytgify.fixture-gif-v2" : "ytgify.load-generated-video") ||
    recipe?.kind !== "repository-file" ||
    recipe.revision !== receipt.recipeRevision ||
    run.manifest.fixtureContract.recipeHash !== receipt.recipeHash ||
    sha256(recipe) !== receipt.recipeHash ||
    !recipe.allowedJourneys.includes(run.manifest.workflowRef.id) ||
    sha256(run.manifest.target) !== sha256(recipe.target) ||
    sha256(run.manifest.identity) !== sha256(recipe.identity) ||
    run.manifest.target?.effectiveUrl !== `${receipt.target}/video-to-gif` ||
    recipe.relativePath !== receipt.fixture.path ||
    recipe.sha256 !== receipt.fixture.sha256 ||
    recipe.sizeBytes !== receipt.fixture.sizeBytes ||
    recipe.mimeType !== "video/webm" ||
    recipe.uploadTarget !== "label:Upload video" ||
    report.status !== "completed" ||
    report.outcome !== "passed" ||
    report.cleanupOutcome !== "passed" ||
    Object.values(report.integrity).some((status) => status !== "verified")
  )
    fail("YTgify run report or recipe differs from the shared candidate receipt");
  const verifiedFile = await verifyExplorationFile(source.consumerRoot, recipe);
  if (
    verifiedFile.sha256 !== recipe.sha256 ||
    verifiedFile.sizeBytes !== recipe.sizeBytes ||
    verifiedFile.mimeType !== recipe.mimeType
  )
    fail("Indexed consumer file differs from the recipe");
  const evidence = report.steps
    .flatMap((step) => step.evidence.map((artifact) => ({ ...artifact, stepId: step.id })))
    .filter((artifact) => artifact.type === "screenshot")
    .map((artifact) => ({
      runId: item.runId,
      artifactId: artifact.artifactId,
      contentHash: artifact.contentHash,
      stepId: artifact.stepId,
      checkpoint: artifact.checkpoint,
    }));
  if (
    evidence.length !== item.evidence.length ||
    evidence.some(
      (artifact, index) => artifact.artifactId !== item.evidence[index] || !hashPattern.test(artifact.contentHash),
    )
  )
    fail("Shared receipt screenshots differ from registered evidence");
  verifiedUploadAction(run, item, evidence);
  for (const artifact of evidence) await store.readVerifiedEvidenceFromRun(run, artifact.artifactId);
  const instance = await store.readFixtureInstance(item.runId, { projectRoot: source.consumerRoot });
  if (
    !instance ||
    instance.instanceId !== item.instanceId ||
    instance.creatorRunId !== item.creatorRunId ||
    instance.cleanupOwnerRunId !== item.cleanupOwnerRunId ||
    sha256(instance.lineage) !== sha256(item.lineage) ||
    instance.recipeHash !== receipt.recipeHash ||
    instance.sha256 !== receipt.fixture.sha256
  )
    fail("Fixture instance differs from shared receipt");
  return { run, instance, evidence, recipe };
}

async function projectFromSource(store, runId, source) {
  const consumer = await lstat(source.consumerRoot);
  if (!consumer.isDirectory() || consumer.isSymbolicLink()) fail("Archived consumer is unavailable");
  const consumerPath = await realpath(source.consumerRoot);
  const generatorPath = relative(consumerPath, await realpath(source.generatorReceiptPath));
  if (!generatorPath || generatorPath === ".." || generatorPath.startsWith(`..${sep}`) || isAbsolute(generatorPath))
    fail("Generator receipt is outside the archived consumer");
  const receipt = await checkedInReceipt(source.receiptPath, source.receiptSha256);
  const generator = await parsePinnedJson(source.generatorReceiptPath, source.generatorReceiptSha256);
  assertReceipt(receipt, generator, source);
  const items = receiptRuns(receipt);
  const selected = items.find((item) => item.runId === runId);
  if (!selected) fail("Selected run is absent from the checked-in shared receipt");
  const checks = new Map();
  for (const item of items) checks.set(item.runId, await verifiedRun(store, source, receipt, item));
  const parent = checks.get(receipt.parent.runId);
  const child = checks.get(receipt.borrowedChild.runId);
  const childBinding = await store.readFixtureInstance(receipt.borrowedChild.runId, {
    projectRoot: source.consumerRoot,
  });
  if (
    child.run.manifest.parentRunId !== receipt.parent.runId ||
    childBinding.lineage?.sourceInstanceId !== parent.instance.instanceId ||
    receipt.handoff.sourceReceiptHash !== sha256(parent.instance)
  )
    fail("Parent/child handoff differs from the checked-in shared receipt");
  const { run, evidence, recipe } = checks.get(runId);
  return {
    fixtureNeeds: [
      {
        id: `fixture_need_${runId}`,
        journeyId: run.manifest.workflowRef.id,
        status: "unaccepted",
        source: "recorded-training",
        kind: "repository-file",
        cardinality: 1,
        target: run.manifest.target,
        identity: run.manifest.identity,
        sourceRevision: `receipt-claim:${source.appCommitClaim}`,
        sourceReceiptHash: source.receiptSha256,
        pinnedUpload: {
          fixtureName: recipe.id,
          relativePath: recipe.relativePath,
          uploadTarget: recipe.uploadTarget,
          filename: recipe.filename,
          sizeBytes: recipe.sizeBytes,
          mimeType: recipe.mimeType,
          sha256: recipe.sha256,
        },
        evidence,
        fieldProvenance: {
          observed: ["journeyId", "target", "identity", "fixture instance", "evidence", "parent-child lineage"],
          receiptClaim: ["appCommitClaim", "generator attempts", "retention", "downloaded GIF"],
          operatorSupplied: ["consumerRoot", "receiptPath", "generatorReceiptPath"],
        },
        observed: {
          instanceId: selected.instanceId,
          recipeHash: receipt.recipeHash,
          recipeId: recipe.id,
          recipeRevision: recipe.revision,
          generationMode: "reused-indexed-file",
        },
        unresolved: [
          "The archived consumer has no independently verifiable Git HEAD; the app revision is a receipt claim.",
          "Generator and FFmpeg toolchain pins, invocation, and supported file policy require recipe review.",
          "The UI reruns reused one indexed WebM; they did not generate a fresh file per run.",
        ],
        uncertainty: [
          "This is a past fixture-backed UI run, not permission to generate or retain a new file.",
          "A reviewed need does not approve a recipe, generator, or future journey run.",
        ],
      },
    ],
  };
}

export async function projectYtgifyFixtureNeed(store, runId) {
  return projectFromSource(store, runId, await readSource(store, runId));
}

/** Register a single immutable source only after all three receipt runs verify. */
export async function importYtgifyFixtureSource(store, runId, source) {
  assertSource(source, runId);
  const review = await projectFromSource(store, runId, source);
  const path = await sourcePath(store, runId, { create: true });
  const temporary = `${path}.${randomUUID()}.tmp`;
  let file;
  try {
    file = await open(temporary, "wx", 0o600);
    await file.writeFile(`${JSON.stringify(source, null, 2)}\n`);
    await file.sync();
    await file.close();
    file = null;
    try {
      await link(temporary, path);
    } catch (error) {
      if (error.code === "EEXIST") fail("YTgify source is already registered and immutable");
      throw error;
    }
    const directory = await open(join(store.root, directoryName), "r");
    try {
      await directory.sync();
    } finally {
      await directory.close();
    }
  } finally {
    try {
      await file?.close();
    } finally {
      await unlink(temporary).catch(() => {});
    }
  }
  return review;
}
