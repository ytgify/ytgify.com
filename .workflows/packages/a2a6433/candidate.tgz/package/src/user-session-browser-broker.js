import { randomUUID } from "node:crypto";
import { open, readFile, unlink, writeFile } from "node:fs/promises";
import { createConnection } from "node:net";
import { join, resolve } from "node:path";

import { WorkflowError } from "./errors.js";
import { assertSafeProjectPath } from "./project-path-safety.js";
import { validateBrowserExecutionRequest, sanitizeExecutionDiagnostic } from "./authenticated-browser-execution.js";

const FILE = "browser-user-session-host.json";
const ID = /^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$/u;
const SECRET = /^brokersecret_[A-Za-z0-9_-]+$/u;

function unavailable() {
  return new WorkflowError("AUTH_SESSION_CAPABILITY_UNAVAILABLE", "Browser user-session capability is unavailable", {
    exitCode: 3,
  });
}

function descriptorPath(storeRoot) {
  return join(resolve(storeRoot), FILE);
}

function validateDescriptor(value) {
  let url;
  try {
    url = new URL(value?.origin);
  } catch {
    throw unavailable();
  }
  if (
    !value ||
    Object.keys(value).length !== 3 ||
    value.schema !== "browser.user-session-host/v1" ||
    url.protocol !== "http:" ||
    url.username ||
    url.password ||
    url.hostname !== "workflows.localhost" ||
    url.pathname !== "/" ||
    url.search ||
    url.hash ||
    !SECRET.test(value.secret ?? "")
  ) {
    throw unavailable();
  }
  return value;
}

function validateScope(scope) {
  let url;
  try {
    url = new URL(scope?.origin);
  } catch {
    throw unavailable();
  }
  if (
    !scope ||
    Object.keys(scope).length !== 4 ||
    !ID.test(scope.projectId ?? "") ||
    !ID.test(scope.targetId ?? "") ||
    !["local", "preview", "staging", "production", "other"].includes(scope.environment) ||
    !["http:", "https:"].includes(url.protocol) ||
    url.username ||
    url.password ||
    url.search ||
    url.hash ||
    !["", "/"].includes(url.pathname)
  ) {
    throw unavailable();
  }
  return scope;
}

export function createUserSessionBrokerSecret() {
  return `brokersecret_${randomUUID().replaceAll("-", "")}`;
}

function lockUnavailable(error) {
  const exists = error.code === "EEXIST";
  const permissionDenied = ["EACCES", "EPERM"].includes(error.code);
  const reason = exists ? "lock-exists" : permissionDenied ? "lock-permission-denied" : "lock-open-failed";
  const message = exists
    ? "Browser session operation is locked. Another operation may be active or interrupted; ownership is unknown."
    : permissionDenied
      ? "Browser session lock could not be created because access was denied."
      : "Browser session lock could not be created.";
  return new WorkflowError("AUTH_SESSION_CAPABILITY_UNAVAILABLE", message, {
    exitCode: 3,
    details: { reason, ...(exists ? { ownerState: "unknown" } : {}) },
  });
}

async function withDescriptorLock(root, operation) {
  const path = `${descriptorPath(root)}.lock`;
  await assertSafeProjectPath(root, path, "Browser session host lock", { finalType: "file", allowMissing: true });
  let handle;
  try {
    handle = await open(path, "wx", 0o600);
  } catch (error) {
    throw lockUnavailable(error);
  }
  try {
    return await operation();
  } finally {
    await handle.close();
    await unlink(path);
  }
}

function endpointRefused(origin, connectImpl) {
  return new Promise((resolve) => {
    const url = new URL(origin);
    // Studio binds IPv4 loopback. Probe transport only; never send the discovery secret.
    const socket = connectImpl({ host: "127.0.0.1", port: Number(url.port || 80) });
    const finish = (refused) => {
      socket.destroy();
      resolve(refused);
    };
    socket.once("connect", () => finish(false));
    socket.once("error", (error) => finish(error.code === "ECONNREFUSED"));
    socket.setTimeout(1_000, () => finish(false));
  });
}

/** Run before binding Studio's port, so a new listener cannot impersonate the stale owner. */
export async function recoverUserSessionBroker({ storeRoot, connectImpl = createConnection }) {
  const root = resolve(storeRoot);
  const path = descriptorPath(root);
  return withDescriptorLock(root, async () => {
    await assertSafeProjectPath(root, path, "Browser session host descriptor", {
      finalType: "file",
      allowMissing: true,
    });
    let descriptor;
    try {
      descriptor = validateDescriptor(JSON.parse(await readFile(path, "utf8")));
    } catch (error) {
      if (error.code === "ENOENT") return;
      throw unavailable();
    }
    if (!(await endpointRefused(descriptor.origin, connectImpl))) throw unavailable();
    await unlink(path);
  });
}

export async function publishUserSessionBroker({ storeRoot, origin, secret }) {
  const root = resolve(storeRoot);
  const path = descriptorPath(root);
  const value = validateDescriptor({ schema: "browser.user-session-host/v1", origin, secret });
  return withDescriptorLock(root, async () => {
    await assertSafeProjectPath(root, path, "Browser session host descriptor", {
      finalType: "file",
      allowMissing: true,
    });
    try {
      await writeFile(path, `${JSON.stringify(value)}\n`, { flag: "wx", mode: 0o600 });
    } catch {
      throw unavailable();
    }
    return path;
  });
}

export async function removeUserSessionBroker({ storeRoot, secret }) {
  const root = resolve(storeRoot);
  const path = descriptorPath(root);
  return withDescriptorLock(root, async () => {
    await assertSafeProjectPath(root, path, "Browser session host descriptor", {
      finalType: "file",
      allowMissing: true,
    });
    try {
      const current = validateDescriptor(JSON.parse(await readFile(path, "utf8")));
      if (current.secret !== secret) return;
      await unlink(path);
    } catch (error) {
      if (error.code !== "ENOENT") throw unavailable();
    }
  });
}

export class BrokeredAuthSessionService {
  constructor({ storeRoot, fetchImpl = globalThis.fetch } = {}) {
    this.storeRoot = resolve(storeRoot);
    this.fetchImpl = fetchImpl;
  }

  async verify(scope) {
    try {
      const path = descriptorPath(this.storeRoot);
      await assertSafeProjectPath(this.storeRoot, path, "Browser session host descriptor", {
        finalType: "file",
        allowMissing: false,
      });
      const descriptor = validateDescriptor(JSON.parse(await readFile(path, "utf8")));
      const response = await this.fetchImpl(new URL("/api/browser-user-session-host/v1/verify", descriptor.origin), {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "x-workflows-browser-broker-secret": descriptor.secret,
        },
        body: JSON.stringify(validateScope(scope)),
        signal: AbortSignal.timeout(10_000),
      });
      if (!response.ok) throw unavailable();
      const value = await response.json();
      const record = value?.record;
      if (
        !record ||
        Object.keys(record).some(
          (key) =>
            !["targetId", "markerHash", "sessionBindingHash", "state", "lastVerifiedAt", "browserSessionRef"].includes(
              key,
            ),
        ) ||
        record.targetId !== scope.targetId ||
        !/^sha256:[a-f0-9]{64}$/u.test(record.markerHash ?? "") ||
        !/^sha256:[a-f0-9]{64}$/u.test(record.sessionBindingHash ?? "") ||
        !["ready", "needs-login"].includes(record.state) ||
        (record.lastVerifiedAt !== undefined && typeof record.lastVerifiedAt !== "string") ||
        (record.state === "ready" && !/^usersession_[A-Za-z0-9_-]+$/u.test(record.browserSessionRef ?? "")) ||
        (record.state === "needs-login" && record.browserSessionRef !== undefined)
      ) {
        throw unavailable();
      }
      return record;
    } catch {
      throw unavailable();
    }
  }

  async dispose() {}

  async execute(request) {
    validateBrowserExecutionRequest(request);
    const path = descriptorPath(this.storeRoot);
    await assertSafeProjectPath(this.storeRoot, path, "Browser session host descriptor", {
      finalType: "file",
      allowMissing: false,
    });
    const descriptor = validateDescriptor(JSON.parse(await readFile(path, "utf8")));
    const response = await this.fetchImpl(new URL("/api/browser-user-session-host/v1/execute", descriptor.origin), {
      method: "POST",
      headers: { "content-type": "application/json", "x-workflows-browser-broker-secret": descriptor.secret },
      body: JSON.stringify(request),
      signal: AbortSignal.timeout(30_000),
    });
    if (!response.ok) {
      const body = await response.json().catch(() => ({}));
      const executionDiagnostic = sanitizeExecutionDiagnostic(body?.executionDiagnostic);
      throw new WorkflowError(
        "RECONCILIATION_REQUIRED",
        "Browser execution did not confirm completion; inspect before retrying",
        { exitCode: 4, details: executionDiagnostic ? { executionDiagnostic } : {} },
      );
    }
    const result = await response.json();
    if (
      result.status !== "completed" ||
      result.runId !== request.runId ||
      result.leaseId !== request.leaseId ||
      result.slotId !== request.slotId ||
      result.revision !== request.expectedRevision
    )
      throw unavailable();
    return result;
  }
}
