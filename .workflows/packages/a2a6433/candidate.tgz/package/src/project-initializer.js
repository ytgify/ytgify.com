import { lstat, mkdir, readFile, rm, rmdir, writeFile } from "node:fs/promises";
import { basename, dirname, join, relative, resolve, sep } from "node:path";
import { parse as parseYaml } from "yaml";

import {
  applyCodexSkillInstallation,
  planCodexSkillInstallation,
  rollbackCodexSkillInstallation,
} from "./codex-skill.js";
import { WorkflowError } from "./errors.js";
import { resolveProjectContext } from "./project-context.js";
import { inspectProjectGitSafety } from "./project-git-safety.js";
import { catalogProjectWorkflows } from "./project-workflow-catalog.js";
import { createSchemaRegistry } from "./schema-registry.js";
import { validateWorkflowSemantics } from "./workflow.js";

const CONFIG_PATH = ".workflows/config.yaml";
const DEFINITIONS_PATH = ".workflows/workflows";
const LOCAL_PATH = ".workflows/local";
const REQUIREMENTS_PATH = ".workflows/requirements.yaml";
const IGNORE_PATH = ".workflows/.gitignore";
const STARTER_PATH = `${DEFINITIONS_PATH}/getting-started.workflow.yaml`;
const IGNORE_RULE = "local/";
const ORIGIN_URL = /^https?:\/\/[^/?#]+\/?$/u;

function fail(code, message, details = {}, exitCode = 4) {
  throw new WorkflowError(code, message, { exitCode, details });
}

async function entry(path) {
  try {
    return await lstat(path);
  } catch (error) {
    if (error.code === "ENOENT") return null;
    throw error;
  }
}

function technicalId(value) {
  const id = value
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/gu, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/gu, "-")
    .replace(/^-+|-+$/gu, "");
  return /^[a-z]/u.test(id) ? id : `project${id ? `-${id}` : ""}`;
}

function humanName(root) {
  const words = basename(root)
    .replace(/([a-z0-9])([A-Z])/gu, "$1 $2")
    .split(/[^A-Za-z0-9]+/u)
    .filter(Boolean);
  return words.length ? words.map((word) => `${word[0].toUpperCase()}${word.slice(1)}`).join(" ") : "Project";
}

function originUrl(value, label) {
  if (typeof value !== "string" || !value) {
    fail("PROJECT_INITIALIZATION_INVALID", `${label} must be non-empty`);
  }
  let parsed;
  try {
    parsed = new URL(value);
  } catch {
    fail("PROJECT_INITIALIZATION_INVALID", `${label} must be an HTTP(S) origin`);
  }
  if (
    !["http:", "https:"].includes(parsed.protocol) ||
    parsed.username ||
    parsed.password ||
    !ORIGIN_URL.test(value) ||
    parsed.origin === "null"
  ) {
    fail(
      "PROJECT_INITIALIZATION_INVALID",
      `${label} must be an HTTP(S) origin without credentials, a path, query, or fragment`,
    );
  }
  return parsed.origin;
}

function originRelativePath(value, label) {
  if (typeof value !== "string" || !/^\/(?!\/)/u.test(value)) {
    fail("PROJECT_INITIALIZATION_INVALID", `${label} must be an origin-relative path beginning with one /`);
  }
  return value;
}

function initializationInput(root, options) {
  const appName = options.appName ?? humanName(root);
  if (options.localUrl !== undefined && options.baseUrl !== undefined) {
    fail(
      "PROJECT_INITIALIZATION_INVALID",
      "Project local URL must use either localUrl or the baseUrl compatibility alias",
    );
  }
  const localUrl = originUrl(options.localUrl ?? options.baseUrl ?? "http://workflows.localhost", "Project local URL");
  const previewUrl =
    options.previewUrl === undefined ? undefined : originUrl(options.previewUrl, "Project preview URL");
  const productionUrl =
    options.productionUrl === undefined ? undefined : originUrl(options.productionUrl, "Project production URL");
  const startRoute = originRelativePath(options.startRoute ?? "/", "Project start route");
  const healthPath = originRelativePath(options.healthPath ?? "/", "Project health path");
  if (typeof appName !== "string" || !appName.trim()) {
    fail("PROJECT_INITIALIZATION_INVALID", "Project app name must be non-empty");
  }
  return {
    appName: appName.trim(),
    localUrl,
    ...(previewUrl === undefined ? {} : { previewUrl }),
    ...(productionUrl === undefined ? {} : { productionUrl }),
    startRoute,
    healthPath,
    projectId: technicalId(appName.trim()),
  };
}

function render(source, input) {
  const values = {
    APP_NAME: input.appName,
    LOCAL_URL: input.localUrl,
    HEALTH_PATH: input.healthPath,
    PROJECT_ID: input.projectId,
    STARTER_ID: `${input.projectId}.getting-started`,
    START_ROUTE: input.startRoute,
    WORKFLOW_NAME: `Getting started with ${input.appName}`,
  };
  let rendered = source;
  for (const [name, value] of Object.entries(values)) {
    rendered = rendered.replaceAll(`"{{${name}}}"`, JSON.stringify(value));
  }
  const previewTarget = input.previewUrl
    ? [
        "    - id: preview",
        "      label: Preview",
        "      environment: preview",
        `      baseUrl: ${JSON.stringify(input.previewUrl)}`,
        `      healthPath: ${JSON.stringify(input.healthPath)}`,
      ].join("\n")
    : "";
  const productionTarget = input.productionUrl
    ? [
        "    - id: production",
        "      label: Production",
        "      environment: production",
        `      baseUrl: ${JSON.stringify(input.productionUrl)}`,
        `      healthPath: ${JSON.stringify(input.healthPath)}`,
      ].join("\n")
    : "";
  rendered = rendered.replace("# {{PREVIEW_TARGET}}", previewTarget);
  rendered = rendered.replace("# {{PRODUCTION_TARGET}}", productionTarget);
  return rendered;
}

async function renderedTemplates(input, registry) {
  const templateRoot = new URL("../templates/project/", import.meta.url);
  const config = render(await readFile(new URL("workflows.config.yaml", templateRoot), "utf8"), input);
  const starter = render(await readFile(new URL("getting-started.workflow.yaml", templateRoot), "utf8"), input);
  const requirements = render(await readFile(new URL("requirements.yaml", templateRoot), "utf8"), input);
  registry.validate("config", parseYaml(config));
  validateWorkflowSemantics(registry.validate("workflow", parseYaml(starter)));
  registry.validate("evaluationRequirements", parseYaml(requirements));
  return { config, starter, requirements };
}

async function assertSafeDestination(root, destination, type) {
  let cursor = root;
  for (const part of relative(root, destination).split(sep).filter(Boolean)) {
    cursor = join(cursor, part);
    const stat = await entry(cursor);
    if (!stat) return null;
    if (stat.isSymbolicLink()) return "unsafe-symlink";
    const final = cursor === destination;
    if (!final && !stat.isDirectory()) return "unsafe-ancestry";
    if (final && type === "directory" && !stat.isDirectory()) return "not-directory";
    if (final && type === "file" && !stat.isFile()) return "not-file";
  }
  return null;
}

async function directoryItem(root, path) {
  const destination = join(root, ...path.split("/"));
  const issue = await assertSafeDestination(root, destination, "directory");
  return {
    kind: "directory",
    path,
    destination,
    status: issue ? "conflict" : (await entry(destination)) ? "unchanged" : "create",
    ...(issue ? { issue } : {}),
  };
}

async function exactFileItem(root, path, contents, kind) {
  const destination = join(root, ...path.split("/"));
  const issue = await assertSafeDestination(root, destination, "file");
  const stat = await entry(destination);
  let status = "create";
  if (issue) status = "conflict";
  else if (stat) status = (await readFile(destination, "utf8")) === contents ? "unchanged" : "conflict";
  return { kind, path, destination, contents, status, ...(issue ? { issue } : {}) };
}

function hasIgnoreRule(contents) {
  return contents.split(/\r?\n/u).some((line) => line.trim() === IGNORE_RULE);
}

async function ignoreItem(root) {
  const destination = join(root, ...IGNORE_PATH.split("/"));
  const issue = await assertSafeDestination(root, destination, "file");
  const stat = await entry(destination);
  if (issue) return { kind: "ignore-rule", path: IGNORE_PATH, destination, status: "conflict", issue };
  if (!stat) {
    return { kind: "ignore-rule", path: IGNORE_PATH, destination, contents: `${IGNORE_RULE}\n`, status: "create" };
  }
  const previousContents = await readFile(destination, "utf8");
  if (hasIgnoreRule(previousContents)) {
    return { kind: "ignore-rule", path: IGNORE_PATH, destination, contents: previousContents, status: "unchanged" };
  }
  const separator = previousContents.length && !previousContents.endsWith("\n") ? "\n" : "";
  return {
    kind: "ignore-rule",
    path: IGNORE_PATH,
    destination,
    contents: `${previousContents}${separator}${IGNORE_RULE}\n`,
    previousContents,
    status: "create",
  };
}

function publicItem(item, status = item.status) {
  return { kind: item.kind, path: item.path, status };
}

async function assertProjectRoot(root) {
  const stat = await entry(root);
  if (!stat?.isDirectory() || stat.isSymbolicLink()) {
    fail("PROJECT_ROOT_INVALID", "Project root must be a real directory", { projectRoot: root }, 3);
  }
}

async function existingProjectPlan(root, options, registry) {
  const setupKeys = ["appName", "localUrl", "baseUrl", "previewUrl", "productionUrl", "startRoute", "healthPath"];
  if (setupKeys.some((key) => options[key] !== undefined) || !(await entry(join(root, CONFIG_PATH)))) return null;
  const currentContext = await resolveProjectContext({ projectRoot: root, registry });
  const skillPlan = await planCodexSkillInstallation(root);
  const gitSafety = await inspectProjectGitSafety(currentContext);
  const items = [...skillPlan.items, { kind: "config", path: CONFIG_PATH, status: "unchanged" }];
  if (gitSafety.status !== "safe") {
    items.push({ kind: "local-state", path: currentContext.paths.localStore, status: "conflict" });
  }
  return { root, registry, currentContext, gitSafety, skillPlan, items, existing: true };
}

/** Build a complete, mutation-free initialization plan. */
export async function planProjectInitialization(options = {}) {
  const root = resolve(options.projectRoot ?? options.cwd ?? process.cwd());
  await assertProjectRoot(root);
  const registry = options.registry ?? (await createSchemaRegistry());
  const existing = await existingProjectPlan(root, options, registry);
  if (existing) return existing;
  const input = initializationInput(root, options);
  const templates = await renderedTemplates(input, registry);
  const skillPlan = await planCodexSkillInstallation(root);
  const items = [
    await directoryItem(root, ".workflows"),
    await directoryItem(root, DEFINITIONS_PATH),
    await directoryItem(root, LOCAL_PATH),
    await exactFileItem(root, CONFIG_PATH, templates.config, "config"),
    await exactFileItem(root, STARTER_PATH, templates.starter, "workflow"),
    await exactFileItem(root, REQUIREMENTS_PATH, templates.requirements, "requirements"),
    await ignoreItem(root),
    ...skillPlan.items,
  ];
  let currentContext;
  try {
    currentContext = await resolveProjectContext({ projectRoot: root, registry });
  } catch (error) {
    const configConflict = items.some((item) => item.kind === "config" && item.status === "conflict");
    if (!configConflict || !["INVALID_YAML", "VALIDATION_FAILED"].includes(error.code)) throw error;
    currentContext = { projectRoot: root, paths: { localStore: LOCAL_PATH } };
  }
  const gitSafety = await inspectProjectGitSafety(currentContext);
  if (gitSafety.tracked) {
    items.push({ kind: "local-state", path: currentContext.paths.localStore, status: "conflict" });
  }
  return { root, registry, input, currentContext, gitSafety, skillPlan, items };
}

async function createDirectory(item, createdDirectories) {
  if (item.status === "unchanged") return publicItem(item, "unchanged");
  await mkdir(item.destination);
  createdDirectories.push(item.destination);
  return publicItem(item, "created");
}

async function writePlannedFile(item, createdFiles, restoredFiles) {
  if (item.status === "unchanged") return publicItem(item, "unchanged");
  if (Object.hasOwn(item, "previousContents")) {
    await writeFile(item.destination, item.contents, { flag: "r+" });
    restoredFiles.push(item);
  } else {
    await writeFile(item.destination, item.contents, { flag: "wx" });
    createdFiles.push(item.destination);
  }
  return publicItem(item, "created");
}

async function rollback(createdFiles, restoredFiles, createdDirectories, skillPlan) {
  await rollbackCodexSkillInstallation(skillPlan);
  for (const path of createdFiles.reverse()) await rm(path, { force: true });
  for (const item of restoredFiles.reverse()) await writeFile(item.destination, item.previousContents);
  for (const path of createdDirectories.reverse()) await rmdir(path).catch(() => {});
  for (const item of skillPlan.items.filter((candidate) => candidate.status === "create").reverse()) {
    let cursor = dirname(item.destination);
    const boundary = join(skillPlan.root, ".agents");
    while (cursor.startsWith(boundary)) {
      await rmdir(cursor).catch(() => {});
      if (cursor === boundary) break;
      cursor = dirname(cursor);
    }
  }
}

/** Initialize one repository without overwriting divergent project content. */
export async function initializeProject(options = {}) {
  const plan = await planProjectInitialization(options);
  const conflicts = plan.items.filter((item) => item.status === "conflict");
  if (conflicts.length) {
    fail("PROJECT_INITIALIZATION_CONFLICT", "Project initialization found conflicting destinations", {
      items: conflicts.map((item) => publicItem(item, "conflicting")),
    });
  }

  const createdFiles = [];
  const restoredFiles = [];
  const createdDirectories = [];
  const results = [];
  try {
    for (const item of plan.items.filter((candidate) => candidate.kind === "directory")) {
      results.push(await createDirectory(item, createdDirectories));
    }
    for (const item of plan.items.filter((candidate) =>
      ["config", "workflow", "requirements", "ignore-rule"].includes(candidate.kind),
    )) {
      results.push(await writePlannedFile(item, createdFiles, restoredFiles));
    }
    const skill = await applyCodexSkillInstallation(plan.skillPlan);
    results.push(...skill.items);

    const projectContext = await resolveProjectContext({ projectRoot: plan.root, registry: plan.registry });
    const gitSafety = await inspectProjectGitSafety(projectContext);
    if (gitSafety.status !== "safe") fail("PROJECT_LOCAL_STATE_UNSAFE", "Project local state is not safely ignored");
    const catalog = await catalogProjectWorkflows(projectContext, { registry: plan.registry });
    const starterId = plan.existing ? null : `${plan.input.projectId}.getting-started`;
    if (
      catalog.status !== "verified" ||
      (starterId && !catalog.workflows.some((workflow) => workflow.id === starterId))
    ) {
      fail("PROJECT_STARTER_INVALID", "Getting-started workflow is not present in the verified project catalog");
    }
    return {
      projectContext,
      items: results,
      created: results.filter((item) => item.status === "created"),
      updated: results.filter((item) => item.status === "updated"),
      unchanged: results.filter((item) => item.status === "unchanged"),
      conflicting: [],
    };
  } catch (error) {
    await rollback(createdFiles, restoredFiles, createdDirectories, plan.skillPlan);
    throw error;
  }
}
