import { isAbsolute } from "node:path";

import { WorkflowError } from "./errors.js";
import { readFixtureNeedReview } from "./fixture-need-decisions.js";
import { pinApplicationRecipe, pinRepositoryFileRecipe } from "./fixture-lifecycle.js";
import { sha256 } from "./stable-json.js";
import { validateWorkflowSemantics } from "./workflow.js";

const sourceFields = ["runId", "needId", "candidateHash", "expectedRevision", "workflowId"];
const recipeFields = ["id", "revision", "purpose", "target", "identity", "adapter"];
const semanticId = /^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$/u;

function fail(message, code = "FIXTURE_CANDIDATE_INVALID") {
  throw new WorkflowError(code, message, { exitCode: code === "FIXTURE_CANDIDATE_STALE" ? 4 : 3 });
}

function object(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function exactKeys(value, allowed, required = allowed) {
  return (
    object(value) && Object.keys(value).every((key) => allowed.includes(key)) && required.every((key) => key in value)
  );
}

function same(left, right) {
  return sha256(left) === sha256(right);
}

function validateRequest(request) {
  if (
    !exactKeys(request, ["sources", "recipe", "workflowDrafts", "compatibilityVersion", "projectRoot"]) ||
    request.compatibilityVersion !== "v1" ||
    !Array.isArray(request.sources) ||
    !request.sources.length ||
    !Array.isArray(request.workflowDrafts) ||
    request.workflowDrafts.length !== request.sources.length ||
    !exactKeys(request.recipe, recipeFields, recipeFields.slice(0, 5)) ||
    !semanticId.test(request.recipe.id ?? "") ||
    !/^v[1-9][0-9]*$/u.test(request.recipe.revision ?? "") ||
    typeof request.recipe.purpose !== "string" ||
    !request.recipe.purpose.trim() ||
    !object(request.recipe.target) ||
    !object(request.recipe.identity) ||
    typeof request.projectRoot !== "string" ||
    !isAbsolute(request.projectRoot)
  ) {
    fail(
      "Fixture candidate request must provide exact sources, recipe fields, full workflow drafts, and a project root",
    );
  }
  const sourceKeys = new Set();
  const workflowIds = new Set();
  for (const source of request.sources) {
    if (
      !exactKeys(source, sourceFields) ||
      !/^run_[A-Za-z0-9_-]+$/u.test(source.runId ?? "") ||
      !/^fixture_need_[A-Za-z0-9_-]+$/u.test(source.needId ?? "") ||
      !/^sha256:[a-f0-9]{64}$/u.test(source.candidateHash ?? "") ||
      !Number.isSafeInteger(source.expectedRevision) ||
      source.expectedRevision < 0 ||
      !semanticId.test(source.workflowId ?? "")
    ) {
      fail("Fixture candidate source pins are incomplete");
    }
    const key = `${source.runId}:${source.needId}`;
    if (sourceKeys.has(key) || workflowIds.has(source.workflowId)) fail("Each source and workflow ID must occur once");
    sourceKeys.add(key);
    workflowIds.add(source.workflowId);
  }
  const draftIds = request.workflowDrafts.map((draft) => draft?.metadata?.id);
  if (draftIds.some((id) => !workflowIds.has(id)) || new Set(draftIds).size !== draftIds.length) {
    fail("Workflow drafts must match the exact source workflow IDs once each");
  }
}

async function acceptedSources(store, registry, request) {
  const reviews = new Map();
  const selected = [];
  for (const source of request.sources) {
    let review = reviews.get(source.runId);
    if (!review) {
      review = await readFixtureNeedReview(store, registry, source.runId);
      reviews.set(source.runId, review);
    }
    if (review.revision !== source.expectedRevision)
      fail("Fixture need decision revision changed", "FIXTURE_CANDIDATE_STALE");
    const need = review.needs.find((item) => item.id === source.needId);
    if (!need || need.candidateHash !== source.candidateHash || need.decision?.status !== "accepted") {
      fail("Fixture need is unaccepted or stale", "FIXTURE_CANDIDATE_STALE");
    }
    if (need.source !== "bounded-exploration" && source.workflowId !== need.journeyId) {
      fail("Supervised workflow ID must equal the observed journey ID");
    }
    selected.push({ ...source, need });
  }
  // The selected journey order is part of the versioned recipe hash.
  if (new Set(selected.map(({ need }) => need.kind)).size !== 1) fail("One recipe cannot combine fixture kinds");
  const first = selected[0].need;
  if (selected.some(({ need }) => !same(need.target, first.target) || !same(need.identity, first.identity))) {
    fail("One recipe cannot combine different observed target or identity scopes");
  }
  return selected;
}

async function pinRecipe(request, selected, registry) {
  const first = selected[0].need;
  const allowedJourneys = selected.map((source) => source.workflowId);
  const declaration = { kind: first.kind, ...request.recipe, allowedJourneys };
  assertLocalScope(first.kind, request.recipe.target, request.recipe.identity);
  let recipe;
  if (first.kind === "repository-file") {
    if (request.recipe.adapter !== undefined) fail("Repository file recipes cannot contain an application adapter");
    const pinnedUpload = first.pinnedUpload;
    if (!pinnedUpload || selected.some(({ need }) => !same(need.pinnedUpload, pinnedUpload))) {
      fail("Repository file sources must name the same pinned upload");
    }
    recipe = await pinRepositoryFileRecipe(request.projectRoot, {
      ...declaration,
      relativePath: pinnedUpload.relativePath,
      uploadTarget: pinnedUpload.uploadTarget,
      sizeBytes: pinnedUpload.sizeBytes,
      mimeType: pinnedUpload.mimeType,
      sha256: pinnedUpload.sha256,
    });
  } else if (first.kind === "application-record") {
    if (!object(request.recipe.adapter)) fail("Application recipe requires an explicit complete adapter");
    recipe = pinApplicationRecipe(declaration);
  } else {
    fail("Unsupported fixture need kind");
  }
  registry.validate("fixtureRecipe", recipe);
  return recipe;
}

function loopbackUrl(value) {
  try {
    const url = new URL(value);
    return (
      ["http:", "https:"].includes(url.protocol) &&
      !url.username &&
      !url.password &&
      !url.hash &&
      url.hostname === "workflows.localhost"
    );
  } catch {
    return false;
  }
}

function assertLocalScope(kind, target, identity) {
  if (
    target.source !== "application-target" ||
    target.environment !== "local" ||
    !loopbackUrl(target.canonicalUrl) ||
    !loopbackUrl(target.effectiveUrl) ||
    new URL(target.canonicalUrl).origin !== new URL(target.effectiveUrl).origin
  ) {
    fail("Fixture candidates require an explicit local loopback application target");
  }
  if (kind === "repository-file" && identity.requirement !== "anonymous") {
    fail("Repository upload candidates require anonymous identity");
  }
  if (kind === "application-record" && (identity.requirement !== "named-profile" || !identity.profile)) {
    fail("Application record candidates require an explicit named profile");
  }
}

function compileWorkflows(request, recipe, registry) {
  const requirement = {
    kind: recipe.kind,
    recipeId: recipe.id,
    recipeRevision: recipe.revision,
    compatibilityVersion: request.compatibilityVersion,
    requiredState: "ready",
  };
  return request.workflowDrafts
    .map((draft) => {
      if (draft?.schema !== "agent-workflow/v1" || draft?.metadata?.lifecycle !== "candidate") {
        fail("Only full workflow v1 candidate drafts can be compiled");
      }
      if (draft.fixtureRequirement && !same(draft.fixtureRequirement, requirement)) {
        fail("Existing workflow fixture requirement differs from the compiled recipe");
      }
      if (!same(draft.target?.identity, recipe.identity)) {
        fail("Workflow draft identity differs from the proposed recipe identity");
      }
      if (draft.start?.route !== recipe.target.route) {
        fail("Workflow draft start route differs from the proposed recipe target route");
      }
      const workflow = { ...structuredClone(draft), fixtureRequirement: requirement };
      registry.validate("workflow", workflow);
      validateWorkflowSemantics(workflow);
      return workflow;
    })
    .sort((left, right) => left.metadata.id.localeCompare(right.metadata.id));
}

function provenanceFor(selected, recipe, workflows) {
  const sources = selected.map(({ runId, needId, candidateHash, expectedRevision, workflowId, need }) => ({
    runId,
    needId,
    candidateHash,
    decisionRevision: expectedRevision,
    decision: structuredClone(need.decision),
    source: need.source,
    sourceJourneyId: need.journeyId,
    workflowId,
    ...(need.sourceRevision ? { sourceRevision: need.sourceRevision } : {}),
    ...(need.sourceReceiptHash ? { sourceReceiptHash: need.sourceReceiptHash } : {}),
    evidence: structuredClone(need.evidence),
    observed:
      recipe.kind === "repository-file"
        ? { pinnedUpload: structuredClone(need.pinnedUpload) }
        : {
            recipeHash: need.observed?.recipeHash,
            recipeId: need.observed?.recipeId,
            recipeRevision: need.observed?.recipeRevision,
            cleanupOwnerRunId: need.observed?.cleanupOwnerRunId,
          },
    observedScope: { target: structuredClone(need.target), identity: structuredClone(need.identity) },
    scopeChanged: !same(need.target, recipe.target) || !same(need.identity, recipe.identity),
  }));
  return {
    sources,
    proposedScope: { target: structuredClone(recipe.target), identity: structuredClone(recipe.identity) },
    fields: {
      observed: [
        "kind",
        "journeyId",
        "target",
        "identity",
        "evidence",
        ...(recipe.kind === "repository-file" ? ["pinnedUpload"] : ["historicalCleanup"]),
      ],
      operatorSupplied: [
        "recipe.id",
        "recipe.revision",
        "recipe.purpose",
        "recipe.target",
        "recipe.identity",
        "workflowDrafts",
        "workflow.target.app",
        ...(selected.some(({ need, workflowId }) => need.journeyId !== workflowId) ? ["source.workflowId"] : []),
      ],
      adapterSupplied: recipe.kind === "application-record" ? ["recipe.adapter"] : [],
    },
    hashes: { recipe: sha256(recipe), workflows: sha256(workflows) },
    unresolved: [
      "Recipe and workflow candidate require separate review before fixture creation.",
      "Workflow app identifiers are operator-supplied and require review against the selected app.",
      ...(sources.some((source) => source.scopeChanged)
        ? [
            "Proposed target or identity differs from source evidence; source evidence does not authorize the new scope.",
          ]
        : []),
      ...new Set(selected.flatMap(({ need }) => need.unresolved ?? [])),
      ...(recipe.kind === "application-record"
        ? ["Historical record IDs and adapter operation semantics do not authorize a new application write."]
        : []),
    ],
  };
}

/** Compile verified, accepted need pins into inert recipe and workflow candidates. */
export async function compileFixtureCandidate(store, registry, request) {
  validateRequest(request);
  const selected = await acceptedSources(store, registry, request);
  const recipe = await pinRecipe(request, selected, registry);
  const workflows = compileWorkflows(request, recipe, registry);
  return {
    schema: "agent-workflow-fixture-candidate/v1",
    status: "pending-recipe-review",
    recipe,
    workflows,
    provenance: provenanceFor(selected, recipe, workflows),
  };
}
