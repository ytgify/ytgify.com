import { WorkflowError } from "./errors.js";
import { matchesExplorationFile } from "./exploration-fixtures.js";

function fail(message) {
  throw new WorkflowError("VALIDATION_FAILED", message, { exitCode: 3 });
}

/** Project hypotheses from byte-verified captures and their exact leased action journal. */
export async function projectExploration(store, runId, { now = () => new Date() } = {}) {
  const run = await store.readRun(runId);
  if (run.manifest.phase !== "exploration" || !run.state.exploration) {
    throw new WorkflowError("INVALID_RUN_PHASE", "Exploration review requires an exploration run", { exitCode: 4 });
  }
  const state = run.state.exploration;
  const evidenceByVisit = new Map();
  const actionByVisit = new Map();
  const uploadByVisit = new Map();
  for (const visit of state.visits) {
    const verified = await store.readVerifiedEvidenceFromRun(run, visit.evidenceId);
    const commit = run.events.find(
      (event) => event.type === "action.committed" && event.eventId === visit.commitEventId,
    );
    const lease = run.events.find(
      (event) => event.type === "action.leased" && event.payload.lease.leaseId === visit.leaseId,
    );
    if (
      !commit?.transaction ||
      !lease?.transaction ||
      commit.payload.result.leaseId !== visit.leaseId ||
      lease.transaction.requestId !== verified.artifact.relation.batchRequestId ||
      verified.artifact.relation.stepId !== "explore" ||
      verified.artifact.relation.checkpoint !== "visit" ||
      commit.payload.exploration.evidenceId !== visit.evidenceId
    ) {
      fail("Exploration visit lost its exact lease, commit, or capture binding");
    }
    evidenceByVisit.set(visit.visitId, {
      visitId: visit.visitId,
      artifactId: verified.artifact.artifactId,
      contentHash: verified.artifact.contentHash,
      commitEventId: commit.eventId,
      leaseId: lease.payload.lease.leaseId,
      leaseRequestId: lease.transaction.requestId,
    });
    actionByVisit.set(visit.visitId, lease.payload.lease.proposal.actions[0]);
    const action = lease.payload.lease.proposal.actions[0];
    if (matchesExplorationFile(run.manifest, action, lease.payload.lease.proposal.requestedCapabilities)) {
      uploadByVisit.set(
        visit.visitId,
        run.manifest.exploration.fixtures.find((fixture) => fixture.name === action.inputRef.name),
      );
    }
  }
  const screens = state.visits.map((visit) => ({
    id: `screen_${visit.visitId}`,
    kind: "screen",
    title: visit.label,
    status: "unaccepted",
    reportedUrl: visit.url,
    evidence: [evidenceByVisit.get(visit.visitId)],
    uncertainty: ["Screen identity and page URL are host reports requiring review.", ...visit.uncertainty],
  }));
  const journeys = [];
  const subjourneys = [];
  const fixtureNeeds = [];
  for (const visit of state.visits) {
    if (!visit.journey) continue;
    const start = evidenceByVisit.get(visit.fromVisitId);
    const end = evidenceByVisit.get(visit.visitId);
    if (!start || !end) fail("Journey nomination lacks two verified visit captures");
    const parents = visit.journey.parentJourneyIds ?? [];
    const candidate = {
      id: `journey_${visit.visitId}`,
      kind: parents.length ? "subjourney" : "journey",
      title: visit.journey.title,
      status: "unaccepted",
      reportedUrl: visit.url,
      entryCondition: visit.journey.entryCondition,
      userOutcome: visit.journey.userOutcome,
      evidence: [start, end],
      transition: {
        fromVisitId: visit.fromVisitId,
        toVisitId: visit.visitId,
        action: actionByVisit.get(visit.visitId).description,
        leaseId: visit.leaseId,
        commitEventId: visit.commitEventId,
      },
      uncertainty: [
        "Entry, outcome, transition, and containment are host proposals requiring review.",
        ...visit.uncertainty,
        ...visit.journey.uncertainty,
      ],
      ...(parents.length ? { parentIds: parents, relationshipRationale: visit.journey.relationshipRationale } : {}),
    };
    (parents.length ? subjourneys : journeys).push(candidate);
    const uploaded = uploadByVisit.get(visit.visitId);
    if (uploaded) {
      fixtureNeeds.push({
        id: `fixture_need_${visit.visitId}`,
        journeyId: candidate.id,
        status: "unaccepted",
        source: "bounded-exploration",
        kind: "repository-file",
        cardinality: 1,
        target: run.manifest.target,
        identity: run.manifest.identity,
        pinnedUpload: {
          fixtureName: uploaded.name,
          relativePath: uploaded.relativePath,
          uploadTarget: uploaded.target,
          filename: uploaded.filename,
          sizeBytes: uploaded.sizeBytes,
          mimeType: uploaded.mimeType,
          sha256: uploaded.sha256,
        },
        evidence: [start, end],
        uncertainty: [
          "The supplied file was bound for exploration; a generator, recipe, ownership, and retention require separate review.",
          ...candidate.uncertainty,
        ],
      });
    }
  }
  const coverage = run.manifest.exploration.intents.map((intent) => {
    const visits = state.visits.filter((visit) => visit.intent === intent);
    const gaps = state.gaps.filter((gap) => gap.intent === intent);
    const lastGap = gaps.at(-1);
    return {
      intent,
      state: visits.length ? "visited" : (lastGap?.state ?? "unvisited"),
      visitIds: visits.map((visit) => visit.visitId),
      gaps: gaps.map((gap) => ({ id: gap.gapId, state: gap.state, reason: gap.reason ?? gap.label ?? "Unresolved" })),
    };
  });
  const limits = run.manifest.exploration.limits;
  const elapsed = new Date(state.finish?.at ?? now()).valueOf() - new Date(run.manifest.createdAt).valueOf();
  const review = {
    schema: "agent-workflow-exploration-review/v1",
    runId,
    status: run.state.status,
    target: run.manifest.target,
    limits,
    finish: state.finish,
    usage: {
      actions: state.actionsUsed,
      captures: state.capturesUsed,
      branches: state.branchesUsed,
      minutes: Math.max(0, elapsed / 60_000),
      exhausted:
        state.actionsUsed >= limits.actions ||
        state.capturesUsed >= limits.captures ||
        elapsed >= limits.minutes * 60_000,
    },
    coverage,
    screens,
    journeys,
    subjourneys,
    fixtureNeeds,
  };
  store.registry?.validate("explorationProposal", review);
  return review;
}
