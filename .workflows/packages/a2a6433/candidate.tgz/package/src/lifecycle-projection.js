import { lstat } from "node:fs/promises";

import { verifyPromotionTruth, verifyQualificationTruth } from "./lifecycle.js";

const PLATFORMS = ["desktop-web", "mobile-web"];
const missing = (error) => ["ENOENT", "RUN_NOT_FOUND", "NOT_FOUND", "REPLAY_NOT_FINALIZED"].includes(error?.code);

function integrityFromError(error) {
  if (missing(error)) return "missing";
  if (
    error instanceof SyntaxError ||
    /(?:CORRUPT|UNSAFE|HASH_MISMATCH|VALIDATION_FAILED|INDEX_|INVALID_LIFECYCLE_ID)/u.test(error?.code ?? "")
  )
    return "corrupt";
  return "stale";
}

const route = (workflowId, suffix) => `#/journeys/${encodeURIComponent(workflowId)}${suffix}`;

async function classified(read) {
  try {
    return { value: await read(), integrity: "verified" };
  } catch (error) {
    return { value: null, integrity: integrityFromError(error) };
  }
}

async function lifecycleRootAbsent(store) {
  if (typeof store?.lifecycleRoot !== "string") return false;
  try {
    await lstat(store.lifecycleRoot);
    return false;
  } catch (error) {
    if (error?.code === "ENOENT") return true;
    throw error;
  }
}

async function promotionProjection(runStore, lifecycleStore, workflowId, revision) {
  const loaded = await classified(() => lifecycleStore.readPromotion(workflowId, revision));
  if (!loaded.value) return { revision, integrity: loaded.integrity };
  const { record } = loaded.value;
  let integrity = "verified";
  try {
    await verifyPromotionTruth({ workflowId, revision, lifecycleStore, runStore });
  } catch (error) {
    integrity = integrityFromError(error);
  }
  return {
    revision,
    contentHash: record.contentHash,
    promotedAt: record.promotedAt,
    replayRunId: record.replayRunId,
    route: route(workflowId, "/release"),
    integrity,
  };
}

async function qualificationProjection(runStore, lifecycleStore, qualificationId) {
  const loaded = await classified(() => lifecycleStore.readRecord("qualification", qualificationId));
  if (!loaded.value) return { qualificationId, integrity: loaded.integrity };
  const record = loaded.value;
  let integrity = "verified";
  try {
    await verifyQualificationTruth({ qualificationId, qualification: record, lifecycleStore, runStore });
  } catch (error) {
    integrity = integrityFromError(error);
  }
  return {
    qualificationId,
    workflowId: record.workflowId,
    revision: record.revision,
    platform: record.platform,
    replayRunId: record.replayRunId,
    effectiveHash: record.effectiveHash,
    qualifiedAt: record.qualifiedAt,
    route: route(record.workflowId, "/release"),
    integrity,
  };
}

function exactMember(run, group, member) {
  const manifest = run?.manifest;
  return (
    manifest?.runId === member.runId &&
    manifest?.workflowRef?.id === group.workflowId &&
    manifest?.workflowRef?.revision === group.revision &&
    manifest?.workflowRef?.contentHash === group.contentHash &&
    manifest?.workflowRef?.effectiveHash === member.effectiveHash &&
    manifest?.evaluationGroupId === group.groupId &&
    manifest?.qualificationId === member.qualificationId &&
    manifest?.platform === member.platform
  );
}

async function groupProjection(runStore, lifecycleStore, groupId) {
  const loaded = await classified(() => lifecycleStore.readRecord("group", groupId));
  if (!loaded.value) return { groupId, integrity: loaded.integrity, outcome: "not-asserted", members: [] };
  const group = loaded.value;
  const members = await Promise.all(
    group.members.map(async (member) => {
      const run = await classified(() => runStore.readRun(member.runId));
      const qualification = await qualificationProjection(runStore, lifecycleStore, member.qualificationId);
      const exact =
        exactMember(run.value, group, member) &&
        qualification.workflowId === group.workflowId &&
        qualification.revision === group.revision &&
        qualification.platform === member.platform &&
        qualification.effectiveHash === member.effectiveHash;
      const integrity =
        run.integrity !== "verified"
          ? run.integrity
          : qualification.integrity !== "verified"
            ? qualification.integrity
            : exact
              ? "verified"
              : "corrupt";
      return {
        runId: member.runId,
        platform: member.platform,
        qualificationId: member.qualificationId,
        effectiveHash: member.effectiveHash,
        viewport: member.viewport ?? null,
        route: route(group.workflowId, `/evaluations/run/${encodeURIComponent(member.runId)}`),
        integrity,
      };
    }),
  );
  return {
    groupId,
    workflowId: group.workflowId,
    revision: group.revision,
    contentHash: group.contentHash,
    resetContractHash: group.resetContractHash,
    createdAt: group.createdAt,
    platforms: members.map((member) => member.platform),
    members,
    route: route(group.workflowId, `/evaluations/group/${encodeURIComponent(groupId)}`),
    integrity: members.every((member) => member.integrity === "verified") ? "verified" : "degraded",
    outcome: "not-asserted",
  };
}

export function emptyLifecycleProjection() {
  return {
    integrity: { status: "verified", issues: [] },
    workflows: [],
    groups: [],
    qualifications: [],
    qualificationMatrix: {},
  };
}

/** Reconstruct one bounded, read-only lifecycle DTO for CLI and Studio. */
export async function projectLifecycleProjection(runStore, lifecycleStore) {
  const index = await classified(() => lifecycleStore.readIndex());
  if (!index.value) {
    if (index.integrity === "missing" && (await lifecycleRootAbsent(lifecycleStore))) return emptyLifecycleProjection();
    return {
      ...emptyLifecycleProjection(),
      integrity: { status: "degraded", issues: ["Lifecycle records could not be verified."] },
    };
  }
  const workflows = await Promise.all(
    Object.keys(index.value)
      .sort()
      .map(async (workflowId) => {
        const revisions = Array.isArray(index.value[workflowId]?.revisions) ? index.value[workflowId].revisions : [];
        const versions = await Promise.all(
          revisions.map((revision) => promotionProjection(runStore, lifecycleStore, workflowId, revision)),
        );
        return { workflowId, versions, latest: versions.at(-1) ?? null };
      }),
  );
  const qualificationIds = await classified(() => lifecycleStore.listRecordIds("qualification"));
  const groupIds = await classified(() => lifecycleStore.listRecordIds("group"));
  const qualifications = qualificationIds.value
    ? await Promise.all(qualificationIds.value.map((id) => qualificationProjection(runStore, lifecycleStore, id)))
    : [];
  const groups = groupIds.value
    ? await Promise.all(groupIds.value.map((id) => groupProjection(runStore, lifecycleStore, id)))
    : [];
  const qualificationMatrix = Object.fromEntries(
    workflows.map(({ workflowId, versions }) => [
      workflowId,
      Object.fromEntries(
        versions.map(({ revision }) => [
          revision,
          Object.fromEntries(
            PLATFORMS.map((platform) => {
              const matches = qualifications
                .filter(
                  (item) => item.workflowId === workflowId && item.revision === revision && item.platform === platform,
                )
                .sort((left, right) => String(right.qualifiedAt).localeCompare(String(left.qualifiedAt)));
              return [platform, matches[0] ?? { qualificationId: null, integrity: "missing" }];
            }),
          ),
        ]),
      ),
    ]),
  );
  const degraded =
    qualificationIds.integrity !== "verified" ||
    groupIds.integrity !== "verified" ||
    workflows.some(({ versions }) => versions.some((version) => version.integrity !== "verified")) ||
    qualifications.some((qualification) => qualification.integrity !== "verified") ||
    groups.some((group) => group.integrity !== "verified");
  return {
    integrity: {
      status: degraded ? "degraded" : "verified",
      issues: degraded ? ["Lifecycle records could not be fully verified."] : [],
    },
    workflows,
    groups,
    qualifications,
    qualificationMatrix,
  };
}
