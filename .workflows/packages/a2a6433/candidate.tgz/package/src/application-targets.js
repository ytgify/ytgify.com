import { WorkflowError } from "./errors.js";

const TARGET_ID = /^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$/u;
const ORIGIN_URL = /^https?:\/\/[^/?#]+\/?$/u;
const ENVIRONMENTS = new Set(["local", "preview", "staging", "production", "other"]);
const MAX_TARGETS = 16;

function fail(code, message, details) {
  throw new WorkflowError(code, message, { exitCode: 3, details });
}

function cleanText(value, label) {
  if (typeof value !== "string") fail("APPLICATION_TARGET_INVALID", `${label} must be a string`);
  const result = [...value]
    .map((character) => {
      const code = character.codePointAt(0);
      return code < 32 || code === 127 ? " " : character;
    })
    .join("")
    .replace(/\s+/gu, " ")
    .trim();
  if (!result || result.length > 200) {
    fail("APPLICATION_TARGET_INVALID", `${label} must contain 1 to 200 printable characters`);
  }
  return result;
}

function safeUrl(value, label, { originOnly = false } = {}) {
  let parsed;
  try {
    parsed = new URL(value);
  } catch {
    fail("APPLICATION_TARGET_URL_INVALID", `${label} must be an absolute HTTP(S) URL`);
  }
  if (
    !["http:", "https:"].includes(parsed.protocol) ||
    parsed.username ||
    parsed.password ||
    parsed.hash ||
    (originOnly && !ORIGIN_URL.test(value)) ||
    parsed.origin === "null"
  ) {
    fail(
      "APPLICATION_TARGET_URL_INVALID",
      originOnly
        ? `${label} must be an HTTP(S) origin without credentials, a path, query, or fragment`
        : `${label} must be an absolute HTTP(S) URL without credentials or a fragment`,
    );
  }
  return originOnly ? `${parsed.origin}/` : parsed.href;
}

function normalizeTarget(target, provenance) {
  if (!target || typeof target !== "object" || Array.isArray(target)) {
    fail("APPLICATION_TARGET_INVALID", "Each application target must be an object");
  }
  if (!TARGET_ID.test(target.id ?? "")) {
    fail("APPLICATION_TARGET_INVALID", "Application target IDs must use stable lowercase identifier syntax", {
      id: target.id,
    });
  }
  if (!ENVIRONMENTS.has(target.environment)) {
    fail("APPLICATION_TARGET_INVALID", "Application target environment is unsupported", {
      environment: target.environment,
    });
  }
  if (target.healthPath !== undefined && !/^\/(?!\/)/u.test(target.healthPath)) {
    fail("APPLICATION_TARGET_INVALID", "Application target healthPath must be an origin-relative path");
  }
  const authentication = target.authentication?.mode === "user-session" ? { mode: "user-session" } : undefined;
  if (authentication && provenance !== "configured-v1") {
    fail("APPLICATION_TARGET_AUTH_UNSUPPORTED", "Application target authentication requires configured v1 provenance");
  }
  return {
    id: target.id,
    label: cleanText(target.label, "Application target label"),
    environment: target.environment,
    baseUrl: safeUrl(target.baseUrl, "Application target baseUrl", { originOnly: provenance === "configured-v1" }),
    ...(target.healthPath === undefined ? {} : { healthPath: target.healthPath }),
    ...(authentication ? { authentication } : {}),
    ...(target.localDogfood ? { localDogfood: structuredClone(target.localDogfood) } : {}),
    provenance,
  };
}

/** Adapt versioned repository config into one bounded, sanitized target inventory. */
export function applicationTargetsFromConfig(config) {
  if (config.schema === "agent-workflow-config/v0") {
    const target = normalizeTarget(
      {
        id: "legacy-default",
        label: config.project.appName,
        environment: "other",
        baseUrl: config.project.baseUrl,
        healthPath: config.project.healthPath,
      },
      "adapted-config-v0",
    );
    return {
      inventory: [target],
      defaultTargetId: target.id,
      warnings: ["Legacy project.baseUrl was adapted as an application target; migrate to agent-workflow-config/v1."],
    };
  }
  if (config.schema !== "agent-workflow-config/v1") {
    fail("APPLICATION_TARGET_CONFIG_UNSUPPORTED", "Application targets require config v0 or v1");
  }
  const source = config.project.targets;
  if (!Array.isArray(source) || source.length < 1 || source.length > MAX_TARGETS) {
    fail("APPLICATION_TARGET_INVALID", `Project targets must contain 1 to ${MAX_TARGETS} entries`);
  }
  const inventory = source.map((target) => normalizeTarget(target, "configured-v1"));
  const ids = new Set();
  for (const target of inventory) {
    if (ids.has(target.id))
      fail("APPLICATION_TARGET_DUPLICATE", "Application target IDs must be unique", { id: target.id });
    ids.add(target.id);
  }
  const defaultTargetId = config.project.defaultTargetId;
  if (defaultTargetId !== undefined && !ids.has(defaultTargetId)) {
    fail("APPLICATION_TARGET_DEFAULT_INVALID", "The default application target must name a configured target", {
      defaultTargetId,
    });
  }
  return {
    inventory: [...inventory].sort((left, right) => left.id.localeCompare(right.id)),
    ...(defaultTargetId === undefined ? {} : { defaultTargetId }),
    warnings: [],
  };
}

function terms(value) {
  return (
    String(value ?? "")
      .toLocaleLowerCase("en-US")
      .match(/[a-z0-9]+/gu) ?? []
  );
}

function question(candidates) {
  const choices = candidates.map((target) => `${target.label} (${target.environment})`);
  return `Which application target do you mean: ${choices.join("; or ")}?`.slice(0, 500);
}

/** Select from verified target truth. Only label and environment terms participate. */
export function selectApplicationTarget(applicationTargets, query = "") {
  const inventory = [...(applicationTargets?.inventory ?? [])].sort((left, right) => left.id.localeCompare(right.id));
  if (inventory.length === 0) return { status: "empty" };
  const requestedTerms = terms(query);
  const matches = requestedTerms.length
    ? inventory.filter((target) => {
        const words = terms(`${target.label} ${target.environment}`);
        return requestedTerms.every((term) => words.includes(term));
      })
    : [];

  let selected = matches.length === 1 ? matches[0] : null;
  let reason = "product-language-match";
  if (!requestedTerms.length && inventory.length === 1 && inventory[0].environment === "local") {
    selected = inventory[0];
    reason = "sole-non-production";
  }
  if (!requestedTerms.length && applicationTargets?.defaultTargetId) {
    const configuredDefault = inventory.find(({ id }) => id === applicationTargets.defaultTargetId);
    if (configuredDefault?.environment === "local") {
      selected = configuredDefault;
      reason = "configured-default";
    }
  }
  if (selected) {
    return {
      status: "selected",
      targetId: selected.id,
      label: selected.label,
      environment: selected.environment,
      baseUrl: selected.baseUrl,
      ...(selected.healthPath === undefined ? {} : { healthPath: selected.healthPath }),
      reason,
    };
  }

  const candidates = matches.length > 1 ? matches : inventory;
  return {
    status: "ambiguous",
    question: question(candidates),
    candidateTargetIds: candidates.map(({ id }) => id),
  };
}
