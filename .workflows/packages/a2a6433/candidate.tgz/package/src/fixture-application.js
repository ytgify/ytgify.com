import { WorkflowError } from "./errors.js";
import { assertFixtureHandoff, fixtureIdentityBinding } from "./fixture-lifecycle.js";
import { sha256 } from "./stable-json.js";

function fail(code, message) {
  throw new WorkflowError(code, message, { exitCode: 4 });
}

function assertNoActionLease(run) {
  if (run.state.activeLease || run.state.uncertainLeaseId)
    fail("FIXTURE_LEASE_REQUIRED", "A browser action lease is active or uncertain");
}

function exactId(recipe, id) {
  const pattern =
    recipe.adapter.recordIdFormat === "uuid"
      ? /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/u
      : /^[A-Za-z0-9_-]{1,120}$/u;
  if (typeof id !== "string" || !pattern.test(id))
    fail("FIXTURE_ID_INVALID", "Adapter returned an invalid exact record ID");
  return id;
}

function fixtureScope(manifest) {
  return {
    recipeHash: manifest.fixtureContract.recipeHash,
    targetHash: sha256(manifest.target),
    identityHash: sha256(fixtureIdentityBinding(manifest)),
    idempotencyKey: sha256({
      runId: manifest.runId,
      recipeHash: manifest.fixtureContract.recipeHash,
      target: manifest.target,
      identity: fixtureIdentityBinding(manifest),
    }),
    cleanupOwnerRunId: manifest.runId,
  };
}

function summarize(transitions) {
  let status = "unbound";
  let recordId = null;
  let readyReceipt = null;
  let activeChildRunId = null;
  for (const entry of transitions) {
    if (entry.recordId && recordId && entry.recordId !== recordId)
      fail("FIXTURE_JOURNAL_CORRUPT", "Fixture record ID changed across transitions");
    if (entry.recordId) recordId = entry.recordId;
    switch (entry.type) {
      case "setup.requested":
        if (status !== "unbound") fail("FIXTURE_JOURNAL_CORRUPT", "Fixture setup repeated");
        status = "uncertain";
        break;
      case "setup.returned":
        if (status !== "uncertain" || !recordId)
          fail("FIXTURE_JOURNAL_CORRUPT", "Fixture setup return lacks a pending exact ID");
        status = "uncertain";
        break;
      case "setup.uncertain":
        if (status !== "uncertain") fail("FIXTURE_JOURNAL_CORRUPT", "Fixture setup uncertainty is out of order");
        status = "uncertain";
        break;
      case "setup.ready":
        if (status !== "uncertain" || !recordId)
          fail("FIXTURE_JOURNAL_CORRUPT", "Fixture readiness has no exact setup return");
        status = "ready";
        readyReceipt = entry;
        break;
      case "cleanup.requested":
        if (!new Set(["ready", "uncertain"]).has(status) || !recordId || activeChildRunId)
          fail("FIXTURE_JOURNAL_CORRUPT", "Fixture cleanup began while unavailable or leased");
        status = "cleanup-pending";
        break;
      case "cleanup.pending":
        if (status !== "cleanup-pending") fail("FIXTURE_JOURNAL_CORRUPT", "Fixture cleanup pending is out of order");
        status = "cleanup-pending";
        break;
      case "cleanup.cleaned":
        if (status !== "cleanup-pending") fail("FIXTURE_JOURNAL_CORRUPT", "Fixture cleanup lacks a pending request");
        status = "cleaned";
        break;
      case "lease.opened":
        if (status !== "ready" || activeChildRunId)
          fail("FIXTURE_JOURNAL_CORRUPT", "Multiple or unavailable child fixture leases");
        activeChildRunId = entry.childRunId;
        break;
      case "lease.closed":
        if (status !== "ready" || activeChildRunId !== entry.childRunId)
          fail("FIXTURE_JOURNAL_CORRUPT", "Fixture lease closure differs");
        activeChildRunId = null;
        break;
      default:
        fail("FIXTURE_JOURNAL_CORRUPT", "Unknown fixture transition");
    }
  }
  return { status, recordId, readyReceipt, activeChildRunId };
}

export class FixtureApplicationService {
  constructor(store, { now = () => new Date() } = {}) {
    this.store = store;
    this.now = now;
    this.adapters = new Map();
  }

  registerAdapter(contract, implementation, scope) {
    if (
      !contract?.id ||
      !contract.revision ||
      !implementation ||
      scope?.disposable !== true ||
      !/^sha256:[a-f0-9]{64}$/u.test(scope.targetHash ?? "") ||
      !/^sha256:[a-f0-9]{64}$/u.test(scope.identityHash ?? "") ||
      ["create", "readById", "readByKey", "deleteById"].some((method) => typeof implementation[method] !== "function")
    )
      fail("FIXTURE_ADAPTER_INVALID", "Host adapter needs exact create, ID/key readback, and ID deletion operations");
    const key = `${contract.id}@${contract.revision}`;
    if (this.adapters.has(key)) fail("FIXTURE_ADAPTER_INVALID", "Host adapter revision is already registered");
    this.adapters.set(key, { contract: structuredClone(contract), implementation, scope: structuredClone(scope) });
  }

  adapterFor(recipe, manifest) {
    if (recipe?.kind !== "application-record") fail("FIXTURE_INCOMPATIBLE", "Run has no application fixture");
    if (manifest.target?.environment !== "local")
      fail("FIXTURE_TARGET_UNSAFE", "Application fixture setup requires a disposable local target");
    const registered = this.adapters.get(`${recipe.adapter.id}@${recipe.adapter.revision}`);
    if (!registered || sha256(registered.contract) !== sha256(recipe.adapter))
      fail("FIXTURE_ADAPTER_UNAVAILABLE", "Exact pinned host adapter revision is unavailable");
    if (
      registered.scope.targetHash !== sha256(manifest.target) ||
      registered.scope.identityHash !== sha256(fixtureIdentityBinding(manifest))
    )
      fail("FIXTURE_ADAPTER_UNAVAILABLE", "Host adapter is not registered for this exact target and identity");
    return registered.implementation;
  }

  async owner(runId) {
    const run = await this.store.readRun(runId);
    if (run.manifest.parentRunId)
      fail("FIXTURE_OWNER_REQUIRED", "A child borrowing a fixture cannot create or clean up the record");
    const recipe = run.manifest.fixtureContract?.recipe;
    const adapter = this.adapterFor(recipe, run.manifest);
    const scope = fixtureScope(run.manifest);
    const transitions = await this.store.readFixtureTransitions(runId);
    for (const entry of transitions) {
      for (const [key, value] of Object.entries(scope)) {
        if (entry[key] !== value)
          fail("FIXTURE_JOURNAL_CORRUPT", "Fixture transition scope differs from immutable run");
      }
      if (entry.recordId) exactId(recipe, entry.recordId);
    }
    return { run, recipe, adapter, scope, transitions, ...summarize(transitions) };
  }

  async append(owner, type, fields = {}) {
    return this.store.appendFixtureTransition(owner.run.manifest.runId, {
      type,
      occurredAt: this.now().toISOString(),
      ...owner.scope,
      ...fields,
    });
  }

  assertOwnedReadback(owner, recordId, record, { requireReady = true } = {}) {
    if (record === null) return null;
    if (
      record?.id !== exactId(owner.recipe, recordId) ||
      record.idempotencyKey !== owner.scope.idempotencyKey ||
      record.targetHash !== owner.scope.targetHash ||
      record.identityHash !== owner.scope.identityHash ||
      (requireReady ? record.ready !== true : typeof record.ready !== "boolean")
    )
      fail("FIXTURE_READBACK_INVALID", "Adapter readback does not prove exact owned record binding");
    return record;
  }

  async readExact(owner, recordId, options) {
    const record = await owner.adapter.readById({
      operationId: owner.recipe.adapter.readByIdOperation,
      recordId,
      target: owner.run.manifest.target,
      identity: fixtureIdentityBinding(owner.run.manifest),
    });
    return this.assertOwnedReadback(owner, recordId, record, options);
  }

  async status(runId) {
    const owner = await this.owner(runId);
    return {
      state: owner.status,
      recordId: owner.recordId,
      activeChildRunId: owner.activeChildRunId,
      cleanupOwnerRunId: runId,
      idempotencyKey: owner.scope.idempotencyKey,
      transitions: owner.transitions,
    };
  }

  async setup(runId) {
    return this.store.withExclusiveFixtures(async () => {
      const owner = await this.owner(runId);
      if (owner.status === "ready") {
        if (!owner.activeChildRunId && (await this.readExact(owner, owner.recordId)))
          return { state: "ready", recordId: owner.recordId, cleanupOwnerRunId: runId };
        fail("FIXTURE_NOT_READY", "Existing fixture is unavailable or leased");
      }
      if (owner.status !== "unbound")
        fail("FIXTURE_UNCERTAIN", "Fixture setup was already attempted; reconcile instead");
      await this.append(owner, "setup.requested");
      let recordId;
      try {
        const created = await owner.adapter.create({
          operationId: owner.recipe.adapter.setupOperation,
          idempotencyKey: owner.scope.idempotencyKey,
          target: owner.run.manifest.target,
          identity: fixtureIdentityBinding(owner.run.manifest),
        });
        recordId = exactId(owner.recipe, created?.id);
      } catch {
        await this.append(owner, "setup.uncertain", { reason: "setup acknowledgement or readback uncertain" });
        fail("FIXTURE_UNCERTAIN", "Fixture setup is uncertain; reconcile by exact key or ID");
      }
      await this.append(owner, "setup.returned", { recordId });
      let ready;
      try {
        ready = await this.readExact(owner, recordId);
      } catch {
        ready = null;
      }
      if (!ready) {
        await this.append(owner, "setup.uncertain", { reason: "exact record readiness is uncertain" });
        fail("FIXTURE_UNCERTAIN", "Fixture setup is uncertain; reconcile by exact ID");
      }
      await this.append(owner, "setup.ready", { recordId });
      return { state: "ready", recordId, cleanupOwnerRunId: runId };
    });
  }

  async reconcileSetup(runId) {
    return this.store.withExclusiveFixtures(async () => {
      const owner = await this.owner(runId);
      if (owner.status !== "uncertain") fail("FIXTURE_INCOMPATIBLE", "Fixture setup is not uncertain");
      let recordId = owner.recordId;
      if (!recordId) {
        const record = await owner.adapter.readByKey({
          operationId: owner.recipe.adapter.readByKeyOperation,
          idempotencyKey: owner.scope.idempotencyKey,
          target: owner.run.manifest.target,
          identity: fixtureIdentityBinding(owner.run.manifest),
        });
        if (!record) return { state: "uncertain", recordId: null };
        if (
          record.idempotencyKey !== owner.scope.idempotencyKey ||
          record.targetHash !== owner.scope.targetHash ||
          record.identityHash !== owner.scope.identityHash
        )
          fail("FIXTURE_READBACK_INVALID", "Key readback differs from the pinned fixture scope");
        recordId = exactId(owner.recipe, record.id);
        await this.append(owner, "setup.returned", { recordId });
      }
      const record = await this.readExact(owner, recordId, { requireReady: false });
      if (!record || record.ready === false) return { state: "uncertain", recordId };
      await this.append(owner, "setup.ready", { recordId });
      return { state: "ready", recordId, cleanupOwnerRunId: runId };
    });
  }

  async readReady(runId) {
    const child = await this.store.readRun(runId);
    const parentRunId = child.manifest.parentRunId;
    const owner = await this.owner(parentRunId ?? runId);
    if (owner.status !== "ready" || !owner.recordId || !owner.readyReceipt)
      fail("FIXTURE_NOT_READY", "Fixture is not ready for use");
    if (parentRunId) {
      if (owner.activeChildRunId !== runId) fail("FIXTURE_LEASE_REQUIRED", "Child has no exclusive fixture lease");
      assertFixtureHandoff(owner.run.manifest, child.manifest, {
        state: "ready",
        runId: parentRunId,
        cleanupOwnerRunId: parentRunId,
      });
      const opened = owner.transitions.findLast((entry) => entry.type === "lease.opened" && entry.childRunId === runId);
      if (!opened || opened.sourceReceiptHash !== sha256(owner.readyReceipt) || opened.recordId !== owner.recordId)
        fail("FIXTURE_JOURNAL_CORRUPT", "Child handoff receipt differs from ready source");
    } else if (owner.activeChildRunId) {
      fail("FIXTURE_LEASE_REQUIRED", "Parent fixture is leased to a child");
    }
    if (!(await this.readExact(owner, owner.recordId))) fail("FIXTURE_NOT_READY", "Fixture readback is absent");
    const manifest = child.manifest;
    const instance = {
      schema: "agent-workflow-fixture-instance/v1",
      kind: "application-record",
      instanceId: `fixture_${sha256({ runId, recordId: owner.recordId, recipeHash: owner.scope.recipeHash }).slice(7, 39)}`,
      runId,
      creatorRunId: owner.run.manifest.runId,
      cleanupOwnerRunId: owner.run.manifest.runId,
      recipeId: owner.recipe.id,
      recipeRevision: owner.recipe.revision,
      recipeHash: owner.scope.recipeHash,
      childRevision: manifest.fixtureContract.childRevision,
      compatibilityVersion: manifest.fixtureContract.compatibilityVersion,
      targetHash: owner.scope.targetHash,
      identityHash: owner.scope.identityHash,
      recordId: owner.recordId,
      idempotencyKey: owner.scope.idempotencyKey,
      adapterRevision: owner.recipe.adapter.revision,
      state: "ready",
      verifiedAt: this.now().toISOString(),
      lineage: parentRunId
        ? {
            parentRunId,
            sourceInstanceId: `fixture_${sha256({ runId: parentRunId, recordId: owner.recordId, recipeHash: owner.scope.recipeHash }).slice(7, 39)}`,
          }
        : null,
      cleanup: { kind: "application-record", ownerRunId: owner.run.manifest.runId, required: true },
    };
    this.store.registry?.validate("fixtureInstance", instance);
    return instance;
  }

  async handoff(parentRunId, childRunId) {
    return this.store.withExclusiveFixtures(async () => {
      const child = await this.store.readRun(childRunId);
      if (child.manifest.parentRunId !== parentRunId)
        fail("FIXTURE_INCOMPATIBLE", "Child manifest does not pin this parent");
      const owner = await this.owner(parentRunId);
      if (owner.status !== "ready" || owner.activeChildRunId)
        fail("FIXTURE_LEASE_REQUIRED", "Parent fixture is not available for exclusive handoff");
      assertNoActionLease(owner.run);
      assertFixtureHandoff(owner.run.manifest, child.manifest, {
        state: "ready",
        runId: parentRunId,
        cleanupOwnerRunId: parentRunId,
      });
      if (!(await this.readExact(owner, owner.recordId))) fail("FIXTURE_NOT_READY", "Source readback is absent");
      const handoff = await this.append(owner, "lease.opened", {
        recordId: owner.recordId,
        childRunId,
        sourceReceiptHash: sha256(owner.readyReceipt),
      });
      return {
        parentRunId,
        childRunId,
        recordId: owner.recordId,
        cleanupOwnerRunId: parentRunId,
        sourceReceiptHash: handoff.sourceReceiptHash,
        handle: `${parentRunId}:${handoff.sequence}`,
      };
    });
  }

  async closeChildLease(parentRunId, childRunId) {
    return this.store.withExclusiveFixtures(async () => {
      const owner = await this.owner(parentRunId);
      if (owner.activeChildRunId !== childRunId || !owner.recordId)
        fail("FIXTURE_LEASE_REQUIRED", "Exact child fixture lease is not active");
      const child = await this.store.readRun(childRunId);
      if (child.manifest.parentRunId !== parentRunId)
        fail("FIXTURE_INCOMPATIBLE", "Child manifest does not pin this parent");
      assertNoActionLease(child);
      await this.append(owner, "lease.closed", { recordId: owner.recordId, childRunId });
      return { state: "ready", cleanupOwnerRunId: parentRunId };
    });
  }

  async cleanup(runId) {
    return this.store.withExclusiveFixtures(async () => {
      const owner = await this.owner(runId);
      if (!["ready", "uncertain"].includes(owner.status) || !owner.recordId || owner.activeChildRunId)
        fail("FIXTURE_CLEANUP_UNAVAILABLE", "Exact owner fixture is unavailable for cleanup");
      assertNoActionLease(owner.run);
      const record = await this.readExact(owner, owner.recordId, { requireReady: false });
      if (!record || (owner.status === "uncertain" && record.ready !== false))
        fail("FIXTURE_CLEANUP_UNAVAILABLE", "Owned fixture record is absent before cleanup");
      await this.append(owner, "cleanup.requested", { recordId: owner.recordId });
      let remaining;
      try {
        await owner.adapter.deleteById({
          operationId: owner.recipe.adapter.deleteByIdOperation,
          recordId: owner.recordId,
          target: owner.run.manifest.target,
          identity: fixtureIdentityBinding(owner.run.manifest),
        });
        remaining = await this.readExact(owner, owner.recordId, { requireReady: false });
      } catch {
        await this.append(owner, "cleanup.pending", {
          recordId: owner.recordId,
          reason: "cleanup acknowledgement or readback uncertain",
        });
        fail("FIXTURE_CLEANUP_UNCERTAIN", "Fixture cleanup is pending; reconcile by exact ID");
      }
      if (remaining !== null) {
        await this.append(owner, "cleanup.pending", {
          recordId: owner.recordId,
          reason: "exact record remains after cleanup",
        });
        fail("FIXTURE_CLEANUP_UNCERTAIN", "Fixture cleanup is pending; reconcile by exact ID");
      }
      await this.append(owner, "cleanup.cleaned", { recordId: owner.recordId });
      return { state: "cleaned", recordId: owner.recordId, cleanupOwnerRunId: runId };
    });
  }

  async reconcileCleanup(runId) {
    return this.store.withExclusiveFixtures(async () => {
      const owner = await this.owner(runId);
      if (owner.status !== "cleanup-pending" || !owner.recordId || owner.activeChildRunId)
        fail("FIXTURE_CLEANUP_UNAVAILABLE", "Fixture cleanup is not pending or has an active child");
      assertNoActionLease(owner.run);
      const remaining = await this.readExact(owner, owner.recordId, { requireReady: false });
      if (remaining !== null) return { state: "cleanup-pending", recordId: owner.recordId };
      await this.append(owner, "cleanup.cleaned", { recordId: owner.recordId });
      return { state: "cleaned", recordId: owner.recordId, cleanupOwnerRunId: runId };
    });
  }

  /** Explicitly resume a pending exact-ID deletion after owned readback. */
  async resumeCleanup(runId) {
    return this.store.withExclusiveFixtures(async () => {
      const owner = await this.owner(runId);
      if (owner.status !== "cleanup-pending" || !owner.recordId || owner.activeChildRunId)
        fail("FIXTURE_CLEANUP_UNAVAILABLE", "Fixture cleanup is not pending or has an active child");
      assertNoActionLease(owner.run);
      const existing = await this.readExact(owner, owner.recordId, { requireReady: false });
      if (existing === null) {
        await this.append(owner, "cleanup.cleaned", { recordId: owner.recordId });
        return { state: "cleaned", recordId: owner.recordId, cleanupOwnerRunId: runId };
      }
      let remaining;
      try {
        await owner.adapter.deleteById({
          operationId: owner.recipe.adapter.deleteByIdOperation,
          recordId: owner.recordId,
          target: owner.run.manifest.target,
          identity: fixtureIdentityBinding(owner.run.manifest),
        });
        remaining = await this.readExact(owner, owner.recordId, { requireReady: false });
      } catch {
        await this.append(owner, "cleanup.pending", {
          recordId: owner.recordId,
          reason: "resumed exact-ID cleanup acknowledgement or readback uncertain",
        });
        fail("FIXTURE_CLEANUP_UNCERTAIN", "Resumed fixture cleanup is pending; reconcile by exact ID");
      }
      if (remaining !== null) {
        await this.append(owner, "cleanup.pending", {
          recordId: owner.recordId,
          reason: "exact record remains after resumed cleanup",
        });
        fail("FIXTURE_CLEANUP_UNCERTAIN", "Resumed fixture cleanup is pending; reconcile by exact ID");
      }
      await this.append(owner, "cleanup.cleaned", { recordId: owner.recordId });
      return { state: "cleaned", recordId: owner.recordId, cleanupOwnerRunId: runId };
    });
  }
}
