import { constants } from "node:fs";
import { lstat, open, readdir } from "node:fs/promises";
import { isAbsolute, join, relative, resolve, sep } from "node:path";

import { WorkflowError } from "./errors.js";
import { createSchemaRegistry } from "./schema-registry.js";

const ACCEPTANCE_ID = /^acceptance_[A-Za-z0-9_-]+$/;

function fail(code, message, details) {
  throw new WorkflowError(code, message, { exitCode: 3, details });
}

function storePath(context) {
  const projectRoot = resolve(context?.projectRoot ?? "");
  const logical = context?.paths?.localStore;
  if (!logical || isAbsolute(logical) || logical.split(/[\\/]+/u).some((part) => !part || part === "..")) {
    fail("PROJECT_CONTEXT_INVALID", "Acceptance reading requires a repository-relative ProjectContext local store");
  }
  const localStore = resolve(projectRoot, ...logical.split(/[\\/]+/u));
  const suffix = relative(projectRoot, localStore);
  if (suffix === ".." || suffix.startsWith(`..${sep}`) || isAbsolute(suffix)) {
    fail("PATH_TRAVERSAL", "Acceptance storage escapes the project");
  }
  return { projectRoot, root: join(localStore, "acceptances") };
}

function acceptancePath(root, acceptanceId) {
  if (!ACCEPTANCE_ID.test(acceptanceId ?? "")) fail("INVALID_ACCEPTANCE_ID", "Invalid acceptance ID");
  return join(root, `${acceptanceId}.json`);
}

async function assertDirectory(path) {
  const entry = await lstat(path);
  if (!entry.isDirectory() || entry.isSymbolicLink()) {
    fail("ACCEPTANCE_STORE_UNSAFE", "Acceptance paths must be real directories");
  }
}

async function assertSafeAncestry(root, target) {
  const suffix = relative(root, target);
  if (suffix === ".." || suffix.startsWith(`..${sep}`) || isAbsolute(suffix)) {
    fail("PATH_TRAVERSAL", "Acceptance path escapes its project");
  }
  let cursor = root;
  await assertDirectory(cursor);
  for (const part of suffix.split(sep).filter(Boolean)) {
    cursor = join(cursor, part);
    try {
      const entry = await lstat(cursor);
      if (entry.isSymbolicLink()) fail("ACCEPTANCE_STORE_UNSAFE", "Acceptance ancestry cannot contain symlinks");
      if (cursor !== target && !entry.isDirectory()) {
        fail("ACCEPTANCE_STORE_UNSAFE", "Acceptance ancestry must contain only directories");
      }
    } catch (error) {
      if (error.code === "ENOENT") break;
      throw error;
    }
  }
}

async function readRegular(path) {
  const entry = await lstat(path);
  if (!entry.isFile() || entry.isSymbolicLink()) fail("ACCEPTANCE_RECORD_CORRUPT", "Acceptance is not a regular file");
  const handle = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    const opened = await handle.stat();
    if (opened.dev !== entry.dev || opened.ino !== entry.ino || opened.size !== entry.size) {
      fail("ACCEPTANCE_RECORD_CORRUPT", "Acceptance changed while being read");
    }
    return await handle.readFile("utf8");
  } finally {
    await handle.close();
  }
}

function evidenceMatches(record, evidence) {
  return (
    evidence?.integrity === "verified" &&
    evidence.evaluationGroupId === record.evidence.evaluationGroupId &&
    evidence.workflowId === record.workflowId &&
    evidence.revision === record.revision &&
    evidence.contentHash === record.contentHash
  );
}

/** Read-only acceptance access. Record creation intentionally has no public API until Tranche 4. */
export class AcceptanceStore {
  constructor(projectContext, { registry, verifyEvidence } = {}) {
    const path = storePath(projectContext);
    this.projectRoot = path.projectRoot;
    this.root = path.root;
    this.registry = registry;
    this.verifyEvidence = verifyEvidence;
  }

  async readAcceptance(acceptanceId) {
    this.registry ??= await createSchemaRegistry();
    const path = acceptancePath(this.root, acceptanceId);
    await assertSafeAncestry(this.projectRoot, path);
    let record;
    try {
      record = JSON.parse(await readRegular(path));
    } catch (error) {
      if (error instanceof SyntaxError) fail("ACCEPTANCE_RECORD_CORRUPT", "Acceptance is invalid JSON");
      throw error;
    }
    this.registry.validate("acceptance", record);
    if (record.acceptanceId !== acceptanceId) fail("ACCEPTANCE_ID_MISMATCH", "Acceptance path and identity differ");
    return structuredClone(record);
  }

  async listAcceptanceIds() {
    try {
      await assertSafeAncestry(this.projectRoot, this.root);
      await assertDirectory(this.root);
    } catch (error) {
      if (error.code === "ENOENT") return [];
      throw error;
    }
    return (await readdir(this.root))
      .filter((name) => /^acceptance_[A-Za-z0-9_-]+\.json$/u.test(name))
      .sort()
      .map((name) => name.slice(0, -5));
  }

  async reverifyAcceptance(acceptanceId, options = {}) {
    let record;
    try {
      record = await this.readAcceptance(acceptanceId);
    } catch (error) {
      return { acceptanceId, integrity: "degraded", support: "unavailable", issues: [error.code ?? "unreadable"] };
    }
    if (record.supersedesAcceptanceId) {
      let superseded;
      try {
        superseded = await this.readAcceptance(record.supersedesAcceptanceId);
      } catch (error) {
        return {
          acceptanceId,
          record,
          integrity: "degraded",
          support: "unavailable",
          issues: [error.code ?? "acceptance-supersession-unavailable"],
        };
      }
      if (
        superseded.workflowId !== record.workflowId ||
        record.supersedesAcceptanceId === acceptanceId ||
        new Date(superseded.acceptedAt).valueOf() >= new Date(record.acceptedAt).valueOf()
      ) {
        return {
          acceptanceId,
          record,
          integrity: "degraded",
          support: "unavailable",
          issues: ["acceptance-supersession-invalid"],
        };
      }
    }
    const verifier = options.verifyEvidence ?? this.verifyEvidence;
    if (typeof verifier !== "function") {
      return {
        acceptanceId,
        record,
        integrity: "degraded",
        support: "unavailable",
        issues: ["acceptance-evidence-not-reverified"],
      };
    }
    let evidence;
    try {
      evidence = await verifier(structuredClone(record.evidence), structuredClone(record));
    } catch {
      evidence = null;
    }
    const verified = evidenceMatches(record, evidence);
    return {
      acceptanceId,
      record,
      integrity: verified ? "verified" : "degraded",
      support: verified ? "supported" : "unavailable",
      issues: verified ? [] : ["acceptance-evidence-not-reverified"],
    };
  }

  async listAcceptanceRecords(options = {}) {
    const records = await Promise.all(
      (await this.listAcceptanceIds()).map((acceptanceId) => this.reverifyAcceptance(acceptanceId, options)),
    );
    return records.sort(
      (left, right) =>
        String(left.record?.acceptedAt ?? "").localeCompare(String(right.record?.acceptedAt ?? "")) ||
        left.acceptanceId.localeCompare(right.acceptanceId),
    );
  }
}
