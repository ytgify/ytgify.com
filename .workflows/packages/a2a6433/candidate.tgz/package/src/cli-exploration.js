import { RunControlStore } from "./run-control-store.js";
import { resolveCurrentApplicationTarget, selectedStoreRoot } from "./cli-journey-source.js";
import { launchExploration } from "./exploration-launch.js";
import { projectExploration } from "./exploration-proposals.js";
import { WorkflowError } from "./errors.js";
import { pinExplorationFiles } from "./exploration-fixtures.js";

export async function executeExplorationCommand(args, flags, registry, resolvers) {
  const [operation, runId] = args;
  const allowed =
    operation === "start"
      ? ["target", "route", "intent", "platform", "fixture", "root", "config", "store", "json"]
      : ["root", "config", "store", "json"];
  const unsupported = [...flags.keys()].find((name) => !allowed.includes(name));
  if (unsupported)
    throw new WorkflowError("INVALID_USAGE", `explore does not accept --${unsupported}`, { exitCode: 2 });
  if (
    operation === "start" &&
    args.length === 1 &&
    flags.get("target") &&
    flags.get("route") &&
    flags.get("intent") &&
    flags.get("platform")
  ) {
    const { applicationTarget, projectContext } = await resolveCurrentApplicationTarget({
      target: flags.get("target"),
      registry,
      resolveProjectContext: resolvers.projectContext,
    });
    const store = await new RunControlStore(selectedStoreRoot(projectContext, flags.get("store")), { registry }).init();
    const fixtures = await pinExplorationFiles(projectContext.projectRoot, flags.get("fixture"));
    return launchExploration({
      applicationTarget,
      startRoute: flags.get("route"),
      intents: flags.get("intent").split(";"),
      platform: flags.get("platform"),
      fixtures,
      projectRoot: projectContext.projectRoot,
      store,
    });
  }
  if (operation === "review" && args.length === 2 && /^run_[A-Za-z0-9_-]+$/u.test(runId)) {
    const projectContext = await resolvers.projectContext();
    const store = await new RunControlStore(selectedStoreRoot(projectContext, flags.get("store")), { registry }).init();
    return projectExploration(store, runId);
  }
  throw new WorkflowError(
    "INVALID_USAGE",
    "explore requires start --target WORDS --route /PATH --intent 'INTENT[;INTENT]' --platform PLATFORM or review RUN_ID",
    { exitCode: 2 },
  );
}
