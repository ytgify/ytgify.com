import { listMapProposals, executeMapProposalMutation, inspectMapEvidence } from "./app-map-proposals.js";
import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { RunControlStore } from "./run-control-store.js";
import { importMapRegistry, readMapRegistry } from "./app-map-registry.js";

export async function executeAppMapCommand(args, flags, registry, context) {
  if (
    args.length !== 1 ||
    !["registry", "import", "inspect", "proposals", "propose", "apply", "undo"].includes(args[0])
  )
    throw new Error(
      "Use app-map registry | inspect --run ID | proposals | propose/apply/undo --file PATH | import --file PATH --expected-revision N",
    );
  const root = flags.has("store")
    ? resolve(flags.get("store"))
    : resolve(context.projectRoot, context.paths.localStore);
  const store = await new RunControlStore(root, { registry }).init();
  if (args[0] === "inspect") return inspectMapEvidence(store, registry, flags.get("run"));
  if (args[0] === "proposals") return listMapProposals(store, registry);
  if (["propose", "apply", "undo"].includes(args[0])) {
    if (!flags.has("file")) throw new Error("Proposal operations require --file JSON_PATH");
    return executeMapProposalMutation(
      store,
      registry,
      args[0],
      JSON.parse(await readFile(resolve(flags.get("file")), "utf8")),
    );
  }
  if (args[0] === "registry") return readMapRegistry(store, registry);
  if (!flags.has("file") || !/^\d+$/.test(flags.get("expected-revision") ?? ""))
    throw new Error("Import requires --file and --expected-revision");
  const document = JSON.parse(await readFile(resolve(flags.get("file")), "utf8"));
  return importMapRegistry(store, registry, document, Number(flags.get("expected-revision")));
}
