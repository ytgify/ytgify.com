import { randomUUID } from "node:crypto";
import { constants } from "node:fs";
import { mkdir, open, rename, unlink } from "node:fs/promises";
import { dirname, join } from "node:path";

import { WorkflowError } from "./errors.js";
import { sha256Bytes } from "./evidence.js";
import { assertSafeProjectPath } from "./project-path-safety.js";

const INPUT_NAME = /^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$/u;
const FILE_NAME = /^dogfood-[A-Za-z0-9][A-Za-z0-9._-]{0,99}\.csv$/u;
const MAX_SYNTHETIC_CSV_BYTES = 1024 * 1024;

function reject(message, code = "UPLOAD_ARTIFACT_INVALID") {
  throw new WorkflowError(code, message, { exitCode: 4 });
}

function uploadDirectory(run) {
  return join(run.directory, "adapter", "upload-artifacts");
}

function uploadPaths(run, leaseId, inputName) {
  if (!/^lease_[A-Za-z0-9_-]+$/u.test(leaseId ?? "")) reject("Invalid staged upload lease", "INVALID_REQUEST");
  if (!INPUT_NAME.test(inputName ?? "")) reject("Invalid staged upload input name", "INVALID_REQUEST");
  const directory = join(uploadDirectory(run), leaseId);
  return {
    directory,
    metadata: join(directory, `${inputName}.json`),
    bytes: join(directory, `${inputName}.bytes`),
  };
}

async function durableExclusive(path, bytes) {
  const handle = await open(
    path,
    constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW,
    0o600,
  );
  try {
    await handle.writeFile(bytes);
    await handle.sync();
  } finally {
    await handle.close();
  }
  const parent = await open(dirname(path), constants.O_RDONLY);
  try {
    await parent.sync();
  } finally {
    await parent.close();
  }
}

async function durableReplace(path, bytes) {
  const temporary = `${path}.${randomUUID().replaceAll("-", "")}.tmp`;
  try {
    await durableExclusive(temporary, bytes);
    await rename(temporary, path);
    const parent = await open(dirname(path), constants.O_RDONLY);
    try {
      await parent.sync();
    } finally {
      await parent.close();
    }
  } finally {
    await unlink(temporary).catch((error) => {
      if (error.code !== "ENOENT") throw error;
    });
  }
}

async function readNoFollow(path, encoding) {
  const handle = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    return await handle.readFile(encoding);
  } finally {
    await handle.close();
  }
}

function decodeSyntheticCsv(request) {
  if (
    request.mimeType !== "text/csv" ||
    !FILE_NAME.test(request.filename ?? "") ||
    !Number.isSafeInteger(request.sizeBytes) ||
    request.sizeBytes < 1 ||
    request.sizeBytes > MAX_SYNTHETIC_CSV_BYTES ||
    !/^sha256:[a-f0-9]{64}$/u.test(request.sha256 ?? "") ||
    typeof request.contentBase64 !== "string" ||
    request.contentBase64.length > Math.ceil((MAX_SYNTHETIC_CSV_BYTES * 4) / 3) + 4
  ) {
    reject("Only a bounded runner-declared synthetic CSV artifact can be staged");
  }
  const bytes = Buffer.from(request.contentBase64, "base64");
  if (bytes.toString("base64") !== request.contentBase64 || bytes.length !== request.sizeBytes)
    reject("Staged upload size or base64 encoding does not match its declaration");
  if (sha256Bytes(bytes) !== request.sha256) reject("Staged upload SHA-256 does not match its declaration");
  let text;
  try {
    text = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  } catch {
    reject("Synthetic CSV must be valid UTF-8");
  }
  const containsDisallowedControl = [...text].some((character) => {
    const code = character.codePointAt(0);
    return code <= 8 || code === 11 || code === 12 || (code >= 14 && code <= 31) || code === 127;
  });
  if (!text.includes(",") || containsDisallowedControl)
    reject("Synthetic CSV content is outside the bounded text policy");
  const rows = csvRows(text);
  if (
    rows.length < 2 ||
    rows[0].length < 2 ||
    rows.some((row) => row.length !== rows[0].length) ||
    rows[0].some((cell) => !/^[A-Za-z][A-Za-z0-9 _-]{0,63}$/u.test(cell.trim()))
  )
    reject("Synthetic CSV must have one bounded header and consistent data rows");
  for (const cell of rows.flat()) {
    const value = cell.trim();
    const negativeNumber = /^-(?:\d+(?:\.\d+)?|\.\d+)$/u.test(value);
    if (/^[=+@]/u.test(value) || (value.startsWith("-") && !negativeNumber))
      reject("Synthetic CSV cannot contain spreadsheet formula input");
  }
  for (const cell of rows.slice(1).flat()) {
    const value = cell.trim();
    if (
      value &&
      !/^dogfood-[A-Za-z0-9][A-Za-z0-9 ._@+-]{0,119}$/u.test(value) &&
      !/^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(value) &&
      !/^(?:true|false)$/u.test(value)
    )
      reject("Synthetic CSV values must be explicitly dogfood-prefixed or scalar fixtures");
  }
  return bytes;
}

function csvRows(text) {
  const rows = [[]];
  let cell = "";
  let quoted = false;
  let closedQuote = false;
  for (let index = 0; index < text.length; index++) {
    const character = text[index];
    if (character === '"') {
      if (quoted && text[index + 1] === '"') {
        cell += '"';
        index++;
      } else if (quoted) {
        quoted = false;
        closedQuote = true;
      } else if (cell.length === 0) {
        quoted = true;
      } else {
        reject("Synthetic CSV contains invalid quoting");
      }
    } else if (!quoted && (character === "," || character === "\n" || character === "\r")) {
      rows.at(-1).push(cell);
      cell = "";
      closedQuote = false;
      if (character !== ",") {
        if (character === "\r" && text[index + 1] === "\n") index++;
        rows.push([]);
      }
    } else {
      if (closedQuote && !/^[\t ]$/u.test(character)) reject("Synthetic CSV contains invalid quoting");
      cell += character;
    }
  }
  if (quoted) reject("Synthetic CSV contains invalid quoting");
  rows.at(-1).push(cell);
  if (rows.at(-1).length === 1 && rows.at(-1)[0] === "") rows.pop();
  return rows;
}

export function validateUploadStageRequest(request) {
  const keys = [
    "schema",
    "runId",
    "hostId",
    "leaseId",
    "stepId",
    "expectedRevision",
    "inputName",
    "filename",
    "sizeBytes",
    "mimeType",
    "sha256",
    "contentBase64",
  ];
  if (
    !request ||
    Object.keys(request).length !== keys.length ||
    keys.some((key) => !Object.hasOwn(request, key)) ||
    request.schema !== "browser.upload-stage/v1" ||
    !/^run_[A-Za-z0-9_-]+$/u.test(request.runId ?? "") ||
    !/^host_[A-Za-z0-9_-]+$/u.test(request.hostId ?? "") ||
    !/^lease_[A-Za-z0-9_-]+$/u.test(request.leaseId ?? "") ||
    !INPUT_NAME.test(request.stepId ?? "") ||
    !INPUT_NAME.test(request.inputName ?? "") ||
    !Number.isSafeInteger(request.expectedRevision) ||
    request.expectedRevision < 0
  ) {
    reject("Invalid staged upload request", "INVALID_REQUEST");
  }
  return request;
}

function activeUploadBinding(run, request, now) {
  const lease = run.state.activeLease;
  if (run.state.revision !== request.expectedRevision) reject("Run revision changed", "REVISION_CONFLICT");
  if (
    run.state.status !== "active" ||
    run.state.ownerHostId !== request.hostId ||
    lease?.hostId !== request.hostId ||
    lease?.leaseId !== request.leaseId ||
    !run.manifest.authentication ||
    !/^usersession_[A-Za-z0-9_-]+$/u.test(lease.target?.adapterSessionId ?? "")
  )
    reject("Upload artifact does not match an active authenticated lease");
  const leasedEvent = [...run.events]
    .reverse()
    .find((event) => event.type === "action.leased" && event.payload.lease.leaseId === lease.leaseId);
  if (
    !leasedEvent ||
    leasedEvent.payload.stepId !== request.stepId ||
    leasedEvent.transaction.requestId !== run.state.activeLeaseRequestId
  )
    reject("Upload artifact step does not match the lease");
  const action = lease.proposal.actions.find(
    (candidate) =>
      candidate.kind === "upload-file" &&
      candidate.inputRef?.kind === "synthetic-file" &&
      candidate.inputRef.name === request.inputName,
  );
  if (
    !action ||
    !/^label:[^\r\n]{1,200}$/u.test(action.target ?? "") ||
    !lease.proposal.requestedCapabilities.includes("file-upload") ||
    action.inputRef.filename !== request.filename ||
    action.inputRef.sizeBytes !== request.sizeBytes ||
    action.inputRef.mimeType !== request.mimeType ||
    action.inputRef.sha256 !== request.sha256
  )
    reject("Lease does not approve this synthetic file upload");
  const expiresAt = new Date(Math.min(Date.parse(lease.expiresAt), Date.parse(lease.hardExpiresAt))).toISOString();
  if (now().valueOf() >= Date.parse(expiresAt)) reject("Upload artifact lease expired", "LEASE_EXPIRED");
  return { action, expiresAt, leasedRequestId: leasedEvent.transaction.requestId };
}

/** Stage bytes without accepting or publishing a host filesystem path. */
export async function stageAuthenticatedUpload({ store, request, now = () => new Date() }) {
  validateUploadStageRequest(request);
  const bytes = decodeSyntheticCsv(request);
  return store.withExclusiveRun(request.runId, async (run) => {
    const binding = activeUploadBinding(run, request, now);
    const paths = uploadPaths(run, request.leaseId, request.inputName);
    await assertSafeProjectPath(run.directory, paths.directory, "Authenticated upload directory", {
      finalType: "directory",
      allowMissing: true,
    });
    await mkdir(paths.directory, { recursive: true });
    await assertSafeProjectPath(run.directory, paths.bytes, "Authenticated upload bytes", {
      finalType: "file",
      allowMissing: true,
    });
    await assertSafeProjectPath(run.directory, paths.metadata, "Authenticated upload receipt", {
      finalType: "file",
      allowMissing: true,
    });
    const artifactId = `upload_${randomUUID().replaceAll("-", "")}`;
    const record = {
      schema: "browser.staged-upload/v1",
      artifactId,
      status: "approved",
      runId: request.runId,
      hostId: request.hostId,
      leaseId: request.leaseId,
      leaseRequestId: binding.leasedRequestId,
      stepId: request.stepId,
      expectedRevision: request.expectedRevision,
      inputName: request.inputName,
      target: binding.action.target,
      filename: request.filename,
      sizeBytes: request.sizeBytes,
      mimeType: request.mimeType,
      sha256: request.sha256,
      expiresAt: binding.expiresAt,
      stagedAt: now().toISOString(),
    };
    let wroteBytes = false;
    try {
      await durableExclusive(paths.bytes, bytes);
      wroteBytes = true;
      await durableExclusive(paths.metadata, Buffer.from(JSON.stringify(record)));
    } catch (error) {
      if (wroteBytes) await unlink(paths.bytes).catch(() => {});
      if (error.code === "EEXIST") reject("This lease input already has a staged upload", "RECONCILIATION_REQUIRED");
      throw error;
    }
    return {
      status: "staged",
      artifact: {
        artifactId,
        filename: record.filename,
        sizeBytes: record.sizeBytes,
        mimeType: record.mimeType,
        sha256: record.sha256,
      },
      binding: {
        runId: record.runId,
        hostId: record.hostId,
        leaseId: record.leaseId,
        leaseRequestId: record.leaseRequestId,
        stepId: record.stepId,
        expectedRevision: record.expectedRevision,
        inputName: record.inputName,
        expiresAt: record.expiresAt,
      },
    };
  });
}

async function readApprovedBytes(run, record, paths) {
  await assertSafeProjectPath(run.directory, paths.bytes, "Authenticated upload bytes", {
    finalType: "file",
    allowMissing: false,
  });
  const bytes = await readNoFollow(paths.bytes);
  if (bytes.length !== record.sizeBytes || sha256Bytes(bytes) !== record.sha256)
    reject("Staged upload bytes no longer match their approved receipt");
  return bytes;
}

export async function loadAuthenticatedUploads(run, { hostId, leaseId, expectedRevision, now = () => new Date() }) {
  const actions = run.state.activeLease?.proposal.actions ?? [];
  const leasedEvent = [...run.events]
    .reverse()
    .find((event) => event.type === "action.leased" && event.payload.lease.leaseId === leaseId);
  if (!leasedEvent || leasedEvent.transaction.requestId !== run.state.activeLeaseRequestId)
    reject("The active upload lease has no matching durable lease event");
  const uploads = new Map();
  for (const action of actions.filter((item) => item.kind === "upload-file")) {
    const inputName = action.inputRef?.name;
    const paths = uploadPaths(run, leaseId, inputName);
    let record;
    try {
      await assertSafeProjectPath(run.directory, paths.metadata, "Authenticated upload receipt", {
        finalType: "file",
        allowMissing: false,
      });
      record = JSON.parse(await readNoFollow(paths.metadata, "utf8"));
    } catch (error) {
      if (error.code === "ENOENT") reject("The lease upload has no runner-approved staged artifact");
      throw error;
    }
    if (record.status === "consumed")
      reject("This lease upload was already consumed and cannot be replayed", "RECONCILIATION_REQUIRED");
    const interveningEvents = run.events.filter(
      (event) => event.revision > record.expectedRevision && event.revision <= expectedRevision,
    );
    const bindingPreserved = interveningEvents.every(
      (event) =>
        (event.type === "lease.heartbeat" && event.payload.leaseId === leaseId) ||
        (event.type === "evidence.slot-issued" &&
          event.payload.slot.leaseId === leaseId &&
          event.payload.slot.hostId === hostId &&
          event.payload.slot.stepId === leasedEvent.payload.stepId &&
          event.payload.slot.leaseRequestId === run.state.activeLeaseRequestId),
    );
    const heartbeatAtStaging = [...run.events]
      .reverse()
      .find(
        (event) =>
          event.revision <= record.expectedRevision &&
          event.type === "lease.heartbeat" &&
          event.payload.leaseId === leaseId,
      );
    const expiryAtStaging = new Date(
      Math.min(
        Date.parse(heartbeatAtStaging?.payload.expiresAt ?? leasedEvent.payload.lease.expiresAt),
        Date.parse(leasedEvent.payload.lease.hardExpiresAt),
      ),
    ).toISOString();
    const liveLease = run.state.activeLease;
    if (
      record.schema !== "browser.staged-upload/v1" ||
      record.status !== "approved" ||
      record.runId !== run.manifest.runId ||
      record.hostId !== hostId ||
      record.leaseId !== leaseId ||
      record.leaseRequestId !== run.state.activeLeaseRequestId ||
      record.leaseRequestId !== leasedEvent.transaction.requestId ||
      record.stepId !== leasedEvent.payload.stepId ||
      record.expectedRevision > expectedRevision ||
      !bindingPreserved ||
      record.inputName !== inputName ||
      record.target !== action.target ||
      record.expiresAt !== expiryAtStaging ||
      liveLease?.leaseId !== leaseId ||
      now().valueOf() >= Math.min(Date.parse(liveLease.expiresAt), Date.parse(liveLease.hardExpiresAt)) ||
      record.mimeType !== "text/csv" ||
      !FILE_NAME.test(record.filename ?? "") ||
      !/^sha256:[a-f0-9]{64}$/u.test(record.sha256 ?? "") ||
      action.inputRef?.filename !== record.filename ||
      action.inputRef?.sizeBytes !== record.sizeBytes ||
      action.inputRef?.mimeType !== record.mimeType ||
      action.inputRef?.sha256 !== record.sha256
    )
      reject("Staged upload receipt does not match the active lease");
    const bytes = await readApprovedBytes(run, record, paths);
    uploads.set(inputName, { record, bytes, paths });
  }
  return uploads;
}

export async function consumeAuthenticatedUploads(uploads, { outcome, now = () => new Date() }) {
  for (const { record, paths } of uploads.values()) {
    const consumed = { ...record, status: "consumed", outcome, consumedAt: now().toISOString() };
    await durableReplace(paths.metadata, Buffer.from(JSON.stringify(consumed)));
    await unlink(paths.bytes).catch((error) => {
      if (error.code !== "ENOENT") throw error;
    });
  }
}

/** Consume staged bytes for a terminal or uncertain lease without granting replay authority. */
export async function consumeAuthenticatedUploadsForLease(run, leaseId, { outcome, now = () => new Date() }) {
  const leasedEvent = [...run.events]
    .reverse()
    .find((event) => event.type === "action.leased" && event.payload.lease.leaseId === leaseId);
  if (!leasedEvent) return;
  const uploads = new Map();
  for (const action of leasedEvent.payload.lease.proposal.actions.filter((item) => item.kind === "upload-file")) {
    const inputName = action.inputRef?.name;
    const paths = uploadPaths(run, leaseId, inputName);
    await assertSafeProjectPath(run.directory, paths.metadata, "Authenticated upload receipt", {
      finalType: "file",
      allowMissing: true,
    });
    let record;
    try {
      record = JSON.parse(await readNoFollow(paths.metadata, "utf8"));
    } catch (error) {
      if (error.code !== "ENOENT" && !(error instanceof SyntaxError)) throw error;
    }
    const recordMatchesLease =
      record?.schema === "browser.staged-upload/v1" &&
      record.runId === run.manifest.runId &&
      record.leaseId === leaseId &&
      record.inputName === inputName;
    if (!recordMatchesLease) {
      await assertSafeProjectPath(run.directory, paths.bytes, "Authenticated upload bytes", {
        finalType: "file",
        allowMissing: true,
      });
      await unlink(paths.bytes).catch((error) => {
        if (error.code !== "ENOENT") throw error;
      });
      continue;
    }
    if (record.status === "consumed") {
      await unlink(paths.bytes).catch((error) => {
        if (error.code !== "ENOENT") throw error;
      });
      continue;
    }
    if (record.status !== "approved") reject("Staged upload receipt has an invalid state");
    await assertSafeProjectPath(run.directory, paths.bytes, "Authenticated upload bytes", {
      finalType: "file",
      allowMissing: false,
    });
    uploads.set(inputName, { record, paths });
  }
  await consumeAuthenticatedUploads(uploads, { outcome, now });
}
