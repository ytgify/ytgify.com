import { isAbsolute } from "node:path";

import { WorkflowError } from "./errors.js";
import { compileFixtureCandidate } from "./fixture-candidate-compiler.js";
import { FixtureApplicationService } from "./fixture-application.js";
import { fixtureIdentityBinding } from "./fixture-lifecycle.js";
import { sha256 } from "./stable-json.js";
import { launchTrainingRun } from "./training.js";

function reject(code, message) {
  throw new WorkflowError(code, message, { exitCode: 4 });
}

export function fixtureCandidateHash(candidate) {
  return sha256(candidate);
}

function requestFromCandidate(candidate, projectRoot) {
  if (
    candidate?.schema !== "agent-workflow-fixture-candidate/v1" ||
    candidate.status !== "pending-recipe-review" ||
    !Array.isArray(candidate.workflows) ||
    !Array.isArray(candidate.provenance?.sources) ||
    !candidate.provenance.sources.length ||
    !isAbsolute(projectRoot ?? "")
  ) {
    reject("FIXTURE_CANDIDATE_INVALID", "A compiled fixture candidate and absolute project root are required");
  }
  const recipe = candidate.recipe;
  return {
    sources: candidate.provenance.sources.map((source) => ({
      runId: source.runId,
      needId: source.needId,
      candidateHash: source.candidateHash,
      expectedRevision: source.decisionRevision,
      workflowId: source.workflowId,
    })),
    recipe: {
      id: recipe?.id,
      revision: recipe?.revision,
      purpose: recipe?.purpose,
      target: recipe?.target,
      identity: recipe?.identity,
      ...(recipe?.kind === "application-record" ? { adapter: recipe.adapter } : {}),
    },
    workflowDrafts: candidate.workflows,
    compatibilityVersion: "v1",
    projectRoot,
  };
}

/**
 * Launch one explicitly reviewed candidate workflow from current accepted source
 * evidence. Application adapters remain host supplied and exact-scope registered.
 */
export async function launchReviewedFixtureCandidate({
  candidate,
  review,
  workflowId,
  applicationTarget,
  platform,
  profile,
  projectRoot,
  sourceStore,
  runStore,
  registry,
  adapter,
  ...trainingOptions
}) {
  const candidateHash = fixtureCandidateHash(candidate);
  if (
    review?.schema !== "agent-workflow-fixture-review/v1" ||
    review.status !== "approved" ||
    review.candidateHash !== candidateHash ||
    typeof review.reviewer !== "string" ||
    !review.reviewer.trim() ||
    typeof review.reason !== "string" ||
    !review.reason.trim()
  ) {
    reject("FIXTURE_REVIEW_REQUIRED", "An exact approved candidate review with reviewer and reason is required");
  }
  if (!sourceStore || !runStore || !registry || typeof workflowId !== "string" || !platform || !applicationTarget) {
    reject(
      "FIXTURE_CANDIDATE_INVALID",
      "Source store, run store, registry, workflow ID, platform, and resolved target are required",
    );
  }
  const current = await compileFixtureCandidate(sourceStore, registry, requestFromCandidate(candidate, projectRoot));
  if (sha256(current) !== candidateHash) {
    reject("FIXTURE_CANDIDATE_STALE", "Candidate content differs from current accepted source or pinned recipe");
  }
  const workflow = current.workflows.find((item) => item.metadata.id === workflowId);
  if (!workflow) reject("FIXTURE_CANDIDATE_INVALID", "Selected workflow is absent from the reviewed candidate");
  if (current.recipe.kind === "application-record") {
    if (
      !adapter ||
      ["create", "readById", "readByKey", "deleteById"].some((key) => typeof adapter[key] !== "function")
    ) {
      reject("FIXTURE_ADAPTER_UNAVAILABLE", "Mutable fixtures require a complete host adapter before launch");
    }
  } else if (adapter) {
    reject("FIXTURE_ADAPTER_INVALID", "Repository-file fixtures do not use a mutable adapter");
  }
  let runId;
  try {
    const launched = await launchTrainingRun({
      ...trainingOptions,
      workflowDefinition: workflow,
      platform,
      profile,
      applicationTarget,
      fixtureRecipe: current.recipe,
      fixtureProjectRoot: projectRoot,
      store: runStore,
      registry,
    });
    runId = launched.launchCard.runId;
    if (current.recipe.kind === "repository-file") {
      const fixture = await runStore.readFixtureInstance(runId, { projectRoot });
      if (fixture?.state !== "ready") {
        reject("FIXTURE_NOT_READY", "Repository fixture binding is not independently readable as ready");
      }
      return { ...launched, candidateHash, fixture };
    }
    const run = await runStore.readRun(runId);
    const fixtureService = new FixtureApplicationService(runStore);
    fixtureService.registerAdapter(current.recipe.adapter, adapter, {
      disposable: true,
      targetHash: sha256(run.manifest.target),
      identityHash: sha256(fixtureIdentityBinding(run.manifest)),
    });
    const setup = await fixtureService.setup(runId);
    if (setup.state !== "ready") {
      reject("FIXTURE_NOT_READY", "Mutable fixture setup did not produce an independently readable ready instance");
    }
    return { ...launched, candidateHash, fixture: await fixtureService.readReady(runId), fixtureService };
  } catch (error) {
    const known = error instanceof WorkflowError;
    const failure = new WorkflowError(known ? error.code : "INTERNAL_ERROR", error?.message ?? String(error), {
      exitCode: known ? error.exitCode : 1,
      details: { ...error?.details, ...(runId ? { runId } : {}), candidateHash },
    });
    failure.cause = error;
    throw failure;
  }
}
