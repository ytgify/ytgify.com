import { randomUUID } from "node:crypto";
import { mkdir, open, readFile, rename, unlink, writeFile } from "node:fs/promises";
import { dirname, join, resolve, sep } from "node:path";

import { WorkflowError } from "./errors.js";
import { validateEvents } from "./validation.js";

const RUN_ID_PATTERN = /^run_[A-Za-z0-9_-]+$/;

function assertInside(root, path) {
  const resolvedRoot = resolve(root);
  const resolvedPath = resolve(path);
  if (resolvedPath !== resolvedRoot && !resolvedPath.startsWith(`${resolvedRoot}${sep}`)) {
    throw new WorkflowError("PATH_TRAVERSAL", "Resolved path escapes the run store", {
      exitCode: 3,
    });
  }
  return resolvedPath;
}

async function atomicWriteJson(path, value) {
  const temporary = `${path}.${randomUUID()}.tmp`;
  await writeFile(temporary, `${JSON.stringify(value, null, 2)}\n`, { flag: "wx" });
  await rename(temporary, path);
}

export class RunStore {
  constructor(root, { registry } = {}) {
    this.root = resolve(root);
    this.registry = registry;
  }

  async init() {
    await mkdir(this.root, { recursive: true });
    return this;
  }

  runDirectory(runId, createdAt) {
    if (!RUN_ID_PATTERN.test(runId)) {
      throw new WorkflowError("INVALID_RUN_ID", `Invalid run ID: ${runId}`, { exitCode: 3 });
    }
    const date = new Date(createdAt);
    if (Number.isNaN(date.valueOf())) {
      throw new WorkflowError("INVALID_DATE", `Invalid run creation date: ${createdAt}`, {
        exitCode: 3,
      });
    }
    return assertInside(this.root, join(this.root, date.toISOString().slice(0, 10), runId));
  }

  async createRun(manifest) {
    const directory = this.runDirectory(manifest.runId, manifest.createdAt);
    await mkdir(dirname(directory), { recursive: true });
    try {
      await mkdir(directory);
    } catch (error) {
      if (error.code === "EEXIST") {
        throw new WorkflowError("RUN_EXISTS", `Run already exists: ${manifest.runId}`, {
          exitCode: 4,
        });
      }
      throw error;
    }

    await mkdir(join(directory, "evidence"));
    await mkdir(join(directory, "adapter"));
    await atomicWriteJson(join(directory, "manifest.json"), manifest);
    await writeFile(join(directory, "events.jsonl"), "", { flag: "wx" });
    return directory;
  }

  async readEvents(directory) {
    const safeDirectory = assertInside(this.root, directory);
    const content = await readFile(join(safeDirectory, "events.jsonl"), "utf8");
    return content
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter(Boolean)
      .map((line) => JSON.parse(line));
  }

  async appendEvent(directory, event) {
    const safeDirectory = assertInside(this.root, directory);
    const lockPath = join(safeDirectory, ".write.lock");
    let lock;

    try {
      lock = await open(lockPath, "wx");
      await lock.writeFile(`${JSON.stringify({ acquiredAt: new Date().toISOString() })}\n`);
    } catch (error) {
      if (error.code === "EEXIST") {
        throw new WorkflowError("SESSION_LOCKED", "Run store is locked by another writer", {
          exitCode: 6,
        });
      }
      throw error;
    }

    try {
      const existing = await this.readEvents(safeDirectory);
      if (this.registry) validateEvents([...existing, event], this.registry);
      else if (event.sequence !== existing.length + 1) {
        throw new WorkflowError("EVENT_SEQUENCE_INVALID", "Event sequence is not contiguous", {
          exitCode: 3,
          details: { expected: existing.length + 1, actual: event.sequence },
        });
      }

      const handle = await open(join(safeDirectory, "events.jsonl"), "a");
      try {
        await handle.writeFile(`${JSON.stringify(event)}\n`);
        await handle.sync();
      } finally {
        await handle.close();
      }
    } finally {
      await lock?.close();
      await unlink(lockPath).catch(() => {});
    }

    return event;
  }
}
