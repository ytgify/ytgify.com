import { lstat } from "node:fs/promises";
import { isAbsolute, join, relative, resolve, sep } from "node:path";

import { WorkflowError } from "./errors.js";

function fail(code, message, details) {
  throw new WorkflowError(code, message, { exitCode: 3, details });
}

function contained(root, path) {
  const suffix = relative(root, path);
  return suffix === "" || (!suffix.startsWith(`..${sep}`) && suffix !== ".." && !isAbsolute(suffix));
}

async function entry(path) {
  try {
    return await lstat(path);
  } catch (error) {
    if (error.code === "ENOENT") return null;
    throw error;
  }
}

/** Reject path escapes, symlinks, and non-directory ancestry without following them. */
export async function assertSafeProjectPath(rootValue, targetValue, label, { finalType, allowMissing = true } = {}) {
  const root = resolve(rootValue);
  const target = resolve(targetValue);
  if (!contained(root, target)) fail("PATH_TRAVERSAL", `${label} escapes the repository`, { path: target });

  const rootEntry = await entry(root);
  if (!rootEntry) {
    if (allowMissing) return;
    fail("PROJECT_PATH_UNSAFE", `${label} ancestry does not exist`, { path: root });
  }
  if (rootEntry.isSymbolicLink() || !rootEntry.isDirectory()) {
    fail("PROJECT_PATH_UNSAFE", `${label} ancestry must start from a real directory`, { path: root });
  }

  let cursor = root;
  const parts = relative(root, target).split(sep).filter(Boolean);
  for (let index = 0; index < parts.length; index += 1) {
    cursor = join(cursor, parts[index]);
    const current = await entry(cursor);
    if (!current) {
      if (allowMissing) return;
      fail("PROJECT_PATH_UNSAFE", `${label} does not exist`, { path: cursor });
    }
    if (current.isSymbolicLink()) {
      fail("PROJECT_PATH_UNSAFE", `${label} ancestry cannot contain symlinks`, { path: cursor });
    }
    const isFinal = index === parts.length - 1;
    if (!isFinal && !current.isDirectory()) {
      fail("PROJECT_PATH_UNSAFE", `${label} ancestry must contain only directories`, { path: cursor });
    }
    if (isFinal && finalType === "file" && !current.isFile()) {
      fail("PROJECT_CONFIG_INVALID", `${label} must be a regular file`, { path: cursor });
    }
    if (isFinal && finalType === "directory" && !current.isDirectory()) {
      fail("PROJECT_PATH_UNSAFE", `${label} must be a directory when it exists`, { path: cursor });
    }
  }
}
