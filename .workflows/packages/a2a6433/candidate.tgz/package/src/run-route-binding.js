import { assertSafeReadinessName } from "./auth-session-adapter.js";
import { WorkflowError } from "./errors.js";
import { fixtureRouteParameterNames } from "./workflow.js";

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/iu;
const TARGET = /^run-route:(binding_[A-Za-z0-9_-]+)$/u;

function invalidBinding(message) {
  return new WorkflowError("RUN_ROUTE_BINDING_INVALID", message, { exitCode: 3 });
}

export function runRouteBindingId(target) {
  return typeof target === "string" ? (TARGET.exec(target)?.[1] ?? null) : null;
}

export function resolveFixtureRouteBinding(workflow, payload) {
  const bindingId = runRouteBindingId(payload?.target);
  if (!bindingId) throw invalidBinding("Fixture route binding target is invalid");

  const route = (workflow.fixtureRoutes ?? []).find(({ id }) => bindingId === `binding_${id}`);
  if (!route) throw invalidBinding("Fixture route binding target is unknown");

  const parameterNames = fixtureRouteParameterNames(route.pathTemplate);
  const suppliedParameters = payload.parameters;
  if (!suppliedParameters || typeof suppliedParameters !== "object" || Array.isArray(suppliedParameters)) {
    throw invalidBinding("Fixture route binding parameters are invalid");
  }
  const suppliedNames = Object.keys(suppliedParameters).sort();
  const declaredNames = Object.keys(route.parameters).sort();
  if (
    suppliedNames.length !== declaredNames.length ||
    suppliedNames.some((name, index) => name !== declaredNames[index])
  ) {
    throw invalidBinding("Fixture route binding parameters do not match the reviewed template");
  }
  for (const name of declaredNames) {
    if (route.parameters[name] !== "uuid" || !UUID.test(suppliedParameters[name])) {
      throw invalidBinding(`Fixture route binding parameter is invalid: ${name}`);
    }
  }

  const placeholders = new Set(parameterNames);
  const path = route.pathTemplate.replace(/\{([^{}]+)\}/gu, (_match, name) => {
    if (!placeholders.has(name)) throw invalidBinding("Fixture route template is invalid");
    return suppliedParameters[name];
  });

  assertSafeReadinessName(payload.readinessName);
  return {
    routeId: route.id,
    capability: route.capability,
    path,
    readiness: { role: route.readinessRole, name: payload.readinessName },
  };
}
