import { constants } from "node:fs";
import { lstat, open, rename, unlink } from "node:fs/promises";
import { join } from "node:path";
import { randomUUID } from "node:crypto";
import { orderedMapEvidence } from "./app-map-contract.js";

const filename = "app-map-registry.json";
const empty = () => ({ schema: "workflows-app-map-registry/v1", revision: 0, assignments: [], history: [] });
async function safeRoot(store) {
  const entry = await lstat(store.root);
  if (!entry.isDirectory() || entry.isSymbolicLink()) throw new Error("Unsafe map registry directory");
}
export function validateMapAssignments(document, registry) {
  registry.validate("appMapRegistry", document);
  const visits = new Set();
  const labels = new Map();
  for (const item of document.assignments) {
    const identity = JSON.parse(item.visitId);
    if (
      !Array.isArray(identity) ||
      identity.length !== 5 ||
      !/^run_[A-Za-z0-9_-]+$/.test(identity[0]) ||
      !Number.isInteger(identity[1]) ||
      identity[1] < 1 ||
      !Number.isInteger(identity[2]) ||
      identity[2] < 0 ||
      typeof identity[3] !== "string" ||
      typeof identity[4] !== "string"
    )
      throw new Error("Invalid map visit identity");
    if (visits.has(item.visitId)) throw new Error("Conflicting map visit assignments");
    visits.add(item.visitId);
    const key = JSON.stringify([item.appId, item.screenId]);
    if (labels.has(key) && labels.get(key) !== item.screenLabel) throw new Error("Conflicting map screen labels");
    labels.set(key, item.screenLabel);
    for (const field of ["screenLabel", "variantLabel", "journeyLabel"]) {
      if (item[field] !== undefined && !item[field].trim()) throw new Error("Empty map label");
    }
    if (item.variantId) {
      const variantKey = JSON.stringify([item.appId, item.screenId, item.variantId]);
      if (labels.has(variantKey) && labels.get(variantKey) !== item.variantLabel)
        throw new Error("Conflicting map variant labels");
      labels.set(variantKey, item.variantLabel);
    }
  }
  return document;
}
export async function readMapRegistry(store, registry) {
  await safeRoot(store);
  let handle;
  try {
    handle = await open(join(store.root, filename), constants.O_RDONLY | constants.O_NOFOLLOW);
    if (!(await handle.stat()).isFile()) throw new Error("Map registry is not a regular file");
    const document = validateMapAssignments(JSON.parse(await handle.readFile("utf8")), registry);
    if (!Number.isInteger(document.revision) || !Array.isArray(document.history))
      throw new Error("Map registry audit is missing");
    if (
      document.history.length !== document.revision ||
      document.history.some((entry, index) => entry.revision !== index)
    )
      throw new Error("Map registry audit sequence is invalid");
    return document;
  } catch (error) {
    if (error.code === "ENOENT") return empty();
    throw error;
  } finally {
    await handle?.close();
  }
}
export async function importMapRegistry(store, registry, document, expectedRevision, operation) {
  validateMapAssignments(document, registry);
  if (!Number.isInteger(expectedRevision) || expectedRevision < 0)
    throw new Error("Expected registry revision is required");
  await safeRoot(store);
  const lockPath = join(store.root, ".app-map-registry.lock");
  const lock = await open(lockPath, "wx", 0o600);
  let temporary;
  try {
    const previous = await readMapRegistry(store, registry);
    if (previous.revision !== expectedRevision)
      throw new Error("Map registry revision changed; read it before retrying");
    const runs = new Map();
    for (const assignment of document.assignments) {
      const [runId] = JSON.parse(assignment.visitId);
      if (!runs.has(runId)) runs.set(runId, await store.readRun(runId));
      const run = runs.get(runId);
      const visit = orderedMapEvidence(run.events).find((item) => item.visitId === assignment.visitId);
      if (!visit || run.workflow?.target?.app !== assignment.appId)
        throw new Error("Map assignment does not match exact run evidence");
      await store.readVerifiedEvidence(runId, visit.artifact.artifactId);
    }
    const next = {
      schema: previous.schema,
      revision: previous.revision + 1,
      assignments: document.assignments,
      history: [
        ...previous.history,
        {
          revision: previous.revision,
          recordedAt: new Date().toISOString(),
          assignments: previous.assignments,
          ...(operation ? { operation } : {}),
        },
      ],
    };
    validateMapAssignments(next, registry);
    temporary = join(store.root, `.app-map-${randomUUID()}.tmp`);
    const output = await open(temporary, "wx", 0o600);
    try {
      await output.writeFile(`${JSON.stringify(next, null, 2)}\n`);
      await output.sync();
    } finally {
      await output.close();
    }
    await rename(temporary, join(store.root, filename));
    return next;
  } finally {
    if (temporary) await unlink(temporary).catch(() => {});
    await lock.close();
    await unlink(lockPath);
  }
}
