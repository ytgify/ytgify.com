import { PerspectiveBatchStore } from "./perspective-batch-store.js";
import { inspectPerspectiveBatch } from "./perspective-batches.js";
import { PerspectiveAssessmentStore } from "./perspective-assessment-store.js";

function perspectiveBatchSummary(record) {
  return {
    batchId: record.batchId,
    createdAt: record.createdAt,
    source: structuredClone(record.source),
    policy: structuredClone(record.policy),
    gateOutcome: "not-loaded",
    coverageOutcome: "not-loaded",
    members: record.members.map((member) => ({ ...structuredClone(member), qualityOutcome: "not-loaded" })),
    integrity: "verified",
  };
}

export async function projectStudioPerspectiveBatches(runStore, workflowId, { detailedRunIds = null } = {}) {
  if (!runStore.root) return { batches: [], integrity: "unavailable" };
  const batchStore = new PerspectiveBatchStore(runStore.root, { registry: runStore.registry });
  const assessmentStore = new PerspectiveAssessmentStore(runStore.root, { registry: runStore.registry });
  try {
    const records = (await batchStore.list()).filter((record) => record.source.workflowId === workflowId);
    const detailSet = detailedRunIds === null ? null : new Set(detailedRunIds);
    const batches = await Promise.all(
      records.map(async (record) => {
        if (detailSet !== null) return perspectiveBatchSummary(record);
        try {
          return {
            ...(await inspectPerspectiveBatch({ batchId: record.batchId, runStore, batchStore, assessmentStore })),
            integrity: "verified",
          };
        } catch {
          return { batchId: record.batchId, integrity: "unavailable", gateOutcome: "blocked", members: [] };
        }
      }),
    );
    return { batches, integrity: batches.some((batch) => batch.integrity !== "verified") ? "degraded" : "verified" };
  } catch {
    return { batches: [], integrity: "unavailable" };
  }
}
