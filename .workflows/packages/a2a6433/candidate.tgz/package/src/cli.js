/* eslint-disable max-lines -- command routing and generated help stay one auditable surface. */
import { executeAppMapCommand } from "./cli-app-map.js";
import { resolve } from "node:path";

import { agentUsage, executeAgentCommand } from "./cli-agent.js";
import { executeBrowserCommand } from "./cli-browser.js";
import { executePerspectivesCommand, executePerspectiveEvaluation } from "./cli-perspectives.js";
import { executeRoutineEvaluation } from "./cli-evaluation.js";
import { executeCliLifecycleOperation } from "./cli-lifecycle.js";
import { printResult } from "./cli-project-presenter.js";
import { executeRoutineActionsCommand } from "./cli-routine-actions.js";
import { executeTrainingCommand } from "./cli-training.js";
import { executeExplorationCommand } from "./cli-exploration.js";
import { executeFixtureNeedCommand } from "./cli-fixture-needs.js";
import { collaborationUsage, executeCollaborationCommand, isCollaborationRunOperation } from "./collaboration-cli.js";
import { asWorkflowError, WorkflowError } from "./errors.js";
import { executeFindingsCommand } from "./findings-command.js";
import { createHelpData } from "./cli-help.js";
import { executeQuestionsCommand } from "./questions-command.js";
import { approveExistingLifecycleRun, LifecycleStore } from "./lifecycle-store.js";
import { resolveProjectContext } from "./project-context.js";
import { inspectProjectReadiness } from "./project-doctor.js";
import { initializeProject, planProjectInitialization } from "./project-initializer.js";
import { projectSurfaceSnapshot, projectUserSessionReadiness } from "./project-surface-snapshot.js";
import { RunControlStore } from "./run-control-store.js";
import { buildRunReport } from "./run-report.js";
import { createSchemaRegistry, readYaml } from "./schema-registry.js";
import { startStudioServer } from "./studio-server.js";
import { approveTrainingRun } from "./training.js";
import { resolveWorkflow } from "./workflow.js";
import { validatePath } from "./validation.js";

function parseArgs(argv) {
  const flags = new Map();
  const positionals = [];

  for (let index = 0; index < argv.length; index += 1) {
    const argument = argv[index];
    if (!argument.startsWith("--")) {
      positionals.push(argument);
      continue;
    }

    const name = argument.slice(2);
    if (
      name === "json" ||
      name === "quiet" ||
      name === "approve" ||
      name === "registry" ||
      name === "headless" ||
      name === "dry-run"
    ) {
      flags.set(name, true);
      continue;
    }

    const value = argv[index + 1];
    if (!value || value.startsWith("--")) {
      throw new WorkflowError("INVALID_USAGE", `Missing value for --${name}`, { exitCode: 2 });
    }
    flags.set(name, value);
    index += 1;
  }

  return { flags, positionals };
}

async function controlStore(flags, registry) {
  return new RunControlStore(resolve(flags.get("store") ?? ".workflows/local"), {
    registry,
  }).init();
}

function success(command, data = {}, warnings = []) {
  return { ok: true, command, data, warnings };
}

function failure(command, error) {
  return {
    ok: false,
    command,
    error: {
      code: error.code,
      message: error.message,
      details: error.details,
    },
  };
}

async function validateCommand(args, registry) {
  if (!args.length) {
    throw new WorkflowError("INVALID_USAGE", "validate requires at least one path", {
      exitCode: 2,
    });
  }
  const items = [];
  for (const path of args) items.push(await validatePath(path, registry));
  return success("validate", { items });
}

async function showCommand(args, flags, registry) {
  const [path] = args;
  const platform = flags.get("platform");
  if (!path || !platform) {
    throw new WorkflowError("INVALID_USAGE", "show requires PATH and --platform", {
      exitCode: 2,
    });
  }

  const workflow = registry.validate("workflow", await readYaml(path));
  const resolved = resolveWorkflow(workflow, platform);
  registry.validate("workflow", resolved.workflow);
  return success("show", {
    platform,
    sourceHash: resolved.sourceHash,
    effectiveHash: resolved.effectiveHash,
    workflow: resolved.workflow,
  });
}

function unsupportedFlags(flags, allowed, command) {
  const unsupported = [...flags.keys()].filter((name) => !allowed.includes(name));
  if (unsupported.length) {
    throw new WorkflowError("INVALID_USAGE", `${command} does not accept --${unsupported[0]}`, { exitCode: 2 });
  }
}

async function projectContext(flags, registry) {
  return resolveProjectContext({
    ...(flags.has("root") ? { projectRoot: resolve(flags.get("root")) } : {}),
    ...(flags.has("config") ? { configPath: flags.get("config") } : {}),
    registry,
  });
}

async function projectCommand(command, args, flags, registry) {
  unsupportedFlags(flags, ["binding", "config", "json", "root"], command);
  const binding = flags.get("binding") ?? "current";
  if (!new Set(["current", "latest"]).has(binding)) {
    throw new WorkflowError("INVALID_USAGE", `${command} --binding must be current or latest`, { exitCode: 2 });
  }
  const context = await projectContext(flags, registry);
  const snapshot = await projectSurfaceSnapshot(context, { binding, registry, terms: args.join(" ") });
  return success(command, { snapshot });
}

async function doctorCommand(args, flags, registry) {
  if (args.length)
    throw new WorkflowError("INVALID_USAGE", "doctor does not accept positional arguments", { exitCode: 2 });
  unsupportedFlags(flags, ["config", "json", "registry", "root"], "doctor");
  const context = await projectContext(flags, registry);
  return success("doctor", await inspectProjectReadiness(context, { registry, checkRegistry: flags.has("registry") }));
}

async function sessionsCommand(args, flags, registry) {
  unsupportedFlags(flags, ["config", "json", "root"], "sessions");
  const context = await projectContext(flags, registry);
  return success("sessions", await projectUserSessionReadiness(context, { registry, targetTerms: args.join(" ") }));
}

async function initCommand(args, flags, registry) {
  if (args.length) {
    throw new WorkflowError("INVALID_USAGE", "init does not accept positional arguments", {
      exitCode: 2,
    });
  }
  const host = flags.get("host");
  if (host !== "codex") {
    throw new WorkflowError("INVALID_USAGE", "init requires --host codex", { exitCode: 2 });
  }
  unsupportedFlags(
    flags,
    [
      "dry-run",
      "app-name",
      "base-url",
      "health-path",
      "host",
      "json",
      "local-url",
      "preview-url",
      "production-url",
      "root",
      "start-route",
    ],
    "init",
  );
  if (flags.has("local-url") && flags.has("base-url")) {
    throw new WorkflowError("INVALID_USAGE", "init accepts either --local-url or legacy --base-url, not both", {
      exitCode: 2,
    });
  }
  const options = {
    projectRoot: resolve(flags.get("root") ?? process.cwd()),
    registry,
    ...(flags.has("app-name") ? { appName: flags.get("app-name") } : {}),
    ...(flags.has("local-url") ? { localUrl: flags.get("local-url") } : {}),
    ...(flags.has("base-url") ? { baseUrl: flags.get("base-url") } : {}),
    ...(flags.has("preview-url") ? { previewUrl: flags.get("preview-url") } : {}),
    ...(flags.has("production-url") ? { productionUrl: flags.get("production-url") } : {}),
    ...(flags.has("start-route") ? { startRoute: flags.get("start-route") } : {}),
    ...(flags.has("health-path") ? { healthPath: flags.get("health-path") } : {}),
  };
  if (flags.has("dry-run")) {
    const plan = await planProjectInitialization(options);
    return success("init", {
      dryRun: true,
      items: plan.items.map(({ kind, path, status }) => ({ kind, path, status })),
      canApply: !plan.items.some(({ status }) => status === "conflict"),
    });
  }
  const initialized = await initializeProject(options);
  return success("init", {
    project: {
      id: initialized.projectContext.project?.id,
      name: initialized.projectContext.project?.appName,
    },
    items: initialized.items,
    created: initialized.created,
    updated: initialized.updated,
    unchanged: initialized.unchanged,
    conflicting: initialized.conflicting,
  });
}

async function trainCommand(args, flags, registry) {
  return success(
    "train",
    await executeTrainingCommand(args, flags, registry, {
      projectContext: () => projectContext(flags, registry),
      controlStore: () => controlStore(flags, registry),
    }),
  );
}

async function runCommand(args, flags, registry) {
  const [operation, runId] = args;
  if (!operation || !runId || args.length !== 2) {
    throw new WorkflowError("INVALID_USAGE", "run requires OPERATION and RUN_ID", { exitCode: 2 });
  }
  if (isCollaborationRunOperation(operation)) {
    return executeCollaborationCommand("run", args, flags, registry);
  }
  const unsupportedFlags = [...flags.keys()].filter((name) => !["store", "json"].includes(name));
  if (unsupportedFlags.length) {
    throw new WorkflowError("INVALID_USAGE", "run accepts only --store PATH and --json", { exitCode: 2 });
  }
  const store = await controlStore(flags, registry);
  if (operation === "approve") {
    const run = await store.readRun(runId);
    const approved =
      run.manifest.phase === "training"
        ? await approveTrainingRun({ runId, store })
        : await approveExistingLifecycleRun({
            runId,
            runStore: store,
            lifecycleStore: new LifecycleStore(store.root, { registry }),
          });
    return success("run approve", {
      runId,
      state: {
        phase: approved.state.phase,
        status: approved.state.status,
        revision: approved.state.revision,
      },
    });
  }
  if (operation === "inspect") {
    const run = await store.readRun(runId);
    return success("run inspect", {
      runId,
      state: run.state,
      workflow: run.manifest.workflowRef,
    });
  }
  throw new WorkflowError("INVALID_USAGE", `Unknown run operation: ${operation}`, { exitCode: 2 });
}

async function lifecycleCommand(command, args, flags, registry) {
  const operation = await executeCliLifecycleOperation({
    command,
    args,
    flags,
    registry,
    resolveProjectContext: () => projectContext(flags, registry),
  });
  return success(operation.command, operation.data);
}

async function evaluateCommand(args, flags, registry) {
  if (args[0] === "perspectives")
    return success(
      "evaluate perspectives",
      await executePerspectiveEvaluation(args, flags, registry, () => projectContext(flags, registry)),
    );
  if (!new Set(["desktop", "mobile"]).has(args[0])) return lifecycleCommand("evaluate", args, flags, registry);
  return success(
    `evaluate ${args[0]}`,
    await executeRoutineEvaluation(args, flags, registry, {
      projectContext: () => projectContext(flags, registry),
      controlStore: () => controlStore(flags, registry),
    }),
  );
}

async function reportCommand(args, flags, registry) {
  const [runId] = args;
  if (!runId || args.length !== 1 || [...flags.keys()].some((name) => !["store", "json"].includes(name))) {
    throw new WorkflowError("INVALID_USAGE", "report requires RUN_ID and accepts only --store PATH and --json", {
      exitCode: 2,
    });
  }
  return success("report", { report: await buildRunReport(await controlStore(flags, registry), runId) });
}

async function studioCommand(args, flags, registry, stdout) {
  if (args.length)
    throw new WorkflowError("INVALID_USAGE", "studio does not accept positional arguments", { exitCode: 2 });
  unsupportedFlags(flags, ["config", "definitions", "port", "root", "store", "headless"], "studio");
  const context = await projectContext(flags, registry);
  const config = context.resolution.configPath
    ? registry.validate("config", await readYaml(resolve(context.projectRoot, context.resolution.configPath)))
    : null;
  const rawPort = String(flags.get("port") ?? config?.studio?.port ?? "auto");
  if (rawPort !== "auto" && !/^[0-9]+$/.test(rawPort)) {
    throw new WorkflowError("INVALID_USAGE", "studio --port must be an integer from 1 to 65535 or auto", {
      exitCode: 2,
    });
  }
  const port = rawPort === "auto" ? 0 : Number(rawPort);
  if (rawPort !== "auto" && (!Number.isSafeInteger(port) || port < 1 || port > 65535)) {
    throw new WorkflowError("INVALID_USAGE", "studio --port must be an integer from 1 to 65535 or auto", {
      exitCode: 2,
    });
  }
  const studio = await startStudioServer({
    headless: flags.get("headless") === true,
    projectContext: context,
    storeRoot: resolve(
      flags.get("store") ?? context.projectRoot,
      ...(flags.has("store") ? [] : context.paths.localStore.split("/")),
    ),
    definitionsRoot: resolve(
      flags.get("definitions") ?? context.projectRoot,
      ...(flags.has("definitions") ? [] : context.paths.workflowDefinitions.split("/")),
    ),
    registry,
    port,
  });
  stdout.write(`Studio listening at ${studio.url}\n`);
  await new Promise((resolveShutdown) => {
    const shutdown = () => resolveShutdown();
    process.once("SIGINT", shutdown);
    process.once("SIGTERM", shutdown);
  });
  await studio.close();
  return { silent: true };
}

export async function main(argv, { stderr = process.stderr, stdout = process.stdout } = {}) {
  const helpIndex = argv.findIndex((argument) => argument === "--help" || argument === "-h");
  if (helpIndex >= 0) {
    const json = argv.includes("--json") ? ["--json"] : [];
    const topic = argv.slice(0, helpIndex).filter((argument) => argument !== "--json" && argument !== "help");
    argv = ["help", ...topic, ...json];
  }
  let command = argv[0] ?? "help";
  let json = argv.includes("--json");

  try {
    const { flags, positionals } = parseArgs(argv.slice(1));
    json = flags.has("json") || json;
    const registry = await createSchemaRegistry();
    let result;

    switch (command) {
      case "app-map":
        result = success(
          "app-map",
          await executeAppMapCommand(positionals, flags, registry, await projectContext(flags, registry)),
        );
        break;
      case "validate":
        result = await validateCommand(positionals, registry);
        break;
      case "show":
        result = await showCommand(positionals, flags, registry);
        break;
      case "doctor":
        result = await doctorCommand(positionals, flags, registry);
        break;
      case "sessions":
        result = await sessionsCommand(positionals, flags, registry);
        break;
      case "init":
        result = await initCommand(positionals, flags, registry);
        break;
      case "list":
      case "status":
      case "runs":
      case "pending":
        result = await projectCommand(command, positionals, flags, registry);
        break;
      case "train":
        result = await trainCommand(positionals, flags, registry);
        break;
      case "explore":
        result = success(
          "explore",
          await executeExplorationCommand(positionals, flags, registry, {
            projectContext: () => projectContext(flags, registry),
          }),
        );
        break;
      case "fixture-needs":
        result = success(
          "fixture-needs",
          await executeFixtureNeedCommand(positionals, flags, registry, {
            projectContext: () => projectContext(flags, registry),
          }),
        );
        break;
      case "run":
        result = await runCommand(positionals, flags, registry);
        break;
      case "replay":
      case "promote":
      case "qualify":
      case "versions":
        result = await lifecycleCommand(command, positionals, flags, registry);
        break;
      case "evaluate":
        result = await evaluateCommand(positionals, flags, registry);
        break;
      case "perspectives":
        result = success(
          `perspectives ${positionals[0]}`,
          await executePerspectivesCommand(positionals, flags, registry),
        );
        break;
      case "report":
        result = await reportCommand(positionals, flags, registry);
        break;
      case "findings":
        result = await executeFindingsCommand(positionals, flags, registry);
        break;
      case "questions":
        result = await executeQuestionsCommand(positionals, flags, registry);
        break;
      case "routine-actions": {
        const operation = await executeRoutineActionsCommand(positionals, flags, registry, () =>
          projectContext(flags, registry),
        );
        result = success(operation.command, operation.data);
        break;
      }
      case "review-intent":
      case "acceptance":
        result = await executeCollaborationCommand(command, positionals, flags, registry);
        break;
      case "browser": {
        const operation = await executeBrowserCommand(positionals, flags, registry);
        result = success(operation.command, operation.data);
        json = true;
        break;
      }
      case "agent":
        json = true;
        result = await executeAgentCommand(positionals, flags, registry, {
          controlStore: () => controlStore(flags, registry),
          projectContext: () => projectContext(flags, registry),
        });
        break;
      case "studio":
        result = await studioCommand(positionals, flags, registry, stdout);
        break;
      case "help":
        result = success(
          "help",
          createHelpData(
            [
              "workflow app-map registry | proposals [--root PATH] [--json]",
              "workflow app-map inspect --run RUN_ID [--root PATH] [--json]",
              "workflow app-map propose | apply | undo --file JSON_PATH [--root PATH] [--json]",
              "workflow app-map import --file JSON_PATH --expected-revision N [--root PATH] [--json]",
              "workflow validate PATH [PATH...] [--json]",
              "workflow show PATH --platform PLATFORM [--json]",
              "workflow doctor [--registry] [--root PATH] [--config PATH] [--json]",
              "workflow sessions [TARGET_TERMS...] [--root PATH] [--config PATH] [--json]",
              "workflow explore start --target WORDS --route /PATH --intent 'INTENT[;INTENT]' --platform PLATFORM [--fixture 'NAME=RELATIVE_PATH=CONTROL_LABEL[;...]'] [--root PATH] [--config PATH] [--store PATH] [--json]",
              "workflow explore review RUN_ID [--root PATH] [--config PATH] [--store PATH] [--json]",
              "workflow fixture-needs review RUN_ID [--root PATH] [--config PATH] [--store PATH] [--json]",
              "workflow fixture-needs decide RUN_ID --file JSON_PATH [--root PATH] [--config PATH] [--store PATH] [--json]",
              "workflow fixture-needs import-supervised RUN_ID --file JSON_PATH [--root PATH] [--config PATH] [--store PATH] [--json]",
              "workflow fixture-needs import-ytgify RUN_ID --file JSON_PATH [--root PATH] [--config PATH] [--store PATH] [--json]",
              "workflow fixture-needs compile --file JSON_PATH [--output PATH] [--root PATH] [--config PATH] [--store PATH] [--json]",
              "workflow browser execute --file PATH [--root PATH] [--config PATH] [--store PATH] [--json]",
              "workflow browser stage-upload --file PATH [--root PATH] [--config PATH] [--store PATH] [--json]",
              "workflow routine-actions export RUN_ID --output PATH [--root PATH] [--config PATH] [--store PATH] [--json]",
              "workflow routine-actions apply WORKFLOW_PATH --review PATH --output PATH [--root PATH] [--config PATH] [--store PATH] [--json]",
              "workflow init --host codex [--root PATH] [--app-name NAME] [--local-url ORIGIN] [--preview-url ORIGIN] [--production-url ORIGIN] [--start-route PATH] [--health-path PATH] [--json] (--base-url is a legacy alias for --local-url)",
              "workflow list [TERMS...] [--binding current|latest] [--root PATH] [--config PATH] [--json]",
              "workflow status [TERMS...] [--binding current|latest] [--root PATH] [--config PATH] [--json]",
              "workflow runs [TERMS...] [--binding current|latest] [--root PATH] [--config PATH] [--json]",
              "workflow pending [TERMS...] [--binding current|latest] [--root PATH] [--config PATH] [--json]",
              "workflow questions propose RUN_ID --file PATH [--store PATH] [--json]",
              "workflow questions list WORKFLOW_ID [--store PATH] [--json]",
              "workflow questions show RUN_ID QUESTION_ID [--store PATH] [--json]",
              "workflow train PATH --platform PLATFORM [--fixture-recipe PATH] [--root PATH] [--target-url URL] [--profile PROFILE] [--lease-policy standard|supervised-codex-browser] [--store PATH] [--json]",
              "workflow train --journey PRODUCT_WORDS [--platform PLATFORM] [--fixture-recipe PATH] [--target PRODUCT_WORDS | --target-url URL] [--profile PROFILE] [--lease-policy standard|supervised-codex-browser] [--root PATH] [--config PATH] [--store PATH] [--json]",
              "workflow run inspect RUN_ID [--store PATH] [--json]",
              "workflow replay candidate PATH --platform PLATFORM [--fixture-recipe PATH] [--profile PROFILE] [--store PATH] [--json]",
              "workflow replay candidate --journey PRODUCT_WORDS --platform PLATFORM [--target PRODUCT_WORDS | --target-url URL] [--fixture-recipe PATH] [--profile PROFILE] [--root PATH] [--config PATH] [--store PATH] [--json]",
              "workflow replay promoted WORKFLOW_ID REVISION --platform PLATFORM [--target PRODUCT_WORDS | --target-url URL] [--fixture-recipe PATH] [--profile PROFILE] [--root PATH] [--config PATH] [--store PATH] [--json]",
              "workflow replay finalize RUN_ID [--store PATH] [--json]",
              "workflow promote PATH --replay RUN_ID [--store PATH] [--json] (verified state; no approval required)",
              "workflow promote --journey PRODUCT_WORDS --replay RUN_ID [--root PATH] [--config PATH] [--store PATH] [--json] (verified state; no approval required)",
              "workflow qualify WORKFLOW_ID REVISION --replay RUN_ID [--store PATH] [--json] (verified state; no approval required)",
              "workflow evaluate launch WORKFLOW_ID REVISION --desktop-qualification ID --mobile-qualification ID [--fixture-recipe PATH] [--target PRODUCT_WORDS | --target-url URL] [--root PATH] [--config PATH] [--store PATH] [--json]",
              "workflow evaluate finalize GROUP_ID RUN_ID [--store PATH] [--json]",
              "workflow evaluate inspect GROUP_ID [--store PATH] [--json]",
              "workflow evaluate desktop PATH [--store PATH] [--json]",
              "workflow evaluate mobile PATH [--store PATH] [--json]",
              "workflow evaluate desktop --journey PRODUCT_WORDS [--target PRODUCT_WORDS | --target-url URL] [--root PATH] [--config PATH] [--store PATH] [--json]",
              "workflow evaluate mobile --journey PRODUCT_WORDS [--target PRODUCT_WORDS | --target-url URL] [--root PATH] [--config PATH] [--store PATH] [--json]",
              "workflow perspectives list [--json]",
              "workflow evaluate perspectives --journey PRODUCT_WORDS --selection PATH --source candidate|promoted [--inquiry-depth focused|balanced|exploratory] [--batch BATCH_ID] [--target PRODUCT_WORDS | --target-url URL] [--root PATH] [--config PATH] [--store PATH] [--json]",
              "workflow perspectives assess RUN_ID --file PATH [--store PATH] [--json]",
              "workflow perspectives inspect BATCH_ID [--store PATH] [--json]",
              "workflow findings verification WORKFLOW_ID FINDING_ID --file PATH [--store PATH] [--json]",
              "workflow findings verify WORKFLOW_ID FINDING_ID --run RUN_ID --file PATH [--store PATH] [--json]",
              "workflow findings relate WORKFLOW_ID --file PATH [--store PATH] [--json]",
              "workflow report RUN_ID [--store PATH] [--json]",
              "workflow findings create RUN_ID [--file PATH] [--store PATH] [--json]",
              "workflow findings resolve WORKFLOW_ID FINDING_ID --desktop-run RUN_ID --mobile-run RUN_ID --commit SHA --verification PATH [--store PATH] [--json]",
              "workflow findings list WORKFLOW_ID [--store PATH] [--json]",
              "workflow findings show WORKFLOW_ID FINDING_ID [--store PATH] [--json]",
              ...collaborationUsage,
              "workflow versions WORKFLOW_ID [--store PATH] [--json]",
              "workflow init --host codex [--root PATH] --dry-run [--json]",
              "workflow studio [--root PATH] [--config PATH] [--store PATH] [--definitions PATH] [--port PORT] [--headless]",
              ...agentUsage,
              "workflow agent COMMAND [--file PATH] [--root PATH] [--config PATH] [--store PATH]",
            ],
            positionals,
          ),
        );
        break;
      default:
        throw new WorkflowError("INVALID_USAGE", `Unknown command: ${command}`, {
          exitCode: 2,
        });
    }

    if (result?.protocolFailure) {
      stdout.write(`${JSON.stringify(result.response)}\n`);
      return result.exitCode;
    }
    if (!result?.silent) printResult(result, { json, stderr, stdout });
    return 0;
  } catch (caught) {
    const error = asWorkflowError(caught);
    printResult(failure(command, error), { json, stderr, stdout });
    return error.exitCode;
  }
}
