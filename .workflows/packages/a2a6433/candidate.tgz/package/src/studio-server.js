import { listMapProposals, executeMapProposalMutation } from "./app-map-proposals.js";
import { projectStudioAppMap, readStudioMapRegistry, updateStudioMapAssignment } from "./studio-map-registry.js";
import { projectMapCatalog, projectMapRun } from "./studio-app-map.js";
import { projectExploration } from "./exploration-proposals.js";
import { decideFixtureNeed, readFixtureNeedReview } from "./fixture-need-decisions.js";
import { listSupervisedFixtureSources } from "./supervised-fixture-needs.js";
import { listYtgifyFixtureSources } from "./ytgify-fixture-needs.js";
/* eslint-disable max-lines -- verified read routes and the delegated mutation boundary share response hardening. */
import { createServer } from "node:http";
import { WorkflowError } from "./errors.js";

import { RunControlStore } from "./run-control-store.js";
import { AuthSessionStore, authSessionBindingHash, authSessionScope } from "./auth-session-store.js";
import { AuthSessionService } from "./auth-session-service.js";
import { PlaywrightUserSessionAdapter } from "./playwright-user-session-adapter.js";
import {
  executeAuthenticatedBrowser,
  validateBrowserExecutionRequest,
  sanitizeExecutionDiagnostic,
} from "./authenticated-browser-execution.js";
import {
  createUserSessionBrokerSecret,
  publishUserSessionBroker,
  recoverUserSessionBroker,
  removeUserSessionBroker,
} from "./user-session-browser-broker.js";
import { LifecycleStore } from "./lifecycle-store.js";
import { FindingStore } from "./finding-store.js";
import { FindingVerificationContractStore } from "./finding-verification-contracts.js";
import { FindingResolutionStore } from "./finding-resolution-store.js";
import { EvaluationQuestionStore } from "./evaluation-question-store.js";
import { RequirementDecisionStore } from "./requirement-decision-store.js";
import { EvaluationQuestionPolicyStore } from "./evaluation-question-policy-store.js";
import { readEvaluationRequirements } from "./evaluation-requirements.js";
import {
  answerStudioQuestion,
  dismissStudioQuestion,
  projectStudioQuestion,
  projectStudioQuestions,
  respondStudioQuestion,
} from "./studio-questions.js";
import { projectStudioFindings } from "./studio-findings.js";
import { projectSurfaceSnapshot } from "./project-surface-snapshot.js";
import { ReviewIntentStore } from "./review-intent-store.js";
import {
  createStudioCsrfToken,
  executeStudioMutation,
  matchStudioMutationPath,
  readStudioJsonBody,
  requireExactStudioHost,
  requireStudioMutationHeaders,
  StudioMutationError,
} from "./studio-mutation-security.js";
import {
  createStudioProjectionContext,
  listStudioLifecycle,
  listStudioRuns,
  projectStudioEvaluationReview,
  projectStudioEvaluationGroupReview,
  projectStudioEvaluationCatalogReview,
  projectStudioReport,
  projectStudioRun,
  projectStudioRunComparison,
  projectStudioTrainingReview,
  projectStudioAuthSession,
} from "./studio-projection.js";
import { StudioProjectionCache } from "./studio-projection-cache.js";
import { deriveStudioDecision, listStudioWorkflows, projectStudioEvaluationTruth } from "./studio-workflows.js";

const RESPONSE_SECURITY_HEADERS = Symbol("Studio response security headers");

function send(response, status, body, type, headOnly = false, securityHeaders = response[RESPONSE_SECURITY_HEADERS]) {
  const bytes = Buffer.isBuffer(body) ? body : Buffer.from(body);
  response.writeHead(status, {
    ...securityHeaders,
    "content-type": type,
    "content-length": bytes.length,
  });
  response.end(headOnly ? undefined : bytes);
}

function json(response, status, value, headOnly, securityHeaders) {
  send(response, status, `${JSON.stringify(value)}\n`, "application/json; charset=utf-8", headOnly, securityHeaders);
}

function error(response, status, code, headOnly, securityHeaders) {
  json(response, status, { error: { code } }, headOnly, securityHeaders);
}

function exactPath(rawUrl) {
  if (typeof rawUrl !== "string" || rawUrl.includes("\\") || /%(?:2e|2f|5c)/i.test(rawUrl)) return null;
  try {
    const url = new URL(rawUrl, "http://workflows.localhost");
    if (url.search || url.hash || url.pathname !== rawUrl) return null;
    return url.pathname;
  } catch {
    return null;
  }
}

function exactMarker(left, right) {
  const fields = ["routePath", "role", "name"];
  return (
    left &&
    right &&
    Object.keys(right).length === fields.length &&
    fields.every((field) => Object.hasOwn(right, field) && left[field] === right[field])
  );
}

function applyLifecycleSummary(workflow, projectedFindings) {
  const workflowRepairVerified = projectedFindings.candidateRepair?.status === "verified";
  const verifiedResolution = projectedFindings.findings
    .filter((finding) => finding.resolution?.integrity === "verified")
    .sort((left, right) => String(right.resolution.createdAt).localeCompare(String(left.resolution.createdAt)))[0];
  const repair =
    workflowRepairVerified && verifiedResolution
      ? {
          status: "verified",
          scope: "workflow",
          findingCount: projectedFindings.candidateRepair.findingCount,
          findingIds: projectedFindings.findings.map((finding) => finding.findingId),
          findingId: verifiedResolution.findingId,
          title:
            projectedFindings.candidateRepair.findingCount === 1
              ? verifiedResolution.title
              : `Candidate revision ${projectedFindings.candidateRepair.candidateRevision} · ${projectedFindings.candidateRepair.findingCount} findings verified`,
          candidateRevision: projectedFindings.candidateRepair.candidateRevision,
          sourceBytesHash: projectedFindings.candidateRepair.sourceBytesHash,
          contentHash: projectedFindings.candidateRepair.contentHash,
          createdAt: verifiedResolution.resolution.createdAt,
          implementationCommit: verifiedResolution.resolution.fix.implementationCommit,
          platforms: verifiedResolution.resolution.verification.map((proof) => ({
            platform: proof.platform,
            runId: proof.runId,
            completedAt: proof.completedAt,
            evidenceCount: proof.evidence.length,
            integrity: "verified",
          })),
        }
      : null;
  workflow.repair = repair;
  for (const platform of workflow.platforms) {
    platform.repairProof = repair?.platforms.find((proof) => proof.platform === platform.id) ?? null;
  }
  const allQualified = workflow.platforms.every((platform) => platform.qualification.integrity === "verified");
  const completedTraining = workflow.recentRuns.find(
    (run) => run.classification === "training" && run.status === "completed" && run.disposition === "evidence",
  );
  if (projectedFindings.summary.open === null || (projectedFindings.summary.unavailable ?? 0) > 0) {
    workflow.lifecycle = {
      state: "status-unavailable",
      label: "Status unavailable",
      detail: "Finding status could not be reconstructed safely.",
      nextAction: { view: "overview", label: "Review workflow", guidance: "Restore the local evidence store." },
    };
  } else if (projectedFindings.summary.open > 0) {
    const reopened = projectedFindings.summary.reopened ?? 0;
    workflow.lifecycle = {
      state: "repair-needed",
      label: `${projectedFindings.summary.open} finding${projectedFindings.summary.open === 1 ? "" : "s"} open${reopened ? `, including ${reopened} reopened` : ""}`,
      detail: reopened
        ? "Prior repair proof is no longer verified. The reopened finding and exact integrity reason require review."
        : "Evaluation evidence identified work that remains open.",
      nextAction: {
        view: "fix",
        label: "Review findings",
        guidance: reopened
          ? "Review the exact failing source and hand off a new bounded repair proof."
          : "Use the agent handoff to make and verify a repair.",
      },
    };
  } else if (repair && !workflow.release) {
    workflow.lifecycle = {
      state: "repair-verified",
      label: "Repair verified",
      detail: `Candidate revision ${repair.candidateRevision} passed fresh desktop and mobile repair checks.`,
      nextAction: {
        view: "fix",
        label: "Review verified repair",
        guidance: `Run and finalize a supervised candidate replay for candidate revision ${repair.candidateRevision}, then use its receipt for external human-supervised promotion. Neither step proves release qualification or release evaluation.`,
      },
    };
  } else if (workflow.release && !allQualified) {
    workflow.lifecycle = {
      state: "qualification-needed",
      label: "Release needs qualification",
      detail: `${workflow.release.revision} exists, but every platform has not been independently qualified.`,
      nextAction: {
        view: "evaluate",
        label: "Review qualification",
        guidance:
          "Qualify each missing platform independently outside Studio; qualification does not prove release evaluation.",
      },
    };
  } else if (workflow.release && allQualified) {
    workflow.lifecycle = {
      state: "ready-to-evaluate",
      label: "Ready for evaluation",
      detail: `${workflow.release.revision} is independently qualified on every declared platform.`,
      nextAction: {
        view: "evaluate",
        label: "Review evaluation",
        guidance:
          "Run or review the release evaluation outside Studio; qualification alone does not prove its outcome.",
      },
    };
  } else if (completedTraining) {
    workflow.lifecycle = {
      state: "training-complete",
      label: "Training walkthrough complete",
      detail: "A supervised walkthrough passed, but no promoted release exists yet.",
      nextAction: { view: "train", label: "Review training proof", guidance: "Review the proof before promotion." },
    };
  } else {
    workflow.lifecycle = {
      state: "training-needed",
      label: "Training needed",
      detail: "The candidate does not yet have a completed supervised walkthrough.",
      nextAction: { view: "train", label: "Review training plan", guidance: "Complete a supervised walkthrough." },
    };
  }
  workflow.nextAction = workflow.lifecycle.nextAction;
  workflow.phases.train.label = workflow.draft.candidateRevision
    ? `Candidate r${workflow.draft.candidateRevision}`
    : "No candidate";
  workflow.phases.evaluate.label = repair
    ? "Repair proof passed"
    : workflow.release
      ? allQualified
        ? "Ready"
        : "Qualification required"
      : "Promotion required";
  workflow.phases.fix.label =
    projectedFindings.summary.open > 0
      ? `${projectedFindings.summary.open} open${projectedFindings.summary.reopened ? ` · ${projectedFindings.summary.reopened} reopened` : ""}`
      : projectedFindings.summary.resolved > 0
        ? "Resolved"
        : "No findings";
}

export function createStudioServer({
  storeRoot,
  registry,
  definitionsRoot,
  workflowPaths,
  studioAssets,
  projectContext,
  snapshot,
  readProjectSnapshot = projectSurfaceSnapshot,
  authSessionService,
  browserBrokerSecret,
  headless = false,
} = {}) {
  if (!studioAssets?.assets || !studioAssets?.securityHeaders) {
    const error = new Error("Packaged Studio assets are unavailable or invalid.");
    error.code = "STUDIO_ASSETS_UNAVAILABLE";
    throw error;
  }
  const staticAssets = studioAssets.assets;
  const securityHeaders = studioAssets.securityHeaders;
  const store = new RunControlStore(storeRoot, { registry });
  const lifecycleStore = new LifecycleStore(storeRoot, { registry });
  const findingStore = new FindingStore(storeRoot, { registry });
  const contractStore = new FindingVerificationContractStore(storeRoot, { registry });
  const resolutionStore = new FindingResolutionStore(storeRoot, { registry });
  const questionStore = new EvaluationQuestionStore(storeRoot, { registry });
  const decisionStore = new RequirementDecisionStore(storeRoot, { registry });
  const questionPolicyStore = new EvaluationQuestionPolicyStore(storeRoot, { registry });
  const reviewIntentStore = projectContext ? new ReviewIntentStore(projectContext, { registry }) : null;
  const ownedAdapter =
    !authSessionService && projectContext
      ? new PlaywrightUserSessionAdapter({ localStoreRoot: storeRoot, headless })
      : null;
  const sessionService =
    authSessionService ??
    (projectContext
      ? new AuthSessionService({
          store: new AuthSessionStore(storeRoot, { registry }),
          adapter: ownedAdapter,
        })
      : null);
  const authVerifying = new Set();
  const authProposals = new Map();
  const authCapabilityFailures = new Set();
  const authMutationQueues = new Map();
  function serializeAuthMutation(targetId, operation) {
    const previous = authMutationQueues.get(targetId) ?? Promise.resolve();
    const current = previous.catch(() => {}).then(operation);
    authMutationQueues.set(targetId, current);
    return current.finally(() => {
      if (authMutationQueues.get(targetId) === current) authMutationQueues.delete(targetId);
    });
  }
  const csrfToken = createStudioCsrfToken();
  const summaryProjectionCache = new StudioProjectionCache();
  let initialProjectSnapshot = snapshot ?? null;
  let activeProjectionWave = null;
  function invalidateProjectionTruth() {
    initialProjectSnapshot = null;
    activeProjectionWave = null;
    summaryProjectionCache.clear();
  }
  function acquireProjectionWave() {
    if (!activeProjectionWave) {
      const context = createStudioProjectionContext(store, lifecycleStore);
      const findingProjections = new Map();
      let runs;
      let lifecycle;
      activeProjectionWave = {
        context,
        users: 0,
        runs() {
          runs ??= listStudioRuns(context.runStore, { cache: summaryProjectionCache });
          return runs;
        },
        lifecycle() {
          lifecycle ??= listStudioLifecycle(context.runStore, context.lifecycleStore);
          return lifecycle;
        },
        finding(workflowId) {
          if (!findingProjections.has(workflowId)) {
            findingProjections.set(
              workflowId,
              projectStudioFindings(
                context.runStore,
                findingStore,
                workflowId,
                resolutionStore,
                contractStore,
                context,
              ),
            );
          }
          return findingProjections.get(workflowId);
        },
      };
    }
    const wave = activeProjectionWave;
    wave.users += 1;
    let released = false;
    return {
      wave,
      release() {
        if (released) return;
        released = true;
        wave.users -= 1;
        if (wave.users === 0 && activeProjectionWave === wave) activeProjectionWave = null;
      },
    };
  }
  async function withProjectionWave(operation) {
    const acquired = acquireProjectionWave();
    try {
      return await operation(acquired.wave);
    } finally {
      acquired.release();
    }
  }
  async function collaborationSnapshot(wave) {
    if (initialProjectSnapshot) {
      const initial = initialProjectSnapshot;
      initialProjectSnapshot = null;
      return initial;
    }
    if (!projectContext) return null;
    let activityRecords;
    try {
      activityRecords = await wave.runs();
    } catch {}
    return readProjectSnapshot(projectContext, {
      registry,
      projectionContext: wave.context,
      lifecycle: await wave.lifecycle(),
      ...(activityRecords ? { activityRecords } : {}),
      findingProjection: (workflowId) => wave.finding(workflowId),
    });
  }
  async function workflowCatalog(wave) {
    const requestLifecycleStore = wave.context.lifecycleStore;
    let runs = [];
    let lifecycle = { workflows: [], groups: [], qualifications: [], qualificationMatrix: {} };
    const sources = { runs: "verified", lifecycle: "verified" };
    try {
      runs = await wave.runs();
    } catch {
      sources.runs = "unavailable";
    }
    try {
      lifecycle = await wave.lifecycle();
    } catch {
      sources.lifecycle = "unavailable";
    }
    const catalog = await listStudioWorkflows({ definitionsRoot, workflowPaths, registry, runs, lifecycle });
    await Promise.all(
      catalog.workflows.map(async (workflow) => {
        const [projected, evaluationReview] = await Promise.all([
          wave.finding(workflow.id),
          projectStudioEvaluationCatalogReview(requestLifecycleStore, workflow.id, runs, lifecycle).catch(() => ({
            groups: [],
            sources: { runs: "unavailable", lifecycle: "unavailable" },
          })),
        ]);
        workflow.findings = projected.summary;
        applyLifecycleSummary(workflow, projected);
        const evaluation = projectStudioEvaluationTruth(workflow, evaluationReview, sources);
        workflow.decision = deriveStudioDecision(workflow, { sources, evaluation });
        workflow.phases.train.status = workflow.decision.dimensions.draft;
        workflow.phases.evaluate.status =
          workflow.decision.dimensions.evaluation === "No evaluation"
            ? allQualifiedStatus(workflow)
            : workflow.decision.dimensions.evaluation;
        workflow.phases.fix.status = workflow.decision.dimensions.findings;
      }),
    );
    return { ...catalog, sources };
  }
  async function trainingWorkflow(workflowId) {
    const catalog = await listStudioWorkflows({
      definitionsRoot,
      workflowPaths,
      registry,
      runs: [],
      lifecycle: { workflows: [], groups: [], qualifications: [], qualificationMatrix: {} },
    });
    return catalog.workflows.find((workflow) => workflow.id === workflowId) ?? null;
  }
  const server = createServer(async (request, response) => {
    response[RESPONSE_SECURITY_HEADERS] = securityHeaders;
    const headOnly = request.method === "HEAD";
    try {
      requireExactStudioHost(request);
      const path = exactPath(request.url);
      if (!path) return error(response, 400, "INVALID_PATH", headOnly, securityHeaders);
      const authMutation = path.match(
        /^\/api\/auth-sessions\/([a-z][a-z0-9]*(?:[._-][a-z0-9]+)*)\/(open|propose|confirm|verify|reauthenticate|clear)$/u,
      );
      const questionMutation = path.match(/^\/api\/questions\/(question_[a-f0-9]{32})\/(answer|dismiss|respond)$/u);
      const fixtureNeedMutation = path.match(/^\/api\/fixture-needs\/runs\/(run_[A-Za-z0-9_-]+)\/decide$/u);
      const mutationRoute = authMutation
        ? { kind: "auth-session", targetId: authMutation[1], command: authMutation[2] }
        : path === "/api/app-map/assignments"
          ? { kind: "map-assignment" }
          : ["/api/app-map/proposals", "/api/app-map/proposals/apply", "/api/app-map/proposals/undo"].includes(path)
            ? { kind: "map-proposal", command: path.split("/")[4] ?? "propose" }
            : questionMutation
              ? { kind: "question", questionId: questionMutation[1], command: questionMutation[2] }
              : fixtureNeedMutation
                ? { kind: "fixture-need-decision", runId: fixtureNeedMutation[1] }
                : path === "/api/question-policy"
                  ? { kind: "question-policy" }
                  : matchStudioMutationPath(path);

      if (["/api/browser-user-session-host/v1/verify", "/api/browser-user-session-host/v1/execute"].includes(path)) {
        if (request.method !== "POST" || !browserBrokerSecret || !sessionService) {
          return error(response, 404, "NOT_FOUND", headOnly, securityHeaders);
        }
        if (request.headers["x-workflows-browser-broker-secret"] !== browserBrokerSecret) {
          return error(response, 403, "BROKER_FORBIDDEN", false, securityHeaders);
        }
        if (request.headers["content-type"] !== "application/json") {
          return error(response, 415, "CONTENT_TYPE_REQUIRED", false, securityHeaders);
        }
        const body = await readStudioJsonBody(request);
        if (path.endsWith("/execute")) {
          validateBrowserExecutionRequest(body);
          const run = await store.readRun(body.runId);
          try {
            const result = await serializeAuthMutation(run.manifest.authentication?.targetId, () =>
              executeAuthenticatedBrowser({ store, request: body, sessionService, projectContext }),
            );
            invalidateProjectionTruth();
            return json(response, 200, result, false, securityHeaders);
          } catch (failure) {
            const executionDiagnostic = sanitizeExecutionDiagnostic(failure.details?.executionDiagnostic);
            if (!executionDiagnostic) throw failure;
            return json(response, 409, { executionDiagnostic }, false, securityHeaders);
          }
        }
        const target = projectContext?.applicationTargets?.inventory?.find(
          (item) =>
            item.id === body?.targetId &&
            item.environment === body?.environment &&
            item.baseUrl === body?.origin &&
            projectContext.project?.id === body?.projectId &&
            item.authentication?.mode === "user-session" &&
            item.provenance === "configured-v1",
        );
        if (!target || Object.keys(body).length !== 4)
          return error(response, 403, "BROKER_FORBIDDEN", false, securityHeaders);
        let record;
        try {
          record = await sessionService.verify(authSessionScope(projectContext, target));
          authCapabilityFailures.delete(target.id);
        } catch (caught) {
          if (caught?.code === "AUTH_SESSION_CAPABILITY_UNAVAILABLE") authCapabilityFailures.add(target.id);
          throw caught;
        }
        if (record.state === "ready" && !record.browserSessionRef) {
          return error(response, 503, "AUTH_SESSION_CAPABILITY_UNAVAILABLE", false, securityHeaders);
        }
        return json(
          response,
          200,
          {
            record: {
              targetId: record.targetId,
              markerHash: record.markerHash,
              sessionBindingHash: record.sessionBindingHash ?? authSessionBindingHash(record),
              state: record.state,
              ...(record.lastVerifiedAt ? { lastVerifiedAt: record.lastVerifiedAt } : {}),
              ...(record.browserSessionRef ? { browserSessionRef: record.browserSessionRef } : {}),
            },
          },
          false,
          securityHeaders,
        );
      }

      if (request.method === "POST") {
        if (!mutationRoute) {
          response.setHeader("allow", "GET, HEAD");
          return error(response, 405, "METHOD_NOT_ALLOWED", false, securityHeaders);
        }
        requireStudioMutationHeaders(request, csrfToken);
        if (mutationRoute.kind === "auth-session" && request.headers["sec-fetch-site"] !== "same-origin") {
          throw new StudioMutationError(403, "FETCH_METADATA_REQUIRED");
        }
        const body = await readStudioJsonBody(request);
        if (
          ["question", "question-policy"].includes(mutationRoute.kind) &&
          request.headers["sec-fetch-site"] !== "same-origin"
        )
          throw new StudioMutationError(403, "FETCH_METADATA_REQUIRED");
        if (mutationRoute.kind === "question") {
          await decisionStore.init();
          const payload =
            mutationRoute.command === "answer"
              ? await answerStudioQuestion({
                  questionStore,
                  decisionStore,
                  runStore: store,
                  projectContext,
                  registry,
                  questionId: mutationRoute.questionId,
                  body,
                })
              : mutationRoute.command === "respond"
                ? await respondStudioQuestion({
                    questionStore,
                    decisionStore,
                    questionId: mutationRoute.questionId,
                    body,
                  })
                : await dismissStudioQuestion({
                    questionStore,
                    decisionStore,
                    questionId: mutationRoute.questionId,
                    body,
                  });
          invalidateProjectionTruth();
          return json(response, payload.replay ? 200 : 201, payload, false, securityHeaders);
        }
        if (mutationRoute.kind === "question-policy") {
          if (
            !projectContext?.project?.id ||
            Object.keys(body).some(
              (key) =>
                ![
                  "expectedRevision",
                  "depth",
                  "optionalQuestionsPerStep",
                  "optionalQuestionsPerRun",
                  "idempotencyKey",
                ].includes(key),
            ) ||
            !Number.isSafeInteger(body.expectedRevision) ||
            !["focused", "balanced", "exploratory"].includes(body.depth) ||
            (body.optionalQuestionsPerStep !== undefined &&
              (!Number.isSafeInteger(body.optionalQuestionsPerStep) ||
                body.optionalQuestionsPerStep < 0 ||
                body.optionalQuestionsPerStep > 20)) ||
            (body.optionalQuestionsPerRun !== undefined &&
              (!Number.isSafeInteger(body.optionalQuestionsPerRun) ||
                body.optionalQuestionsPerRun < 0 ||
                body.optionalQuestionsPerRun > 200)) ||
            !/^req_[A-Za-z0-9_-]{4,196}$/u.test(body.idempotencyKey ?? "")
          )
            throw new StudioMutationError(400, "INVALID_REQUEST");
          const policy = await questionPolicyStore.set(
            projectContext.project.id,
            body.expectedRevision,
            body.depth,
            {
              optionalQuestionsPerStep: body.optionalQuestionsPerStep,
              optionalQuestionsPerRun: body.optionalQuestionsPerRun,
            },
            { idempotencyKey: body.idempotencyKey },
          );
          invalidateProjectionTruth();
          return json(response, 200, { policy }, false, securityHeaders);
        }
        if (mutationRoute.kind === "map-proposal") {
          const payload = await executeMapProposalMutation(store, registry, mutationRoute.command, body);
          invalidateProjectionTruth();
          return json(response, 200, payload, false, securityHeaders);
        }
        if (mutationRoute.kind === "fixture-need-decision") {
          const payload = await decideFixtureNeed(store, registry, mutationRoute.runId, body, { channel: "studio" });
          invalidateProjectionTruth();
          return json(response, 200, payload, false, securityHeaders);
        }
        if (mutationRoute.kind === "map-assignment") {
          const payload = await updateStudioMapAssignment(store, registry, body);
          invalidateProjectionTruth();
          return json(response, 200, payload, false, securityHeaders);
        }
        if (mutationRoute.kind === "auth-session") {
          const target = projectContext?.applicationTargets?.inventory?.find(
            (item) => item.id === mutationRoute.targetId && item.authentication?.mode === "user-session",
          );
          if (!target || !sessionService) throw new StudioMutationError(404, "AUTH_TARGET_UNAVAILABLE");
          const expectedFields =
            mutationRoute.command === "confirm" ? ["expectedRevision", "candidate"] : ["expectedRevision"];
          if (
            !body ||
            Object.keys(body).some((field) => !expectedFields.includes(field)) ||
            !Number.isSafeInteger(body.expectedRevision) ||
            body.expectedRevision < 0 ||
            (mutationRoute.command === "confirm" && (!body.candidate || typeof body.candidate !== "object"))
          ) {
            throw new StudioMutationError(400, "INVALID_REQUEST");
          }
          const scope = authSessionScope(projectContext, target);
          let payload;
          try {
            payload = await serializeAuthMutation(target.id, async () => {
              let current = null;
              try {
                current = await sessionService.store.read(scope);
              } catch (caught) {
                if (caught?.code === "AUTH_SESSION_STALE") current = await sessionService.store.readForRecovery(scope);
                else if (caught?.code !== "AUTH_SESSION_NOT_CONFIGURED") throw caught;
              }
              if ((current?.revision ?? 0) !== body.expectedRevision) {
                throw new StudioMutationError(409, "AUTH_SESSION_REVISION_CONFLICT");
              }
              if (mutationRoute.command === "open") {
                return {
                  session: projectStudioAuthSession(target, await sessionService.open(scope, body.expectedRevision)),
                };
              }
              if (mutationRoute.command === "propose") {
                const candidates = await sessionService.propose(scope);
                authProposals.set(`${target.id}:${current.revision}`, candidates);
                return { session: projectStudioAuthSession(target, current), candidates };
              }
              if (mutationRoute.command === "confirm") {
                const proposed = authProposals.get(`${target.id}:${current.revision}`) ?? [];
                if (!proposed.some((candidate) => exactMarker(candidate, body.candidate))) {
                  throw new StudioMutationError(400, "AUTH_MARKER_NOT_PROPOSED");
                }
                const confirmed = await sessionService.confirm(scope, body.expectedRevision, body.candidate);
                authProposals.delete(`${target.id}:${current.revision}`);
                return { session: projectStudioAuthSession(target, confirmed) };
              }
              if (mutationRoute.command === "verify") {
                authVerifying.add(target.id);
                try {
                  return { session: projectStudioAuthSession(target, await sessionService.verify(scope)) };
                } finally {
                  authVerifying.delete(target.id);
                }
              }
              if (mutationRoute.command === "reauthenticate") {
                return { session: projectStudioAuthSession(target, await sessionService.reauthenticate(scope)) };
              }
              await sessionService.clear(scope, body.expectedRevision);
              authProposals.delete(`${target.id}:${body.expectedRevision}`);
              return { session: projectStudioAuthSession(target, null) };
            });
            authCapabilityFailures.delete(target.id);
          } catch (caught) {
            if (caught?.code === "AUTH_SESSION_CAPABILITY_UNAVAILABLE") authCapabilityFailures.add(target.id);
            throw caught;
          }
          return json(response, 200, payload, false, securityHeaders);
        }
        const result = await executeStudioMutation({
          route: mutationRoute,
          body,
          runStore: store,
          reviewIntentStore,
        });
        invalidateProjectionTruth();
        return json(response, result.status, result.payload, false, securityHeaders);
      }
      if (!new Set(["GET", "HEAD"]).has(request.method)) {
        response.setHeader("allow", "GET, HEAD");
        return error(response, 405, "METHOD_NOT_ALLOWED", headOnly, securityHeaders);
      }
      if (request.headers["content-length"] || request.headers["transfer-encoding"]) {
        return error(response, 400, "BODY_NOT_ALLOWED", headOnly, securityHeaders);
      }
      if (mutationRoute && mutationRoute.kind !== "question-policy" && path !== "/api/app-map/proposals") {
        response.setHeader("allow", "POST");
        return error(response, 405, "METHOD_NOT_ALLOWED", headOnly, securityHeaders);
      }

      if (path === "/api/csrf") {
        response.setHeader("x-workflows-csrf-token", csrfToken);
        return json(response, 200, { csrfToken }, headOnly, securityHeaders);
      }

      if (staticAssets.has(path)) {
        const asset = staticAssets.get(path);
        const assetHeaders = path.startsWith("/_next/static/")
          ? { ...securityHeaders, "cache-control": "public, max-age=31536000, immutable" }
          : securityHeaders;
        return send(response, 200, asset.bytes, asset.type, headOnly, assetHeaders);
      }
      if (path === "/api/runs") {
        try {
          return json(response, 200, { runs: await listStudioRuns(store) }, headOnly);
        } catch {
          return json(response, 503, { error: { code: "STORE_UNAVAILABLE" }, runs: [] }, headOnly);
        }
      }
      if (path === "/api/workflows") {
        try {
          return json(response, 200, await withProjectionWave((wave) => workflowCatalog(wave)), headOnly);
        } catch {
          return json(
            response,
            503,
            { error: { code: "WORKFLOWS_UNAVAILABLE" }, workflows: [], unavailable: [] },
            headOnly,
          );
        }
      }
      if (path === "/api/project-snapshot") {
        try {
          const value = await withProjectionWave((wave) => collaborationSnapshot(wave));
          if (!value) return error(response, 503, "PROJECT_CONTEXT_UNAVAILABLE", headOnly);
          return json(response, 200, value, headOnly);
        } catch {
          return error(response, 503, "PROJECT_SNAPSHOT_UNAVAILABLE", headOnly);
        }
      }
      if (path === "/api/question-policy") {
        if (!projectContext?.project?.id) return error(response, 503, "PROJECT_CONTEXT_UNAVAILABLE", headOnly);
        return json(
          response,
          200,
          { policy: await questionPolicyStore.read(projectContext.project.id) },
          headOnly,
          securityHeaders,
        );
      }
      const workflowQuestions = path.match(/^\/api\/workflows\/([a-z][a-z0-9]*(?:[._-][a-z0-9]+)*)\/questions$/u);
      if (workflowQuestions) {
        return json(
          response,
          200,
          await projectStudioQuestions({ questionStore, decisionStore, workflowId: workflowQuestions[1] }),
          headOnly,
          securityHeaders,
        );
      }
      const questionDetail = path.match(/^\/api\/questions\/(question_[a-f0-9]{32})$/u);
      if (questionDetail) {
        const requirements = projectContext ? await readEvaluationRequirements(projectContext, { registry }) : null;
        return json(
          response,
          200,
          {
            question: await projectStudioQuestion({ questionStore, decisionStore, questionId: questionDetail[1] }),
            catalogHash: requirements?.catalogHash ?? null,
          },
          headOnly,
          securityHeaders,
        );
      }
      const authStatus = path.match(/^\/api\/auth-sessions\/([a-z][a-z0-9]*(?:[._-][a-z0-9]+)*)$/u);
      if (authStatus) {
        const target = projectContext?.applicationTargets?.inventory?.find(
          (item) => item.id === authStatus[1] && item.authentication?.mode === "user-session",
        );
        if (!target || !sessionService) return error(response, 404, "AUTH_TARGET_UNAVAILABLE", headOnly);
        const scope = authSessionScope(projectContext, target);
        const capabilityFailed = authCapabilityFailures.has(target.id);
        try {
          const record = await sessionService.store.read(scope);
          return json(
            response,
            200,
            {
              session: projectStudioAuthSession(
                target,
                record,
                authVerifying.has(target.id) ? "verifying" : capabilityFailed ? "needs-attention" : undefined,
                capabilityFailed
                  ? record.state === "setup"
                    ? ["open", "clear"]
                    : ["open", "verify", "clear"]
                  : undefined,
              ),
            },
            headOnly,
          );
        } catch (caught) {
          if (caught?.code === "AUTH_SESSION_NOT_CONFIGURED") {
            return json(response, 200, { session: projectStudioAuthSession(target, null) }, headOnly);
          }
          if (caught?.code === "AUTH_SESSION_STALE") {
            try {
              const stale = await sessionService.store.readForRecovery(scope);
              return json(
                response,
                200,
                { session: projectStudioAuthSession(target, stale, "needs-attention", ["open", "clear"]) },
                headOnly,
              );
            } catch {}
          }
          return json(response, 200, { session: projectStudioAuthSession(target, null, "needs-attention") }, headOnly);
        }
      }
      const evaluationReview = path.match(
        /^\/api\/workflows\/([a-z][a-z0-9]*(?:[._-][a-z0-9]+)*)\/evaluation-review(?:\/details\/(run_[A-Za-z0-9_-]+(?:~run_[A-Za-z0-9_-]+)?)|\/pages\/([A-Za-z0-9_-]{1,2048}))?$/,
      );
      if (evaluationReview) {
        try {
          const detailedRunIds = evaluationReview[2]?.split("~") ?? [];
          const review = await projectStudioEvaluationReview(store, lifecycleStore, evaluationReview[1], null, {
            detailedRunIds,
            pagination: { cursor: evaluationReview[3] ?? null },
            cache: summaryProjectionCache,
          });
          if (
            detailedRunIds.some(
              (runId) => !review.runs.some((run) => run.runId === runId && Object.hasOwn(run, "steps")),
            )
          ) {
            return error(response, 404, "EVALUATION_RUN_UNAVAILABLE", headOnly);
          }
          return json(response, 200, review, headOnly);
        } catch (caught) {
          if (caught?.code === "STUDIO_CURSOR_INVALID") {
            return error(response, 400, "STUDIO_CURSOR_INVALID", headOnly);
          }
          return error(response, 503, "EVALUATION_REVIEW_UNAVAILABLE", headOnly);
        }
      }
      if (path === "/api/app-map/proposals") {
        return json(response, 200, await listMapProposals(store, registry), headOnly);
      }
      if (path === "/api/explorations") {
        try {
          const ids = await store.listRunIds();
          const runs = [];
          const unavailableRunIds = [];
          for (const id of ids) {
            try {
              const run = await store.readRun(id);
              if (run.manifest.phase !== "exploration") continue;
              runs.push({
                runId: id,
                createdAt: run.manifest.createdAt,
                status: run.state.status,
                targetLabel: run.manifest.target.label,
                intents: run.manifest.exploration.intents,
                visits: run.state.exploration.visits.length,
              });
            } catch {
              unavailableRunIds.push(id);
            }
          }
          runs.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
          return json(response, 200, { runs, unavailableRunIds }, headOnly);
        } catch {
          return error(response, 503, "EXPLORATION_INVENTORY_UNAVAILABLE", headOnly);
        }
      }
      const explorationRun = path.match(/^\/api\/explorations\/(run_[A-Za-z0-9_-]+)$/);
      if (explorationRun) {
        try {
          return json(response, 200, await projectExploration(store, explorationRun[1]), headOnly);
        } catch (caught) {
          return error(
            response,
            caught?.code === "RUN_NOT_FOUND" || caught?.code === "INVALID_RUN_PHASE" ? 404 : 503,
            "EXPLORATION_REVIEW_UNAVAILABLE",
            headOnly,
          );
        }
      }
      const fixtureNeedRun = path.match(/^\/api\/fixture-needs\/runs\/(run_[A-Za-z0-9_-]+)$/u);
      if (path === "/api/fixture-needs/supervised") {
        try {
          return json(response, 200, { runs: await listSupervisedFixtureSources(store) }, headOnly);
        } catch {
          return error(response, 503, "SUPERVISED_FIXTURE_SOURCES_UNAVAILABLE", headOnly);
        }
      }
      if (path === "/api/fixture-needs/recorded-training") {
        try {
          return json(response, 200, { runs: await listYtgifyFixtureSources(store) }, headOnly);
        } catch {
          return error(response, 503, "RECORDED_TRAINING_FIXTURE_SOURCES_UNAVAILABLE", headOnly);
        }
      }
      if (fixtureNeedRun) {
        try {
          return json(response, 200, await readFixtureNeedReview(store, registry, fixtureNeedRun[1]), headOnly);
        } catch (caught) {
          return error(
            response,
            caught?.code === "RUN_NOT_FOUND" || caught?.code === "INVALID_RUN_PHASE" ? 404 : 503,
            "FIXTURE_NEED_REVIEW_UNAVAILABLE",
            headOnly,
          );
        }
      }
      if (path === "/api/app-map/registry") {
        return json(response, 200, await readStudioMapRegistry(store, registry), headOnly);
      }
      if (path === "/api/app-map/projection") {
        return json(response, 200, await projectStudioAppMap(store, registry), headOnly);
      }
      const mapRun = path.match(/^\/api\/app-map\/runs\/(run_[A-Za-z0-9_-]+)$/);
      if (path === "/api/app-map" || mapRun) {
        try {
          const catalog = await listStudioWorkflows({
            definitionsRoot,
            workflowPaths,
            registry,
            runs: [],
            lifecycle: { workflows: [], groups: [], qualifications: [], qualificationMatrix: {} },
          });
          const value = mapRun
            ? await projectMapRun(store, registry, mapRun[1], catalog.workflows)
            : await projectMapCatalog(store, catalog.workflows, registry);
          return json(response, 200, value, headOnly);
        } catch {
          return error(response, mapRun ? 404 : 503, "APP_MAP_UNAVAILABLE", headOnly);
        }
      }
      const trainingReview = path.match(
        /^\/api\/workflows\/([a-z][a-z0-9]*(?:[._-][a-z0-9]+)*)\/training-review(?:\/details\/(run_[A-Za-z0-9_-]+)|\/pages\/([A-Za-z0-9_-]{1,2048}))?$/,
      );
      if (trainingReview) {
        try {
          const workflow = await trainingWorkflow(trainingReview[1]);
          if (!workflow) return error(response, 404, "WORKFLOW_UNAVAILABLE", headOnly);
          const detailedRunIds = trainingReview[2] ? [trainingReview[2]] : [];
          const review = await projectStudioTrainingReview(store, workflow.id, workflow.draft.candidateRevision, {
            detailedRunIds,
            pagination: { cursor: trainingReview[3] ?? null },
            cache: summaryProjectionCache,
          });
          if (trainingReview[2] && !review.runs.some((run) => run.runId === trainingReview[2] && run.steps)) {
            return error(response, 404, "TRAINING_RUN_UNAVAILABLE", headOnly);
          }
          return json(response, 200, review, headOnly);
        } catch (caught) {
          if (caught?.code === "STUDIO_CURSOR_INVALID") {
            return error(response, 400, "STUDIO_CURSOR_INVALID", headOnly);
          }
          return error(response, 503, "TRAINING_REVIEW_UNAVAILABLE", headOnly);
        }
      }
      const findingReview = path.match(/^\/api\/workflows\/([a-z][a-z0-9]*(?:[._-][a-z0-9]+)*)\/findings$/);
      if (findingReview) {
        try {
          return json(
            response,
            200,
            await projectStudioFindings(store, findingStore, findingReview[1], resolutionStore, contractStore),
            headOnly,
          );
        } catch {
          return error(response, 503, "FINDINGS_UNAVAILABLE", headOnly);
        }
      }
      const comparison = path.match(/^\/api\/evaluation-comparisons\/(run_[A-Za-z0-9_-]+)\/(run_[A-Za-z0-9_-]+)$/);
      if (comparison) {
        try {
          return json(response, 200, await projectStudioRunComparison(store, comparison[1], comparison[2]), headOnly);
        } catch {
          return error(response, 404, "COMPARISON_UNAVAILABLE", headOnly);
        }
      }
      const workflowDetail = path.match(/^\/api\/workflows\/([a-z][a-z0-9]*(?:[._-][a-z0-9]+)*)$/);
      if (workflowDetail) {
        try {
          const catalog = await withProjectionWave((wave) => workflowCatalog(wave));
          const workflow = catalog.workflows.find((item) => item.id === workflowDetail[1]);
          if (!workflow) return error(response, 404, "WORKFLOW_UNAVAILABLE", headOnly);
          return json(response, 200, { workflow, sources: catalog.sources }, headOnly);
        } catch {
          return error(response, 404, "WORKFLOW_UNAVAILABLE", headOnly);
        }
      }
      if (path === "/api/lifecycle") {
        try {
          return json(response, 200, await listStudioLifecycle(store, lifecycleStore), headOnly);
        } catch {
          return error(response, 503, "LIFECYCLE_UNAVAILABLE", headOnly);
        }
      }
      const evaluationGroup = path.match(/^\/api\/evaluation-groups\/(group_[A-Za-z0-9_-]+)$/);
      if (evaluationGroup) {
        try {
          return json(
            response,
            200,
            await projectStudioEvaluationGroupReview(store, lifecycleStore, evaluationGroup[1]),
            headOnly,
          );
        } catch {
          return error(response, 404, "EVALUATION_GROUP_UNAVAILABLE", headOnly);
        }
      }
      const detail = path.match(/^\/api\/runs\/(run_[A-Za-z0-9_-]+)$/);
      if (detail) {
        try {
          return json(response, 200, await projectStudioRun(store, detail[1]), headOnly);
        } catch {
          return error(response, 404, "RUN_UNAVAILABLE", headOnly);
        }
      }
      const report = path.match(/^\/api\/runs\/(run_[A-Za-z0-9_-]+)\/report$/);
      if (report) {
        try {
          return json(response, 200, await projectStudioReport(store, report[1]), headOnly);
        } catch {
          return error(response, 404, "REPORT_UNAVAILABLE", headOnly);
        }
      }
      const evidence = path.match(/^\/api\/runs\/(run_[A-Za-z0-9_-]+)\/artifacts\/(artifact_[A-Za-z0-9_-]+)$/);
      if (evidence) {
        try {
          const verified = await store.readVerifiedEvidence(evidence[1], evidence[2]);
          return send(response, 200, verified.bytes, verified.artifact.mimeType ?? "image/png", headOnly);
        } catch {
          return error(response, 404, "ARTIFACT_UNAVAILABLE", headOnly);
        }
      }
      return error(response, 404, "NOT_FOUND", headOnly);
    } catch (caught) {
      if (!response.headersSent) {
        if (caught instanceof StudioMutationError) error(response, caught.status, caught.code, headOnly);
        else {
          const conflict = new Set([
            "REVISION_CONFLICT",
            "IDEMPOTENCY_CONFLICT",
            "REVIEW_INTENT_IDEMPOTENCY_CONFLICT",
            "REVIEW_INTENT_STORE_LOCKED",
            "QUESTION_POLICY_REVISION_CONFLICT",
            "QUESTION_POLICY_IDEMPOTENCY_CONFLICT",
            "REQUIREMENTS_REVISION_CONFLICT",
          ]);
          const unavailable = new Set([
            "REVIEW_INTENT_STORE_UNSAFE",
            "REVIEW_INTENT_RECORD_CORRUPT",
            "RUN_STORE_UNSAFE",
            "QUESTION_STORE_UNSAFE",
            "DECISION_STORE_UNSAFE",
          ]);
          const authConflicts = new Set([
            "AUTH_SESSION_REVISION_CONFLICT",
            "AUTH_SESSION_STALE",
            "AUTH_MARKER_NOT_CONFIGURED",
            "AUTH_MARKER_NOT_FOUND",
          ]);
          if (conflict.has(caught?.code) || authConflicts.has(caught?.code))
            error(response, 409, caught.code, headOnly);
          else if (caught?.code === "AUTH_SESSION_NOT_CONFIGURED") error(response, 409, caught.code, headOnly);
          else if (caught?.code === "AUTH_SESSION_CAPABILITY_UNAVAILABLE") error(response, 503, caught.code, headOnly);
          else if (caught?.code === "AUTH_SESSION_CLEAR_FAILED") error(response, 503, caught.code, headOnly);
          else if (caught?.code === "ILLEGAL_TRANSITION") error(response, 409, "RUN_STATE_CONFLICT", headOnly);
          else if (caught?.code === "REVIEW_INTENT_SOURCE_MISMATCH") error(response, 409, caught.code, headOnly);
          else if (caught?.code === "REVIEW_INTENT_SOURCE_UNAVAILABLE") error(response, 404, caught.code, headOnly);
          else if (new Set(["NOT_FOUND", "RUN_NOT_FOUND"]).has(caught?.code)) {
            error(response, 404, "RUN_UNAVAILABLE", headOnly);
          } else if (caught?.code === "INVALID_REQUEST") error(response, 400, "INVALID_REQUEST", headOnly);
          else if (unavailable.has(caught?.code)) error(response, 503, "STORE_UNAVAILABLE", headOnly);
          else error(response, 500, "INTERNAL_ERROR", headOnly);
        }
      } else response.destroy();
    }
  });
  server.disposeAuthSessions = async () => sessionService?.dispose?.();
  return server;
}

function allQualifiedStatus(workflow) {
  return workflow.decision.dimensions.qualifications.every((item) => item.status === "Qualified")
    ? "Qualified"
    : "Not qualified";
}

export async function startStudioServer({
  storeRoot,
  registry,
  definitionsRoot,
  workflowPaths,
  projectContext,
  snapshot,
  readProjectSnapshot,
  authSessionService,
  assetRoot,
  port = 0,
  headless = false,
} = {}) {
  const browserBrokerSecret = projectContext ? createUserSessionBrokerSecret() : undefined;
  const { loadStudioAssets } = await import("./studio-assets.js");
  const studioAssets = await loadStudioAssets(assetRoot);
  const server = createStudioServer({
    storeRoot,
    registry,
    definitionsRoot,
    workflowPaths,
    studioAssets,
    projectContext,
    snapshot,
    readProjectSnapshot,
    authSessionService,
    browserBrokerSecret,
    headless,
  });
  try {
    if (browserBrokerSecret) await recoverUserSessionBroker({ storeRoot });
    await new Promise((resolve, reject) => {
      server.once("error", reject);
      server.listen(port, "127.0.0.1", () => {
        server.off("error", reject);
        resolve();
      });
    });
  } catch (error) {
    await server.disposeAuthSessions();
    if (error.code === "EADDRINUSE") {
      throw new WorkflowError(
        "STUDIO_PORT_IN_USE",
        `Studio port ${port} is occupied; use --port auto or choose another port`,
        { exitCode: 3 },
      );
    }
    throw error;
  }
  const address = server.address();
  if (browserBrokerSecret) {
    try {
      await publishUserSessionBroker({
        storeRoot,
        origin: `http://workflows.localhost:${address.port}/`,
        secret: browserBrokerSecret,
      });
    } catch (error) {
      const stopped = new Promise((resolve) => server.close(resolve));
      server.closeAllConnections();
      await stopped;
      await server.disposeAuthSessions();
      throw error;
    }
  }
  let closing;
  const close = () => {
    closing ??= (async () => {
      try {
        const stopped = new Promise((resolve, reject) => server.close((error) => (error ? reject(error) : resolve())));
        // Stop accepting before releasing existing HTTP clients, including incomplete requests.
        server.closeAllConnections();
        await stopped;
      } finally {
        try {
          await server.disposeAuthSessions();
        } finally {
          if (browserBrokerSecret) await removeUserSessionBroker({ storeRoot, secret: browserBrokerSecret });
        }
      }
    })();
    return closing;
  };
  return {
    server,
    port: address.port,
    url: `http://workflows.localhost:${address.port}/`,
    assetManifest: studioAssets.manifest,
    close,
  };
}
