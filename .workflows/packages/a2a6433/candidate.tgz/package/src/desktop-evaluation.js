import { readFile } from "node:fs/promises";
import { resolve } from "node:path";

import { parse as parseYaml } from "yaml";

import { WorkflowError } from "./errors.js";
import { sha256Bytes } from "./evidence.js";
import { verifyCatalogWorkflowSource } from "./project-workflow-catalog.js";
import { catalogProjectWorkflows } from "./project-workflow-catalog.js";
import {
  projectSelectionSnapshot,
  selectVerifiedApplicationTarget,
  selectVerifiedCatalogSource,
} from "./project-surface-snapshot.js";
import { launchPinnedRun, resolveLaunchAuthentication } from "./run-launch.js";
import { RunControlStore } from "./run-control-store.js";
import { resolveWorkflow, validateWorkflowSemantics } from "./workflow.js";
import { resolvePlatformViewport } from "./platform-viewport.js";
import { validateAuthenticatedActions } from "./authenticated-browser-execution.js";
import { verifyRoutineActionReviewAttestation } from "./routine-action-review-attestation.js";

function invalid(message) {
  throw new WorkflowError("ROUTINE_EVALUATION_CONTRACT_REQUIRED", message, { exitCode: 3 });
}

export async function launchRoutineEvaluation({
  workflowPath,
  workflowSource,
  platform,
  applicationTarget,
  targetUrl,
  store,
  registry,
  now,
  projectContext,
  authSessionStore,
  evaluationPerspective,
}) {
  const sourceBytes = workflowSource ? null : await readFile(workflowPath);
  const workflow = workflowSource
    ? registry.validate("workflow", workflowSource.workflow)
    : registry.validate("workflow", parseYaml(sourceBytes.toString("utf8")));
  validateWorkflowSemantics(workflow);
  if (!["desktop-web", "mobile-web"].includes(platform)) {
    invalid("Routine evaluation supports only desktop-web or mobile-web");
  }
  if (workflow.metadata.lifecycle !== "candidate" || !Number.isSafeInteger(workflow.metadata.candidateRevision)) {
    invalid("Routine evaluation requires an exact candidate revision");
  }
  if (!["anonymous", "named-profile"].includes(workflow.target.identity.requirement))
    invalid("Routine evaluation requires an anonymous or named-profile workflow identity");
  if (!workflow.evaluation?.resetStepId || !workflow.evaluation?.cleanupStepId) {
    invalid("Routine evaluation requires reset and cleanup steps");
  }
  for (const step of workflow.steps) {
    if (!step.routineActionBatches?.length) {
      invalid(`Routine evaluation step ${step.id} requires a pinned routine action batch`);
    }
    const identities = step.routineActionBatches.map((batch) => batch.id);
    if (new Set(identities).size !== identities.length) {
      invalid(`Routine evaluation step ${step.id} has duplicate routine action identities`);
    }
    for (const handlerId of step.optionalHandlers ?? []) {
      const handler = workflow.optionalStateHandlers.find((item) => item.id === handlerId);
      const evidence = handler?.evidence;
      if (
        handler?.maxApplications !== 1 ||
        evidence?.length !== 1 ||
        !evidence[0] ||
        typeof evidence[0] !== "object" ||
        evidence[0].type !== "screenshot" ||
        !handler.routineDismissal
      ) {
        invalid(
          `Routine evaluation optional handler ${handlerId} requires one scoped routine dismissal and screenshot`,
        );
      }
    }
    for (const batch of step.routineActionBatches) {
      const hasUpload = batch.actions.some((action) => action.kind === "upload-file");
      if (
        !batch.requestedCapabilities.includes("browser.control") ||
        (hasUpload && !batch.requestedCapabilities.includes("file-upload"))
      )
        invalid(`Routine evaluation step ${step.id} batch ${batch.id} has an invalid capability contract`);
    }
  }
  if (!workflow.target.supportedPlatforms.some((item) => item.id === platform))
    invalid(`Routine evaluation requires ${platform} support`);
  const resolved = resolveWorkflow(workflow, platform, "platform-v2");
  const viewport = resolvePlatformViewport(resolved.workflow, platform);
  if (workflowSource) {
    await verifyCatalogWorkflowSource(workflowSource);
    await store.init();
  }
  const authenticationSession = await resolveLaunchAuthentication({
    identityRequirement: workflow.target.identity.requirement,
    projectContext,
    applicationTarget,
    storeRoot: store.root,
    authSessionStore,
    registry,
  });
  if (workflow.target.identity.requirement === "named-profile" && !authenticationSession)
    invalid("Named-profile routine evaluation requires the configured Studio-owned user session");
  if (
    workflow.steps.some((step) =>
      step.routineActionBatches.some((batch) => batch.actions.some((action) => action.kind === "upload-file")),
    ) &&
    !authenticationSession
  )
    invalid("Routine file upload requires the configured Studio-owned user session");
  if (authenticationSession) {
    for (const step of workflow.steps) {
      for (const batch of step.routineActionBatches) {
        try {
          validateAuthenticatedActions(batch.actions);
        } catch {
          invalid(`Routine evaluation step ${step.id} batch ${batch.id} uses an unsupported authenticated action`);
        }
      }
    }
    await verifyRoutineActionReviewAttestation(store, workflow);
  }
  return launchPinnedRun({
    phase: "evaluation",
    workflow: resolved.workflow,
    workflowRef: {
      id: workflow.metadata.id,
      sourceKind: "candidate",
      candidateRevision: workflow.metadata.candidateRevision,
      sourceBytesHash: workflowSource?.sourceBytesHash ?? sha256Bytes(sourceBytes),
      contentHash: resolved.sourceHash,
      platform,
      effectiveHash: resolved.effectiveHash,
      effectiveHashVersion: resolved.effectiveHashVersion,
    },
    platform,
    profile: platform === "desktop-web" ? "desktop-evaluation" : "mobile-evaluation",
    store,
    now,
    viewport,
    leasePolicyName: "routine-codex-browser-v1",
    requestLaunchApproval: false,
    applicationTarget,
    targetUrl,
    authenticationSession,
    evaluationPerspective,
  });
}

export function launchDesktopEvaluation(options) {
  return launchRoutineEvaluation({ ...options, platform: "desktop-web" });
}

export function launchMobileEvaluation(options) {
  return launchRoutineEvaluation({ ...options, platform: "mobile-web" });
}

/** Launch from one ProjectContext, catalog, and snapshot without exposing a definition path. */
export async function launchSemanticRoutineEvaluation({
  projectContext,
  journey,
  target,
  platform,
  targetUrl,
  storeRoot,
  registry,
  authSessionStore,
  evaluationPerspective,
}) {
  const catalog = await catalogProjectWorkflows(projectContext, { registry });
  const snapshot = await projectSelectionSnapshot(projectContext, {
    binding: "current",
    catalog,
    registry,
    terms: journey,
    targetTerms: target,
  });
  const workflowSource = selectVerifiedCatalogSource(snapshot, catalog);
  const applicationTarget = targetUrl === undefined ? selectVerifiedApplicationTarget(snapshot) : undefined;
  await verifyCatalogWorkflowSource(workflowSource);
  const root = storeRoot ?? resolve(projectContext.projectRoot, ...projectContext.paths.localStore.split("/"));
  const store = new RunControlStore(root, { registry });
  return launchRoutineEvaluation({
    workflowSource,
    platform,
    applicationTarget,
    targetUrl,
    store,
    registry,
    projectContext,
    authSessionStore,
    evaluationPerspective,
  });
}

export const DEFAULT_DESKTOP_EVALUATION_VIEWPORT = Object.freeze({ width: 1440, height: 900 });
export const DEFAULT_MOBILE_EVALUATION_VIEWPORT = Object.freeze({ width: 393, height: 852 });

/** @deprecated A workflow's immutable manifest/slot viewport is authoritative. */
export const DESKTOP_EVALUATION_VIEWPORT = Object.freeze({ ...DEFAULT_DESKTOP_EVALUATION_VIEWPORT });
/** @deprecated A workflow's immutable manifest/slot viewport is authoritative. */
export const MOBILE_EVALUATION_VIEWPORT = Object.freeze({ ...DEFAULT_MOBILE_EVALUATION_VIEWPORT });
