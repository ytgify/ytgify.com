import { randomUUID } from "node:crypto";
import { constants } from "node:fs";
import { link, lstat, mkdir, open, readdir, unlink } from "node:fs/promises";
import { dirname, join, relative, resolve, sep } from "node:path";

import { WorkflowError } from "./errors.js";
import { buildRunReport } from "./run-report.js";
import { sha256 } from "./stable-json.js";

const FINDING_ID = /^finding_[a-f0-9]{32}$/;
const WORKFLOW_ID = /^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$/;
const WRITE_AUTHORITY = Symbol("finding-write-authority");
const LENS_ID = /^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$/;
const SEVERITIES = new Set(["info", "low", "medium", "high", "critical"]);

function fail(code, message) {
  throw new WorkflowError(code, message, { exitCode: 3 });
}

function assertIdentity(pattern, value, label) {
  if (!pattern.test(value)) fail("INVALID_FINDING_ID", `Invalid ${label}`);
}

function assertInside(root, path) {
  const suffix = relative(resolve(root), resolve(path));
  if (suffix.startsWith("..") || resolve(root, suffix) !== resolve(path))
    fail("PATH_TRAVERSAL", "Finding path escapes its root");
}

async function assertDirectory(path) {
  const entry = await lstat(path);
  if (!entry.isDirectory() || entry.isSymbolicLink()) fail("FINDING_STORE_UNSAFE", "Finding paths cannot be symlinks");
}

async function assertSafeAncestry(root, path) {
  assertInside(root, path);
  let cursor = resolve(root);
  await assertDirectory(cursor);
  for (const part of relative(cursor, resolve(path)).split(sep).filter(Boolean)) {
    cursor = join(cursor, part);
    try {
      const entry = await lstat(cursor);
      if (entry.isSymbolicLink()) fail("FINDING_STORE_UNSAFE", "Finding path ancestry cannot contain symlinks");
      if (cursor !== resolve(path) && !entry.isDirectory())
        fail("FINDING_STORE_UNSAFE", "Finding path ancestry must contain only directories");
    } catch (error) {
      if (error.code === "ENOENT") break;
      throw error;
    }
  }
}

async function syncDirectory(path) {
  const handle = await open(path, "r");
  try {
    await handle.sync();
  } finally {
    await handle.close();
  }
}

async function readRegular(path) {
  await assertDirectory(dirname(path));
  const entry = await lstat(path);
  if (!entry.isFile() || entry.isSymbolicLink()) fail("FINDING_RECORD_CORRUPT", "Finding is not a regular file");
  const handle = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    const opened = await handle.stat();
    if (opened.dev !== entry.dev || opened.ino !== entry.ino || opened.size !== entry.size)
      fail("FINDING_RECORD_CORRUPT", "Finding changed while being read");
    return await handle.readFile("utf8");
  } finally {
    await handle.close();
  }
}

async function immutableWrite(path, bytes) {
  const temporary = `${path}.${randomUUID()}.tmp`;
  const handle = await open(temporary, "wx", 0o600);
  try {
    await handle.writeFile(bytes);
    await handle.sync();
  } finally {
    await handle.close();
  }
  try {
    await link(temporary, path);
    await syncDirectory(dirname(path));
  } catch (error) {
    if (error.code === "EEXIST") fail("IMMUTABLE_FINDING_EXISTS", "Finding records cannot be replaced");
    throw error;
  } finally {
    await unlink(temporary).catch(() => {});
  }
}

export class FindingStore {
  constructor(root, { registry } = {}) {
    this.root = resolve(root);
    this.findingsRoot = join(this.root, "findings");
    this.registry = registry;
  }

  async init() {
    await mkdir(this.root, { recursive: true });
    await assertDirectory(this.root);
    await mkdir(this.findingsRoot, { recursive: true });
    await assertDirectory(this.findingsRoot);
    return this;
  }

  workflowRoot(workflowId) {
    assertIdentity(WORKFLOW_ID, workflowId, "workflow ID");
    const path = resolve(this.findingsRoot, workflowId);
    assertInside(this.findingsRoot, path);
    return path;
  }

  recordPath(workflowId, findingId) {
    assertIdentity(FINDING_ID, findingId, "finding ID");
    const root = this.workflowRoot(workflowId);
    const path = resolve(root, `${findingId}.json`);
    assertInside(root, path);
    return path;
  }

  async writeFinding(record, authority) {
    if (authority !== WRITE_AUTHORITY) fail("FINDING_WRITE_FORBIDDEN", "Findings require a verified run-note boundary");
    this.registry?.validate("finding", record);
    const root = this.workflowRoot(record.workflowId);
    await assertSafeAncestry(this.findingsRoot, root);
    await mkdir(root).catch((error) => {
      if (error.code !== "EEXIST") throw error;
    });
    await assertDirectory(root);
    const path = this.recordPath(record.workflowId, record.findingId);
    await assertSafeAncestry(this.findingsRoot, path);
    await immutableWrite(path, Buffer.from(`${JSON.stringify(record, null, 2)}\n`));
    return structuredClone(record);
  }

  async readFinding(workflowId, findingId) {
    const path = this.recordPath(workflowId, findingId);
    await assertSafeAncestry(this.findingsRoot, path);
    let record;
    try {
      record = JSON.parse(await readRegular(path));
    } catch (error) {
      if (error instanceof SyntaxError) fail("FINDING_RECORD_CORRUPT", "Finding is invalid JSON");
      throw error;
    }
    this.registry?.validate("finding", record);
    if (record.workflowId !== workflowId || record.findingId !== findingId)
      fail("FINDING_ID_MISMATCH", "Finding path does not match record identity");
    return record;
  }

  async listFindingIds(workflowId) {
    const root = this.workflowRoot(workflowId);
    try {
      await assertSafeAncestry(this.findingsRoot, root);
      await assertDirectory(root);
    } catch (error) {
      if (error.code === "ENOENT") return [];
      throw error;
    }
    return (await readdir(root))
      .filter((name) => /^finding_[a-f0-9]{32}\.json$/.test(name))
      .sort()
      .map((name) => name.slice(0, -5));
  }
}

function requiredText(value, label, maxLength) {
  if (typeof value !== "string" || !value.trim() || value.length > maxLength)
    throw new TypeError(`${label} is invalid`);
  return value.trim();
}

export async function recordFindingFromRunNote({
  findingStore,
  runStore,
  runId,
  stepId,
  noteIndex,
  lens,
  severity,
  title,
  recommendation,
}) {
  if (!Number.isSafeInteger(noteIndex) || noteIndex < 0) throw new TypeError("noteIndex is invalid");
  if (!LENS_ID.test(lens?.id ?? "")) throw new TypeError("lens.id is invalid");
  if (!SEVERITIES.has(severity)) throw new TypeError("severity is invalid");
  const [run, report] = await Promise.all([
    runStore.readRun(runId),
    buildRunReport(runStore, runId, { skipPerspective: true }),
  ]);
  const reportStep = report.steps.find((step) => step.id === stepId);
  const workflowStep = run.workflow?.steps?.find((step) => step.id === stepId);
  const note = reportStep?.notes?.[noteIndex];
  if (!reportStep || !workflowStep || !note) throw new TypeError("Finding source note is unavailable");
  const referencedEvidence = Array.isArray(note.evidence) && note.evidence.length ? new Set(note.evidence) : null;
  const findingEvidence = referencedEvidence
    ? reportStep.evidence.filter((artifact) => referencedEvidence.has(artifact.artifactId))
    : reportStep.evidence;
  if (referencedEvidence && findingEvidence.length !== referencedEvidence.size) {
    throw new TypeError("Finding source note references unavailable evidence");
  }
  const workflowId = report.workflow.id;
  const promotedRevision = run.manifest.workflowRef?.revision;
  const candidateRevision = run.manifest.workflowRef?.candidateRevision ?? run.workflow?.metadata?.candidateRevision;
  if (!promotedRevision && !Number.isSafeInteger(candidateRevision)) {
    throw new TypeError("Finding source revision is unavailable");
  }
  const workflowRevision = promotedRevision ?? `candidate-r${candidateRevision}`;
  const findingId = `finding_${sha256({ workflowId, runId, stepId, noteIndex, lensId: lens.id }).slice(7, 39)}`;
  const record = {
    schema: "agent-workflow-finding/v1",
    findingId,
    workflowId,
    workflowRevision,
    runId,
    ...(run.manifest.evaluationGroupId ? { evaluationGroupId: run.manifest.evaluationGroupId } : {}),
    platform: report.platform,
    step: {
      id: workflowStep.id,
      name: workflowStep.name,
      action: workflowStep.action,
      expected: structuredClone(workflowStep.expected),
    },
    source: {
      noteIndex,
      kind: note.kind,
      text: note.text,
      reportHash: sha256(report),
    },
    lens: { id: lens.id, label: requiredText(lens.label, "lens.label", 80) },
    severity,
    status: "open",
    title: requiredText(title, "title", 200),
    summary: note.text,
    recommendation: requiredText(recommendation, "recommendation", 4000),
    evidence: findingEvidence.map((artifact) => ({
      artifactId: artifact.artifactId,
      contentHash: artifact.contentHash,
      checkpoint: artifact.checkpoint,
      integrityAtCreation: artifact.integrity,
    })),
    createdAt: reportStep.completedAt ?? report.timestamps.completedAt ?? report.timestamps.createdAt,
  };
  try {
    return await findingStore.writeFinding(record, WRITE_AUTHORITY);
  } catch (error) {
    if (error.code !== "IMMUTABLE_FINDING_EXISTS") throw error;
    const existing = await findingStore.readFinding(workflowId, findingId);
    if (sha256(existing) !== sha256(record)) throw error;
    return existing;
  }
}
