import { readFile } from "node:fs/promises";
import { resolve } from "node:path";

import { FindingRelationStore, relateFindings } from "./finding-relations.js";
import { FindingVerificationStore, recordFindingVerification } from "./finding-verification.js";
import {
  FindingVerificationContractStore,
  recordFindingVerificationContract,
} from "./finding-verification-contracts.js";
import { WorkflowError } from "./errors.js";
import { FindingStore, recordFindingFromRunNote } from "./finding-store.js";
import { FindingResolutionStore, recordFindingResolution } from "./finding-resolution-store.js";
import { RunControlStore } from "./run-control-store.js";
import { projectStudioFindings } from "./studio-findings.js";

function success(command, data) {
  return { ok: true, command, data, warnings: [] };
}

async function readStandardInput() {
  let input = "";
  for await (const chunk of process.stdin) input += chunk;
  return input;
}

async function readInput(flags) {
  const text = flags.get("file") ? await readFile(resolve(flags.get("file")), "utf8") : await readStandardInput();
  if (!text.trim()) {
    throw new WorkflowError("INVALID_USAGE", "findings create requires JSON on stdin or --file", { exitCode: 2 });
  }
  try {
    return JSON.parse(text);
  } catch (error) {
    throw new WorkflowError("INVALID_JSON", "Could not parse finding input JSON", {
      exitCode: 2,
      details: { cause: error.message },
    });
  }
}

function stores(flags, registry) {
  const root = resolve(flags.get("store") ?? ".workflows/local");
  return {
    verificationStore: new FindingVerificationStore(root, { registry }),
    relationStore: new FindingRelationStore(root, { registry }),
    contractStore: new FindingVerificationContractStore(root, { registry }),
    findingStore: new FindingStore(root, { registry }),
    resolutionStore: new FindingResolutionStore(root, { registry }),
    runStore: new RunControlStore(root, { registry }),
  };
}

export function isFindingSourceRun(run) {
  return run.manifest.phase === "evaluation" && ["completed", "failed"].includes(run.state.status);
}

async function createFinding(runId, flags, registry, findingStore, resolutionStore, runStore, contractStore) {
  const run = await runStore.readRun(runId);
  if (!isFindingSourceRun(run)) {
    throw new WorkflowError(
      "FINDING_SOURCE_NOT_COMPLETED_EVALUATION",
      "Findings can be created only from a terminal completed or failed evaluation run",
      { exitCode: 3 },
    );
  }
  const input = registry.validate("findingInput", await readInput(flags));
  await findingStore.init();
  let record;
  try {
    record = await recordFindingFromRunNote({
      findingStore,
      runStore,
      runId,
      stepId: input.stepId,
      noteIndex: input.noteIndex,
      lens: input.lens,
      severity: input.severity,
      title: input.title,
      recommendation: input.recommendation,
    });
  } catch (error) {
    if (!(error instanceof TypeError)) throw error;
    throw new WorkflowError("FINDING_SOURCE_INVALID", error.message, { exitCode: 3 });
  }
  if (input.verification) {
    await contractStore.init();
    await recordFindingVerificationContract({
      findingStore,
      contractStore,
      workflowId: record.workflowId,
      findingId: record.findingId,
      criteria: input.verification.criteria,
    });
  }
  const projected = await projectStudioFindings(
    runStore,
    findingStore,
    record.workflowId,
    resolutionStore,
    contractStore,
  );
  return success("findings create", {
    finding: projected.findings.find((item) => item.findingId === record.findingId),
  });
}

export async function executeFindingsCommand(args, flags, registry) {
  const [operation, first, second] = args;
  const allowed = ["create", "verification", "relate"].includes(operation)
    ? ["store", "json", "file"]
    : operation === "verify"
      ? ["store", "json", "run", "file"]
      : operation === "resolve"
        ? ["store", "json", "desktop-run", "mobile-run", "commit", "verification"]
        : ["store", "json"];
  if (!operation || [...flags.keys()].some((name) => !allowed.includes(name))) {
    throw new WorkflowError("INVALID_USAGE", "findings accepts create, list, or show with documented flags", {
      exitCode: 2,
    });
  }
  const { findingStore, resolutionStore, runStore, contractStore, verificationStore, relationStore } = stores(
    flags,
    registry,
  );
  if (operation === "create") {
    if (!first || second || args.length !== 2) {
      throw new WorkflowError("INVALID_USAGE", "findings create requires RUN_ID", { exitCode: 2 });
    }
    return createFinding(first, flags, registry, findingStore, resolutionStore, runStore, contractStore);
  }
  if (operation === "relate") {
    if (!first || args.length !== 2)
      throw new WorkflowError("INVALID_USAGE", "findings relate requires WORKFLOW_ID and --file", { exitCode: 2 });
    const input = await readInput(flags);
    if (!input || Object.keys(input).some((key) => !["findingIds", "reason"].includes(key)))
      throw new WorkflowError("INVALID_USAGE", "Relation accepts findingIds and reason", { exitCode: 2 });
    await relationStore.init();
    return success("findings relate", {
      relation: await relateFindings({ ...input, relationStore, findingStore, workflowId: first }),
    });
  }
  if (operation === "verify") {
    if (!first || !second || args.length !== 3 || !flags.get("run"))
      throw new WorkflowError(
        "INVALID_USAGE",
        "findings verify requires WORKFLOW_ID FINDING_ID --run RUN_ID --file PATH",
        { exitCode: 2 },
      );
    const input = await readInput(flags);
    if (!input || Object.keys(input).some((key) => key !== "checks"))
      throw new WorkflowError("INVALID_USAGE", "Verification accepts checks only", { exitCode: 2 });
    const finding = await findingStore.readFinding(first, second);
    const contract = await contractStore.readContract(first, second);
    await verificationStore.init();
    return success("findings verify", {
      verification: await recordFindingVerification({
        runStore,
        verificationStore,
        finding,
        contract,
        runId: flags.get("run"),
        checks: input.checks,
      }),
    });
  }
  if (operation === "verification") {
    if (!first || !second || args.length !== 3)
      throw new WorkflowError("INVALID_USAGE", "findings verification requires WORKFLOW_ID and FINDING_ID", {
        exitCode: 2,
      });
    const input = await readInput(flags);
    if (!input || Object.keys(input).some((key) => key !== "criteria"))
      throw new WorkflowError("INVALID_USAGE", "Verification input accepts criteria only", { exitCode: 2 });
    await contractStore.init();
    const contract = await recordFindingVerificationContract({
      findingStore,
      contractStore,
      workflowId: first,
      findingId: second,
      criteria: input.criteria,
    });
    return success("findings verification", { contract });
  }
  if (operation === "resolve") {
    if (!first || !second || args.length !== 3) {
      throw new WorkflowError("INVALID_USAGE", "findings resolve requires WORKFLOW_ID and FINDING_ID", {
        exitCode: 2,
      });
    }
    if (!flags.get("desktop-run") || !flags.get("mobile-run") || !flags.get("commit")) {
      throw new WorkflowError("INVALID_USAGE", "findings resolve requires --desktop-run, --mobile-run, and --commit", {
        exitCode: 2,
      });
    }
    if (!flags.get("verification"))
      throw new WorkflowError(
        "INVALID_USAGE",
        "findings resolve requires --verification PATH containing targeted receipt IDs",
        { exitCode: 2 },
      );
    const ids = await readInput(new Map([["file", flags.get("verification")]]));
    if (!Array.isArray(ids) || !ids.length || ids.some((id) => typeof id !== "string"))
      throw new WorkflowError("INVALID_USAGE", "Verification file must contain a nonempty array of receipt IDs", {
        exitCode: 2,
      });
    const contract = await contractStore.readContract(first, second);
    const targetedVerification = await Promise.all(ids.map((id) => verificationStore.readReceipt(first, second, id)));
    await resolutionStore.init();
    let resolution;
    try {
      resolution = await recordFindingResolution({
        resolutionStore,
        findingStore,
        runStore,
        workflowId: first,
        findingId: second,
        desktopRunId: flags.get("desktop-run"),
        mobileRunId: flags.get("mobile-run"),
        implementationCommit: flags.get("commit"),
        contract,
        targetedVerification,
      });
    } catch (error) {
      if (!(error instanceof TypeError)) throw error;
      throw new WorkflowError("RESOLUTION_INPUT_INVALID", error.message, { exitCode: 3 });
    }
    const projected = await projectStudioFindings(runStore, findingStore, first, resolutionStore, contractStore);
    return success("findings resolve", {
      resolution,
      finding: projected.findings.find((item) => item.findingId === second),
    });
  }
  if (operation === "list") {
    if (!first || second || args.length !== 2) {
      throw new WorkflowError("INVALID_USAGE", "findings list requires WORKFLOW_ID", { exitCode: 2 });
    }
    return success("findings list", {
      workflowId: first,
      ...(await projectStudioFindings(runStore, findingStore, first, resolutionStore, contractStore)),
    });
  }
  if (operation === "show") {
    if (!first || !second || args.length !== 3) {
      throw new WorkflowError("INVALID_USAGE", "findings show requires WORKFLOW_ID and FINDING_ID", {
        exitCode: 2,
      });
    }
    const projected = await projectStudioFindings(runStore, findingStore, first, resolutionStore, contractStore);
    const finding = projected.findings.find((item) => item.findingId === second);
    if (!finding) throw new WorkflowError("FINDING_NOT_FOUND", "Finding is unavailable", { exitCode: 3 });
    return success("findings show", { finding });
  }
  throw new WorkflowError("INVALID_USAGE", `Unknown findings operation: ${operation}`, { exitCode: 2 });
}
