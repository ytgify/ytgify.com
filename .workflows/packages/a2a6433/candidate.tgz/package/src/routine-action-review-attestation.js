import { constants } from "node:fs";
import { mkdir, open, unlink } from "node:fs/promises";
import { join } from "node:path";

import { WorkflowError } from "./errors.js";
import { assertSafeProjectPath } from "./project-path-safety.js";
import { exportSupervisedRoutineActions } from "./routine-action-review-contract.js";
import { sha256 } from "./stable-json.js";

function invalid(message) {
  throw new WorkflowError("ROUTINE_ACTION_REVIEW_REQUIRED", message, { exitCode: 3 });
}

function pathsFor(runStore, contentHash) {
  if (!/^sha256:[a-f0-9]{64}$/u.test(contentHash ?? "")) invalid("Invalid reviewed workflow hash");
  const directory = join(runStore.root, "routine-action-reviews");
  return { directory, record: join(directory, `${contentHash.slice("sha256:".length)}.json`) };
}

async function readNoFollow(path) {
  const handle = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    return JSON.parse(await handle.readFile("utf8"));
  } finally {
    await handle.close();
  }
}

function routineActionReviewRecord(workflow, review, now = () => new Date()) {
  const contentHash = sha256(workflow);
  return {
    schema: "agent-workflow-routine-action-attestation/v1",
    workflowId: workflow.metadata.id,
    candidateRevision: workflow.metadata.candidateRevision,
    contentHash,
    sourceRunId: review.source.runId,
    reviewedDocumentHash: sha256(review),
    batches: review.batches.map(({ stepId, leaseId, actionHash }) => ({ stepId, leaseId, actionHash })),
    recordedAt: now().toISOString(),
  };
}

/** Persist the exact output/review binding. Only the reviewed apply path calls this writer. */
export async function writeRoutineActionReviewAttestation(runStore, workflow, review, now) {
  const record = routineActionReviewRecord(workflow, review, now);
  const paths = pathsFor(runStore, record.contentHash);
  await assertSafeProjectPath(runStore.root, paths.directory, "Routine action review directory", {
    finalType: "directory",
    allowMissing: true,
  });
  await mkdir(paths.directory, { recursive: true });
  await assertSafeProjectPath(runStore.root, paths.directory, "Routine action review directory", {
    finalType: "directory",
    allowMissing: false,
  });
  await assertSafeProjectPath(runStore.root, paths.record, "Routine action review attestation", {
    finalType: "file",
    allowMissing: true,
  });
  const handle = await open(
    paths.record,
    constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW,
    0o600,
  );
  let complete = false;
  try {
    await handle.writeFile(`${JSON.stringify(record, null, 2)}\n`);
    await handle.sync();
    complete = true;
  } finally {
    await handle.close();
    if (!complete) await unlink(paths.record).catch(() => {});
  }
  const directory = await open(paths.directory, constants.O_RDONLY);
  try {
    await directory.sync();
  } finally {
    await directory.close();
  }
  return record;
}

/** Require a durable apply receipt before authenticated candidate evaluation can launch. */
export async function verifyRoutineActionReviewAttestation(runStore, workflow) {
  const contentHash = sha256(workflow);
  const paths = pathsFor(runStore, contentHash);
  await assertSafeProjectPath(runStore.root, paths.record, "Routine action review attestation", {
    finalType: "file",
    allowMissing: true,
  });
  let record;
  try {
    record = await readNoFollow(paths.record);
  } catch (error) {
    if (error.code === "ENOENT") invalid("Authenticated routine evaluation requires a reviewed batch attestation");
    throw error;
  }
  const expectedWorkflowBatches = workflow.steps.flatMap((step) =>
    step.routineActionBatches.map((batch) => ({
      stepId: step.id,
      actionHash: sha256({ actions: batch.actions, requestedCapabilities: batch.requestedCapabilities }),
    })),
  );
  if (
    record?.schema !== "agent-workflow-routine-action-attestation/v1" ||
    record.workflowId !== workflow.metadata.id ||
    record.candidateRevision !== workflow.metadata.candidateRevision ||
    record.contentHash !== contentHash ||
    !/^run_[A-Za-z0-9_-]+$/u.test(record.sourceRunId ?? "") ||
    !/^sha256:[a-f0-9]{64}$/u.test(record.reviewedDocumentHash ?? "") ||
    !Array.isArray(record.batches) ||
    record.batches.length !== expectedWorkflowBatches.length ||
    record.batches.some((actual) => !/^lease_[A-Za-z0-9_-]+$/u.test(actual.leaseId ?? "")) ||
    JSON.stringify(record.batches.map(({ stepId, actionHash }) => ({ stepId, actionHash }))) !==
      JSON.stringify(expectedWorkflowBatches)
  )
    invalid("Reviewed batch attestation does not match this exact candidate workflow");
  let expectedReview;
  try {
    expectedReview = await exportSupervisedRoutineActions({ runStore, runId: record.sourceRunId });
  } catch {
    invalid("Reviewed batch attestation source Training run is unavailable or no longer clean");
  }
  const expectedLineage = expectedReview.batches.map(({ stepId, leaseId, actionHash }) => ({
    stepId,
    leaseId,
    actionHash,
  }));
  if (
    record.reviewedDocumentHash !== sha256({ ...expectedReview, reviewed: true }) ||
    JSON.stringify(record.batches) !== JSON.stringify(expectedLineage)
  )
    invalid("Reviewed batch attestation does not match its durable supervised Training source");
  return record;
}
