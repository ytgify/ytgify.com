import { randomUUID } from "node:crypto";
import { constants } from "node:fs";
import { link, lstat, mkdir, open, readdir, unlink } from "node:fs/promises";
import { dirname, join, relative, resolve, sep } from "node:path";

import { WorkflowError } from "./errors.js";
import { verifyFindingVerificationContract } from "./finding-verification-contracts.js";
import { verifyFindingCorrection } from "./finding-verification.js";
import { buildRunReport } from "./run-report.js";
import { sha256 } from "./stable-json.js";

const RESOLUTION_ID = /^resolution_[a-f0-9]{32}$/;
const FINDING_ID = /^finding_[a-f0-9]{32}$/;
const WORKFLOW_ID = /^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$/;
const COMMIT = /^[a-f0-9]{40}$/;
const TERMINAL = new Set(["completed", "failed", "blocked", "abandoned"]);
const FORBIDDEN_EVENTS = new Set([
  "approval.requested",
  "approval.recorded",
  "action.rejected",
  "run.pause_requested",
  "run.paused",
  "run.resumed",
  "run.emergency_stopped",
  "reconciliation.completed",
  "run.abandoned",
]);
const WRITE_AUTHORITY = Symbol("finding-resolution-write-authority");

function fail(code, message) {
  throw new WorkflowError(code, message, { exitCode: 3 });
}

function assertIdentity(pattern, value, label) {
  if (!pattern.test(value)) fail("INVALID_RESOLUTION_ID", `Invalid ${label}`);
}

function assertInside(root, path) {
  const suffix = relative(resolve(root), resolve(path));
  if (suffix.startsWith("..") || resolve(root, suffix) !== resolve(path))
    fail("PATH_TRAVERSAL", "Resolution path escapes its root");
}

async function assertDirectory(path) {
  const entry = await lstat(path);
  if (!entry.isDirectory() || entry.isSymbolicLink())
    fail("RESOLUTION_STORE_UNSAFE", "Resolution paths cannot be symlinks");
}

async function assertSafeAncestry(root, path) {
  assertInside(root, path);
  let cursor = resolve(root);
  await assertDirectory(cursor);
  for (const part of relative(cursor, resolve(path)).split(sep).filter(Boolean)) {
    cursor = join(cursor, part);
    try {
      const entry = await lstat(cursor);
      if (entry.isSymbolicLink()) fail("RESOLUTION_STORE_UNSAFE", "Resolution ancestry cannot contain symlinks");
      if (cursor !== resolve(path) && !entry.isDirectory())
        fail("RESOLUTION_STORE_UNSAFE", "Resolution ancestry must contain only directories");
    } catch (error) {
      if (error.code === "ENOENT") break;
      throw error;
    }
  }
}

async function syncDirectory(path) {
  const handle = await open(path, "r");
  try {
    await handle.sync();
  } finally {
    await handle.close();
  }
}

async function readRegular(path) {
  await assertDirectory(dirname(path));
  const entry = await lstat(path);
  if (!entry.isFile() || entry.isSymbolicLink()) fail("RESOLUTION_RECORD_CORRUPT", "Resolution is not a file");
  const handle = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    const opened = await handle.stat();
    if (opened.dev !== entry.dev || opened.ino !== entry.ino || opened.size !== entry.size)
      fail("RESOLUTION_RECORD_CORRUPT", "Resolution changed while being read");
    return await handle.readFile("utf8");
  } finally {
    await handle.close();
  }
}

async function immutableWrite(path, bytes) {
  const temporary = `${path}.${randomUUID()}.tmp`;
  const handle = await open(temporary, "wx", 0o600);
  try {
    await handle.writeFile(bytes);
    await handle.sync();
  } finally {
    await handle.close();
  }
  try {
    await link(temporary, path);
    await syncDirectory(dirname(path));
  } catch (error) {
    if (error.code === "EEXIST") fail("IMMUTABLE_RESOLUTION_EXISTS", "Resolution records cannot be replaced");
    throw error;
  } finally {
    await unlink(temporary).catch(() => {});
  }
}

export class FindingResolutionStore {
  constructor(root, { registry } = {}) {
    this.root = resolve(root);
    this.resolutionsRoot = join(this.root, "resolutions");
    this.registry = registry;
  }

  async init() {
    await mkdir(this.root, { recursive: true });
    await assertDirectory(this.root);
    await mkdir(this.resolutionsRoot, { recursive: true });
    await assertDirectory(this.resolutionsRoot);
    return this;
  }

  findingRoot(workflowId, findingId) {
    assertIdentity(WORKFLOW_ID, workflowId, "workflow ID");
    assertIdentity(FINDING_ID, findingId, "finding ID");
    const path = resolve(this.resolutionsRoot, workflowId, findingId);
    assertInside(this.resolutionsRoot, path);
    return path;
  }

  recordPath(workflowId, findingId, resolutionId) {
    assertIdentity(RESOLUTION_ID, resolutionId, "resolution ID");
    const root = this.findingRoot(workflowId, findingId);
    const path = resolve(root, `${resolutionId}.json`);
    assertInside(root, path);
    return path;
  }

  async writeResolution(record, authority) {
    if (authority !== WRITE_AUTHORITY)
      fail("RESOLUTION_WRITE_FORBIDDEN", "Resolutions require independently verified evaluation runs");
    this.registry?.validate("findingResolution", record);
    const root = this.findingRoot(record.workflowId, record.findingId);
    await assertSafeAncestry(this.resolutionsRoot, root);
    await mkdir(root, { recursive: true });
    await assertDirectory(root);
    const path = this.recordPath(record.workflowId, record.findingId, record.resolutionId);
    await assertSafeAncestry(this.resolutionsRoot, path);
    await immutableWrite(path, Buffer.from(`${JSON.stringify(record, null, 2)}\n`));
    return structuredClone(record);
  }

  async readResolution(workflowId, findingId, resolutionId) {
    const path = this.recordPath(workflowId, findingId, resolutionId);
    await assertSafeAncestry(this.resolutionsRoot, path);
    let record;
    try {
      record = JSON.parse(await readRegular(path));
    } catch (error) {
      if (error instanceof SyntaxError) fail("RESOLUTION_RECORD_CORRUPT", "Resolution is invalid JSON");
      throw error;
    }
    this.registry?.validate("findingResolution", record);
    if (record.workflowId !== workflowId || record.findingId !== findingId || record.resolutionId !== resolutionId)
      fail("RESOLUTION_ID_MISMATCH", "Resolution path does not match its identity");
    return record;
  }

  async listResolutionIds(workflowId, findingId) {
    const root = this.findingRoot(workflowId, findingId);
    try {
      await assertSafeAncestry(this.resolutionsRoot, root);
      await assertDirectory(root);
    } catch (error) {
      if (error.code === "ENOENT") return [];
      throw error;
    }
    return (await readdir(root))
      .filter((name) => /^resolution_[a-f0-9]{32}\.json$/.test(name))
      .sort()
      .map((name) => name.slice(0, -5));
  }
}

function evidenceSnapshot(report) {
  return report.steps.flatMap((step) =>
    step.evidence.map((artifact) => ({
      artifactId: artifact.artifactId,
      contentHash: artifact.contentHash,
      checkpoint: artifact.checkpoint,
      stepId: step.id,
    })),
  );
}

function cleanCommittedResults(run) {
  return run.events
    .filter((event) => event.type === "action.committed")
    .every(
      (event) =>
        event.payload.result?.unexpectedStates?.length === 0 &&
        event.payload.result?.uncertainty?.length === 0 &&
        event.payload.assessment?.proposedOutcome === "passed",
    );
}

async function verifyEvaluation(runStore, runId, platform, workflowId) {
  const [run, report] = await Promise.all([
    runStore.readRun(runId),
    buildRunReport(runStore, runId, { skipPerspective: true }),
  ]);
  const ref = run.manifest.workflowRef;
  const clean =
    run.manifest.phase === "evaluation" &&
    run.manifest.platform === platform &&
    ref?.sourceKind === "candidate" &&
    Number.isSafeInteger(ref.candidateRevision) &&
    report.workflow.id === workflowId &&
    report.status === "completed" &&
    report.outcome === "passed" &&
    report.cleanupOutcome === "passed" &&
    report.integrity.overall === "verified" &&
    run.state.tainted !== true &&
    report.steps.every((step) => step.outcome === "passed" && step.attempts === 1) &&
    !run.events.some((event) => FORBIDDEN_EVENTS.has(event.type)) &&
    run.events.filter((event) => event.type === "host.claimed").length === 1 &&
    cleanCommittedResults(run) &&
    TERMINAL.has(run.state.status);
  if (!clean) fail("RESOLUTION_PROOF_INVALID", `${platform} run is not clean verified evaluation proof`);
  return {
    run,
    report,
    snapshot: {
      platform,
      runId,
      reportHash: sha256(report),
      effectiveHash: report.workflow.effectiveHash,
      completedAt: report.timestamps.completedAt,
      evidence: evidenceSnapshot(report),
    },
  };
}

async function verifyFindingSource(runStore, finding) {
  const [run, report] = await Promise.all([
    runStore.readRun(finding.runId),
    buildRunReport(runStore, finding.runId, { skipPerspective: true }),
  ]);
  const step = run.workflow?.steps?.find((item) => item.id === finding.step.id);
  const reportStep = report.steps.find((item) => item.id === finding.step.id);
  const note = reportStep?.notes?.[finding.source.noteIndex];
  const evidence = new Map(reportStep?.evidence.map((item) => [item.artifactId, item]) ?? []);
  const valid =
    report.workflow.id === finding.workflowId &&
    report.platform === finding.platform &&
    sha256(report) === finding.source.reportHash &&
    note?.kind === finding.source.kind &&
    note?.text === finding.source.text &&
    step &&
    sha256(finding.step) === sha256({ id: step.id, name: step.name, action: step.action, expected: step.expected }) &&
    finding.evidence.every((item) => {
      const current = evidence.get(item.artifactId);
      return (
        current?.contentHash === item.contentHash &&
        current.checkpoint === item.checkpoint &&
        current.integrity === "verified"
      );
    });
  if (!valid) fail("RESOLUTION_SOURCE_INVALID", "Finding source no longer independently verifies");
}

export async function recordFindingResolution({
  resolutionStore,
  findingStore,
  runStore,
  workflowId,
  findingId,
  desktopRunId,
  mobileRunId,
  implementationCommit,
  contract,
  targetedVerification,
}) {
  if (!COMMIT.test(implementationCommit ?? "")) throw new TypeError("implementationCommit is invalid");
  const finding = await findingStore.readFinding(workflowId, findingId);
  await verifyFindingSource(runStore, finding);
  if (!contract || !Array.isArray(targetedVerification) || targetedVerification.length === 0)
    fail(
      "RESOLUTION_CORRECTION_VERIFICATION_REQUIRED",
      "New resolutions require a finding-specific correction contract and targeted verification proof",
    );
  verifyFindingVerificationContract(finding, contract);
  for (const receipt of targetedVerification) await verifyFindingCorrection({ runStore, finding, contract, receipt });
  const [desktop, mobile] = await Promise.all([
    verifyEvaluation(runStore, desktopRunId, "desktop-web", workflowId),
    verifyEvaluation(runStore, mobileRunId, "mobile-web", workflowId),
  ]);
  const desktopRef = desktop.run.manifest.workflowRef;
  const mobileRef = mobile.run.manifest.workflowRef;
  const sourceRevision = /^candidate-r([1-9][0-9]*)$/.exec(finding.workflowRevision);
  if (!sourceRevision) fail("RESOLUTION_SOURCE_REVISION_UNSUPPORTED", "Resolution v1 requires a candidate finding");
  if (
    desktopRef.candidateRevision !== mobileRef.candidateRevision ||
    desktopRef.sourceBytesHash !== mobileRef.sourceBytesHash ||
    desktopRef.contentHash !== mobileRef.contentHash ||
    desktopRef.candidateRevision <= Number(sourceRevision[1])
  )
    fail("RESOLUTION_PROOF_MISMATCH", "Verification runs must prove the same newer candidate revision");
  const requiredPlatforms = new Set(contract.criteria.flatMap((criterion) => criterion.applicablePlatforms));
  const targetedByPlatform = new Map(targetedVerification.map((receipt) => [receipt.run.platform, receipt]));
  if ([...requiredPlatforms].some((platform) => !targetedByPlatform.has(platform)))
    fail("RESOLUTION_CORRECTION_COVERAGE_INCOMPLETE", "Targeted verification does not cover every applicable platform");
  for (const receipt of targetedVerification) {
    if (
      receipt.run.candidateRevision !== desktopRef.candidateRevision ||
      receipt.run.sourceBytesHash !== desktopRef.sourceBytesHash ||
      receipt.run.contentHash !== desktopRef.contentHash ||
      receipt.checks.some((check) => check.assessment.implementationCommit !== implementationCommit)
    )
      fail(
        "RESOLUTION_CORRECTION_IDENTITY_MISMATCH",
        "Targeted and full verification must use the same corrected candidate and implementation identity",
      );
  }
  const latestTargeted = targetedVerification
    .flatMap((receipt) => [receipt.run.completedAt, receipt.recordedAt])
    .sort()
    .at(-1);
  const earliestFull = [desktop.report.timestamps.createdAt, mobile.report.timestamps.createdAt].sort()[0];
  if (!latestTargeted || !earliestFull || new Date(latestTargeted) >= new Date(earliestFull))
    fail("RESOLUTION_CORRECTION_ORDER_INVALID", "Targeted correction proof must be followed by fresh full evaluations");
  const identity = {
    workflowId,
    findingId,
    implementationCommit,
    desktopRunId,
    mobileRunId,
    contractHash: contract.contractHash,
    targetedReceiptHashes: targetedVerification.map((receipt) => receipt.receiptHash).sort(),
  };
  const record = {
    schema: "agent-workflow-finding-resolution/v2",
    resolutionId: `resolution_${sha256(identity).slice(7, 39)}`,
    findingId,
    workflowId,
    source: { runId: finding.runId, reportHash: finding.source.reportHash },
    fix: {
      candidateRevision: desktopRef.candidateRevision,
      sourceBytesHash: desktopRef.sourceBytesHash,
      contentHash: desktopRef.contentHash,
      implementationCommit,
    },
    verification: [desktop.snapshot, mobile.snapshot],
    correction: {
      contractHash: contract.contractHash,
      findingHash: contract.findingHash,
      targetedVerification: structuredClone(targetedVerification),
    },
    status: "verified-resolved",
    createdAt: [desktop.report.timestamps.completedAt, mobile.report.timestamps.completedAt].sort().at(-1),
  };
  try {
    return await resolutionStore.writeResolution(record, WRITE_AUTHORITY);
  } catch (error) {
    if (error.code !== "IMMUTABLE_RESOLUTION_EXISTS") throw error;
    const existing = await resolutionStore.readResolution(workflowId, findingId, record.resolutionId);
    if (sha256(existing) !== sha256(record)) throw error;
    return existing;
  }
}

export async function verifyFindingResolution(runStore, finding, record, { contract } = {}) {
  try {
    await verifyFindingSource(runStore, finding);
    if (record.findingId !== finding.findingId || record.workflowId !== finding.workflowId) return "stale";
    if (record.source.runId !== finding.runId || record.source.reportHash !== finding.source.reportHash) return "stale";
    const byPlatform = new Map(record.verification.map((item) => [item.platform, item]));
    let verifiedRef;
    const fullRuns = [];
    for (const platform of ["desktop-web", "mobile-web"]) {
      const stored = byPlatform.get(platform);
      if (!stored) return "stale";
      const current = await verifyEvaluation(runStore, stored.runId, platform, record.workflowId);
      fullRuns.push(current);
      if (sha256(current.snapshot) !== sha256(stored)) return "stale";
      const ref = current.run.manifest.workflowRef;
      verifiedRef ??= ref;
      if (
        ref.candidateRevision !== record.fix.candidateRevision ||
        ref.sourceBytesHash !== record.fix.sourceBytesHash ||
        ref.contentHash !== record.fix.contentHash ||
        ref.candidateRevision !== verifiedRef.candidateRevision ||
        ref.sourceBytesHash !== verifiedRef.sourceBytesHash ||
        ref.contentHash !== verifiedRef.contentHash
      )
        return "stale";
    }
    const completedAt = fullRuns
      .map((current) => current.report.timestamps.completedAt)
      .sort()
      .at(-1);
    if (record.createdAt !== completedAt) return "stale";
    if (record.schema === "agent-workflow-finding-resolution/v1") return "canonical-only";
    if (!contract || record.correction?.contractHash !== contract.contractHash) return "stale";
    verifyFindingVerificationContract(finding, contract);
    if (record.correction.findingHash !== contract.findingHash) return "stale";
    const sourceRevision = /^candidate-r([1-9][0-9]*)$/.exec(finding.workflowRevision);
    if (!sourceRevision || record.fix.candidateRevision <= Number(sourceRevision[1])) return "stale";
    const requiredPlatforms = new Set(contract.criteria.flatMap((criterion) => criterion.applicablePlatforms));
    const targetedPlatforms = new Set();
    for (const receipt of record.correction.targetedVerification) {
      await verifyFindingCorrection({ runStore, finding, contract, receipt });
      targetedPlatforms.add(receipt.run.platform);
      if (
        receipt.run.candidateRevision !== record.fix.candidateRevision ||
        receipt.run.sourceBytesHash !== record.fix.sourceBytesHash ||
        receipt.run.contentHash !== record.fix.contentHash ||
        receipt.checks.some((check) => check.assessment.implementationCommit !== record.fix.implementationCommit)
      )
        return "stale";
      if (
        fullRuns.some((current) =>
          [receipt.run.completedAt, receipt.recordedAt].some(
            (timestamp) => new Date(timestamp) >= new Date(current.report.timestamps.createdAt),
          ),
        )
      )
        return "stale";
    }
    if ([...requiredPlatforms].some((platform) => !targetedPlatforms.has(platform))) return "stale";
    const identity = {
      workflowId: record.workflowId,
      findingId: record.findingId,
      implementationCommit: record.fix.implementationCommit,
      desktopRunId: byPlatform.get("desktop-web").runId,
      mobileRunId: byPlatform.get("mobile-web").runId,
      contractHash: record.correction.contractHash,
      targetedReceiptHashes: record.correction.targetedVerification.map((receipt) => receipt.receiptHash).sort(),
    };
    if (record.resolutionId !== `resolution_${sha256(identity).slice(7, 39)}`) return "stale";
    return "verified";
  } catch (error) {
    if (["ENOENT", "RUN_NOT_FOUND", "NOT_FOUND"].includes(error?.code)) return "missing";
    if (/(?:CORRUPT|UNSAFE|VALIDATION_FAILED|ID_MISMATCH)/.test(error?.code ?? "")) return "corrupt";
    return "stale";
  }
}
