import { createHash } from "node:crypto";

const HASH_PATTERN = /^sha256:[a-f0-9]{64}$/;
const PORTABLE_PATH_PATTERN = /^[A-Za-z0-9._~/-]+$/;
const STUDIO_SCHEMA = "agent-workflow-studio-asset-manifest/v1";
const INVENTORY_SCHEMA = "agent-workflow-package-inventory/v1";
const PROVENANCE_SCHEMA = "agent-workflow-package-provenance/v1";
const PACKAGE_NAME = "@lineagehq/workflows";
const RELEASE_TARGET = "0.4.0";

export class ArtifactDigestError extends Error {
  constructor(message) {
    super(message);
    this.name = "ArtifactDigestError";
    this.code = "ARTIFACT_DIGEST_INVALID";
  }
}

function invalid(message) {
  throw new ArtifactDigestError(message);
}

function assertPlainObject(value, label) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    invalid(`${label} must be an object`);
  }
}

function assertExactKeys(value, expected, label, { optional = [] } = {}) {
  assertPlainObject(value, label);
  const allowed = new Set([...expected, ...optional]);
  const keys = Object.keys(value);
  const missing = expected.filter((key) => !Object.hasOwn(value, key));
  const extra = keys.filter((key) => !allowed.has(key));
  if (missing.length > 0 || extra.length > 0) {
    invalid(`${label} fields are invalid`);
  }
}

function assertHash(value, label) {
  if (typeof value !== "string" || !HASH_PATTERN.test(value)) {
    invalid(`${label} must be a lowercase sha256 digest`);
  }
}

function assertPositiveSize(value, label) {
  if (!Number.isSafeInteger(value) || value < 1) {
    invalid(`${label} must be a positive safe integer`);
  }
}

function compareUtf8(left, right) {
  return Buffer.compare(Buffer.from(left, "utf8"), Buffer.from(right, "utf8"));
}

export function validatePortableCanonicalPath(path) {
  if (typeof path !== "string" || !PORTABLE_PATH_PATTERN.test(path)) {
    invalid("path must use the portable ASCII path alphabet");
  }
  const segments = path.split("/");
  if (segments.some((segment) => segment === "" || segment === "." || segment === "..")) {
    invalid("path must be normalized, relative, and traversal-free");
  }
  return path;
}

function assertCanonicalEntries(entries, label, { entrypoint } = {}) {
  if (!Array.isArray(entries) || entries.length === 0) {
    invalid(`${label} must be a non-empty array`);
  }

  let previous;
  const paths = new Set();
  for (const [index, entry] of entries.entries()) {
    assertExactKeys(entry, ["path", "size", "sha256"], `${label}[${index}]`);
    validatePortableCanonicalPath(entry.path);
    assertPositiveSize(entry.size, `${label}[${index}].size`);
    assertHash(entry.sha256, `${label}[${index}].sha256`);
    if (paths.has(entry.path)) invalid(`${label} paths must be unique`);
    if (previous !== undefined && compareUtf8(previous, entry.path) >= 0) {
      invalid(`${label} paths must use ascending UTF-8 byte order`);
    }
    paths.add(entry.path);
    previous = entry.path;
  }

  if (entrypoint !== undefined && !paths.has(entrypoint)) {
    invalid("Studio entrypoint must identify exactly one asset");
  }
}

function jsonLine(value) {
  return `${JSON.stringify(value)}\n`;
}

function sha256JsonLine(value) {
  return `sha256:${createHash("sha256").update(jsonLine(value), "utf8").digest("hex")}`;
}

function studioDigestInput(manifest, { requireDigest }) {
  assertExactKeys(
    manifest,
    ["schema", "formatVersion", "entrypoint", "assets", ...(requireDigest ? ["manifestDigest"] : [])],
    "Studio asset manifest",
    { optional: requireDigest ? [] : ["manifestDigest"] },
  );
  if (manifest.schema !== STUDIO_SCHEMA || manifest.formatVersion !== 1) {
    invalid("Studio asset manifest identity is invalid");
  }
  validatePortableCanonicalPath(manifest.entrypoint);
  assertCanonicalEntries(manifest.assets, "Studio assets", { entrypoint: manifest.entrypoint });
  if (Object.hasOwn(manifest, "manifestDigest")) {
    assertHash(manifest.manifestDigest, "manifestDigest");
  }
  return {
    schema: manifest.schema,
    formatVersion: manifest.formatVersion,
    entrypoint: manifest.entrypoint,
    assets: manifest.assets.map(({ path, size, sha256 }) => ({ path, size, sha256 })),
  };
}

export function computeStudioManifestDigest(manifest) {
  return sha256JsonLine(studioDigestInput(manifest, { requireDigest: false }));
}

export function verifyStudioAssetManifest(manifest) {
  const computed = sha256JsonLine(studioDigestInput(manifest, { requireDigest: true }));
  if (manifest.manifestDigest !== computed) invalid("Studio manifest digest mismatch");
  return computed;
}

function isExcludedInventoryPath(path) {
  if (path === "package-provenance.json") return true;
  return path.split("/").some((segment) => segment === ".git" || segment === "node_modules");
}

function inventoryDigestInput(inventory) {
  assertExactKeys(inventory, ["schema", "files"], "package inventory");
  if (inventory.schema !== INVENTORY_SCHEMA) invalid("package inventory identity is invalid");
  assertCanonicalEntries(inventory.files, "package inventory files");
  if (inventory.files.some(({ path }) => isExcludedInventoryPath(path))) {
    invalid("package inventory contains an excluded path");
  }
  return {
    schema: inventory.schema,
    files: inventory.files.map(({ path, size, sha256 }) => ({ path, size, sha256 })),
  };
}

export function computePackageInventoryDigest(inventory) {
  return sha256JsonLine(inventoryDigestInput(inventory));
}

export function verifyPackageInventory(inventory, expectedDigest) {
  assertHash(expectedDigest, "expected package digest");
  const computed = computePackageInventoryDigest(inventory);
  if (expectedDigest !== computed) invalid("package inventory digest mismatch");
  return computed;
}

function provenanceDigestInput(provenance, { requireDigest }) {
  assertExactKeys(
    provenance,
    [
      "schema",
      "package",
      "source",
      "commit",
      "packageDigest",
      "studioManifestDigest",
      "verified",
      ...(requireDigest ? ["provenanceDigest"] : []),
    ],
    "package provenance",
    { optional: requireDigest ? [] : ["provenanceDigest"] },
  );
  if (provenance.schema !== PROVENANCE_SCHEMA) invalid("package provenance identity is invalid");
  assertExactKeys(provenance.package, ["name", "version", "releaseTarget"], "package identity");
  const currentRelease =
    provenance.package.version === RELEASE_TARGET && provenance.package.releaseTarget === RELEASE_TARGET;
  const legacyRelease =
    (/^0\.2\.0(?:-rc\.[1-9][0-9]*)?$/.test(provenance.package.version) &&
      provenance.package.releaseTarget === "0.2.0") ||
    (provenance.package.version === "0.2.1" && provenance.package.releaseTarget === "0.2.1") ||
    (provenance.package.version === "0.3.0" && provenance.package.releaseTarget === "0.3.0") ||
    (provenance.package.version === "0.3.1" && provenance.package.releaseTarget === "0.3.1") ||
    (provenance.package.version === "0.3.2" && provenance.package.releaseTarget === "0.3.2");
  if (provenance.package.name !== PACKAGE_NAME || (!currentRelease && !legacyRelease)) {
    invalid("package identity is invalid");
  }
  if (!new Set(["git", "tarball", "registry"]).has(provenance.source)) {
    invalid("package provenance source is invalid");
  }
  if (typeof provenance.commit !== "string" || !/^[a-f0-9]{40}$/.test(provenance.commit)) {
    invalid("package provenance commit is invalid");
  }
  assertHash(provenance.packageDigest, "packageDigest");
  assertHash(provenance.studioManifestDigest, "studioManifestDigest");
  if (provenance.verified !== true) invalid("package provenance must record verified truth");
  if (Object.hasOwn(provenance, "provenanceDigest")) {
    assertHash(provenance.provenanceDigest, "provenanceDigest");
  }
  return {
    schema: provenance.schema,
    package: {
      name: provenance.package.name,
      version: provenance.package.version,
      releaseTarget: provenance.package.releaseTarget,
    },
    source: provenance.source,
    commit: provenance.commit,
    packageDigest: provenance.packageDigest,
    studioManifestDigest: provenance.studioManifestDigest,
    verified: provenance.verified,
  };
}

export function computePackageProvenanceDigest(provenance) {
  return sha256JsonLine(provenanceDigestInput(provenance, { requireDigest: false }));
}

export function verifyPackageProvenance(provenance, { studioManifest, packageInventory }) {
  const input = provenanceDigestInput(provenance, { requireDigest: true });
  const studioManifestDigest = verifyStudioAssetManifest(studioManifest);
  const packageDigest = computePackageInventoryDigest(packageInventory);
  if (input.studioManifestDigest !== studioManifestDigest) {
    invalid("package provenance Studio manifest digest mismatch");
  }
  if (input.packageDigest !== packageDigest) {
    invalid("package provenance installed payload digest mismatch");
  }
  const provenanceDigest = sha256JsonLine(input);
  if (provenance.provenanceDigest !== provenanceDigest) {
    invalid("package provenance digest mismatch");
  }
  return { packageDigest, provenanceDigest, studioManifestDigest };
}
