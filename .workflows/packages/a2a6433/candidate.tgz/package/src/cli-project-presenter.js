import { presentHelp } from "./cli-help.js";

function projectName(snapshot) {
  return snapshot.project.name ?? "This project";
}

function byWorkflow(snapshot) {
  return new Map(snapshot.inventory.workflows.map((workflow) => [workflow.workflowId, workflow]));
}

function platforms(workflow) {
  return workflow.platforms.length ? workflow.platforms.join(", ") : "platform unavailable";
}

function candidateLines(snapshot) {
  const candidates = snapshot.query.terms ? snapshot.candidates : snapshot.inventory.workflows;
  if (!candidates.length) return ["No matching journeys are available."];
  return candidates.map(
    (workflow) =>
      `${workflow.name} — ${workflow.purpose} Platforms: ${platforms(workflow)}. State: ${workflow.integrity}.`,
  );
}

function selectionLines(snapshot) {
  if (snapshot.selection.status === "empty") return ["No journey matches that description."];
  if (snapshot.selection.status === "ambiguous") return [snapshot.selection.question];
  const selected = byWorkflow(snapshot).get(snapshot.selection.workflowId);
  if (!selected) return ["The selected journey is unavailable."];
  return [`${selected.name} — ${selected.purpose}`, `Platforms: ${platforms(selected)}. State: ${selected.integrity}.`];
}

function runLines(snapshot) {
  if (!snapshot.activity.length) return ["No runs are recorded."];
  const workflows = byWorkflow(snapshot);
  return snapshot.activity.map((run) => {
    const name = workflows.get(run.workflowId)?.name ?? "Unavailable journey";
    return `${name} on ${run.platform}: ${run.phase}, ${run.status}. State: ${run.integrity}.`;
  });
}

function pendingLines(snapshot) {
  if (!snapshot.pendingAttention.length) return ["Nothing currently needs attention."];
  const workflows = byWorkflow(snapshot);
  return snapshot.pendingAttention.map((item) => {
    const name = workflows.get(item.workflowId)?.name ?? "Unavailable journey";
    return `${name}: ${item.summary} State: ${item.integrity}.`;
  });
}

/** Render project truth for people without exposing or requesting internal identities. */
function presentProjectResult(command, snapshot) {
  const heading = `${projectName(snapshot)} — ${snapshot.integrity.status}, ${snapshot.freshness.status}`;
  const lines =
    command === "list"
      ? candidateLines(snapshot)
      : command === "status"
        ? selectionLines(snapshot)
        : command === "runs"
          ? runLines(snapshot)
          : pendingLines(snapshot);
  return `${[heading, ...lines].join("\n")}\n`;
}

function reviewIntentText(command, data) {
  if (command === "review-intent record") {
    return `Review request recorded with no human authority.\n${data.record.action.summary}\n`;
  }
  if (command === "review-intent show") {
    if (data.record.integrity !== "verified") return "The review request is unavailable.\nAuthority: none.\n";
    return `Review request — ${data.record.kind.replaceAll("-", " ")}\n${data.record.summary}\nAuthority: none.\n`;
  }
  if (!data.records.length) return "No review requests are recorded.\n";
  const lines = data.records.map((record) =>
    record.integrity === "verified"
      ? `${record.kind.replaceAll("-", " ")}: ${record.summary}`
      : "A review request is unavailable.",
  );
  return `${lines.join("\n")}\nAuthority: none.\n`;
}

function acceptanceText(command, data) {
  if (command === "acceptance record") {
    return `Agent review recorded: ${data.record.decision}.\n`;
  }
  if (command === "acceptance show") {
    if (data.record.integrity !== "verified") {
      return "The acceptance record is unavailable and cannot support acceptance.\n";
    }
    return `${data.record.actorKind === "human" ? "Human" : "Agent"} review: ${data.record.decision}.\nEvidence support: ${data.record.support}.\n`;
  }
  if (!data.records.length) return "No optional review decisions are recorded.\n";
  const lines = data.records.map((record) =>
    record.integrity === "verified"
      ? `${record.decision}. Evidence support: ${record.support}.`
      : "An acceptance decision is unavailable and cannot support acceptance.",
  );
  return `${lines.join("\n")}\n`;
}

function runMutationText(command, data) {
  const operation = command.slice("run ".length).replaceAll("-", " ");
  const replay = data.replay ? " Existing receipt returned." : "";
  return `Run ${operation} recorded.${replay} Current state: ${data.state.status}.\n`;
}

function presentCollaborationResult(command, data) {
  if (command.startsWith("review-intent ")) return reviewIntentText(command, data);
  if (command.startsWith("acceptance ")) return acceptanceText(command, data);
  return runMutationText(command, data);
}

function sessionReadinessText(data) {
  if (!data.sessions.length) return "No configured target requires a user-managed session.\n";
  const lines = data.sessions.map((session) => {
    const verified = session.lastVerifiedAt ? ` Last verified ${session.lastVerifiedAt}.` : "";
    return `${session.label} (${session.environment}): ${session.status.replaceAll("-", " ")}.${verified}`;
  });
  if (data.selection.status === "ambiguous") lines.push(data.selection.question);
  return `${lines.join("\n")}\n`;
}

function humanStatus(value) {
  if (value === "ready") return "Ready";
  if (value === "not-requested") return "Not checked";
  if (value === "not-verified") return "Not yet verified";
  return "Needs attention";
}

function doctorText(data) {
  const lines = [
    "Workflows doctor",
    `Local project: ${humanStatus(data.localStatus)}`,
    `Installed package: ${humanStatus(data.packageStatus)}`,
    `GitHub Packages: ${humanStatus(data.registryStatus)}${data.registryStatus === "not-requested" ? " (optional after install)" : ""}`,
    `Journey execution: ${humanStatus(data.readiness?.execution?.status)}`,
  ];
  const localChecks = new Set(data.readiness?.local?.checks ?? []);
  const localProblems = (data.checks ?? []).filter(
    (item) => localChecks.has(item.id) && !["ready", "not-applicable"].includes(item.status),
  );
  const packageChecks = new Set(data.readiness?.package?.checks ?? []);
  const packageProblems = (data.checks ?? []).filter(
    (item) => packageChecks.has(item.id) && !["ready", "not-applicable"].includes(item.status),
  );
  if (localProblems.length) {
    lines.push("", "Fix before running a journey:", ...localProblems.map((item) => `- ${item.summary}`));
  } else if (packageProblems.length) {
    lines.push("", "Package diagnostics:", ...packageProblems.map((item) => `- ${item.summary}`));
  }
  if (data.registryStatus === "not-ready" && data.mode === "online-requested") {
    const registryChecks = new Set(data.readiness?.registry?.checks ?? []);
    const registryProblems = (data.checks ?? []).filter(
      (item) => registryChecks.has(item.id) && !["ready", "not-applicable"].includes(item.status),
    );
    lines.push("", "Registry diagnostics:", ...registryProblems.map((item) => `- ${item.summary}`));
  }
  lines.push(
    "",
    data.localStatus === "ready"
      ? "Next: select a journey and run training or evaluation; Workflows will verify the browser and target then."
      : "Next: run workflow init --host codex, resolve any reported conflicts, then run workflow doctor again.",
  );
  return `${lines.join("\n")}\n`;
}

function initText(data) {
  const groups = data.dryRun
    ? {
        created: data.items.filter((item) => item.status === "create").length,
        updated: data.items.filter((item) => item.status === "update").length,
        unchanged: data.items.filter((item) => item.status === "unchanged").length,
        conflicting: data.items.filter((item) => item.status === "conflict"),
      }
    : {
        created: data.created?.length ?? 0,
        updated: data.updated?.length ?? 0,
        unchanged: data.unchanged?.length ?? 0,
        conflicting: data.conflicting ?? [],
      };
  const lines = [
    data.dryRun ? "Workflows initialization preview" : "Workflows initialized",
    `Created ${groups.created} · Updated ${groups.updated} · Unchanged ${groups.unchanged} · Conflicts ${groups.conflicting.length}`,
  ];
  if (groups.conflicting.length) {
    lines.push("", "Resolve these files before continuing:", ...groups.conflicting.map((item) => `- ${item.path}`));
  }
  if (data.dryRun) {
    lines.push(
      "",
      data.canApply
        ? "Next: run the same workflow init command without --dry-run."
        : "Next: resolve the conflicts above, then preview initialization again.",
    );
  } else {
    lines.push("", "Next: run workflow doctor, then workflow studio when you are ready to review journeys.");
  }
  return `${lines.join("\n")}\n`;
}

/** Write one CLI result using the audience-appropriate presentation. */
export function printResult(result, { json, stderr = process.stderr, stdout = process.stdout }) {
  if (json) {
    stdout.write(`${JSON.stringify(result)}\n`);
    return;
  }

  if (result.ok) {
    if (result.command === "help") {
      stdout.write(presentHelp(result.data));
      return;
    }
    if (result.command === "sessions") {
      stdout.write(sessionReadinessText(result.data));
      return;
    }
    if (result.command === "doctor") {
      stdout.write(doctorText(result.data));
      return;
    }
    if (result.command === "init") {
      stdout.write(initText(result.data));
      return;
    }
    if (PROJECT_COMMANDS.has(result.command) && result.data?.snapshot) {
      stdout.write(presentProjectResult(result.command, result.data.snapshot));
      return;
    }
    if (result.command === "report" && result.data?.report) {
      stdout.write(`${JSON.stringify(result.data.report, null, 2)}\n`);
      return;
    }
    if (COLLABORATION_COMMANDS.has(result.command)) {
      stdout.write(presentCollaborationResult(result.command, result.data));
      return;
    }
    stdout.write(`${result.command}: ok\n`);
    for (const item of result.data?.items ?? []) {
      stdout.write(`  ${item.kind}: ${item.path}\n`);
    }
    return;
  }

  stderr.write(`${result.error.code}: ${result.error.message}\n`);
}
const PROJECT_COMMANDS = new Set(["list", "status", "runs", "pending"]);
const COLLABORATION_COMMANDS = new Set([
  "review-intent record",
  "review-intent list",
  "review-intent show",
  "acceptance record",
  "acceptance list",
  "acceptance show",
  "run pause",
  "run stop",
  "run emergency-stop",
  "run resume",
]);
