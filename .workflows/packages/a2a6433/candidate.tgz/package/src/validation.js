import { readFile } from "node:fs/promises";
import { extname } from "node:path";

import { WorkflowError } from "./errors.js";
import { PROTOCOL_SCHEMAS, validateProtocolMessage } from "./protocol.js";
import { parseJsonLine, readYaml } from "./schema-registry.js";
import { validateWorkflowSemantics } from "./workflow.js";

function sameReference(left, right) {
  return JSON.stringify(left) === JSON.stringify(right);
}

export async function validateWorkflowFile(path, registry) {
  const workflow = registry.validate("workflow", await readYaml(path));
  validateWorkflowSemantics(workflow);
  return { kind: "workflow", path, id: workflow.metadata.id };
}

export async function validateConfigFile(path, registry) {
  const config = registry.validate("config", await readYaml(path));
  return { kind: "config", path, id: config.project.id };
}

export function validateEvents(events, registry, { path = "events.jsonl" } = {}) {
  if (!events.length) {
    throw new WorkflowError("VALIDATION_FAILED", "Event log is empty", {
      exitCode: 3,
      details: { path },
    });
  }

  const eventIds = new Set();
  const reference = events[0].workflowRef;

  events.forEach((event, index) => {
    registry.validate("event", event);
    const expectedSequence = index + 1;
    if (event.sequence !== expectedSequence) {
      throw new WorkflowError("EVENT_SEQUENCE_INVALID", "Event sequence is not contiguous", {
        exitCode: 3,
        details: { expected: expectedSequence, actual: event.sequence, path },
      });
    }
    if (eventIds.has(event.eventId)) {
      throw new WorkflowError("EVENT_ID_DUPLICATE", `Duplicate event ID: ${event.eventId}`, {
        exitCode: 3,
        details: { path },
      });
    }
    if (!sameReference(reference, event.workflowRef)) {
      throw new WorkflowError("WORKFLOW_REFERENCE_CHANGED", "Event workflow reference changed", {
        exitCode: 3,
        details: { sequence: event.sequence, path },
      });
    }
    eventIds.add(event.eventId);
  });

  if (events[0].type !== "run.started") {
    throw new WorkflowError("EVENT_ORDER_INVALID", "First event must be run.started", {
      exitCode: 3,
      details: { path },
    });
  }

  const completedIndex = events.findIndex((event) => event.type === "run.completed");
  if (completedIndex >= 0 && completedIndex !== events.length - 1) {
    throw new WorkflowError("EVENT_ORDER_INVALID", "run.completed must be the final event", {
      exitCode: 3,
      details: { path },
    });
  }

  return events;
}

export function validateRunControlEvents(events, registry, { path = "events.jsonl" } = {}) {
  if (!events.length) {
    throw new WorkflowError("VALIDATION_FAILED", "Run-control event log is empty", {
      exitCode: 3,
      details: { path },
    });
  }

  const eventIds = new Set();
  const runId = events[0].runId;
  events.forEach((event, index) => {
    registry.validate("runControl", event);
    if (event.schema !== "agent-workflow-run-event/v1") {
      throw new WorkflowError("EVENT_SCHEMA_INVALID", "Run-control log contains a non-event record", {
        exitCode: 3,
        details: { path, index },
      });
    }
    if (event.sequence !== index + 1 || event.revision !== index) {
      throw new WorkflowError("EVENT_SEQUENCE_INVALID", "Run-control sequence and revision are not contiguous", {
        exitCode: 3,
        details: {
          path,
          expectedSequence: index + 1,
          actualSequence: event.sequence,
          expectedRevision: index,
          actualRevision: event.revision,
        },
      });
    }
    if (event.runId !== runId) {
      throw new WorkflowError("RUN_ID_CHANGED", "Run-control event run ID changed", {
        exitCode: 3,
        details: { path, sequence: event.sequence },
      });
    }
    if (eventIds.has(event.eventId)) {
      throw new WorkflowError("EVENT_ID_DUPLICATE", `Duplicate event ID: ${event.eventId}`, {
        exitCode: 3,
        details: { path },
      });
    }
    eventIds.add(event.eventId);
  });

  if (events[0].type !== "run.created") {
    throw new WorkflowError("EVENT_ORDER_INVALID", "First event must be run.created", {
      exitCode: 3,
      details: { path },
    });
  }
  return events;
}

export async function validateEventLogFile(path, registry) {
  const content = await readFile(path, "utf8");
  const events = content
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line, index) => parseJsonLine(line, { path, lineNumber: index + 1 }));

  if (events[0]?.schema === "agent-workflow-run-event/v1") {
    validateRunControlEvents(events, registry, { path });
    return { kind: "run-control-event-log", path, runId: events[0].runId, events: events.length };
  }

  validateEvents(events, registry, { path });
  return { kind: "event-log", path, runId: events[0].runId, events: events.length };
}

export async function validatePath(path, registry) {
  if (extname(path) === ".jsonl") return validateEventLogFile(path, registry);

  const document = await readYaml(path);
  switch (document?.schema) {
    case "agent-workflow/v0":
    case "agent-workflow/v1":
      registry.validate("workflow", document);
      validateWorkflowSemantics(document);
      return { kind: "workflow", path, id: document.metadata.id };
    case "agent-workflow-config/v0":
    case "agent-workflow-config/v1":
      registry.validate("config", document);
      return { kind: "config", path, id: document.project.id };
    case "agent-workflow-run-manifest/v1":
      registry.validate("runControl", document);
      return { kind: "run-manifest", path, runId: document.runId };
    default:
      if (Object.values(PROTOCOL_SCHEMAS).includes(document?.schema)) {
        validateProtocolMessage(document, registry);
        return { kind: "protocol", path, schema: document.schema };
      }
      throw new WorkflowError("UNKNOWN_DOCUMENT", `Unknown document schema: ${path}`, {
        exitCode: 3,
        details: { schema: document?.schema ?? null },
      });
  }
}
