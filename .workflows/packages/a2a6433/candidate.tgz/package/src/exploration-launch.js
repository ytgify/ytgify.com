import { randomUUID } from "node:crypto";
import { basename } from "node:path";
import { WorkflowError } from "./errors.js";
import { leasePolicyHash, selectLeasePolicy } from "./lease-policy.js";
import { resolveRunTarget } from "./run-target.js";
import { verifyExplorationFile } from "./exploration-fixtures.js";

const limits = Object.freeze({ actions: 24, captures: 20, branches: 4, minutes: 45 });
const id = (prefix) => `${prefix}_${randomUUID().replaceAll("-", "")}`;

export async function launchExploration({
  applicationTarget,
  startRoute,
  intents,
  platform,
  fixtures = [],
  projectRoot,
  store,
  now = () => new Date(),
}) {
  if (!applicationTarget || applicationTarget.environment !== "local" || applicationTarget.authentication) {
    throw new WorkflowError("INVALID_USAGE", "Exploration requires an anonymous configured local target", {
      exitCode: 2,
    });
  }
  const hostname = new URL(applicationTarget.baseUrl).hostname;
  if (!new Set(["localhost", "127.0.0.1", "[::1]"]).has(hostname) && !hostname.endsWith(".localhost")) {
    throw new WorkflowError("INVALID_USAGE", "Exploration requires a loopback local target", { exitCode: 2 });
  }
  if (!["desktop-web", "mobile-web"].includes(platform)) {
    throw new WorkflowError("INVALID_USAGE", "Exploration requires desktop-web or mobile-web", { exitCode: 2 });
  }
  if (typeof startRoute !== "string" || !/^\/(?!\/)/u.test(startRoute) || startRoute.includes("#")) {
    throw new WorkflowError("INVALID_USAGE", "Exploration requires an origin-relative starting route", { exitCode: 2 });
  }
  if (!Array.isArray(intents) || !intents.length || intents.length > 12 || intents.some((item) => !item?.trim())) {
    throw new WorkflowError("INVALID_USAGE", "Exploration requires one to twelve nonempty intents", { exitCode: 2 });
  }
  if (
    !Array.isArray(fixtures) ||
    fixtures.length > 4 ||
    (fixtures.length && !projectRoot) ||
    new Set(fixtures.map((item) => item.name)).size !== fixtures.length
  ) {
    throw new WorkflowError("INVALID_USAGE", "Exploration fixtures require an explicit project root", { exitCode: 2 });
  }
  for (const fixture of fixtures) {
    if (
      fixture.kind !== "project-file" ||
      fixture.filename !== basename(fixture.relativePath) ||
      !/^label:[^\r\n]{1,200}$/u.test(fixture.target)
    ) {
      throw new WorkflowError("INVALID_USAGE", "Exploration fixture descriptor is invalid", { exitCode: 2 });
    }
    const verified = await verifyExplorationFile(projectRoot, fixture);
    if (verified.mimeType !== fixture.mimeType)
      throw new WorkflowError("INVALID_USAGE", "Exploration fixture MIME type changed", { exitCode: 2 });
  }
  const target = resolveRunTarget({ schema: "agent-workflow/v1", start: { route: startRoute } }, { applicationTarget });
  if (new URL(target.canonicalUrl).origin !== new URL(applicationTarget.baseUrl).origin) {
    throw new WorkflowError("TARGET_URL_INVALID", "Starting route escapes the local target origin", { exitCode: 3 });
  }
  const leasePolicy = selectLeasePolicy("standard", { phase: "exploration" });
  const manifest = {
    schema: "agent-workflow-run-manifest/v1",
    runId: id("run"),
    createdAt: now().toISOString(),
    phase: "exploration",
    profile: "anonymous",
    platform,
    target,
    identity: { requirement: "anonymous", note: "Local exploration without a user session" },
    exploration: { startRoute, intents: [...new Set(intents.map((item) => item.trim()))], limits, fixtures },
    leasePolicy,
    policyHash: leasePolicyHash(leasePolicy),
    eventSchema: "agent-workflow-run-event/v1",
  };
  const transaction = await store.createRun(manifest, { eventId: id("evt") });
  return {
    launchCard: {
      runId: manifest.runId,
      phase: "exploration",
      target,
      startRoute,
      intents: manifest.exploration.intents,
      limits,
      fixtures,
    },
    state: transaction.state,
  };
}
