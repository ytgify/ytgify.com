import { randomUUID } from "node:crypto";
import { writeFile } from "node:fs/promises";
import { PREFERRED_PROTOCOL_VERSION } from "./protocol.js";

function requestId() {
  return `req_${randomUUID().replaceAll("-", "")}`;
}

function request(command, runId, hostId, payload, expectedRevision) {
  return {
    schema: "agent-workflow-protocol-request/v1",
    protocolVersion: PREFERRED_PROTOCOL_VERSION,
    requestId: requestId(),
    command,
    runId,
    ...(expectedRevision === undefined ? {} : { expectedRevision }),
    actor: { kind: "agent-host", id: hostId },
    issuedAt: new Date().toISOString(),
    payload,
  };
}

export async function runScriptedTraining({ service, runId, hostId, capabilities, executeStep }) {
  let run = await service.store.readRun(runId);
  await service.handle(request("agent.claim", runId, hostId, { hostInstanceId: hostId }, run.state.revision));
  run = await service.store.readRun(runId);
  await service.handle(request("agent.capabilities", runId, hostId, { capabilities }, run.state.revision));

  while (true) {
    const inspected = await service.handle(request("agent.inspect", runId, hostId, {}));
    if (["completed", "blocked", "failed", "abandoned"].includes(inspected.state.status)) {
      return inspected;
    }
    if (!inspected.result.step) {
      throw new Error(`Scripted host has no instruction while run is ${inspected.state.status}`);
    }
    const { step } = inspected.result;
    const proposed = await service.handle(
      request(
        "agent.propose",
        runId,
        hostId,
        {
          proposal: {
            schema: "agent-workflow-action-proposal/v1",
            immediateOutcome: step.expected[0],
            actions: [{ kind: "activate-control", description: step.action, target: step.name }],
            stopConditions: ["the expected state is visible", "an unexpected state appears"],
            risk: { category: "reversible-ui", externallyVisible: false, destructive: false },
            requestedCapabilities: ["browser.control"],
          },
        },
        inspected.revision,
      ),
    );
    if (proposed.result.decision !== "allowed") {
      throw new Error(`Scripted proposal was not allowed: ${proposed.result.reason}`);
    }
    const unavailableRequirement = step.requiredEvidence.find((requirement) =>
      inspected.result.capabilityGaps.includes(requirement.type),
    );
    if (unavailableRequirement) {
      await service.handle(
        request(
          "agent.commit",
          runId,
          hostId,
          {
            result: {
              schema: "agent-workflow-committed-result/v1",
              leaseId: proposed.result.lease.leaseId,
              declaredActions: [step.action],
              actualActions: [],
              immediateOutcome: `${unavailableRequirement.type} is unavailable.`,
              observations: [],
              evidence: [],
              unexpectedStates: [],
              uncertainty: [
                `Cannot assess ${unavailableRequirement.checkpoint} without ${unavailableRequirement.type}.`,
              ],
              rationale: "The runner recorded this required capability as unavailable during preflight.",
            },
            assessment: {
              stepId: step.id,
              expectations: step.expected.map((expectation) => ({
                expectation,
                outcome: "blocked",
                observation: `Not assessable because ${unavailableRequirement.type} is unavailable.`,
                evidence: [],
              })),
              proposedOutcome: "blocked",
              block: {
                code: "capability_unavailable",
                capability: unavailableRequirement.type,
              },
            },
            artifacts: [],
          },
          proposed.revision,
        ),
      );
      continue;
    }

    const observed = await executeStep({ step, lease: proposed.result.lease });
    const artifacts = [];
    let revision = proposed.revision;
    for (const [index, requirement] of step.requiredEvidence.entries()) {
      const capability = capabilities.find((item) => item.evidenceTypes.includes(requirement.type));
      if (!capability) throw new Error(`No capability can capture ${requirement.type}`);
      const issued = await service.handle(
        request(
          "agent.evidence",
          runId,
          hostId,
          {
            action: "issue",
            leaseId: proposed.result.lease.leaseId,
            stepId: step.id,
            checkpoint: requirement.checkpoint,
            capabilityId: capability.id,
            type: requirement.type,
          },
          revision,
        ),
      );
      await writeFile(issued.result.slot.stagingPath, observed.evidenceBytes[index], {
        flag: "wx",
      });
      const registered = await service.handle(
        request(
          "agent.evidence",
          runId,
          hostId,
          {
            action: "register",
            leaseId: proposed.result.lease.leaseId,
            slotId: issued.result.slot.slotId,
          },
          issued.revision,
        ),
      );
      artifacts.push(registered.result.artifact);
      revision = registered.revision;
    }
    await service.handle(
      request(
        "agent.commit",
        runId,
        hostId,
        {
          result: {
            schema: "agent-workflow-committed-result/v1",
            leaseId: proposed.result.lease.leaseId,
            declaredActions: [step.action],
            actualActions: [step.action],
            immediateOutcome: observed.immediateOutcome ?? step.expected[0],
            observations: observed.observations,
            evidence: artifacts.map((artifact) => artifact.artifactId),
            unexpectedStates: observed.unexpectedStates ?? [],
            uncertainty: observed.uncertainty ?? [],
            rationale: observed.rationale,
            ...(observed.notes ? { notes: observed.notes } : {}),
          },
          assessment: {
            stepId: step.id,
            expectations: step.expected.map((expectation, index) => ({
              expectation,
              outcome: observed.expectationOutcomes?.[index] ?? "passed",
              observation: observed.observations[index]?.claim ?? observed.rationale,
              evidence: artifacts.map((artifact) => artifact.artifactId),
            })),
            proposedOutcome: observed.proposedOutcome ?? "passed",
            ...(observed.deviation ? { deviation: observed.deviation } : {}),
          },
          artifacts: artifacts.map((artifact) => artifact.artifactId),
        },
        revision,
      ),
    );
  }
}
