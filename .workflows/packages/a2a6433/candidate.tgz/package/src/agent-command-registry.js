const FLAG_SUFFIX = "[--file PATH] [--root PATH] [--config PATH] [--store PATH] [--json]";

const DEFINITIONS = [
  {
    operation: "inspect",
    payloadSchema: "#/$defs/inspectPayload",
    expectedRevisionRequired: false,
    prerequisite: "A durable run identity from verified discovery or launch.",
    nextStep: "Use allowedOperations and the returned revision to choose the next request.",
    resultKind: "inspection",
    authorizesBrowserMutation: false,
    commonFailures: ["NOT_FOUND", "INTERNAL_ERROR"],
  },
  {
    operation: "claim",
    payloadSchema: "#/$defs/claimPayload",
    expectedRevisionRequired: true,
    prerequisite: "The run is unowned and agent.claim appears in allowedOperations.",
    nextStep: "Report demonstrated capabilities, then inspect and follow the returned allowedOperations.",
    resultKind: "acknowledgement",
    authorizesBrowserMutation: false,
    commonFailures: ["REVISION_CONFLICT", "RUN_OWNED", "ILLEGAL_TRANSITION"],
  },
  {
    operation: "route.bind",
    payloadSchema: "#/$defs/routeBindPayload",
    expectedRevisionRequired: true,
    prerequisite: "The owning host has no active lease and route binding is allowed.",
    nextStep: "Propose the current step using the returned binding ID as the opaque run-route target.",
    resultKind: "route-binding",
    authorizesBrowserMutation: false,
    commonFailures: ["REVISION_CONFLICT", "RUN_OWNED", "VALIDATION_FAILED"],
  },
  {
    operation: "capabilities",
    payloadSchema: "#/$defs/capabilitiesPayload",
    expectedRevisionRequired: true,
    prerequisite: "The owning host has demonstrated the submitted capabilities.",
    nextStep: "Verify authentication when required, otherwise propose the current step.",
    resultKind: "capabilities",
    authorizesBrowserMutation: false,
    commonFailures: ["REVISION_CONFLICT", "CAPABILITY_UNAVAILABLE", "VALIDATION_FAILED"],
  },
  {
    operation: "authentication.verify",
    payloadSchema: "#/$defs/inspectPayload",
    expectedRevisionRequired: true,
    prerequisite: "The exact Studio-owned session and marker are configured for the owning host.",
    nextStep: "Inspect the refreshed state, then propose only the current allowed step.",
    resultKind: "authentication",
    authorizesBrowserMutation: false,
    commonFailures: ["REVISION_CONFLICT", "CAPABILITY_UNAVAILABLE", "RECONCILIATION_REQUIRED"],
  },
  {
    operation: "propose",
    payloadSchema: "#/$defs/proposePayload",
    expectedRevisionRequired: true,
    prerequisite: "The owning host is active, the next step is current, and no lease is active.",
    nextStep: "Execute only the leased action, then register the required evidence and commit.",
    resultKind: "lease",
    authorizesBrowserMutation: true,
    commonFailures: ["REVISION_CONFLICT", "CAPABILITY_UNAVAILABLE", "RECONCILIATION_REQUIRED"],
  },
  {
    operation: "evidence",
    payloadSchema: "#/$defs/evidencePayload",
    expectedRevisionRequired: true,
    prerequisite: "The owning host has the matching unexpired lease and declared checkpoint.",
    nextStep:
      "Issue and register screenshot or declared GIF download-content evidence before committing the leased step.",
    resultKind: "evidence",
    authorizesBrowserMutation: false,
    commonFailures: ["REVISION_CONFLICT", "LEASE_EXPIRED", "VALIDATION_FAILED"],
  },
  {
    operation: "commit",
    payloadSchema: "#/$defs/commitPayload",
    expectedRevisionRequired: true,
    prerequisite: "The owning host has an unexpired lease and all referenced evidence is registered.",
    nextStep: "Inspect the resulting state before proposing another external action.",
    resultKind: "commit",
    authorizesBrowserMutation: false,
    commonFailures: ["REVISION_CONFLICT", "LEASE_EXPIRED", "CAPABILITY_UNAVAILABLE"],
  },
  {
    operation: "optional-state.authorize",
    payloadSchema: "#/$defs/optionalStateAuthorizePayload",
    expectedRevisionRequired: true,
    prerequisite: "The exact routine parent lease and handler evidence are active.",
    nextStep: "Perform only the authorized optional-state action, then complete it explicitly.",
    resultKind: "optional-state",
    authorizesBrowserMutation: true,
    commonFailures: ["REVISION_CONFLICT", "LEASE_EXPIRED", "VALIDATION_FAILED"],
  },
  {
    operation: "optional-state.complete",
    payloadSchema: "#/$defs/optionalStateCompletePayload",
    expectedRevisionRequired: true,
    prerequisite: "The immediately preceding optional-state authorization is active and unchanged.",
    nextStep: "Return to the parent routine lease and continue its required evidence flow.",
    resultKind: "optional-state",
    authorizesBrowserMutation: false,
    commonFailures: ["REVISION_CONFLICT", "LEASE_EXPIRED", "ILLEGAL_TRANSITION"],
  },
  {
    operation: "heartbeat",
    payloadSchema: "#/$defs/heartbeatPayload",
    expectedRevisionRequired: true,
    prerequisite: "The owning host has an unexpired lease and runner timing recommends renewal.",
    nextStep: "Use the returned timing as authoritative and continue only within the renewed lease.",
    resultKind: "acknowledgement",
    authorizesBrowserMutation: false,
    commonFailures: ["REVISION_CONFLICT", "LEASE_EXPIRED", "ILLEGAL_TRANSITION"],
  },
  {
    operation: "reconcile",
    payloadSchema: "#/$defs/reconcilePayload",
    expectedRevisionRequired: true,
    prerequisite: "The owning host is reconciling the exact uncertain lease or explicit handoff.",
    nextStep: "Inspect the reconciled state and follow its new allowedOperations.",
    resultKind: "reconciliation",
    authorizesBrowserMutation: false,
    commonFailures: ["REVISION_CONFLICT", "RECONCILIATION_REQUIRED", "VALIDATION_FAILED"],
  },
  {
    operation: "exploration.finish",
    payloadSchema: "#/$defs/explorationFinishPayload",
    expectedRevisionRequired: true,
    prerequisite:
      "The exploration owner has no active or uncertain lease and explicitly accounts for uncovered intents.",
    nextStep: "Review the durable partial or complete record; proposals remain unaccepted.",
    resultKind: "acknowledgement",
    authorizesBrowserMutation: false,
    commonFailures: ["REVISION_CONFLICT", "ILLEGAL_TRANSITION", "VALIDATION_FAILED"],
  },
  {
    operation: "release",
    payloadSchema: "#/$defs/releasePayload",
    expectedRevisionRequired: true,
    prerequisite: "The owning host has no active or uncertain lease.",
    nextStep: "Stop mutating the released run unless it is explicitly claimed again.",
    resultKind: "acknowledgement",
    authorizesBrowserMutation: false,
    commonFailures: ["REVISION_CONFLICT", "RECONCILIATION_REQUIRED", "ILLEGAL_TRANSITION"],
  },
];

export const agentCommandRegistry = Object.freeze(
  DEFINITIONS.map((definition) =>
    Object.freeze({
      ...definition,
      command: `agent.${definition.operation}`,
      usage: `workflow agent ${definition.operation} ${FLAG_SUFFIX}`,
      commonFailures: Object.freeze([...definition.commonFailures]),
    }),
  ),
);

export const agentUsage = Object.freeze(agentCommandRegistry.map(({ usage }) => usage));

const AGENT_OPERATIONS = new Set(agentCommandRegistry.map(({ operation }) => operation));

export function isAgentOperation(operation) {
  return AGENT_OPERATIONS.has(operation);
}

export function agentOperationsForHelp(topic) {
  if (topic === "agent") return agentCommandRegistry;
  if (!topic.startsWith("agent ")) return [];
  const operation = topic.slice("agent ".length);
  return agentCommandRegistry.filter((item) => item.operation === operation);
}
