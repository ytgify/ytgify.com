import { resolve } from "node:path";

import { verifyEvaluationTruth } from "./lifecycle.js";
import { LifecycleStore } from "./lifecycle-store.js";
import { RunControlStore } from "./run-control-store.js";

function localStoreRoot(projectContext) {
  return resolve(projectContext.projectRoot, ...projectContext.paths.localStore.split("/"));
}

/**
 * Independently reread an immutable evaluation group and every member's complete
 * evaluation lineage. A passing run or caller-supplied integrity flag is never
 * sufficient on its own.
 */
export async function reverifyAcceptanceEvidence(projectContext, evidence, record, options = {}) {
  try {
    if (
      typeof evidence?.evaluationGroupId !== "string" ||
      typeof record?.workflowId !== "string" ||
      typeof record?.revision !== "string" ||
      typeof record?.contentHash !== "string"
    ) {
      return null;
    }
    const root = localStoreRoot(projectContext);
    const lifecycleStore = options.lifecycleStore ?? new LifecycleStore(root, { registry: options.registry });
    const runStore = options.runStore ?? new RunControlStore(root, { registry: options.registry });
    const verifyTruth = options.verifyEvaluationTruth ?? verifyEvaluationTruth;
    const group = await lifecycleStore.readRecord("group", evidence.evaluationGroupId);
    const versions = await lifecycleStore.listVersions(record.workflowId);
    const latest = versions.at(-1);
    const members = group?.members;
    if (
      group?.groupId !== evidence.evaluationGroupId ||
      group.workflowId !== record.workflowId ||
      group.revision !== record.revision ||
      group.contentHash !== record.contentHash ||
      !Array.isArray(members) ||
      members.length === 0 ||
      members.some(({ runId }) => typeof runId !== "string" || runId.length === 0) ||
      new Set(members.map(({ runId }) => runId)).size !== members.length ||
      latest?.revision !== record.revision ||
      latest?.contentHash !== record.contentHash
    ) {
      return null;
    }
    const verifiedMembers = await Promise.all(
      members.map(({ runId }) => verifyTruth({ groupId: group.groupId, runId, lifecycleStore, runStore })),
    );
    if (
      verifiedMembers.some(
        (truth, index) =>
          truth?.group?.groupId !== group.groupId ||
          truth?.member?.runId !== members[index].runId ||
          truth?.receipt?.groupId !== group.groupId ||
          truth?.receipt?.runId !== members[index].runId ||
          truth?.receipt?.outcome !== "passed",
      )
    ) {
      return null;
    }
    return {
      evaluationGroupId: group.groupId,
      integrity: "verified",
      workflowId: group.workflowId,
      revision: group.revision,
      contentHash: group.contentHash,
    };
  } catch {
    return null;
  }
}

export function acceptanceEvidenceVerifier(projectContext, options = {}) {
  return (evidence, record) => reverifyAcceptanceEvidence(projectContext, evidence, record, options);
}
