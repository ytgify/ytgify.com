import { WorkflowError } from "./errors.js";

const ORIGIN_URL = /^https?:\/\/[^/?#]+\/?$/u;

function invalid(message) {
  throw new WorkflowError("TARGET_URL_INVALID", message, { exitCode: 3 });
}

function checkedUrl(value, label) {
  let parsed;
  try {
    parsed = new URL(value);
  } catch {
    invalid(`${label} must be an absolute HTTP(S) URL`);
  }
  if (!new Set(["http:", "https:"]).has(parsed.protocol)) invalid(`${label} must use HTTP or HTTPS`);
  if (parsed.username || parsed.password) invalid(`${label} must not contain credentials`);
  if (parsed.hash) invalid(`${label} must not contain a fragment`);
  return parsed.href;
}

function checkedApplicationBaseUrl(value, provenance) {
  const url = checkedUrl(value, "Resolved application target baseUrl");
  if (provenance === "configured-v1" && !ORIGIN_URL.test(value)) {
    invalid("Resolved config-v1 application target baseUrl must be an HTTP(S) origin");
  }
  return url;
}

function workflowRoute(workflow) {
  return workflow.schema === "agent-workflow/v1" ? workflow.start.route : workflow.start.path;
}

function checkedLabel(value) {
  if (typeof value !== "string") invalid("Resolved application target label is required");
  const normalized = [...value]
    .map((character) => {
      const code = character.codePointAt(0);
      return code < 32 || code === 127 ? " " : character;
    })
    .join("")
    .replace(/\s+/gu, " ")
    .trim();
  if (!normalized || normalized.length > 200 || normalized !== value) {
    invalid("Resolved application target label is not normalized");
  }
  return normalized;
}

function applicationTargetRecord(workflow, applicationTarget, targetUrl) {
  if (!applicationTarget || typeof applicationTarget !== "object" || Array.isArray(applicationTarget)) {
    invalid("Route-relative workflows require an already-resolved application target or target URL override");
  }
  const targetId = applicationTarget.targetId ?? applicationTarget.id;
  const selection = applicationTarget.selection ?? applicationTarget.reason;
  for (const [label, value] of [
    ["targetId", targetId],
    ["environment", applicationTarget.environment],
    ["selection", selection],
    ["provenance", applicationTarget.provenance],
  ]) {
    if (typeof value !== "string" || !value.trim()) invalid(`Resolved application target ${label} is required`);
  }
  if (!/^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$/u.test(targetId)) {
    invalid("Resolved application target targetId is invalid");
  }
  if (!["local", "preview", "staging", "production", "other"].includes(applicationTarget.environment)) {
    invalid("Resolved application target environment is invalid");
  }
  if (
    !["product-language-match", "sole-non-production", "configured-default"].includes(selection) ||
    !["configured-v1", "adapted-config-v0"].includes(applicationTarget.provenance)
  ) {
    invalid("Resolved application target selection provenance is invalid");
  }
  if (applicationTarget.environment === "production" && selection !== "product-language-match") {
    invalid("Production requires an explicit product-language target selection");
  }
  const route = workflowRoute(workflow);
  const label = checkedLabel(applicationTarget.label);
  const baseUrl = checkedApplicationBaseUrl(applicationTarget.baseUrl, applicationTarget.provenance);
  const canonicalUrl = checkedUrl(new URL(route, baseUrl).href, "Resolved application target route");
  return {
    source: targetUrl === undefined ? "application-target" : "human-override",
    targetId,
    label,
    environment: applicationTarget.environment,
    selection,
    provenance: applicationTarget.provenance,
    route,
    canonicalUrl,
    effectiveUrl: targetUrl === undefined ? canonicalUrl : checkedUrl(targetUrl, "Target URL override"),
  };
}

function expertTargetRecord(workflow, targetUrl) {
  if (typeof targetUrl !== "string" || !targetUrl.trim()) invalid("Target URL override must be a non-empty string");
  const effectiveUrl = checkedUrl(targetUrl, "Target URL override");
  return {
    source: "human-override",
    targetId: "expert-target-url",
    label: "Expert target URL",
    environment: "other",
    selection: "expert-target-url",
    provenance: "target-url-adapter",
    route: workflowRoute(workflow),
    canonicalUrl: effectiveUrl,
    effectiveUrl,
  };
}

export function resolveRunTarget(workflow, options = {}) {
  const { applicationTarget, targetUrl } = typeof options === "string" ? { targetUrl: options } : (options ?? {});
  if (workflow.schema === "agent-workflow/v1") {
    return applicationTarget
      ? applicationTargetRecord(workflow, applicationTarget, targetUrl)
      : expertTargetRecord(workflow, targetUrl);
  }
  if (applicationTarget) return applicationTargetRecord(workflow, applicationTarget, targetUrl);
  const canonicalUrl = checkedUrl(new URL(workflow.start.path, workflow.target.baseUrl).href, "Workflow target");
  if (targetUrl === undefined) return { source: "workflow", url: canonicalUrl, canonicalUrl };
  if (typeof targetUrl !== "string" || !targetUrl.trim()) invalid("Target URL override must be a non-empty string");
  return {
    source: "human-override",
    url: checkedUrl(targetUrl, "Target URL override"),
    canonicalUrl,
  };
}
