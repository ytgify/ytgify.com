import { sha256 } from "./stable-json.js";
import { constants } from "node:fs";
import { open, readdir, lstat, link, unlink } from "node:fs/promises";
import { join } from "node:path";
import { randomUUID } from "node:crypto";
import { isDeepStrictEqual } from "node:util";
import { readMapRegistry, importMapRegistry, validateMapAssignments } from "./app-map-registry.js";
import { mapRegistrySummary } from "./studio-map-registry.js";
import { orderedMapEvidence } from "./app-map-contract.js";
import { StudioMutationError } from "./studio-mutation-security.js";

const fail = (status = 400, code = "INVALID_MAP_PROPOSAL") => {
  throw new StudioMutationError(status, code);
};
const conflict = () => fail(409, "REVISION_CONFLICT");
const same = (a, b) => isDeepStrictEqual(a ?? null, b ?? null);
const assignment = (item) =>
  item.screen === null ? null : { visitId: item.visitId, appId: item.appId, ...item.screen };
const current = (document, visitId) => document.assignments.find((item) => item.visitId === visitId) ?? null;
function fields(body, keys) {
  if (!body || typeof body !== "object" || Array.isArray(body) || Object.keys(body).some((key) => !keys.includes(key)))
    fail();
}
function revision(value) {
  if (!Number.isSafeInteger(value) || value < 0) fail();
}
async function safeRoot(store) {
  const stat = await lstat(store.root);
  if (!stat.isDirectory() || stat.isSymbolicLink()) fail(503, "APP_MAP_PROPOSALS_UNAVAILABLE");
}
async function verifiedVisit(store, item) {
  let identity;
  try {
    identity = JSON.parse(item.visitId);
  } catch {
    fail();
  }
  if (!Array.isArray(identity) || !/^run_[A-Za-z0-9_-]+$/.test(identity[0])) fail();
  const run = await store.readRun(identity[0]);
  const visit = orderedMapEvidence(run.events).find((value) => value.visitId === item.visitId);
  if (!visit?.registered || run.workflow?.target?.app !== item.appId) fail();
  await store.readVerifiedEvidence(identity[0], visit.artifact.artifactId);
}
function patch(document, items, undo = false) {
  const ids = new Set(items.map((item) => item.visitId));
  return {
    schema: document.schema,
    assignments: [
      ...document.assignments.filter((item) => !ids.has(item.visitId)),
      ...items.map((item) => (undo ? item.before : assignment(item))).filter(Boolean),
    ],
  };
}
function validateItems(items, registry) {
  if (!Array.isArray(items) || !items.length || items.length > 50) fail();
  const ids = new Set();
  for (const item of items) {
    fields(item, ["visitId", "appId", "screen", "explanation", "before"]);
    if (
      typeof item.explanation !== "string" ||
      !item.explanation.trim() ||
      item.explanation.length > 2000 ||
      typeof item.visitId !== "string" ||
      item.visitId.length > 1024 ||
      typeof item.appId !== "string" ||
      !/^[a-z][a-z0-9._-]*$/.test(item.appId) ||
      ids.has(item.visitId)
    )
      fail();
    ids.add(item.visitId);
    if (item.screen !== null) {
      fields(item.screen, ["screenId", "screenLabel", "stateLabel", "variantId", "variantLabel", "journeyLabel"]);
      validateMapAssignments({ schema: "workflows-app-map-registry/v1", assignments: [assignment(item)] }, registry);
    }
  }
}
async function readProposal(store, registry, id) {
  if (typeof id !== "string" || !/^proposal_[a-f0-9-]{36}$/.test(id)) fail();
  await safeRoot(store);
  const file = await open(join(store.root, `app-map-${id}.json`), constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    const stat = await file.stat();
    if (!stat.isFile() || stat.size > 1048576) fail();
    const document = JSON.parse(await file.readFile("utf8"));
    if (document.proposalId !== id || document.schema !== "workflows-app-map-proposal/v1") fail();
    fields(document, ["schema", "proposalId", "createdAt", "expectedRevision", "items"]);
    revision(document.expectedRevision);
    if (typeof document.createdAt !== "string" || !Number.isFinite(Date.parse(document.createdAt))) fail();
    validateItems(document.items, registry);
    for (const item of document.items) {
      if (!Object.hasOwn(item, "before")) fail();
      if (item.before !== null) {
        validateMapAssignments({ schema: "workflows-app-map-registry/v1", assignments: [item.before] }, registry);
        if (item.before.visitId !== item.visitId || item.before.appId !== item.appId) fail();
      }
    }
    return document;
  } finally {
    await file.close();
  }
}
export async function listMapProposals(store, registry) {
  await safeRoot(store);
  const document = await readMapRegistry(store, registry);
  const names = (await readdir(store.root)).filter((name) => /^app-map-proposal_[a-f0-9-]{36}\.json$/.test(name));
  const proposals = [];
  for (const name of names) {
    const proposal = await readProposal(store, registry, name.slice(8, -5));
    const receipts = document.history
      .filter((entry) => entry.operation?.proposalId === proposal.proposalId && entry.operation.kind === "apply")
      .map((entry) => ({
        proposalId: proposal.proposalId,
        appliedRevision: entry.revision + 1,
        visitIds: entry.operation.visitIds,
      }));
    proposals.push({
      ...proposal,
      receipts,
      items: proposal.items.map((item) => ({
        ...item,
        runId: JSON.parse(item.visitId)[0],
        status: same(current(document, item.visitId), assignment(item))
          ? "applied"
          : same(current(document, item.visitId), item.before)
            ? "pending"
            : "conflict",
      })),
    });
  }
  return { revision: document.revision, proposals: proposals.sort((a, b) => b.createdAt.localeCompare(a.createdAt)) };
}
export async function proposeMapAssignments(store, registry, body) {
  fields(body, ["expectedRevision", "items"]);
  revision(body.expectedRevision);
  validateItems(body.items, registry);
  if (body.items.some((item) => Object.hasOwn(item, "before"))) fail();
  const previous = await readMapRegistry(store, registry);
  if (previous.revision !== body.expectedRevision) conflict();
  for (const item of body.items) {
    await verifiedVisit(store, item);
    if (same(current(previous, item.visitId), assignment(item))) fail();
  }
  validateMapAssignments(patch(previous, body.items), registry);
  // Stable semantic identity plus atomic publication makes concurrent retries converge.
  const digest = sha256({ ...body, items: [...body.items].sort((a, b) => a.visitId.localeCompare(b.visitId)) }).slice(
    7,
    39,
  );
  const proposalId = `proposal_${digest.slice(0, 8)}-${digest.slice(8, 12)}-${digest.slice(12, 16)}-${digest.slice(16, 20)}-${digest.slice(20)}`;
  const document = {
    schema: "workflows-app-map-proposal/v1",
    proposalId,
    createdAt: new Date().toISOString(),
    expectedRevision: body.expectedRevision,
    items: body.items.map((item) => ({ ...item, before: current(previous, item.visitId) })),
  };
  await safeRoot(store);
  const temporary = join(store.root, `.app-map-proposal-${randomUUID()}.tmp`);
  const file = await open(temporary, "wx", 0o600);
  try {
    await file.writeFile(`${JSON.stringify(document, null, 2)}\n`);
    await file.sync();
    await file.close();
    try {
      await link(temporary, join(store.root, `app-map-${document.proposalId}.json`));
    } catch (error) {
      if (error.code !== "EEXIST") throw error;
      const existing = await readProposal(store, registry, proposalId);
      const normalize = (items) => [...items].sort((a, b) => a.visitId.localeCompare(b.visitId));
      if (
        existing.expectedRevision !== body.expectedRevision ||
        !same(normalize(existing.items), normalize(document.items))
      )
        conflict();
      return existing;
    }
  } finally {
    await file.close();
    await unlink(temporary).catch(() => {});
  }
  return document;
}
async function applyOrUndo(store, registry, body, undo) {
  fields(body, ["proposalId", "expectedRevision", "visitIds", ...(undo ? ["appliedRevision"] : [])]);
  revision(body.expectedRevision);
  if (!Array.isArray(body.visitIds) || !body.visitIds.length || new Set(body.visitIds).size !== body.visitIds.length)
    fail();
  const proposal = await readProposal(store, registry, body.proposalId);
  const items = body.visitIds.map((id) => proposal.items.find((item) => item.visitId === id));
  if (items.some((item) => !item)) fail();
  const previous = await readMapRegistry(store, registry);
  if (previous.revision !== body.expectedRevision) conflict();
  if (undo) {
    revision(body.appliedRevision);
    if (body.appliedRevision < 1 || body.appliedRevision > previous.revision) fail();
    const before = previous.history[body.appliedRevision - 1];
    if (
      before.operation?.proposalId !== body.proposalId ||
      before.operation.kind !== "apply" ||
      body.visitIds.some((id) => !before.operation.visitIds.includes(id))
    )
      conflict();
    const after = body.appliedRevision === previous.revision ? previous : previous.history[body.appliedRevision];
    for (const item of items) {
      if (!same(current(before, item.visitId), item.before) || !same(current(after, item.visitId), assignment(item)))
        conflict();
    }
  }
  for (const item of items) {
    if (!same(current(previous, item.visitId), undo ? assignment(item) : item.before)) conflict();
    await verifiedVisit(store, item);
  }
  const result = await importMapRegistry(store, registry, patch(previous, items, undo), body.expectedRevision, {
    proposalId: body.proposalId,
    kind: undo ? "undo" : "apply",
    visitIds: body.visitIds,
    ...(undo ? { appliedRevision: body.appliedRevision } : {}),
  });
  return {
    registry: mapRegistrySummary(result),
    ...(undo
      ? {}
      : {
          receipt: { proposalId: proposal.proposalId, appliedRevision: result.revision, visitIds: body.visitIds },
        }),
  };
}
const applyMapProposal = (store, registry, body) => applyOrUndo(store, registry, body, false);
const undoMapProposal = (store, registry, body) => applyOrUndo(store, registry, body, true);
export async function executeMapProposalMutation(store, registry, command, body) {
  try {
    return await { propose: proposeMapAssignments, apply: applyMapProposal, undo: undoMapProposal }[command](
      store,
      registry,
      body,
    );
  } catch (error) {
    if (error instanceof StudioMutationError) throw error;
    if (error.code === "EEXIST" || error.message === "Map registry revision changed; read it before retrying")
      conflict();
    fail();
  }
}
export async function inspectMapEvidence(store, registry, runId) {
  if (!/^run_[A-Za-z0-9_-]+$/.test(runId ?? "")) fail();
  const run = await store.readRun(runId);
  const document = await readMapRegistry(store, registry);
  const diagnostics = [];
  let proposals = { proposals: [] };
  try {
    proposals = await listMapProposals(store, registry);
    if (proposals.revision !== document.revision) {
      proposals = { proposals: [] };
      diagnostics.push("Assignments changed during inspection. Inspect again before proposing classifications.");
    }
  } catch {
    diagnostics.push(
      "Proposal inventory unavailable. Inspect evidence, but do not create replacement proposals until inventory is recovered.",
    );
  }
  const visits = [];
  for (const visit of orderedMapEvidence(run.events)) {
    let verified = false;
    if (visit.registered) {
      try {
        await store.readVerifiedEvidence(runId, visit.artifact.artifactId);
        verified = true;
      } catch {
        /* Report unavailable evidence. */
      }
    }
    visits.push({
      visitId: visit.visitId,
      sequence: visit.sequence,
      ordinal: visit.ordinal,
      stepId: visit.artifact.relation?.stepId ?? null,
      checkpoint: visit.artifact.relation?.checkpoint ?? null,
      artifactId: visit.artifact.artifactId,
      contentHash: visit.artifact.contentHash,
      verified,
      url: verified
        ? `/api/runs/${encodeURIComponent(runId)}/artifacts/${encodeURIComponent(visit.artifact.artifactId)}`
        : null,
      assignment: current(document, visit.visitId),
      classification: !verified
        ? "evidence-unavailable"
        : !current(document, visit.visitId)
          ? "screen-unassigned"
          : !current(document, visit.visitId).variantId
            ? "variant-unassigned"
            : "classified",
      proposals: proposals.proposals.flatMap((proposal) =>
        proposal.items
          .filter((item) => item.visitId === visit.visitId && item.status !== "applied")
          .map((item) => ({ proposalId: proposal.proposalId, status: item.status })),
      ),
    });
  }
  return {
    ...mapRegistrySummary(document),
    runId,
    appId: run.workflow?.target?.app ?? null,
    visits,
    diagnostics,
    coverage: {
      total: visits.length,
      verified: visits.filter((visit) => visit.verified).length,
      classified: visits.filter((visit) => visit.classification === "classified").length,
      screenUnassigned: visits.filter((visit) => visit.classification === "screen-unassigned").length,
      variantUnassigned: visits.filter((visit) => visit.classification === "variant-unassigned").length,
      evidenceUnavailable: visits.filter((visit) => visit.classification === "evidence-unavailable").length,
    },
  };
}
