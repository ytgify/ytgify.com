import { open, readFile, unlink } from "node:fs/promises";
import { resolve } from "node:path";

import { selectedStoreRoot } from "./cli-journey-source.js";
import { WorkflowError } from "./errors.js";
import { compileFixtureCandidate } from "./fixture-candidate-compiler.js";
import { decideFixtureNeed, readFixtureNeedReview } from "./fixture-need-decisions.js";
import { RunControlStore } from "./run-control-store.js";
import { importSupervisedFixtureSource } from "./supervised-fixture-needs.js";
import { importYtgifyFixtureSource } from "./ytgify-fixture-needs.js";

export async function executeFixtureNeedCommand(args, flags, registry, resolvers) {
  const [operation, runId] = args;
  const allowed =
    operation === "compile"
      ? ["root", "config", "store", "file", "output", "json"]
      : operation === "decide" || operation === "import-supervised" || operation === "import-ytgify"
        ? ["root", "config", "store", "file", "json"]
        : ["root", "config", "store", "json"];
  const unsupported = [...flags.keys()].find((name) => !allowed.includes(name));
  if (unsupported)
    throw new WorkflowError("INVALID_USAGE", `fixture-needs does not accept --${unsupported}`, { exitCode: 2 });
  if (
    args.length !== (operation === "compile" ? 1 : 2) ||
    (operation !== "compile" && !/^run_[A-Za-z0-9_-]+$/u.test(runId ?? "")) ||
    !new Set(["review", "decide", "import-supervised", "import-ytgify", "compile"]).has(operation) ||
    (operation !== "review" && !flags.get("file"))
  ) {
    throw new WorkflowError(
      "INVALID_USAGE",
      "fixture-needs requires review RUN_ID, decide RUN_ID --file JSON_PATH, import-supervised RUN_ID --file JSON_PATH, import-ytgify RUN_ID --file JSON_PATH, or compile --file JSON_PATH [--output PATH]",
      {
        exitCode: 2,
      },
    );
  }
  const projectContext = await resolvers.projectContext();
  const store = await new RunControlStore(selectedStoreRoot(projectContext, flags.get("store")), { registry }).init();
  try {
    if (operation === "review") return readFixtureNeedReview(store, registry, runId);
    if (operation === "import-supervised")
      return importSupervisedFixtureSource(
        store,
        runId,
        JSON.parse(await readFile(resolve(flags.get("file")), "utf8")),
      );
    if (operation === "import-ytgify")
      return importYtgifyFixtureSource(store, runId, JSON.parse(await readFile(resolve(flags.get("file")), "utf8")));
    if (operation === "compile") {
      const candidate = await compileFixtureCandidate(
        store,
        registry,
        JSON.parse(await readFile(resolve(flags.get("file")), "utf8")),
      );
      if (flags.get("output")) {
        const outputPath = resolve(flags.get("output"));
        let output;
        try {
          output = await open(outputPath, "wx", 0o600);
          await output.writeFile(`${JSON.stringify(candidate, null, 2)}\n`);
          await output.sync();
        } catch (error) {
          if (output) await unlink(outputPath).catch(() => {});
          throw error;
        } finally {
          await output?.close();
        }
        return { ...candidate, outputPath };
      }
      return candidate;
    }
    return decideFixtureNeed(store, registry, runId, JSON.parse(await readFile(resolve(flags.get("file")), "utf8")), {
      channel: "cli",
    });
  } catch (error) {
    if (error.status && error.code) throw new WorkflowError(error.code, error.message, { exitCode: 3 });
    throw error;
  }
}
