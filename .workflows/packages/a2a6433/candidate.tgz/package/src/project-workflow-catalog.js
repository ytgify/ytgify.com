import { constants } from "node:fs";
import { lstat, open, readdir } from "node:fs/promises";
import { isAbsolute, join, relative, resolve, sep } from "node:path";
import { parse as parseYaml } from "yaml";

import { WorkflowError } from "./errors.js";
import { sha256Bytes } from "./evidence.js";
import { createSchemaRegistry } from "./schema-registry.js";
import { validateWorkflowSemantics } from "./workflow.js";

const WORKFLOW_FILE = /\.workflow\.ya?ml$/u;

function fail(code, message, details = {}) {
  throw new WorkflowError(code, message, { exitCode: 3, details });
}

function definitionPath(context) {
  const root = resolve(context?.projectRoot ?? "");
  const logical = context?.paths?.workflowDefinitions;
  if (!logical || isAbsolute(logical) || logical.split(/[\\/]+/u).some((part) => !part || part === "..")) {
    fail("PROJECT_CONTEXT_INVALID", "ProjectContext workflow definitions must be repository-relative");
  }
  const absolute = resolve(root, ...logical.split(/[\\/]+/u));
  const suffix = relative(root, absolute);
  if (suffix === ".." || suffix.startsWith(`..${sep}`) || isAbsolute(suffix)) {
    fail("PATH_TRAVERSAL", "Workflow definitions escape the repository");
  }
  return { root, logical: logical.split(/\\/u).join("/"), absolute };
}

async function safeDirectory(root, target) {
  try {
    const rootStat = await lstat(root);
    if (!rootStat.isDirectory() || rootStat.isSymbolicLink()) return { issue: "unsafe-project-root" };
  } catch {
    return { issue: "unsafe-project-root" };
  }
  let cursor = root;
  for (const part of relative(root, target).split(sep).filter(Boolean)) {
    cursor = join(cursor, part);
    try {
      const stat = await lstat(cursor);
      if (stat.isSymbolicLink()) return { issue: "symlinked-definitions" };
      if (cursor !== target && !stat.isDirectory()) return { issue: "unsafe-definitions-ancestry" };
      if (cursor === target && !stat.isDirectory()) return { issue: "definitions-not-directory" };
    } catch (error) {
      if (error.code === "ENOENT") return { missing: true };
      return { issue: "unreadable-definitions" };
    }
  }
  return {};
}

function issue(path, code) {
  return { path, code, status: "unverified" };
}

async function readDefinition(path) {
  const handle = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    const before = await handle.stat();
    if (!before.isFile()) throw new Error("workflow definition is not a regular file");
    const bytes = await handle.readFile();
    const after = await handle.stat();
    if (
      !after.isFile() ||
      before.dev !== after.dev ||
      before.ino !== after.ino ||
      before.size !== after.size ||
      before.mtimeMs !== after.mtimeMs ||
      before.ctimeMs !== after.ctimeMs
    ) {
      throw new Error("workflow definition changed while cataloging");
    }
    return {
      document: parseYaml(bytes.toString("utf8")),
      bytes,
      sourceBytesHash: sha256Bytes(bytes),
      identity: {
        dev: after.dev,
        ino: after.ino,
        size: after.size,
        mtimeMs: after.mtimeMs,
        ctimeMs: after.ctimeMs,
      },
    };
  } finally {
    await handle.close();
  }
}

function sourceChanged() {
  fail("WORKFLOW_SOURCE_CHANGED", "The selected journey changed after verified discovery; evaluate it again");
}

/** Reverify a catalog source identity without rereading or replacing its selected bytes. */
export async function verifyCatalogWorkflowSource(source) {
  if (
    source?.kind !== "verified-project-catalog-source/v1" ||
    !source.workflow ||
    !Buffer.isBuffer(source.bytes) ||
    !/^sha256:[a-f0-9]{64}$/u.test(source.sourceBytesHash ?? "") ||
    sha256Bytes(source.bytes) !== source.sourceBytesHash ||
    typeof source.path !== "string" ||
    !source.identity
  ) {
    sourceChanged();
  }
  let handle;
  try {
    handle = await open(source.path, constants.O_RDONLY | constants.O_NOFOLLOW);
    const current = await handle.stat();
    const expected = source.identity;
    if (
      !current.isFile() ||
      current.dev !== expected.dev ||
      current.ino !== expected.ino ||
      current.size !== expected.size ||
      current.mtimeMs !== expected.mtimeMs ||
      current.ctimeMs !== expected.ctimeMs
    ) {
      sourceChanged();
    }
  } catch (error) {
    if (error instanceof WorkflowError) throw error;
    sourceChanged();
  } finally {
    await handle?.close();
  }
  return source;
}

/** Load only verified, unique workflow definitions selected by a ProjectContext. */
export async function catalogProjectWorkflows(projectContext, options = {}) {
  const definitions = definitionPath(projectContext);
  const directory = await safeDirectory(definitions.root, definitions.absolute);
  if (directory.missing) {
    return {
      projectRoot: definitions.root,
      definitionsRoot: definitions.logical,
      status: "verified",
      workflows: [],
      issues: [],
    };
  }
  if (directory.issue) {
    return {
      projectRoot: definitions.root,
      definitionsRoot: definitions.logical,
      status: "degraded",
      workflows: [],
      issues: [issue(definitions.logical, directory.issue)],
    };
  }

  let entries;
  try {
    entries = await readdir(definitions.absolute, { withFileTypes: true });
  } catch {
    return {
      projectRoot: definitions.root,
      definitionsRoot: definitions.logical,
      status: "degraded",
      workflows: [],
      issues: [issue(definitions.logical, "unreadable-definitions")],
    };
  }
  const registry = options.registry ?? (await createSchemaRegistry());
  const workflows = [];
  const issues = [];

  for (const entry of entries
    .filter((item) => WORKFLOW_FILE.test(item.name))
    .sort((a, b) => a.name.localeCompare(b.name))) {
    const logical = `${definitions.logical}/${entry.name}`;
    const absolute = join(definitions.absolute, entry.name);
    try {
      const stat = await lstat(absolute);
      if (!entry.isFile() || entry.isSymbolicLink() || !stat.isFile() || stat.isSymbolicLink()) {
        issues.push(issue(logical, "unsafe-definition"));
        continue;
      }
      const definition = await readDefinition(absolute);
      const workflow = registry.validate("workflow", definition.document);
      validateWorkflowSemantics(workflow);
      workflows.push({
        id: workflow.metadata.id,
        path: logical,
        status: "verified",
        workflow,
        source: {
          kind: "verified-project-catalog-source/v1",
          workflow,
          bytes: definition.bytes,
          sourceBytesHash: definition.sourceBytesHash,
          path: absolute,
          identity: definition.identity,
        },
      });
    } catch {
      issues.push(issue(logical, "invalid-or-unreadable-definition"));
    }
  }

  const byId = new Map();
  for (const item of workflows) byId.set(item.id, [...(byId.get(item.id) ?? []), item]);
  const duplicateIds = new Set([...byId].filter(([, items]) => items.length > 1).map(([id]) => id));
  const verified = workflows.filter((item) => !duplicateIds.has(item.id));
  for (const id of [...duplicateIds].sort()) {
    for (const item of byId.get(id)) issues.push(issue(item.path, "duplicate-workflow-id"));
  }
  issues.sort((a, b) => a.path.localeCompare(b.path) || a.code.localeCompare(b.code));
  return {
    projectRoot: definitions.root,
    definitionsRoot: definitions.logical,
    status: issues.length ? "degraded" : "verified",
    workflows: verified,
    issues,
  };
}
