/**
 * Verify an artifact from a run that has already been reconstructed.
 *
 * Production stores expose a metadata-only verification path so projections do
 * not reload the run or retain screenshot bytes. The fallbacks keep projections
 * compatible with lightweight stores used by callers and tests.
 */
const STUDIO_EVIDENCE_VERIFY_CONCURRENCY = 4;

export async function verifyRunEvidence({ store, run, artifact, runId = run.manifest?.runId ?? artifact.runId }) {
  if (Object.hasOwn(store, "readVerifiedEvidence") && !Object.hasOwn(store, "verifyRegisteredEvidenceFromRun")) {
    const verified = await store.readVerifiedEvidence(runId, artifact.artifactId);
    return { artifact: verified.artifact };
  }
  if (typeof store.verifyRegisteredEvidenceFromRun === "function") {
    return store.verifyRegisteredEvidenceFromRun(run, artifact.artifactId);
  }
  if (typeof store.readVerifiedEvidenceFromRun === "function") {
    const verified = await store.readVerifiedEvidenceFromRun(run, artifact.artifactId);
    return { artifact: verified.artifact };
  }
  const verified = await store.readVerifiedEvidence(runId, artifact.artifactId);
  return { artifact: verified.artifact };
}

export async function verifyRunEvidenceBatch({
  store,
  run,
  artifacts,
  runId,
  concurrency = STUDIO_EVIDENCE_VERIFY_CONCURRENCY,
}) {
  if (!Number.isSafeInteger(concurrency) || concurrency < 1)
    throw new TypeError("concurrency must be a positive integer");
  const results = new Array(artifacts.length);
  let nextIndex = 0;
  async function worker() {
    while (nextIndex < artifacts.length) {
      const index = nextIndex;
      nextIndex += 1;
      try {
        results[index] = {
          status: "fulfilled",
          value: await verifyRunEvidence({ store, run, artifact: artifacts[index], runId }),
        };
      } catch (reason) {
        results[index] = { status: "rejected", reason };
      }
    }
  }
  await Promise.all(Array.from({ length: Math.min(concurrency, artifacts.length) }, () => worker()));
  return results;
}
