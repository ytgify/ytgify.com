import { execFile as execFileCallback } from "node:child_process";
import { createHash, randomUUID } from "node:crypto";
import { constants } from "node:fs";
import { link, lstat, mkdir, open, readdir, unlink } from "node:fs/promises";
import { isAbsolute, join } from "node:path";
import { promisify } from "node:util";

import { WorkflowError } from "./errors.js";
import { fixtureIdentityBinding } from "./fixture-lifecycle.js";
import { buildRunReport } from "./run-report.js";
import { sha256 } from "./stable-json.js";

const execFile = promisify(execFileCallback);
const sourceDirectory = "supervised-fixture-sources";
const runIdPattern = /^run_[A-Za-z0-9_-]+$/u;
const temporarySourcePattern =
  /^run_[A-Za-z0-9_-]+\.json\.[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}\.tmp$/u;
const hashPattern = /^sha256:[a-f0-9]{64}$/u;
const commitPattern = /^[a-f0-9]{40}$/u;
const artifactPattern = /^artifact_[A-Za-z0-9_-]+$/u;
const fail = (reason) => {
  throw new WorkflowError("SUPERVISED_FIXTURE_SOURCE_INVALID", reason, { exitCode: 3 });
};

function assertSource(source, runId) {
  if (
    !source ||
    Array.isArray(source) ||
    typeof source !== "object" ||
    Object.keys(source).sort().join() !==
      ["schema", "runId", "appCheckout", "appCommit", "receiptPath", "receiptSha256"].sort().join() ||
    source.schema !== "agent-workflow-supervised-fixture-source/v1" ||
    source.runId !== runId ||
    !runIdPattern.test(runId) ||
    !isAbsolute(source.appCheckout ?? "") ||
    !commitPattern.test(source.appCommit ?? "") ||
    !isAbsolute(source.receiptPath ?? "") ||
    !hashPattern.test(source.receiptSha256 ?? "")
  ) {
    fail(
      "Supervised fixture source must pin an exact run, absolute checkout/receipt, app commit, and raw receipt SHA-256",
    );
  }
}

async function regularBytes(path, maximum = 1024 * 1024) {
  let file;
  try {
    const entry = await lstat(path);
    if (!entry.isFile() || entry.isSymbolicLink() || entry.size > maximum)
      fail("Source file is not a bounded regular file");
    file = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW);
    const opened = await file.stat();
    if (!opened.isFile() || opened.dev !== entry.dev || opened.ino !== entry.ino || opened.size !== entry.size)
      fail("Source file changed during verification");
    return await file.readFile();
  } finally {
    await file?.close();
  }
}

async function sourcePath(store, runId, { create = false } = {}) {
  if (!runIdPattern.test(runId)) fail("Invalid supervised run ID");
  const root = await lstat(store.root);
  if (!root.isDirectory() || root.isSymbolicLink()) fail("Run store root is unavailable");
  const directory = join(store.root, sourceDirectory);
  if (create)
    await mkdir(directory, { mode: 0o700 }).catch((error) => {
      if (error.code !== "EEXIST") throw error;
    });
  const entry = await lstat(directory);
  if (!entry.isDirectory() || entry.isSymbolicLink()) fail("Supervised source directory is invalid");
  return join(directory, `${runId}.json`);
}

async function readSource(store, runId) {
  const file = await sourcePath(store, runId);
  let source;
  try {
    source = JSON.parse(await regularBytes(file));
  } catch (error) {
    if (error instanceof SyntaxError) fail("Supervised source JSON is invalid");
    throw error;
  }
  assertSource(source, runId);
  return source;
}

export async function hasSupervisedFixtureSource(store, runId) {
  let file;
  try {
    file = await sourcePath(store, runId);
    const entry = await lstat(file);
    if (!entry.isFile() || entry.isSymbolicLink()) fail("Supervised source file is invalid");
    return true;
  } catch (error) {
    if (error.code === "ENOENT") return false;
    throw error;
  }
}

export async function listSupervisedFixtureSources(store) {
  const directory = join(store.root, sourceDirectory);
  let names;
  try {
    const entry = await lstat(directory);
    if (!entry.isDirectory() || entry.isSymbolicLink()) fail("Supervised source directory is invalid");
    names = await readdir(directory);
  } catch (error) {
    if (error.code === "ENOENT") return [];
    throw error;
  }
  const runs = [];
  for (const name of names.sort()) {
    if (temporarySourcePattern.test(name)) {
      const entry = await lstat(join(directory, name)).catch((error) => {
        if (error.code === "ENOENT") return null;
        throw error;
      });
      if (!entry) continue;
      if (!entry.isFile() || entry.isSymbolicLink()) fail("Supervised source temporary file is invalid");
      continue;
    }
    const match = name.match(/^(run_[A-Za-z0-9_-]+)\.json$/u);
    if (!match) fail("Supervised source directory contains an unexpected entry");
    await readSource(store, match[1]);
    runs.push({ runId: match[1] });
  }
  return runs;
}

async function readPinnedReceipt(source) {
  const app = await lstat(source.appCheckout);
  if (!app.isDirectory() || app.isSymbolicLink()) fail("Pinned app checkout is unavailable");
  const { stdout } = await execFile("git", ["-C", source.appCheckout, "rev-parse", "HEAD"], { timeout: 5000 });
  if (stdout.trim() !== source.appCommit) fail("Pinned app commit differs from checkout HEAD");
  const status = await execFile(
    "git",
    ["-C", source.appCheckout, "status", "--porcelain", "--untracked-files=normal"],
    {
      timeout: 5000,
    },
  );
  if (status.stdout.trim()) fail("Pinned app checkout has tracked or untracked changes");
  const bytes = await regularBytes(source.receiptPath);
  const digest = `sha256:${createHash("sha256").update(bytes).digest("hex")}`;
  if (digest !== source.receiptSha256) fail("Pinned receipt bytes changed");
  let receipt;
  try {
    receipt = JSON.parse(bytes);
  } catch {
    fail("Pinned receipt JSON is invalid");
  }
  if (
    receipt.appSourceSha !== source.appCommit ||
    !hashPattern.test(receipt.recipeHash ?? "") ||
    receipt.sentinelUnchanged !== true
  )
    fail("Receipt does not match the pinned supervised source");
  return receipt;
}

function receiptRuns(receipt, selectedRunId) {
  if (receipt.schema === "workflows-job-apply-companion-dogfood/v1") {
    assertKeys(receipt, [
      "schema",
      "appSourceSha",
      "candidateTarballSha256",
      "target",
      "recipeHash",
      "runs",
      "sentinelUnchanged",
      "limits",
    ]);
    if (!Array.isArray(receipt.runs) || !receipt.runs.some((item) => item.runId === selectedRunId))
      fail("Selected run is absent from the standalone receipt");
    for (const item of receipt.runs)
      assertKeys(item, ["attempt", "runId", "recordId", "instanceId", "status", "evidence", "cleanup", "notesHash"]);
    return receipt.runs.map((item) => ({ ...item, evidence: item.evidence }));
  }
  if (receipt.schema === "workflows-job-apply-borrowed-child-dogfood/v1") {
    assertKeys(receipt, [
      "schema",
      "appSourceSha",
      "candidateTarballSha256",
      "target",
      "recipeHash",
      "parentRunId",
      "childRunId",
      "recordId",
      "parentInstanceId",
      "childInstanceId",
      "sourceInstanceId",
      "parentStatus",
      "childStatus",
      "parentEvidence",
      "childEvidence",
      "cleanupOwnerRunId",
      "cleanup",
      "sentinelUnchanged",
      "companyHash",
      "notesHash",
    ]);
    if (![receipt.parentRunId, receipt.childRunId].includes(selectedRunId))
      fail("Selected run is absent from the parent/child receipt");
    return [
      {
        runId: receipt.parentRunId,
        recordId: receipt.recordId,
        instanceId: receipt.parentInstanceId,
        status: receipt.parentStatus,
        evidence: receipt.parentEvidence,
        cleanup: receipt.cleanup,
      },
      {
        runId: receipt.childRunId,
        recordId: receipt.recordId,
        instanceId: receipt.childInstanceId,
        status: receipt.childStatus,
        evidence: receipt.childEvidence,
        cleanup: receipt.cleanup,
      },
    ];
  }
  fail("Unsupported supervised Job Apply receipt schema");
}

function assertKeys(value, expected) {
  if (
    !value ||
    typeof value !== "object" ||
    Array.isArray(value) ||
    Object.keys(value).sort().join() !== [...expected].sort().join()
  )
    fail("Supervised receipt fields differ from its pinned schema");
}

async function verifiedRun(store, item, receipt) {
  if (
    !runIdPattern.test(item.runId ?? "") ||
    !Array.isArray(item.evidence) ||
    item.evidence.length === 0 ||
    new Set(item.evidence).size !== item.evidence.length ||
    item.evidence.some((id) => !artifactPattern.test(id)) ||
    item.status !== "completed" ||
    item.cleanup !== "cleaned"
  )
    fail("Receipt run or screenshot list is incomplete");
  const run = await store.readRun(item.runId);
  const report = await buildRunReport(store, item.runId, { skipPerspective: true });
  if (
    run.manifest.phase !== "training" ||
    !run.manifest.workflowRef?.id?.startsWith("job-apply.") ||
    run.manifest.fixtureContract?.recipe?.kind !== "application-record" ||
    run.manifest.fixtureContract.recipeHash !== receipt.recipeHash ||
    sha256(run.manifest.fixtureContract.recipe) !== receipt.recipeHash ||
    !run.manifest.fixtureContract.recipe.allowedJourneys.includes(run.manifest.workflowRef?.id) ||
    sha256(run.manifest.target) !== sha256(run.manifest.fixtureContract.recipe.target) ||
    sha256(run.manifest.identity) !== sha256(run.manifest.fixtureContract.recipe.identity) ||
    (run.manifest.target?.effectiveUrl !== `${receipt.target}/` &&
      run.manifest.target?.effectiveUrl !== receipt.target) ||
    report.status !== "completed" ||
    report.outcome !== "passed" ||
    report.cleanupOutcome !== "passed" ||
    Object.values(report.integrity).some((value) => value !== "verified")
  )
    fail("Run report or fixture recipe does not support a clean supervised need");
  const evidence = report.steps
    .flatMap((step) => step.evidence)
    .filter((artifact) => artifact.type === "screenshot")
    .map((artifact) => ({
      runId: item.runId,
      artifactId: artifact.artifactId,
      contentHash: artifact.contentHash,
      stepId: report.steps.find((step) => step.evidence.some((e) => e.artifactId === artifact.artifactId))?.id,
      checkpoint: artifact.checkpoint,
    }));
  if (
    evidence.length !== item.evidence.length ||
    evidence.some(
      (artifact, index) => artifact.artifactId !== item.evidence[index] || !hashPattern.test(artifact.contentHash),
    )
  )
    fail("Receipt screenshots differ from registered verified evidence");
  for (const artifact of evidence) await store.readVerifiedEvidenceFromRun(run, artifact.artifactId);
  return { run, evidence };
}

async function verifyJournal(store, receipt, selected) {
  const parentRunId = receipt.parentRunId ?? selected.runId;
  const transitions = await store.readFixtureTransitions(parentRunId);
  const parent = await store.readRun(parentRunId);
  const recordId = receipt.recordId ?? selected.recordId;
  const targetHash = sha256(parent.manifest.target);
  const identityHash = sha256(fixtureIdentityBinding(parent.manifest));
  const idempotencyKey = sha256({
    runId: parentRunId,
    recipeHash: receipt.recipeHash,
    target: parent.manifest.target,
    identity: fixtureIdentityBinding(parent.manifest),
  });
  if (
    !transitions.length ||
    !recordId ||
    transitions.some(
      (entry) =>
        entry.recipeHash !== receipt.recipeHash ||
        entry.targetHash !== targetHash ||
        entry.identityHash !== identityHash ||
        entry.idempotencyKey !== idempotencyKey ||
        entry.cleanupOwnerRunId !== parentRunId ||
        (entry.recordId && entry.recordId !== recordId),
    ) ||
    transitions[0].type !== "setup.requested" ||
    transitions.at(-1).type !== "cleanup.cleaned" ||
    !transitions.some((entry) => entry.type === "setup.ready" && entry.recordId === recordId)
  )
    fail("Fixture journal does not prove exact owned setup and cleanup");
  verifySupervisedFixtureJournal(transitions, receipt.childRunId ?? null);
  if (receipt.childRunId) {
    const child = await store.readRun(receipt.childRunId);
    const opened = transitions.find(
      (entry) => entry.type === "lease.opened" && entry.childRunId === receipt.childRunId,
    );
    const closed = transitions.find(
      (entry) => entry.type === "lease.closed" && entry.childRunId === receipt.childRunId,
    );
    if (
      child.manifest.parentRunId !== parentRunId ||
      child.manifest.fixtureContract?.recipeHash !== receipt.recipeHash ||
      !opened ||
      !closed ||
      opened.sequence >= closed.sequence ||
      receipt.cleanupOwnerRunId !== parentRunId ||
      receipt.sourceInstanceId !== receipt.parentInstanceId ||
      !receipt.childInstanceId ||
      !receipt.parentInstanceId
    )
      fail("Parent/child fixture lineage differs from journal and receipt");
  }
  return { recordId, parentRunId };
}

/** Check state order, including a single exact parent/child borrow when present. */
export function verifySupervisedFixtureJournal(transitions, childRunId = null) {
  let state = "unbound";
  let child = null;
  let opens = 0;
  let closes = 0;
  for (const transition of transitions) {
    switch (transition.type) {
      case "setup.requested":
        if (state !== "unbound") fail("Fixture setup journal is out of order");
        state = "uncertain";
        break;
      case "setup.returned":
      case "setup.uncertain":
        if (state !== "uncertain") fail("Fixture setup journal is out of order");
        break;
      case "setup.ready":
        if (state !== "uncertain") fail("Fixture readiness journal is out of order");
        state = "ready";
        break;
      case "lease.opened":
        if (state !== "ready" || child || transition.childRunId !== childRunId || opens)
          fail("Fixture child lease journal is inconsistent");
        child = transition.childRunId;
        opens += 1;
        break;
      case "lease.closed":
        if (state !== "ready" || child !== transition.childRunId || transition.childRunId !== childRunId)
          fail("Fixture child lease journal is inconsistent");
        child = null;
        closes += 1;
        break;
      case "cleanup.requested":
        if (state !== "ready" || child || (childRunId && closes !== 1))
          fail("Fixture cleanup began before child lease closure");
        state = "cleanup-pending";
        break;
      case "cleanup.pending":
        if (state !== "cleanup-pending") fail("Fixture cleanup journal is out of order");
        break;
      case "cleanup.cleaned":
        if (state !== "cleanup-pending") fail("Fixture cleanup journal is out of order");
        state = "cleaned";
        break;
      default:
        fail("Fixture journal contains an unknown transition");
    }
  }
  if (state !== "cleaned" || child || (childRunId && (opens !== 1 || closes !== 1)))
    fail("Fixture journal does not prove completed cleanup");
}

async function projectFromSource(store, runId, source) {
  const receipt = await readPinnedReceipt(source);
  const listed = receiptRuns(receipt, runId);
  if (new Set(listed.map((item) => item.runId)).size !== listed.length) fail("Receipt duplicates a run");
  const verified = new Map();
  for (const item of listed) verified.set(item.runId, await verifiedRun(store, item, receipt));
  const selected = listed.find((item) => item.runId === runId);
  let lineage;
  if (!receipt.childRunId) {
    for (const item of listed) {
      const checked = await verifyJournal(store, receipt, item);
      if (item.runId === runId) lineage = checked;
    }
  } else {
    lineage = await verifyJournal(store, receipt, selected);
  }
  const { run, evidence } = verified.get(runId);
  const recipe = run.manifest.fixtureContract.recipe;
  return {
    fixtureNeeds: [
      {
        id: `fixture_need_${runId}`,
        journeyId: run.manifest.workflowRef.id,
        status: "unaccepted",
        source: "supervised-inspection",
        kind: "application-record",
        cardinality: 1,
        target: run.manifest.target,
        identity: run.manifest.identity,
        sourceRevision: source.appCommit,
        sourceReceiptHash: source.receiptSha256,
        evidence,
        fieldProvenance: {
          observed: ["journeyId", "target", "identity", "recordId", "recipeHash", "evidence", "cleanup"],
          adapterSupplied: ["setupOperation", "readByIdOperation", "readByKeyOperation", "deleteByIdOperation"],
          operatorSupplied: ["appCheckout", "receiptPath"],
        },
        observed: {
          recordId: lineage.recordId,
          cleanupOwnerRunId: lineage.parentRunId,
          recipeHash: receipt.recipeHash,
          recipeId: recipe.id,
          recipeRevision: recipe.revision,
        },
        unresolved: [
          "Adapter permission and operation semantics require independent review before recipe compilation.",
          "Private target and identity must be repinned for a new fixture run.",
          "Native readback claims are pinned receipt statements; this projection does not rerun native readback.",
        ],
        uncertainty: [
          "This supervised inspection proves a past private synthetic run, not permission to create another record.",
          "Recipe, adapter, ownership, and retention require separate review.",
        ],
      },
    ],
  };
}

export async function projectSupervisedFixtureNeed(store, runId) {
  return projectFromSource(store, runId, await readSource(store, runId));
}

/** Register one immutable source manifest only after the entire proof verifies. */
export async function importSupervisedFixtureSource(store, runId, source) {
  assertSource(source, runId);
  const review = await projectFromSource(store, runId, source);
  const path = await sourcePath(store, runId, { create: true });
  const temporary = `${path}.${randomUUID()}.tmp`;
  let file;
  try {
    file = await open(temporary, "wx", 0o600);
    await file.writeFile(`${JSON.stringify(source, null, 2)}\n`);
    await file.sync();
    await file.close();
    file = null;
    try {
      await link(temporary, path);
    } catch (error) {
      if (error.code === "EEXIST") fail("Supervised source is already registered and immutable");
      throw error;
    }
    const directory = await open(join(store.root, sourceDirectory), "r");
    try {
      await directory.sync();
    } finally {
      await directory.close();
    }
  } finally {
    try {
      await file?.close();
    } finally {
      await unlink(temporary).catch(() => {});
    }
  }
  return review;
}
