import { readMapRegistry, importMapRegistry } from "./app-map-registry.js";
import { orderedMapEvidence } from "./app-map-contract.js";
import { verifyRunEvidenceBatch } from "./studio-evidence-verifier.js";
import { StudioMutationError } from "./studio-mutation-security.js";

export function mapRegistrySummary(document) {
  const screens = new Map();
  for (const { appId, screenId, screenLabel } of document.assignments) {
    screens.set(JSON.stringify([appId, screenId]), { appId, screenId, screenLabel });
  }
  const variants = new Map();
  for (const { appId, screenId, variantId, variantLabel } of document.assignments) {
    if (variantId)
      variants.set(JSON.stringify([appId, screenId, variantId]), { appId, screenId, variantId, variantLabel });
  }
  return {
    revision: document.revision,
    assignments: document.assignments,
    screens: [...screens.values()],
    ...(variants.size ? { variants: [...variants.values()] } : {}),
  };
}

export async function readStudioMapRegistry(store, registry) {
  try {
    return mapRegistrySummary(await readMapRegistry(store, registry));
  } catch {
    throw new StudioMutationError(503, "APP_MAP_REGISTRY_UNAVAILABLE");
  }
}

function compare(left, right) {
  return String(left ?? "").localeCompare(String(right ?? ""));
}

function boundedJourneyLabel(workflowName, workflowId) {
  const label = [workflowName, workflowId].find((value) => typeof value === "string" && value.trim())?.trim();
  const characters = [...(label ?? "Unavailable journey")];
  return characters.length <= 160 ? characters.join("") : `${characters.slice(0, 159).join("")}…`;
}

function evidenceIntegrity(error) {
  const code = typeof error?.code === "string" ? error.code : "";
  if (
    error instanceof SyntaxError ||
    code.endsWith("HASH_MISMATCH") ||
    new Set(["SIZE_MISMATCH", "CORRUPT", "VALIDATION_FAILED", "RUN_INDEX_CORRUPT", "ILLEGAL_TRANSITION"]).has(code)
  )
    return "corrupt";
  if (new Set(["ENOENT", "NOT_FOUND", "ARTIFACT_NOT_FOUND", "RUN_NOT_FOUND"]).has(code)) return "missing";
  return "unavailable";
}

function observationOrder(left, right) {
  const leftId = left.technicalIdentity;
  const rightId = right.technicalIdentity;
  return (
    compare(leftId.workflowId, rightId.workflowId) ||
    compare(leftId.runId, rightId.runId) ||
    leftId.sequence - rightId.sequence ||
    leftId.ordinal - rightId.ordinal ||
    compare(leftId.visitId, rightId.visitId)
  );
}

function visitIdentityOrder(left, right) {
  const [, leftSequence, leftOrdinal, leftArtifactId, leftContentHash] = JSON.parse(left);
  const [, rightSequence, rightOrdinal, rightArtifactId, rightContentHash] = JSON.parse(right);
  return (
    leftSequence - rightSequence ||
    leftOrdinal - rightOrdinal ||
    compare(leftArtifactId, rightArtifactId) ||
    compare(leftContentHash, rightContentHash)
  );
}

/**
 * Project the durable assignment registry into the application-level contract.
 * Identity stays explicit metadata: labels never derive from routes, screenshots,
 * DOM, workflow steps, or any other evidence heuristic.
 */
export async function projectStudioAppMap(store, registry) {
  let document;
  try {
    document = await readMapRegistry(store, registry);
  } catch {
    throw new StudioMutationError(503, "APP_MAP_REGISTRY_UNAVAILABLE");
  }

  const diagnostics = [];
  const runs = new Map();
  const assignmentsByRun = new Map();
  for (const assignment of document.assignments) {
    const [runId] = JSON.parse(assignment.visitId);
    assignmentsByRun.set(runId, [...(assignmentsByRun.get(runId) ?? []), assignment]);
    if (runs.has(runId)) continue;
    try {
      const run = await store.readRun(runId);
      runs.set(runId, {
        run,
        visits: new Map(orderedMapEvidence(run.events).map((visit) => [visit.visitId, visit])),
        verifications: new Map(),
      });
    } catch (error) {
      const integrity = evidenceIntegrity(error);
      runs.set(runId, { run: null, visits: new Map(), failureIntegrity: integrity });
      diagnostics.push(`Run ${runId} is ${integrity}; assigned observations are stale`);
    }
  }

  for (const [runId, source] of runs) {
    if (!source.run) continue;
    const candidates = (assignmentsByRun.get(runId) ?? []).flatMap((assignment) => {
      const visit = source.visits.get(assignment.visitId);
      if (!visit?.registered || source.run.workflow?.target?.app !== assignment.appId) return [];
      return [{ visitId: assignment.visitId, artifact: visit.artifact }];
    });
    const verdicts = await verifyRunEvidenceBatch({
      store,
      run: source.run,
      runId,
      artifacts: candidates.map((candidate) => candidate.artifact),
    });
    for (const [index, verdict] of verdicts.entries()) {
      source.verifications.set(
        candidates[index].visitId,
        verdict.status === "fulfilled" ? "verified" : evidenceIntegrity(verdict.reason),
      );
    }
  }

  const applications = new Map();
  const observationByVisit = new Map();
  for (const assignment of document.assignments) {
    const identity = JSON.parse(assignment.visitId);
    const [runId, sequence, ordinal, artifactId, contentHash] = identity;
    const source = runs.get(runId);
    const run = source?.run;
    const visit = source?.visits.get(assignment.visitId);
    const current = Boolean(visit && run?.workflow?.target?.app === assignment.appId);
    let integrity = source?.failureIntegrity ?? "unavailable";
    if (current && visit.registered) integrity = source.verifications.get(assignment.visitId) ?? "unavailable";
    if (!current) diagnostics.push(`Observation ${assignment.visitId} no longer matches exact run evidence`);

    const workflowId = run?.manifest?.workflowRef?.id ?? run?.workflow?.metadata?.id ?? null;
    const journeyLabel = assignment.journeyLabel ?? boundedJourneyLabel(run?.workflow?.metadata?.name, workflowId);
    const observation = {
      journeyLabel,
      platform: run?.manifest?.platform ?? null,
      stateLabel: assignment.stateLabel ?? null,
      evidence: {
        url:
          current && visit.registered && integrity === "verified"
            ? `/api/runs/${encodeURIComponent(runId)}/artifacts/${encodeURIComponent(artifactId)}`
            : null,
        integrity,
        freshness: current ? "current" : "stale",
      },
      technicalIdentity: {
        visitId: assignment.visitId,
        runId,
        workflowId,
        artifactId,
        contentHash,
        sequence,
        ordinal,
      },
    };
    observationByVisit.set(assignment.visitId, { assignment, observation });

    let application = applications.get(assignment.appId);
    if (!application) {
      application = { appId: assignment.appId, screens: new Map(), transitions: new Map() };
      applications.set(assignment.appId, application);
    }
    let screen = application.screens.get(assignment.screenId);
    if (!screen) {
      screen = { screenId: assignment.screenId, screenLabel: assignment.screenLabel, variants: new Map() };
      application.screens.set(assignment.screenId, screen);
    }
    const variantKey = assignment.variantId ?? "";
    let variant = screen.variants.get(variantKey);
    if (!variant) {
      variant = {
        variantId: assignment.variantId ?? null,
        variantLabel: assignment.variantLabel ?? null,
        classification: assignment.variantId ? "named" : "unclassified",
        observations: [],
      };
      screen.variants.set(variantKey, variant);
    }
    variant.observations.push(observation);
  }

  for (const [runId, source] of runs) {
    if (!source?.run) continue;
    let previous = null;
    for (const visit of source.visits.values()) {
      const projected = observationByVisit.get(visit.visitId);
      if (
        !projected ||
        projected.observation.evidence.freshness !== "current" ||
        projected.observation.evidence.integrity !== "verified"
      ) {
        previous = null;
        continue;
      }
      if (previous && previous.assignment.screenId !== projected.assignment.screenId) {
        const application = applications.get(projected.assignment.appId);
        if (previous.assignment.appId !== projected.assignment.appId || !application) {
          previous = projected;
          continue;
        }
        const transitionKey = JSON.stringify([previous.assignment.screenId, projected.assignment.screenId]);
        let transition = application.transitions.get(transitionKey);
        if (!transition) {
          transition = {
            fromScreenId: previous.assignment.screenId,
            toScreenId: projected.assignment.screenId,
            occurrences: [],
          };
          application.transitions.set(transitionKey, transition);
        }
        transition.occurrences.push({
          journeyLabel: projected.observation.journeyLabel,
          platform: projected.observation.platform,
          fromVisitId: previous.assignment.visitId,
          toVisitId: projected.assignment.visitId,
          runId,
        });
      }
      previous = projected;
    }
  }

  const projection = {
    schema: "workflows-semantic-app-map/v1",
    revision: document.revision,
    applications: [...applications.values()]
      .sort((left, right) => compare(left.appId, right.appId))
      .map((application) => ({
        appId: application.appId,
        screens: [...application.screens.values()]
          .sort((left, right) => compare(left.screenId, right.screenId))
          .map((screen) => ({
            screenId: screen.screenId,
            screenLabel: screen.screenLabel,
            variants: [...screen.variants.values()]
              .sort((left, right) => compare(left.variantId, right.variantId))
              .map((variant) => ({
                ...variant,
                observations: variant.observations.sort(observationOrder),
              })),
          })),
        transitions: [...application.transitions.values()]
          .sort(
            (left, right) =>
              compare(left.fromScreenId, right.fromScreenId) || compare(left.toScreenId, right.toScreenId),
          )
          .map((transition) => ({
            ...transition,
            occurrences: transition.occurrences.sort(
              (left, right) =>
                compare(left.runId, right.runId) ||
                visitIdentityOrder(left.fromVisitId, right.fromVisitId) ||
                visitIdentityOrder(left.toVisitId, right.toVisitId),
            ),
          })),
      })),
    diagnostics: [...new Set(diagnostics)].sort(compare),
  };
  registry.validate("appMapProjection", projection);
  return projection;
}

function invalid() {
  throw new StudioMutationError(400, "INVALID_MAP_ASSIGNMENT");
}

function validateRequest(body) {
  if (
    !body ||
    Array.isArray(body) ||
    typeof body !== "object" ||
    Object.keys(body).some((key) => !["expectedRevision", "visitId", "appId", "screen"].includes(key)) ||
    !Number.isSafeInteger(body.expectedRevision) ||
    body.expectedRevision < 0 ||
    typeof body.visitId !== "string" ||
    body.visitId.length > 1024 ||
    typeof body.appId !== "string" ||
    !/^[a-z][a-z0-9._-]*$/.test(body.appId)
  )
    invalid();
  if (body.screen !== null) {
    if (
      !body.screen ||
      Array.isArray(body.screen) ||
      typeof body.screen !== "object" ||
      Object.keys(body.screen).some(
        (key) => !["screenId", "screenLabel", "stateLabel", "variantId", "variantLabel", "journeyLabel"].includes(key),
      ) ||
      typeof body.screen.screenLabel !== "string" ||
      !body.screen.screenLabel.trim()
    )
      invalid();
  }
}

export async function updateStudioMapAssignment(store, registry, body) {
  validateRequest(body);
  const previous = await readStudioMapRegistry(store, registry);
  if (previous.revision !== body.expectedRevision) throw new StudioMutationError(409, "REVISION_CONFLICT");
  try {
    const identity = JSON.parse(body.visitId);
    if (!Array.isArray(identity) || !/^run_[A-Za-z0-9_-]+$/.test(identity[0])) invalid();
    const run = await store.readRun(identity[0]);
    const visit = orderedMapEvidence(run.events).find((item) => item.visitId === body.visitId);
    if (!visit?.registered || run.workflow?.target?.app !== body.appId) invalid();
    await store.readVerifiedEvidence(identity[0], visit.artifact.artifactId);
    const assignments = previous.assignments.filter((item) => item.visitId !== body.visitId);
    if (body.screen !== null) assignments.push({ visitId: body.visitId, appId: body.appId, ...body.screen });
    return mapRegistrySummary(
      await importMapRegistry(
        store,
        registry,
        {
          schema: "workflows-app-map-registry/v1",
          assignments,
        },
        body.expectedRevision,
      ),
    );
  } catch (error) {
    if (error.code === "EEXIST" || error.message === "Map registry revision changed; read it before retrying") {
      throw new StudioMutationError(409, "REVISION_CONFLICT");
    }
    if (error instanceof StudioMutationError) throw error;
    invalid();
  }
}
