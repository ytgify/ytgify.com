const TERMINAL_RUN_STATUSES = new Set(["completed", "blocked", "failed", "abandoned"]);

export function classifyStudioRunDispositions(runs) {
  const newerTerminal = new Set();
  return runs.map((run) => {
    const key = [run.workflow?.id, run.classification, run.platform].join(":");
    let disposition = "unfinished";
    let dispositionReason = "This run has not reached a terminal outcome.";
    if (run.status === "unavailable") {
      disposition = "unavailable";
      dispositionReason = "The run could not be reconstructed safely.";
    } else if (TERMINAL_RUN_STATUSES.has(run.status)) {
      disposition = "evidence";
      dispositionReason = "This terminal run remains available as immutable evidence.";
      newerTerminal.add(key);
    } else if (newerTerminal.has(key)) {
      disposition = "superseded";
      dispositionReason = "A newer terminal run exists for the same platform and run type.";
    }
    return { ...run, disposition, dispositionReason };
  });
}
