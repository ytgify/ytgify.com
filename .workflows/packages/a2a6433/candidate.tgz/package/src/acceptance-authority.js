import { randomUUID } from "node:crypto";
import { link, lstat, mkdir, open, unlink } from "node:fs/promises";
import { dirname, isAbsolute, join, relative, resolve, sep } from "node:path";

import { reverifyAcceptanceEvidence } from "./acceptance-evidence.js";
import { AcceptanceStore } from "./acceptance-store.js";
import { WorkflowError } from "./errors.js";
import { sha256 } from "./stable-json.js";

function fail(code, message, details, exitCode = 3) {
  throw new WorkflowError(code, message, { exitCode, details });
}

async function syncDirectory(path) {
  const handle = await open(path, "r");
  try {
    await handle.sync();
  } finally {
    await handle.close();
  }
}

async function immutableWrite(path, bytes) {
  const temporary = `${path}.${randomUUID()}.tmp`;
  const handle = await open(temporary, "wx", 0o600);
  try {
    await handle.writeFile(bytes);
    await handle.sync();
  } finally {
    await handle.close();
  }
  try {
    await link(temporary, path);
    await syncDirectory(dirname(path));
  } catch (error) {
    if (error.code === "EEXIST")
      fail("IMMUTABLE_ACCEPTANCE_EXISTS", "Acceptance records cannot be replaced", { path }, 4);
    throw error;
  } finally {
    await unlink(temporary).catch(() => {});
  }
}

async function withAcceptanceLock(root, operation) {
  const path = join(root, ".write.lock");
  let handle;
  try {
    handle = await open(path, "wx", 0o600);
  } catch (error) {
    if (error.code === "EEXIST")
      fail("ACCEPTANCE_STORE_LOCKED", "Another acceptance mutation is in progress", undefined, 6);
    throw error;
  }
  try {
    return await operation();
  } finally {
    await handle.close();
    await unlink(path).catch(() => {});
  }
}

async function assertAcceptanceHead(store, candidate) {
  const records = await Promise.all(
    (await store.listAcceptanceIds()).map((acceptanceId) => store.readAcceptance(acceptanceId)),
  );
  const sameWorkflow = records.filter(({ workflowId }) => workflowId === candidate.workflowId);
  const superseded = new Set(sameWorkflow.map(({ supersedesAcceptanceId }) => supersedesAcceptanceId).filter(Boolean));
  const heads = sameWorkflow.filter(({ acceptanceId }) => !superseded.has(acceptanceId));
  if (heads.length > 1) fail("ACCEPTANCE_HEAD_AMBIGUOUS", "Existing acceptance history is ambiguous", undefined, 4);
  const expected = heads[0]?.acceptanceId;
  if (candidate.supersedesAcceptanceId !== expected) {
    fail(
      "REVISION_CONFLICT",
      "Acceptance no longer supersedes the current journey decision",
      {
        expected: expected ?? null,
        actual: candidate.supersedesAcceptanceId ?? null,
      },
      4,
    );
  }
}

async function assertSafeAncestry(root, target) {
  const resolvedRoot = resolve(root);
  const resolvedTarget = resolve(target);
  const suffix = relative(resolvedRoot, resolvedTarget);
  if (suffix === ".." || suffix.startsWith(`..${sep}`) || isAbsolute(suffix)) {
    fail("PATH_TRAVERSAL", "Acceptance path escapes its project");
  }
  let cursor = resolvedRoot;
  const rootEntry = await lstat(cursor);
  if (!rootEntry.isDirectory() || rootEntry.isSymbolicLink())
    fail("ACCEPTANCE_STORE_UNSAFE", "Project root must be a real directory");
  for (const part of suffix.split(sep).filter(Boolean)) {
    cursor = join(cursor, part);
    try {
      const entry = await lstat(cursor);
      if (entry.isSymbolicLink()) fail("ACCEPTANCE_STORE_UNSAFE", "Acceptance ancestry cannot contain symlinks");
      if (cursor !== resolvedTarget && !entry.isDirectory())
        fail("ACCEPTANCE_STORE_UNSAFE", "Acceptance ancestry must contain directories");
    } catch (error) {
      if (error.code === "ENOENT") break;
      throw error;
    }
  }
}

function assertResumable(run, runId, expectedRevision) {
  if (run.state.runId !== runId || run.state.revision !== expectedRevision || run.state.status !== "paused") {
    fail(
      "REVISION_CONFLICT",
      "Run is no longer the exact paused revision",
      {
        expected: expectedRevision,
        current: run.state.revision,
        status: run.state.status,
      },
      4,
    );
  }
  if (run.manifest.nonResumable) fail("RUN_NON_RESUMABLE", "This run cannot be resumed", undefined, 4);
}

/** Resume records agent execution under existing user authorization. */
export async function resumeRun({ store, runId, expectedRevision, idempotencyKey, now = () => new Date() }) {
  if (!/^req_[A-Za-z0-9_-]+$/u.test(idempotencyKey ?? ""))
    fail("INVALID_REQUEST", "Resume requires an idempotency key");
  const request = { command: "resume", expectedRevision, idempotencyKey };
  const prior = await store.readTransaction?.(runId, idempotencyKey);
  if (prior) {
    if (prior.receipt.operation !== "run.resume" || prior.receipt.requestHash !== sha256(request))
      fail("IDEMPOTENCY_CONFLICT", "Resume request key was already used for different input", undefined, 4);
    return prior;
  }
  const before = await store.readRun(runId);
  assertResumable(before, runId, expectedRevision);

  return store.appendTransaction(runId, {
    operation: "run.resume",
    requestId: idempotencyKey,
    request,
    result: { resumed: true },
    receiptId: `receipt_${randomUUID().replaceAll("-", "")}`,
    eventId: `evt_${randomUUID().replaceAll("-", "")}`,
    occurredAt: now().toISOString(),
    type: "run.resumed",
    source: "agent-host",
    payload: {
      authority: {
        actorKind: "agent",
        channel: "agent-command",
        interactive: false,
        bindingHash: sha256(request),
      },
    },
    beforeAppend: async ({ current }) => {
      assertResumable(current, runId, expectedRevision);
    },
  });
}

/** Independently verify before recording and again immediately before immutable commit. */
export async function recordOptionalReview({ projectContext, record, registry, now = () => new Date() }) {
  registry.validate("projectContext", projectContext);
  const candidate = structuredClone(record);
  delete candidate.authority;
  delete candidate.acceptedAt;
  if (!/^acceptance_[A-Za-z0-9_-]+$/u.test(candidate.acceptanceId ?? ""))
    fail("INVALID_ACCEPTANCE_ID", "Invalid acceptance ID");
  const root = resolve(projectContext.projectRoot, ...projectContext.paths.localStore.split("/"), "acceptances");
  await assertSafeAncestry(projectContext.projectRoot, root);
  await mkdir(root, { recursive: true });
  const entry = await lstat(root);
  if (!entry.isDirectory() || entry.isSymbolicLink())
    fail("ACCEPTANCE_STORE_UNSAFE", "Acceptance root must be a real directory");
  const store = new AcceptanceStore(projectContext, { registry });
  await assertAcceptanceHead(store, candidate);
  const first = await reverifyAcceptanceEvidence(projectContext, candidate.evidence, candidate, { registry });
  if (!first)
    fail("ACCEPTANCE_EVIDENCE_UNAVAILABLE", "Evaluation evidence does not exactly support this decision", undefined, 4);
  return withAcceptanceLock(root, async () => {
    await assertAcceptanceHead(store, candidate);
    const second = await reverifyAcceptanceEvidence(projectContext, candidate.evidence, candidate, { registry });
    if (!second || sha256(second) !== sha256(first))
      fail("ACCEPTANCE_EVIDENCE_CHANGED", "Evaluation evidence changed during review verification", undefined, 4);
    const committed = {
      ...candidate,
      authority: {
        actorKind: "agent",
        channel: "agent-command",
        interactive: false,
        bindingHash: sha256(candidate),
      },
      acceptedAt: now().toISOString(),
    };
    registry.validate("acceptance", committed);
    await immutableWrite(
      join(root, `${committed.acceptanceId}.json`),
      Buffer.from(`${JSON.stringify(committed, null, 2)}\n`),
    );
    return structuredClone(committed);
  });
}

// Legacy import aliases; neither function reads a terminal.
export { resumeRun as resumeWithAttachedTerminal, recordOptionalReview as acceptWithAttachedTerminal };
