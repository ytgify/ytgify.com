import { lstat, readdir } from "node:fs/promises";
import { basename, join, resolve } from "node:path";

import { readYaml } from "./schema-registry.js";
import { validateWorkflowSemantics } from "./workflow.js";

const WORKFLOW_FILE = /\.workflow\.ya?ml$/;

function text(value) {
  return typeof value === "string" ? value : null;
}

function strings(value) {
  return Array.isArray(value) ? value.filter((item) => typeof item === "string") : [];
}

function viewport(value) {
  if (value === "default-desktop") return { preset: value };
  if (!value || typeof value !== "object") return null;
  return { width: value.width, height: value.height };
}

async function explicitWorkflowFiles({ definitionsRoot, workflowPaths }) {
  if (Array.isArray(workflowPaths)) return workflowPaths.map((path) => resolve(path));
  const root = resolve(definitionsRoot ?? ".workflows");
  try {
    const rootStat = await lstat(root);
    if (!rootStat.isDirectory() || rootStat.isSymbolicLink()) return [];
    const entries = await readdir(root, { withFileTypes: true });
    return entries
      .filter((entry) => entry.isFile() && WORKFLOW_FILE.test(entry.name))
      .map((entry) => join(root, entry.name))
      .sort();
  } catch (error) {
    if (error?.code === "ENOENT") return [];
    throw error;
  }
}

async function loadDefinition(path, registry) {
  const stat = await lstat(path);
  if (!stat.isFile() || stat.isSymbolicLink()) throw new Error("unsafe workflow definition");
  const workflow = registry.validate("workflow", await readYaml(path));
  validateWorkflowSemantics(workflow);
  return workflow;
}

function projectEvidence(evidence) {
  if (!evidence || typeof evidence !== "object") return null;
  return {
    type: text(evidence.type) ?? "unknown",
    checkpoint: text(evidence.checkpoint),
    required: evidence.required !== false,
  };
}

function projectStep(step, platformOverrides) {
  return {
    id: step.id,
    name: step.name,
    action: step.action,
    dependsOn: strings(step.dependsOn),
    expected: strings(step.expected),
    evidence: (step.evidence ?? []).map(projectEvidence).filter(Boolean),
    optionalHandlers: strings(step.optionalHandlers),
    platformGuidance: Object.fromEntries(
      Object.entries(platformOverrides ?? {})
        .map(([platformId, override]) => [platformId, text(override?.steps?.[step.id]?.actionGuidance)])
        .filter(([, guidance]) => guidance),
    ),
  };
}

function latestVersion(lifecycle, workflowId) {
  const versions = lifecycle.workflows.find((item) => item.workflowId === workflowId)?.versions ?? [];
  return versions.at(-1) ?? null;
}

function qualificationFor(lifecycle, workflowId, revision, platformId) {
  if (!revision) return { qualificationId: null, integrity: "missing" };
  return (
    lifecycle.qualificationMatrix?.[workflowId]?.[revision]?.[platformId] ?? {
      qualificationId: null,
      integrity: "missing",
    }
  );
}

function platformName(id) {
  if (id === "desktop-web") return "Desktop";
  if (id === "mobile-web") return "Mobile";
  return id;
}

function qualificationDimensions(workflow) {
  return workflow.platforms.map((platform) => ({
    id: platform.id,
    label: platformName(platform.id),
    status:
      platform.qualification.integrity === "verified"
        ? "Qualified"
        : platform.qualification.integrity === "missing"
          ? "Not qualified"
          : "Status unavailable",
  }));
}

function action(id, label, view, next) {
  return { id, label, view, next };
}

const REQUIRED_EVALUATION_PLATFORMS = ["desktop-web", "mobile-web"];

/**
 * Reduce detailed paired-evaluation records to conservative lifecycle truth.
 * Success requires both expected platforms, verified lineage and receipts,
 * passed journeys, and non-empty fully verified evidence sets.
 */
export function projectStudioEvaluationTruth(workflow, evaluationReview, sources = {}) {
  const revision = workflow.release?.revision ?? null;
  if (
    sources.runs !== "verified" ||
    sources.lifecycle !== "verified" ||
    evaluationReview?.sources?.lifecycle !== "verified"
  ) {
    return { status: "unavailable", evidence: "unavailable", groupId: null, revision };
  }
  const group = evaluationReview.groups?.find((item) => item.revision === revision) ?? null;
  if (!group) return { status: "none", evidence: "none", groupId: null, revision };
  if (["passed", "failed", "incomplete", "degraded"].includes(group.outcome)) {
    return {
      status: group.outcome,
      evidence: group.outcome === "passed" ? "verified" : group.outcome === "failed" ? "not-verified" : "unavailable",
      groupId: group.groupId,
      revision: group.revision,
    };
  }
  const members = REQUIRED_EVALUATION_PLATFORMS.map((platform) =>
    group.members?.find((member) => member.platform === platform),
  );
  if (members.some((member) => !member)) {
    return { status: "incomplete", evidence: "unavailable", groupId: group.groupId, revision: group.revision };
  }
  const trustworthyLineage =
    group.integrity === "verified" &&
    members.every(
      (member) =>
        member.integrity === "verified" &&
        member.qualification?.integrity === "verified" &&
        member.run &&
        ["completed", "failed"].includes(member.run.status),
    );
  const explicitFailure = members.some(
    (member) =>
      member.run?.journeyOutcome === "failed" ||
      member.receipt?.outcome === "failed" ||
      (member.run?.evidenceReview?.required?.failed ?? member.run?.artifactSummary?.failed ?? 0) > 0,
  );
  if (trustworthyLineage && explicitFailure) {
    return { status: "failed", evidence: "not-verified", groupId: group.groupId, revision: group.revision };
  }
  const passed =
    group.integrity === "verified" &&
    members.every(
      (member) =>
        member.integrity === "verified" &&
        member.qualification?.integrity === "verified" &&
        member.receipt?.outcome === "passed" &&
        member.run?.status === "completed" &&
        member.run.journeyOutcome === "passed" &&
        (member.run.evidenceReview
          ? member.run.evidenceReview.outcome === "passed"
          : member.run.artifactSummary?.total > 0 &&
            member.run.artifactSummary.verified === member.run.artifactSummary.total &&
            member.run.artifactSummary.failed === 0),
    );
  if (passed) return { status: "passed", evidence: "verified", groupId: group.groupId, revision: group.revision };
  const incomplete = trustworthyLineage && !explicitFailure;
  return {
    status: incomplete ? "incomplete" : "unavailable",
    evidence: "unavailable",
    groupId: group.groupId,
    revision: group.revision,
  };
}

/**
 * Produce the sole operator-facing decision after the server has assembled all
 * independent lifecycle sources. The dimensions stay inspectable and ordered
 * precedence only selects the safest review destination; it is not a score.
 */
export function deriveStudioDecision(workflow, { sources = {}, evaluation } = {}) {
  const qualifications = qualificationDimensions(workflow);
  const allQualified = qualifications.length > 0 && qualifications.every((item) => item.status === "Qualified");
  const qualificationUnavailable = qualifications.some((item) => item.status === "Status unavailable");
  const findings = workflow.findings ?? { status: "unavailable", open: null, degraded: null };
  const reopenedFindings = findings.reopened ?? 0;
  const unavailableFindings = findings.unavailable ?? Math.max(0, (findings.degraded ?? 0) - reopenedFindings);
  const knownOpenFindings =
    findings.status === "available" &&
    unavailableFindings === 0 &&
    Number.isInteger(findings.open) &&
    findings.open > 0;
  const verifiedRepair = workflow.repair?.status === "verified";
  const findingsUnavailable = findings.status !== "available" || findings.open === null || unavailableFindings > 0;
  const releaseUnavailable = workflow.release && workflow.release.integrity !== "verified";
  const sourceUnavailable =
    sources.runs !== "verified" ||
    sources.lifecycle !== "verified" ||
    evaluation?.status === "unavailable" ||
    qualificationUnavailable;
  const dimensions = {
    draft: workflow.draft.status === "candidate" ? "Draft" : "No draft",
    release: workflow.release ? (releaseUnavailable ? "Status unavailable" : "Release available") : "No release",
    qualifications,
    evaluation:
      evaluation?.status === "passed"
        ? "Evaluation passed"
        : evaluation?.status === "failed"
          ? "Evaluation failed"
          : evaluation?.status === "incomplete"
            ? "Evaluation incomplete"
            : evaluation?.status === "degraded"
              ? "Evaluation degraded"
              : evaluation?.status === "none"
                ? "No evaluation"
                : "Status unavailable",
    evidence:
      evaluation?.evidence === "verified"
        ? "Verified evidence"
        : evaluation?.evidence === "not-verified"
          ? "Evidence not verified"
          : evaluation?.evidence === "none"
            ? "No evidence"
            : "Status unavailable",
    findings: knownOpenFindings
      ? `${findings.open} findings open${reopenedFindings ? `, including ${reopenedFindings} reopened` : ""}`
      : findingsUnavailable
        ? "Status unavailable"
        : verifiedRepair && (findings.resolved ?? 0) > 0
          ? `${findings.resolved} findings resolved`
          : "No findings reported",
  };

  let state;
  let summary;
  let primaryAction;
  if (knownOpenFindings) {
    state = "findings-open";
    primaryAction = action("review-findings", `Review ${findings.open} findings`, "fix", "review findings");
    summary = reopenedFindings
      ? `${findings.open} findings are open, including ${reopenedFindings} reopened because prior repair proof is no longer verified.`
      : evaluation?.status === "passed" && evaluation.evidence === "verified"
        ? `Desktop and mobile evaluation passed with verified evidence. ${findings.open} findings remain open.`
        : `${findings.open} verified findings remain open.`;
  } else if (verifiedRepair && !workflow.release) {
    state = "repair-verified";
    primaryAction = action("review-verified-repair", "Review verified repair", "fix", "review verified repair");
    summary = `Every readable finding is verified-resolved against candidate revision ${workflow.repair.candidateRevision}. Run and finalize a supervised candidate replay, then use its receipt for external human-supervised promotion. Neither step proves release qualification or release evaluation.`;
  } else if (releaseUnavailable) {
    state = "release-unavailable";
    primaryAction = action("review-release", "Review release", "versions", "review release");
    summary = "Release integrity is unavailable. Evaluation readiness was not inferred.";
  } else if (findingsUnavailable || sourceUnavailable) {
    state = "status-unavailable";
    primaryAction = action(
      "review-available-details",
      "Review available details",
      "overview",
      "review available details",
    );
    summary = "Some lifecycle details are unavailable. No optimistic next action was inferred.";
  } else if (!workflow.release) {
    if (workflow.draft.status === "candidate") {
      state = "draft-only";
      primaryAction = action("review-training-draft", "Review training draft", "train", "review the training draft");
      summary = "No release or evaluation is available. Desktop and mobile qualification prerequisites are missing.";
    } else {
      state = "prerequisites-missing";
      primaryAction = action("review-prerequisites", "Review prerequisites", "overview", "review prerequisites");
      summary = "No training draft, release, or evaluation is available. Qualification prerequisites are missing.";
    }
  } else if (!allQualified) {
    state = "not-qualified";
    primaryAction = action("review-prerequisites", "Review prerequisites", "overview", "review prerequisites");
    summary = "A release is available. Desktop and mobile qualification prerequisites are missing.";
  } else if (evaluation?.status === "none") {
    state = "evaluation-ready";
    primaryAction = action(
      "review-evaluation-readiness",
      "Review evaluation readiness",
      "evaluate",
      "review evaluation readiness",
    );
    summary = "Desktop and mobile are qualified. No paired evaluation is available.";
  } else if (evaluation?.status === "failed") {
    state = "evaluation-failed";
    primaryAction = action(
      "review-failed-evaluation",
      "Review failed evaluation",
      "evaluate",
      "review failed evaluation",
    );
    summary = "The latest desktop and mobile evaluation did not pass. Evidence is not verified.";
  } else if (evaluation?.status === "degraded") {
    state = "evaluation-degraded";
    primaryAction = action("review-evaluation", "Review degraded evaluation", "evaluate", "review degraded evaluation");
    summary = "Evaluation facts are readable, but a critical evidence or lineage source is degraded.";
  } else if (evaluation?.status === "passed") {
    state = "evaluation-passed";
    primaryAction = action("review-evaluation", "Review evaluation", "evaluate", "review evaluation");
    summary = "Desktop and mobile evaluation passed with verified evidence. No findings were reported.";
  } else {
    state = "evaluation-incomplete";
    primaryAction = action("review-evaluation", "Review evaluation", "evaluate", "review evaluation");
    summary = "Desktop and mobile evaluation details are available, but a verified outcome is not yet available.";
  }

  return { state, summary: `${summary} Next: ${primaryAction.next}.`, action: primaryAction, dimensions };
}

export function projectStudioWorkflow(workflow, { runs = [], lifecycle } = {}) {
  lifecycle ??= { workflows: [], groups: [], qualificationMatrix: {} };
  const workflowId = workflow.metadata.id;
  const workflowRuns = runs.filter((run) => run.workflow?.id === workflowId);
  const evaluationGroups = lifecycle.groups.filter((group) => group.workflowId === workflowId);
  const groupedEvaluationRuns = new Set(
    evaluationGroups.flatMap((group) => group.members?.map((member) => member.runId) ?? []),
  );
  const evaluationRecordCount =
    evaluationGroups.length +
    workflowRuns.filter((run) => run.classification === "candidate-evaluation" && !groupedEvaluationRuns.has(run.runId))
      .length;
  const version = latestVersion(lifecycle, workflowId);
  const platforms = workflow.target.supportedPlatforms.map((platform) => ({
    id: platform.id,
    adapterCapability: platform.adapterCapability,
    viewport: viewport(platform.viewport),
    qualification: qualificationFor(lifecycle, workflowId, version?.revision, platform.id),
  }));
  const evaluationEligible =
    platforms.length > 0 && platforms.every((platform) => platform.qualification.integrity === "verified");
  const isDraft = workflow.metadata.lifecycle === "candidate";
  return {
    id: workflowId,
    name: workflow.metadata.name,
    description: workflow.metadata.description,
    tags: strings(workflow.metadata.tags),
    draft: isDraft
      ? { status: "candidate", candidateRevision: workflow.metadata.candidateRevision }
      : { status: "none", candidateRevision: null },
    release: version,
    platforms,
    latestRun: workflowRuns[0] ?? null,
    recentRuns: workflowRuns.slice(0, 10),
    evaluationRecordCount,
    findings: { status: "unavailable", open: null },
    decision: null,
    phases: {
      train: { status: isDraft ? "draft" : "released" },
      evaluate: { status: evaluationEligible ? "available" : "not-qualified" },
      fix: { status: "no-findings-source" },
    },
    target: {
      app: workflow.target.app,
      identity: {
        requirement: workflow.target.identity.requirement,
        profile: text(workflow.target.identity.profile),
        note: workflow.target.identity.note,
      },
    },
    start: {
      isolation: workflow.start.isolation,
      path: workflow.start.path,
      expectedState: workflow.start.expectedState,
      constraints: strings(workflow.start.constraints),
      preflightCapabilities: strings(workflow.start.preflightCapabilities),
    },
    execution: {
      topology: workflow.execution.topology,
      agentFreedom: workflow.execution.agentFreedom,
      onUnexpectedState: workflow.execution.onUnexpectedState,
      environmentChange: workflow.execution.environmentChange,
      failureContinuation: workflow.execution.failureContinuation,
      recoveryBudget: workflow.execution.recoveryBudget,
    },
    evidencePolicy: {
      default: strings(workflow.evidencePolicy.default),
      onFailure: strings(workflow.evidencePolicy.onFailure),
    },
    optionalStateHandlers: (workflow.optionalStateHandlers ?? []).map((handler) => ({
      id: handler.id,
      when: handler.when,
      action: handler.action,
      expectedState: handler.expectedState,
      maxApplications: handler.maxApplications,
    })),
    evaluation: workflow.evaluation
      ? {
          resetStepId: workflow.evaluation.resetStepId,
          cleanupStepId: workflow.evaluation.cleanupStepId,
          requiredViewport: workflow.evaluation.requiredViewport ?? null,
        }
      : null,
    steps: workflow.steps.map((step) => projectStep(step, workflow.platformOverrides)),
    completion: {
      successRequires: strings(workflow.completion.successRequires),
      cleanup: {
        alwaysAttempt: workflow.completion.cleanup.alwaysAttempt,
        actions: strings(workflow.completion.cleanup.actions),
      },
    },
    versions: lifecycle.workflows.find((item) => item.workflowId === workflowId)?.versions ?? [],
    evaluationGroups,
  };
}

export async function listStudioWorkflows({ definitionsRoot, workflowPaths, registry, runs, lifecycle }) {
  const files = await explicitWorkflowFiles({ definitionsRoot, workflowPaths });
  const loaded = await Promise.all(
    files.map(async (path) => {
      try {
        return { path, workflow: await loadDefinition(path, registry) };
      } catch {
        return { path, workflow: null };
      }
    }),
  );
  const counts = new Map();
  for (const item of loaded) {
    const id = item.workflow?.metadata?.id;
    if (id) counts.set(id, (counts.get(id) ?? 0) + 1);
  }
  const workflows = loaded
    .filter((item) => item.workflow && counts.get(item.workflow.metadata.id) === 1)
    .map((item) => projectStudioWorkflow(item.workflow, { runs, lifecycle }))
    .sort((left, right) => left.name.localeCompare(right.name) || left.id.localeCompare(right.id));
  const unavailable = loaded
    .filter((item) => !item.workflow || counts.get(item.workflow.metadata.id) > 1)
    .map((item) => ({ source: basename(item.path), integrity: "corrupt" }));
  return { workflows, unavailable };
}
