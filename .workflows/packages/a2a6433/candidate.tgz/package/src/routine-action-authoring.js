import { readFile, unlink, writeFile } from "node:fs/promises";
import { resolve } from "node:path";

import { parse as parseYaml, stringify as stringifyYaml } from "yaml";

import { WorkflowError } from "./errors.js";
import { sha256 } from "./stable-json.js";
import { writeRoutineActionReviewAttestation } from "./routine-action-review-attestation.js";
import { exportSupervisedRoutineActions, validateReviewedRoutineBatch } from "./routine-action-review-contract.js";

export { exportSupervisedRoutineActions } from "./routine-action-review-contract.js";

function invalid(message, details) {
  throw new WorkflowError("ROUTINE_ACTION_REVIEW_REQUIRED", message, { exitCode: 3, details });
}

/** Apply an explicitly reviewed export to a new candidate file; this does not record human acceptance. */
export async function applyReviewedRoutineActions({ runStore, workflowPath, reviewPath, outputPath, registry, now }) {
  const review = JSON.parse(await readFile(resolve(reviewPath), "utf8"));
  if (review?.reviewed !== true) invalid("Set reviewed:true only after inspecting every exported action batch");
  const expected = await exportSupervisedRoutineActions({ runStore, runId: review.source?.runId });
  if (sha256({ ...review, reviewed: false }) !== sha256(expected))
    invalid("Reviewed routine actions no longer match the exact supervised Training receipts");
  const sourcePath = resolve(workflowPath);
  const destination = resolve(outputPath);
  if (sourcePath === destination) invalid("Reviewed actions must be written to a new candidate file");
  const workflow = registry.validate("workflow", parseYaml(await readFile(sourcePath, "utf8")));
  if (
    workflow.metadata.id !== review.source.workflowId ||
    sha256(workflow) !== review.source.contentHash ||
    workflow.metadata.lifecycle !== "candidate" ||
    !Number.isSafeInteger(workflow.metadata.candidateRevision)
  )
    invalid("Reviewed actions do not match this exact candidate workflow source");
  const next = structuredClone(workflow);
  next.metadata.candidateRevision += 1;
  for (const item of review.batches) {
    const step = next.steps.find((candidate) => candidate.id === item.stepId);
    if (!step) invalid(`Reviewed step is absent from the candidate: ${item.stepId}`);
    step.routineActionBatches = [validateReviewedRoutineBatch(item.stepId, structuredClone(item.batch))];
  }
  registry.validate("workflow", next);
  await writeFile(destination, stringifyYaml(next), { flag: "wx", mode: 0o600 });
  try {
    await writeRoutineActionReviewAttestation(runStore, next, review, now);
  } catch (error) {
    await unlink(destination).catch(() => {});
    throw error;
  }
  return {
    workflowId: next.metadata.id,
    candidateRevision: next.metadata.candidateRevision,
    output: destination,
    contentHash: sha256(next),
    sourceRunId: review.source.runId,
    acceptanceRecorded: false,
  };
}
