import { requiredEvidenceReview } from "./studio-evidence-summary.js";
import { verifyRunEvidenceBatch } from "./studio-evidence-verifier.js";

function eventFor(events, type, predicate = () => true) {
  return events.find((event) => event.type === type && predicate(event));
}

function evidenceDto(runId, artifact, integrity) {
  return {
    artifactId: artifact.artifactId,
    type: artifact.type,
    observedAt: artifact.observedAt,
    contentHash: artifact.contentHash,
    sizeBytes: artifact.sizeBytes,
    mimeType: artifact.mimeType ?? null,
    dimensions: artifact.dimensions ?? null,
    download: artifact.download ?? null,
    captureGeometry: artifact.captureGeometry ?? "unbound",
    fullPage: artifact.fullPage ?? null,
    checkpoint: artifact.relation?.checkpoint ?? null,
    optionalHandlerId: artifact.relation?.optionalHandlerId ?? null,
    integrity,
    url: `/api/runs/${encodeURIComponent(runId)}/artifacts/${encodeURIComponent(artifact.artifactId)}`,
  };
}

function authenticationDto(authentication) {
  if (!authentication?.required) return undefined;
  if (authentication.status === "verified") {
    return {
      status: "verified",
      targetId: authentication.targetId,
      lastVerifiedAt: authentication.lastVerifiedAt,
    };
  }
  return {
    status: "required",
    targetId: authentication.targetId,
    recoveryAction: {
      id: "open-authentication-session",
      targetId: authentication.targetId,
    },
  };
}

export async function buildRunReport(store, runId, { assessmentStore, skipPerspective = false } = {}) {
  const run = await store.readRun(runId);
  const artifacts = Object.values(run.state.traversal?.artifacts ?? {});
  const integrity = new Map();
  const verdicts = await verifyRunEvidenceBatch({ store, run, artifacts, runId });
  for (const [index, verdict] of verdicts.entries()) {
    integrity.set(artifacts[index].artifactId, verdict.status === "fulfilled" ? "verified" : "failed");
  }
  const steps = (run.workflow?.steps ?? []).map((step) => {
    const state = run.state.traversal?.steps?.[step.id] ?? {};
    const leased = eventFor(run.events, "action.leased", (event) => event.payload.stepId === step.id);
    const committed = eventFor(run.events, "action.committed", (event) => event.payload.assessment?.stepId === step.id);
    const evidence = artifacts
      .filter((artifact) => artifact.relation?.stepId === step.id)
      .map((artifact) => evidenceDto(runId, artifact, integrity.get(artifact.artifactId)));
    const optionalStates = (run.state.optionalApplications?.[step.id] ?? []).map((application) => {
      const authorized = eventFor(
        run.events,
        "optional-state.authorized",
        (event) => event.payload.authorizationId === application.authorizationId,
      );
      const applied = eventFor(
        run.events,
        "optional-state.applied",
        (event) => event.payload.authorizationId === application.authorizationId,
      );
      return {
        handlerId: application.handlerId,
        authorizationId: application.authorizationId,
        contractHash: application.contractHash,
        scope: structuredClone(application.scope),
        authorizedAt: authorized?.occurredAt ?? null,
        appliedAt: applied?.occurredAt ?? null,
        evidence: application.evidenceIds.map((artifactId) => {
          const artifact = artifacts.find((item) => item.artifactId === artifactId);
          return artifact
            ? evidenceDto(runId, artifact, integrity.get(artifactId))
            : { artifactId, integrity: "failed" };
        }),
      };
    });
    return {
      id: step.id,
      name: step.name,
      outcome: state.outcome ?? "pending",
      attempts: state.attempts ?? 0,
      startedAt: leased?.occurredAt ?? null,
      completedAt: committed?.occurredAt ?? null,
      notes: structuredClone(committed?.payload.result?.notes ?? []),
      evidence,
      optionalStates,
    };
  });
  const required = requiredEvidenceReview(run.workflow?.steps ?? [], steps);
  const allEvidenceVerified =
    artifacts.length > 0 &&
    required.expected === required.verified &&
    [...integrity.values()].every((value) => value === "verified") &&
    steps.every((step) =>
      step.optionalStates.every(
        (application) =>
          application.authorizedAt &&
          application.appliedAt &&
          application.evidence.length === 1 &&
          application.evidence.every(
            (item) => item.integrity === "verified" && item.optionalHandlerId === application.handlerId,
          ),
      ),
    );
  const cleanupStep = steps.find((step) => step.id === run.workflow?.evaluation?.cleanupStepId);
  const cleanupIntegrity =
    run.state.cleanupOutcome === "passed" &&
    cleanupStep?.outcome === "passed" &&
    cleanupStep.evidence.some(
      (item) => item.type === "screenshot" && item.optionalHandlerId === null && item.integrity === "verified",
    )
      ? "verified"
      : "failed";
  const overallIntegrity =
    run.state.status === "completed" &&
    run.state.traversal?.journeyOutcome === "passed" &&
    cleanupIntegrity === "verified" &&
    allEvidenceVerified
      ? "verified"
      : "degraded";
  const report = {
    schema: "agent-workflow-run-report/v1",
    runId,
    workflow: {
      id: run.manifest.workflowRef?.id ?? run.workflow?.metadata?.id ?? null,
      candidateRevision: run.manifest.workflowRef?.candidateRevision ?? null,
      sourceBytesHash: run.manifest.workflowRef?.sourceBytesHash ?? null,
      contentHash: run.manifest.workflowRef?.contentHash ?? null,
      effectiveHash: run.manifest.workflowRef?.effectiveHash ?? null,
      effectiveHashVersion: run.manifest.workflowRef?.effectiveHashVersion ?? null,
    },
    platform: run.manifest.platform,
    target: structuredClone(run.manifest.target ?? null),
    viewport: run.manifest.viewport ?? null,
    approvalMode: run.manifest.approvalMode ?? null,
    leasePolicy: run.manifest.leasePolicy ?? null,
    ...(run.state.authentication?.required ? { authentication: authenticationDto(run.state.authentication) } : {}),
    status: run.state.status,
    outcome: run.state.traversal?.journeyOutcome ?? run.state.terminalOutcome,
    // Runner terminalization alone does not prove the declared application cleanup.
    cleanupOutcome:
      run.state.cleanupOutcome === "passed" && cleanupIntegrity !== "verified" ? "failed" : run.state.cleanupOutcome,
    integrity: {
      overall: overallIntegrity,
      cleanup: cleanupIntegrity,
      evidence: allEvidenceVerified ? "verified" : "failed",
    },
    timestamps: {
      createdAt: run.events[0]?.occurredAt ?? null,
      completedAt: eventFor(run.events, "cleanup.completed")?.occurredAt ?? null,
    },
    steps,
  };
  if (!skipPerspective) {
    let resolvedAssessmentStore = assessmentStore;
    if (!resolvedAssessmentStore && store.root) {
      const { PerspectiveAssessmentStore } = await import("./perspective-assessment-store.js");
      resolvedAssessmentStore = new PerspectiveAssessmentStore(store.root, { registry: store.registry });
    }
    if (resolvedAssessmentStore) {
      const { projectPerspectiveCoverage } = await import("./perspective-assessment-store.js");
      const projected = await projectPerspectiveCoverage({
        runStore: store,
        assessmentStore: resolvedAssessmentStore,
        runId,
      });
      report.perspective = projected.perspective;
      report.coverage =
        projected.coverage === "not-recorded"
          ? projected.coverage
          : { ...projected.coverage, criteria: structuredClone(projected.criteria) };
      report.qualityOutcome = projected.qualityOutcome;
    } else if (!run.manifest.evaluationPerspective) {
      report.perspective = "not-recorded";
      report.coverage = "not-recorded";
      report.qualityOutcome = "unavailable";
    }
  }
  return report;
}
