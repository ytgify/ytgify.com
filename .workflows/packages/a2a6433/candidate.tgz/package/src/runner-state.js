import { WorkflowError } from "./errors.js";

const TERMINAL_STEP_OUTCOMES = new Set(["passed", "passed_with_deviation", "failed", "blocked", "skipped"]);

function transitionError(message, details = {}) {
  return new WorkflowError("ILLEGAL_TRANSITION", message, {
    exitCode: 4,
    details,
  });
}

function assertStatus(state, allowed, event) {
  if (!allowed.includes(state.status)) {
    throw transitionError(`Cannot apply ${event.type} while run is ${state.status}`, {
      sequence: event.sequence,
      allowed,
    });
  }
}

function assertActiveStep(state, event) {
  const stepId = event.payload?.stepId;
  if (!state.activeStep || state.activeStep !== stepId) {
    throw transitionError(`${event.type} does not belong to the active step`, {
      activeStep: state.activeStep,
      eventStep: stepId ?? null,
    });
  }
}

function allStepsTerminal(state) {
  return Object.values(state.steps).every((step) => TERMINAL_STEP_OUTCOMES.has(step.outcome));
}

function dependenciesPermit(state, stepId) {
  const step = state.workflow.steps.find((candidate) => candidate.id === stepId);
  return (step.dependsOn ?? []).every((dependency) => {
    const outcome = state.steps[dependency]?.outcome;
    return outcome === "passed" || outcome === "passed_with_deviation" || outcome === "skipped";
  });
}

export function createRunnerState(workflow) {
  return {
    status: "unstarted",
    sequence: 0,
    runId: null,
    workflowRef: null,
    workflow,
    activeStep: null,
    steps: Object.fromEntries(workflow.steps.map((step) => [step.id, { attempt: 0, outcome: "pending" }])),
    cleanup: { status: "pending", outcome: null },
    tainted: false,
    findings: 0,
    completedOutcome: null,
  };
}

export function reduceEvent(previousState, event) {
  const state = structuredClone(previousState);
  const expectedSequence = state.sequence + 1;

  if (event.sequence !== expectedSequence) {
    throw transitionError("Event sequence is not the next expected value", {
      expected: expectedSequence,
      actual: event.sequence,
    });
  }

  if (state.runId && event.runId !== state.runId) {
    throw transitionError("Event run ID changed", {
      expected: state.runId,
      actual: event.runId,
    });
  }

  if (state.workflowRef && JSON.stringify(event.workflowRef) !== JSON.stringify(state.workflowRef)) {
    throw transitionError("Event workflow reference changed");
  }

  switch (event.type) {
    case "run.started": {
      assertStatus(state, ["unstarted"], event);
      state.status = "preflight";
      state.runId = event.runId;
      state.workflowRef = event.workflowRef;
      break;
    }

    case "preflight.checked": {
      assertStatus(state, ["preflight"], event);
      state.status = event.payload.outcome === "passed" ? "ready" : "cleanup";
      if (state.status === "cleanup") {
        for (const step of Object.values(state.steps)) step.outcome = "blocked";
      }
      break;
    }

    case "step.started": {
      assertStatus(state, ["ready"], event);
      const { stepId, attempt } = event.payload;
      const stepState = state.steps[stepId];
      if (!stepState) throw transitionError(`Unknown step: ${stepId}`);
      if (stepState.outcome !== "pending") {
        throw transitionError(`Step is not pending: ${stepId}`, { outcome: stepState.outcome });
      }
      if (!dependenciesPermit(state, stepId)) {
        throw transitionError(`Step dependencies do not permit execution: ${stepId}`);
      }
      if (attempt !== stepState.attempt + 1) {
        throw transitionError(`Invalid attempt number for step: ${stepId}`, {
          expected: stepState.attempt + 1,
          actual: attempt,
        });
      }
      stepState.attempt = attempt;
      stepState.outcome = "active";
      state.activeStep = stepId;
      state.status = "running";
      break;
    }

    case "optional_state.observed":
    case "handler.applied":
    case "observation.recorded":
    case "evidence.captured":
    case "evidence.inspected":
    case "deviation.recorded":
    case "finding.recorded": {
      assertStatus(state, ["running"], event);
      assertActiveStep(state, event);
      if (event.type === "finding.recorded") state.findings += 1;
      break;
    }

    case "step.completed": {
      assertStatus(state, ["running", "ready"], event);
      const { stepId, attempt, outcome } = event.payload;
      const stepState = state.steps[stepId];
      if (!stepState) throw transitionError(`Unknown step: ${stepId}`);

      const pendingTerminal =
        state.status === "ready" && stepState.outcome === "pending" && (outcome === "blocked" || outcome === "skipped");

      if (!pendingTerminal) {
        assertActiveStep(state, event);
        if (attempt !== stepState.attempt) {
          throw transitionError(`Step attempt does not match active attempt: ${stepId}`);
        }
      }

      if (!TERMINAL_STEP_OUTCOMES.has(outcome)) {
        throw transitionError(`Invalid terminal step outcome: ${outcome}`);
      }

      stepState.outcome = outcome;
      state.activeStep = null;
      state.status = allStepsTerminal(state) ? "cleanup" : "ready";
      break;
    }

    case "run.tainted": {
      assertStatus(state, ["preflight", "ready", "running", "cleanup"], event);
      state.tainted = true;
      break;
    }

    case "cleanup.started": {
      assertStatus(state, ["cleanup"], event);
      if (state.cleanup.status !== "pending") {
        throw transitionError("Cleanup has already started");
      }
      state.cleanup.status = "active";
      break;
    }

    case "cleanup.completed": {
      assertStatus(state, ["cleanup"], event);
      if (state.cleanup.status !== "active") {
        throw transitionError("Cleanup is not active");
      }
      state.cleanup.status = "completed";
      state.cleanup.outcome = event.payload.outcome;
      break;
    }

    case "run.completed": {
      assertStatus(state, ["cleanup"], event);
      if (!allStepsTerminal(state)) throw transitionError("Not every step is terminal");
      if (state.cleanup.status !== "completed") throw transitionError("Cleanup is not complete");

      const actualSummary = Object.values(state.steps).reduce(
        (summary, step) => {
          const key = step.outcome === "passed_with_deviation" ? "passedWithDeviation" : step.outcome;
          summary[key] += 1;
          return summary;
        },
        { passed: 0, passedWithDeviation: 0, failed: 0, blocked: 0, skipped: 0 },
      );

      if (JSON.stringify(actualSummary) !== JSON.stringify(event.payload.stepSummary)) {
        throw transitionError("Final step summary does not match reduced state", {
          expected: actualSummary,
          actual: event.payload.stepSummary,
        });
      }
      if (event.payload.findingCount !== state.findings) {
        throw transitionError("Final finding count does not match reduced state", {
          expected: state.findings,
          actual: event.payload.findingCount,
        });
      }
      if (state.tainted && event.payload.outcome !== "tainted") {
        throw transitionError("A tainted run must close with outcome tainted");
      }

      state.status = "closed";
      state.completedOutcome = event.payload.outcome;
      break;
    }

    default:
      throw transitionError(`Unknown event type: ${event.type}`);
  }

  state.sequence = event.sequence;
  return state;
}

export function replayEvents(workflow, events) {
  return events.reduce((state, event) => reduceEvent(state, event), createRunnerState(workflow));
}
