import { link, lstat, mkdir, readFile, rename, rm, writeFile } from "node:fs/promises";
import { dirname, join, relative, resolve, sep } from "node:path";

import { createHash, randomUUID } from "node:crypto";
import { legacySkillHashes } from "./codex-skill-baselines.js";
import { assertSafeProjectPath } from "./project-path-safety.js";

import { WorkflowError } from "./errors.js";
import { PREFERRED_PROTOCOL_VERSION } from "./protocol.js";

const SKILL_FILES = [
  "SKILL.md",
  "agents/openai.yaml",
  "references/protocol.md",
  "references/exploration.md",
  "references/evidence.md",
  "references/capability-gaps.md",
  "references/lifecycle.md",
  "references/readiness.md",
  "references/discovery.md",
  "references/evaluation.md",
  "references/app-map.md",
  "references/collaboration.md",
  "references/authentication.md",
  "references/operations.md",
  "references/findings.md",
];

function renderTemplate(source, pins) {
  return source
    .replaceAll("{{PACKAGE_NAME}}", pins.packageName)
    .replaceAll("{{PACKAGE_VERSION}}", pins.packageVersion)
    .replaceAll("{{PROTOCOL_VERSION}}", pins.protocolVersion);
}

async function expectedSkill(root = process.cwd()) {
  const projectRoot = resolve(root);
  const packageJson = JSON.parse(await readFile(new URL("../package.json", import.meta.url), "utf8"));
  const pins = {
    packageName: packageJson.name,
    packageVersion: packageJson.version,
    protocolVersion: PREFERRED_PROTOCOL_VERSION,
  };
  const templateRoot = new URL("../templates/agent-workflows/", import.meta.url);
  const destinationRoot = join(projectRoot, ".agents", "skills", "agent-workflows");
  const items = await Promise.all(
    SKILL_FILES.map(async (file) => {
      const source = await readFile(new URL(file, templateRoot), "utf8");
      const destination = join(destinationRoot, file);
      return {
        kind: "skill-file",
        path: relative(projectRoot, destination),
        destination,
        contents: renderTemplate(source, pins),
      };
    }),
  );
  const destination = join(destinationRoot, ".generated.json");
  items.push({
    kind: "skill-baseline",
    path: relative(projectRoot, destination),
    destination,
    contents:
      JSON.stringify(
        {
          schema: "workflow-skill-baseline/v1",
          pins,
          hashes: Object.fromEntries(items.map((item) => [item.path, digest(item.contents)])),
        },
        null,
        2,
      ) + "\n",
  });
  return { host: "codex", root: projectRoot, pins, items };
}

async function installedStatus(root, item) {
  let cursor = root;
  try {
    const rootStat = await lstat(root);
    if (!rootStat.isDirectory() || rootStat.isSymbolicLink()) return "conflict";
    for (const part of relative(root, item.destination).split(sep).filter(Boolean)) {
      cursor = join(cursor, part);
      const stat = await lstat(cursor);
      if (stat.isSymbolicLink()) return "conflict";
      if (cursor !== item.destination && !stat.isDirectory()) return "conflict";
      if (cursor === item.destination && !stat.isFile()) return "conflict";
    }
    return (await readFile(item.destination, "utf8")) === item.contents ? "unchanged" : "conflict";
  } catch (error) {
    if (error.code === "ENOENT") return "create";
    if (["EISDIR", "EACCES", "EPERM"].includes(error.code)) return "conflict";
    throw error;
  }
}

function digest(contents) {
  return createHash("sha256").update(contents).digest("hex");
}

async function safeContents(root, item) {
  await assertSafeProjectPath(root, item.destination, "Generated skill", { finalType: "file" });
  return readFile(item.destination, "utf8").catch((error) => {
    if (error.code === "ENOENT") return null;
    throw error;
  });
}

/** Build an exact installation/upgrade plan without changing project files. */
export async function planCodexSkillInstallation(root = process.cwd()) {
  const expected = await expectedSkill(root);
  const baselineItem = expected.items.at(-1);
  let baseline = null;
  let baselineInvalid = false;
  try {
    const contents = await safeContents(expected.root, baselineItem);
    if (contents !== null) {
      baseline = JSON.parse(contents);
      if (
        baseline.schema !== "workflow-skill-baseline/v1" ||
        !baseline.hashes ||
        typeof baseline.hashes !== "object" ||
        Array.isArray(baseline.hashes) ||
        Object.values(baseline.hashes).some((hash) => typeof hash !== "string" || !/^[a-f0-9]{64}$/.test(hash))
      ) {
        baselineInvalid = true;
      }
    }
  } catch {
    baselineInvalid = true;
  }
  const items = [];
  for (const item of expected.items) {
    let status = await installedStatus(expected.root, item);
    let previousContents;
    if (item.kind === "skill-baseline" && baselineInvalid) status = "conflict";
    else if (status === "conflict" && !baselineInvalid) {
      try {
        const contents = await safeContents(expected.root, item);
        const known = baseline ? [baseline.hashes[item.path]] : (legacySkillHashes[item.path] ?? []);
        if (contents !== null && (item.kind === "skill-baseline" || known.includes(digest(contents)))) {
          status = "update";
          previousContents = contents;
        }
      } catch {
        /* Unsafe paths remain conflicts. */
      }
    }
    items.push({ ...item, status, ...(previousContents === undefined ? {} : { previousContents }) });
  }
  return { ...expected, items };
}

function skillConflict(item) {
  return new WorkflowError("SKILL_EXISTS", `Refusing to overwrite a modified Codex skill file: ${item.path}`, {
    exitCode: 4,
  });
}

async function exactPlan(plan) {
  if (!plan || typeof plan.root !== "string") {
    throw new WorkflowError("SKILL_PLAN_INVALID", "Codex skill installation requires an exact generated plan", {
      exitCode: 4,
    });
  }
  const expected = await expectedSkill(plan.root);
  const pinsMatch = ["packageName", "packageVersion", "protocolVersion"].every(
    (key) => plan.pins?.[key] === expected.pins[key],
  );
  const itemsMatch =
    plan.host === expected.host &&
    plan.root === expected.root &&
    plan.items?.length === expected.items.length &&
    expected.items.every((item, index) => {
      const planned = plan.items[index];
      return (
        planned?.kind === item.kind &&
        planned.path === item.path &&
        planned.destination === item.destination &&
        planned.contents === item.contents &&
        ["create", "unchanged", "conflict", "update"].includes(planned.status)
      );
    });
  if (!pinsMatch || !itemsMatch) {
    throw new WorkflowError("SKILL_PLAN_INVALID", "Codex skill installation plan is not exact", { exitCode: 4 });
  }
  return {
    ...expected,
    items: expected.items.map((item, index) => ({
      ...item,
      status: plan.items[index].status,
      previousContents: plan.items[index].previousContents,
    })),
  };
}

/** Restore only bytes still owned by this operation. Never replace later edits. */
export async function rollbackCodexSkillInstallation(plan) {
  for (const item of [...plan.items].reverse()) {
    if (!["create", "update"].includes(item.status)) continue;
    if ((await safeContents(plan.root, item).catch(() => null)) !== item.contents) continue;
    if (item.status === "update") {
      await writeGeneratedFile(plan.root, {
        ...item,
        contents: item.previousContents,
        previousContents: item.contents,
      });
    } else await rm(item.destination);
  }
}

async function writeGeneratedFile(root, item) {
  await mkdir(dirname(item.destination), { recursive: true });
  const temporary = `${item.destination}.${randomUUID()}.tmp`;
  try {
    await writeFile(temporary, item.contents, { flag: "wx" });
    const current = await safeContents(root, item);
    if (current !== (item.previousContents ?? null)) throw skillConflict(item);
    if (item.status === "create") {
      await link(temporary, item.destination);
      return null;
    }
    // Move, then inspect the actual displaced inode. Retain it even after success:
    // an editor may still have that inode open. Never overwrite a newly saved destination.
    const backup = `${item.destination}.${randomUUID()}.backup`;
    await rename(item.destination, backup);
    try {
      if ((await safeContents(root, { destination: backup })) !== item.previousContents) throw skillConflict(item);
      await link(temporary, item.destination);
    } catch (error) {
      try {
        await link(backup, item.destination);
      } catch (restoreError) {
        if (restoreError.code !== "EEXIST") throw restoreError;
      }
      throw new WorkflowError(
        "SKILL_EXISTS",
        `Guidance changed during upgrade; preserved displaced file at ${backup}`,
        {
          exitCode: 4,
          details: { path: item.path, backupPath: backup, cause: error.code },
        },
      );
    }
    return backup;
  } finally {
    await rm(temporary, { force: true });
  }
}

/** Apply an exact plan, rejecting stale plans and preserving modified guidance. */
export async function applyCodexSkillInstallation(plan) {
  const verifiedPlan = await exactPlan(plan);
  const fresh = await planCodexSkillInstallation(plan.root);
  for (const [index, item] of fresh.items.entries()) {
    const planned = verifiedPlan.items[index];
    if (item.status === "conflict") throw skillConflict(item);
    if (item.status !== planned.status || item.previousContents !== planned.previousContents) throw skillConflict(item);
  }
  const applied = [];
  const backups = new Map();
  try {
    for (const item of fresh.items) {
      if (item.status === "unchanged") continue;
      // Recheck at the mutation boundary as well as before the transaction.
      const current = await safeContents(fresh.root, item);
      if (current !== (item.previousContents ?? null)) throw skillConflict(item);
      const backup = await writeGeneratedFile(fresh.root, item);
      if (backup) backups.set(item.path, backup);
      applied.push(item);
    }
  } catch (error) {
    await rollbackCodexSkillInstallation({ ...fresh, items: applied });
    throw error;
  }
  return {
    host: fresh.host,
    root: fresh.root,
    pins: fresh.pins,
    items: fresh.items.map(({ kind, path, status }) => ({
      kind,
      path,
      status: status === "create" ? "created" : status === "update" ? "updated" : "unchanged",
      ...(backups.has(path) ? { backupPath: backups.get(path) } : {}),
    })),
  };
}

export async function installCodexSkill(root = process.cwd()) {
  return applyCodexSkillInstallation(await planCodexSkillInstallation(root));
}
