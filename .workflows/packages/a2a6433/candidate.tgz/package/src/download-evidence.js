import { WorkflowError } from "./errors.js";

function invalid(message) {
  throw new WorkflowError("VALIDATION_FAILED", message, { exitCode: 3 });
}

// Validate the LZW stream without allocating decoded frame buffers.
function validatePixels(data, minimumCodeSize, pixels, colors) {
  if (minimumCodeSize < 2 || minimumCodeSize > 8) invalid("Invalid GIF LZW code size");
  const clear = 1 << minimumCodeSize;
  const end = clear + 1;
  const lengths = new Uint32Array(4096);
  const maxima = new Uint16Array(4096);
  const first = new Uint16Array(4096);
  for (let i = 0; i < clear; i += 1) {
    lengths[i] = 1;
    maxima[i] = i;
    first[i] = i;
  }
  let bits = minimumCodeSize + 1,
    next = end + 1,
    offset = 0,
    previous = -1,
    count = 0,
    initialized = false;
  while (offset + bits <= data.length * 8) {
    let code = 0;
    for (let i = 0; i < bits; i += 1) code |= ((data[(offset + i) >> 3] >> ((offset + i) & 7)) & 1) << i;
    offset += bits;
    if (code === clear) {
      bits = minimumCodeSize + 1;
      next = end + 1;
      previous = -1;
      initialized = true;
      continue;
    }
    if (!initialized) invalid("GIF LZW stream must start with a clear code");
    if (code === end) {
      if (count !== pixels || data.length * 8 - offset >= 8)
        invalid("GIF pixel count or trailing LZW bytes are invalid");
      return;
    }
    if (code > next || (code === next && previous < 0) || (previous < 0 && code >= clear))
      invalid("Invalid GIF LZW dictionary reference");
    const special = code === next;
    const length = special ? lengths[previous] + 1 : lengths[code];
    const maximum = special ? maxima[previous] : maxima[code];
    const firstPixel = special ? first[previous] : first[code];
    if (!length || maximum >= colors) invalid("Invalid GIF palette index");
    count += length;
    if (count > pixels) invalid("GIF decoded pixels exceed frame dimensions");
    if (previous >= 0 && next < 4096) {
      lengths[next] = lengths[previous] + 1;
      maxima[next] = Math.max(maxima[previous], firstPixel);
      first[next] = first[previous];
      next += 1;
      if (next === 1 << bits && bits < 12) bits += 1;
    }
    previous = code;
  }
  invalid("GIF LZW stream is truncated or missing its end code");
}

/** Bounded GIF87a/89a validation; rejects truncation, invalid pixels and trailing data. */
export function inspectGifBytes(input, maxBytes = 10 * 1024 * 1024) {
  if (
    !ArrayBuffer.isView(input) ||
    input.BYTES_PER_ELEMENT !== 1 ||
    Object.prototype.toString.call(input) !== "[object Uint8Array]"
  )
    invalid("GIF evidence must be raw bytes");
  if (!Number.isSafeInteger(maxBytes) || maxBytes < 1 || !input.byteLength || input.byteLength > maxBytes)
    invalid("GIF exceeds the evidence byte limit");
  const bytes = Buffer.from(input.buffer, input.byteOffset, input.byteLength);
  let offset = 0;
  const take = (length) => {
    if (offset + length > bytes.length) invalid("Truncated GIF evidence");
    const result = bytes.subarray(offset, offset + length);
    offset += length;
    return result;
  };
  const header = take(6).toString("latin1");
  if (!["GIF87a", "GIF89a"].includes(header)) invalid("Download evidence is not a GIF");
  const screen = take(7),
    width = screen.readUInt16LE(0),
    height = screen.readUInt16LE(2);
  if (!width || !height || width > 16384 || height > 16384 || width * height > 100_000_000)
    invalid("GIF dimensions exceed limits");
  const globalColors = screen[4] & 128 ? 2 << (screen[4] & 7) : 0;
  if (globalColors) take(globalColors * 3);
  const blocks = () => {
    const chunks = [];
    let length;
    while ((length = take(1)[0])) chunks.push(take(length));
    return Buffer.concat(chunks);
  };
  let frameCount = 0,
    durationMs = 0,
    delay = 0,
    totalPixels = 0,
    control = false;
  while (offset < bytes.length) {
    const marker = take(1)[0];
    if (marker === 0x3b) {
      if (!frameCount || control || offset !== bytes.length) invalid("GIF lacks frames or contains trailing data");
      return { mimeType: "image/gif", extension: "gif", width, height, frameCount, durationMs };
    }
    if (marker === 0x21) {
      const label = take(1)[0];
      if (label === 0xf9) {
        if (control || take(1)[0] !== 4) invalid("Invalid GIF graphic control block");
        const gce = take(4);
        if (gce[0] & 0xe0 || ((gce[0] >> 2) & 7) > 3 || take(1)[0] !== 0) invalid("Invalid GIF graphic control flags");
        delay = gce.readUInt16LE(1) * 10;
        control = true;
      } else if (label === 0xff) {
        if (take(1)[0] !== 11) invalid("Invalid GIF application extension");
        take(11);
        blocks();
      } else if (label === 0xfe) blocks();
      else invalid("Unsupported GIF extension");
      continue;
    }
    if (marker !== 0x2c) invalid("Invalid GIF block marker");
    const frame = take(9),
      x = frame.readUInt16LE(0),
      y = frame.readUInt16LE(2),
      w = frame.readUInt16LE(4),
      h = frame.readUInt16LE(6);
    if (!w || !h || x + w > width || y + h > height || frame[8] & 0x18)
      invalid("Invalid GIF frame dimensions or flags");
    const localColors = frame[8] & 128 ? 2 << (frame[8] & 7) : 0;
    if (localColors) take(localColors * 3);
    if (!(localColors || globalColors)) invalid("GIF frame has no palette");
    totalPixels += w * h;
    frameCount += 1;
    if (totalPixels > 100_000_000 || frameCount > 1000) invalid("GIF animation exceeds validation limits");
    const codeSize = take(1)[0];
    validatePixels(blocks(), codeSize, w * h, localColors || globalColors);
    durationMs += delay;
    delay = 0;
    control = false;
  }
  invalid("GIF trailer is missing");
}

export function verifyDownload(format, bytesLength, expected) {
  if (!expected || format.mimeType !== expected.mimeType || bytesLength < expected.minimumBytes)
    invalid("Download does not satisfy its pinned MIME type and minimum size");
}
