import { randomUUID } from "node:crypto";

import { AuthSessionStore, authSessionBindingHash, authSessionScope } from "./auth-session-store.js";
import { WorkflowError } from "./errors.js";
import { leasePolicyHash, selectLeasePolicy } from "./lease-policy.js";
import { resolveRunTarget } from "./run-target.js";
import { sha256 } from "./stable-json.js";
import { assertPerspectiveSnapshot } from "./evaluation-perspectives.js";
import {
  assertCurrentFixtureUploadOrigin,
  assertPinnedFixtureContract,
  pinFixtureContract,
  verifyFixtureBinding,
} from "./fixture-lifecycle.js";

function id(prefix) {
  return `${prefix}_${randomUUID().replaceAll("-", "")}`;
}

function exactConfiguredTarget(projectContext, applicationTarget) {
  const targetId = applicationTarget.id ?? applicationTarget.targetId;
  const conflictingTargetIds =
    applicationTarget.id !== undefined &&
    applicationTarget.targetId !== undefined &&
    applicationTarget.id !== applicationTarget.targetId;
  const matches = (projectContext.applicationTargets?.inventory ?? []).filter((target) => target.id === targetId);
  let selectedOrigin;
  let configuredOrigin;
  try {
    selectedOrigin = new URL(applicationTarget.baseUrl).origin;
    configuredOrigin = matches.length === 1 ? new URL(matches[0].baseUrl).origin : null;
  } catch {
    selectedOrigin = null;
  }
  if (
    conflictingTargetIds ||
    matches.length !== 1 ||
    matches[0].authentication?.mode !== "user-session" ||
    applicationTarget.provenance !== "configured-v1" ||
    matches[0].provenance !== applicationTarget.provenance ||
    matches[0].environment !== applicationTarget.environment ||
    configuredOrigin !== selectedOrigin
  ) {
    throw new WorkflowError("AUTH_SESSION_NOT_CONFIGURED", "Authenticated runs require an exact configured target", {
      exitCode: 3,
    });
  }
  return matches[0];
}

/** Resolve only the sanitized marker identity pinned by an authenticated launch. */
export async function resolveLaunchAuthentication({
  identityRequirement,
  projectContext,
  applicationTarget,
  storeRoot,
  authSessionStore,
  registry,
}) {
  if (typeof identityRequirement !== "string" || identityRequirement.length === 0) {
    throw new TypeError("Launch authentication requires an explicit workflow identity requirement");
  }
  if (identityRequirement === "anonymous") return null;
  if (applicationTarget?.authentication?.mode !== "user-session") return null;
  if (!projectContext || applicationTarget.provenance !== "configured-v1") {
    throw new WorkflowError("AUTH_SESSION_NOT_CONFIGURED", "Authenticated runs require an exact configured target", {
      exitCode: 3,
    });
  }
  const configuredTarget = exactConfiguredTarget(projectContext, applicationTarget);
  const store = authSessionStore ?? (storeRoot ? new AuthSessionStore(storeRoot, { registry }) : null);
  if (!store) {
    throw new WorkflowError("AUTH_SESSION_NOT_CONFIGURED", "Authenticated runs require an exact configured target", {
      exitCode: 3,
    });
  }
  const record = await store.read(authSessionScope(projectContext, configuredTarget));
  if (!record.markerHash) {
    throw new WorkflowError("AUTH_MARKER_NOT_CONFIGURED", "Set up this environment in Studio before launching", {
      exitCode: 4,
    });
  }
  return {
    mode: "user-session",
    targetId: configuredTarget.id,
    markerHash: record.markerHash,
    sessionBindingHash: authSessionBindingHash(record),
  };
}

export async function launchPinnedRun(options) {
  if (Object.hasOwn(options, "approved")) {
    throw new TypeError("Pinned run approval cannot be supplied as an option");
  }
  const {
    phase,
    workflow,
    workflowRef,
    platform,
    profile,
    store,
    now = () => new Date(),
    evaluationGroupId,
    qualificationId,
    viewport,
    capabilitySnapshot,
    sourceReplayRunId,
    leasePolicyName = "authorized-codex-browser-v1",
    applicationTarget,
    targetUrl,
    authenticationSession,
    evaluationPerspective,
    runId: requestedRunId,
    fixtureRecipe,
    fixtureProjectRoot,
    fixtureCompatibilityVersion,
    parentRunId,
  } = options;
  const createdAt = now().toISOString();
  const runId = requestedRunId ?? id("run");
  if (!/^run_[A-Za-z0-9_-]+$/.test(runId)) throw new TypeError("Invalid requested run ID");
  if (workflow.target?.identity?.requirement === "anonymous" && authenticationSession) {
    throw new TypeError("Anonymous workflow launches cannot pin authentication");
  }
  if (authenticationSession && !/^sha256:[a-f0-9]{64}$/u.test(authenticationSession.sessionBindingHash ?? "")) {
    throw new TypeError("Authenticated launches require an exact sanitized session binding");
  }
  const leasePolicy = selectLeasePolicy(leasePolicyName, {
    phase,
    humanSelected: leasePolicyName !== "routine-codex-browser-v1",
  });
  const target = resolveRunTarget(workflow, { applicationTarget, targetUrl });
  const fixtureContract = fixtureRecipe
    ? pinFixtureContract({
        recipe: fixtureRecipe,
        compatibilityVersion: fixtureCompatibilityVersion,
        childRevision: workflowRef?.effectiveHash,
        journeyId: workflow.metadata.id,
        target,
        identity: workflow.target.identity,
      })
    : null;
  if (evaluationPerspective) {
    assertPerspectiveSnapshot(evaluationPerspective, { platform });
    if (!evaluationPerspective.batchId || !Object.hasOwn(evaluationPerspective, "controlRunId")) {
      throw new TypeError("Evaluation perspective manifest metadata requires batchId and controlRunId");
    }
    if (
      workflow.target?.identity?.requirement === "named-profile" &&
      authenticationSession &&
      !Object.hasOwn(evaluationPerspective, "sessionPredecessorRunId")
    ) {
      throw new TypeError("Named-profile perspective metadata requires a serialized session predecessor");
    }
  }
  const manifest = {
    schema: "agent-workflow-run-manifest/v1",
    runId,
    createdAt,
    phase,
    ...(evaluationGroupId ? { evaluationGroupId } : {}),
    ...(evaluationPerspective ? { evaluationPerspective: structuredClone(evaluationPerspective) } : {}),
    workflowRef: structuredClone(workflowRef),
    profile,
    platform,
    target,
    identity: structuredClone(workflow.target.identity),
    ...(fixtureContract ? { fixtureContract } : {}),
    ...(parentRunId ? { parentRunId } : {}),
    ...(authenticationSession
      ? {
          authentication: {
            mode: "user-session",
            targetId: authenticationSession.targetId,
            markerHash: authenticationSession.markerHash,
            sessionBindingHash: authenticationSession.sessionBindingHash,
          },
        }
      : {}),
    leasePolicy,
    policyHash: leasePolicyHash(leasePolicy),
    eventSchema: "agent-workflow-run-event/v1",
    resetContractHash: sha256(workflow.evaluation),
    ...(qualificationId ? { qualificationId } : {}),
    ...(viewport ? { viewport: structuredClone(viewport) } : {}),
    ...(capabilitySnapshot ? { capabilitySnapshot: structuredClone(capabilitySnapshot) } : {}),
    ...(sourceReplayRunId ? { sourceReplayRunId } : {}),
    ...(phase === "evaluation" ? { nonResumable: true } : {}),
  };
  assertPinnedFixtureContract(manifest, workflow);
  if (fixtureRecipe?.kind === "repository-file" && ["replay", "evaluation"].includes(phase)) {
    if (
      manifest.target.source !== "application-target" ||
      manifest.target.environment !== "local" ||
      manifest.identity.requirement !== "anonymous" ||
      manifest.authentication
    ) {
      throw new WorkflowError(
        "FIXTURE_INCOMPATIBLE",
        "Repository file replay and evaluation need an anonymous local target",
        { exitCode: 4 },
      );
    }
    assertCurrentFixtureUploadOrigin(manifest, manifest.target.effectiveUrl);
  }
  if (fixtureRecipe?.kind === "repository-file" && fixtureProjectRoot) {
    await verifyFixtureBinding(fixtureProjectRoot, manifest);
  }
  let transaction;
  let published = false;
  try {
    transaction = await store.createRun(manifest, { eventId: id("evt"), workflow });
    published = true;
    if (fixtureRecipe?.kind === "repository-file" && fixtureProjectRoot) {
      await store.bindRepositoryFixture(runId, { projectRoot: fixtureProjectRoot });
    }
  } catch (error) {
    if (!fixtureRecipe) throw error;
    const known = error instanceof WorkflowError;
    const failure = new WorkflowError(known ? error.code : "INTERNAL_ERROR", error?.message ?? String(error), {
      exitCode: known ? error.exitCode : 1,
      details: { ...error?.details, runId, runPublication: published ? "confirmed" : "unknown" },
    });
    failure.cause = error;
    throw failure;
  }
  const launchCard = {
    runId,
    phase,
    workflow: workflowRef,
    platform,
    profile,
    viewport: viewport ?? null,
    resetContractHash: manifest.resetContractHash,
    leasePolicy,
    policyHash: manifest.policyHash,
    target,
  };
  return { launchCard, manifest, state: transaction.state };
}
