import { resolve } from "node:path";

import { WorkflowError } from "./errors.js";
import { readYaml } from "./schema-registry.js";
import { sha256 } from "./stable-json.js";

function invalid() {
  throw new WorkflowError(
    "LOCAL_DOGFOOD_SCOPE_INVALID",
    "Local synthetic authority requires an unchanged configured local target, loopback origin, and explicit workflow scope",
    { exitCode: 3 },
  );
}

function localOrigin(value) {
  try {
    const url = new URL(value);
    const local =
      url.hostname === "localhost" ||
      url.hostname.endsWith(".localhost") ||
      url.hostname === "127.0.0.1" ||
      url.hostname === "[::1]";
    if (!local || !["http:", "https:"].includes(url.protocol) || url.username || url.password) invalid();
    return url.origin;
  } catch {
    invalid();
  }
}

/** Resolve only explicit repository configuration; flags and historical runs grant no authority. */
export async function resolveLocalDogfood(context, target, workflowId, registry) {
  if (!context || context.resolution?.mode !== "configured") return undefined;
  const config = registry.validate(
    "config",
    await readYaml(resolve(context.projectRoot, context.resolution.configPath)),
  );
  const configured = config.project.targets?.find((item) => item.id === target.targetId);
  if (!configured?.localDogfood) return undefined;
  const policy = configured.localDogfood;
  if (
    config.schema !== "agent-workflow-config/v1" ||
    configured.environment !== "local" ||
    target.environment !== "local" ||
    target.source !== "application-target" ||
    target.provenance !== "configured-v1" ||
    policy.syntheticData !== true ||
    !policy.workflowIds.includes(workflowId)
  )
    invalid();
  const origin = localOrigin(configured.baseUrl);
  if (localOrigin(target.effectiveUrl) !== origin || localOrigin(target.canonicalUrl) !== origin) invalid();
  return { kind: "local-synthetic-v1", targetId: configured.id, origin, workflowId };
}

export function assertLocalDogfoodManifest(manifest) {
  const policy = manifest.localDogfood;
  if (!policy) return;
  const target = manifest.target;
  if (
    policy.kind !== "local-synthetic-v1" ||
    manifest.phase !== "training" ||
    !["desktop-web", "mobile-web"].includes(manifest.platform) ||
    !["standard", "authorized-codex-browser-v1"].includes(manifest.leasePolicy?.name) ||
    policy.workflowId !== manifest.workflowRef?.id ||
    target?.source !== "application-target" ||
    target.environment !== "local" ||
    target.provenance !== "configured-v1" ||
    target.targetId !== policy.targetId ||
    localOrigin(policy.origin) !== policy.origin ||
    localOrigin(target.effectiveUrl) !== policy.origin ||
    localOrigin(target.canonicalUrl) !== policy.origin
  )
    invalid();
}

export async function revalidateLocalDogfood(context, manifest, registry) {
  if (!manifest.localDogfood) return;
  assertLocalDogfoodManifest(manifest);
  const current = await resolveLocalDogfood(context, manifest.target, manifest.workflowRef.id, registry);
  if (!current || sha256(current) !== sha256(manifest.localDogfood)) invalid();
}

/** Exact pinned batches only. Credentials, arbitrary adapters, and off-origin navigation never inherit this scope. */
export function localDogfoodBatch(manifest, step, proposal) {
  assertLocalDogfoodManifest(manifest);
  if (
    !manifest.localDogfood ||
    !step ||
    !proposal.actions.length ||
    proposal.actions.length > 3 ||
    proposal.requestedCapabilities.some((capability) => capability !== "browser.control")
  )
    return null;
  const kinds = ["observe", "activate-control", "enter-text", "navigate", "scroll", "wait", "capture-evidence"];
  for (const action of proposal.actions) {
    if (!kinds.includes(action.kind) || action.inputRef) return null;
    if (action.kind === "navigate") {
      try {
        const url = new URL(action.target, manifest.localDogfood.origin);
        if (url.origin !== manifest.localDogfood.origin || url.username || url.password) return null;
      } catch {
        return null;
      }
    }
  }
  const hash = sha256({ actions: proposal.actions, requestedCapabilities: proposal.requestedCapabilities });
  return (
    (step.routineActionBatches ?? []).find(
      (batch) => sha256({ actions: batch.actions, requestedCapabilities: batch.requestedCapabilities }) === hash,
    ) ?? null
  );
}
