function text(value) {
  return typeof value === "string" ? value : null;
}

function workflowIdentity(run) {
  return {
    id: text(run.manifest.workflowRef?.id) ?? text(run.workflow?.metadata?.id),
    name: text(run.workflow?.metadata?.name),
  };
}

export function projectTrainingRunSummary(run, candidateRevision) {
  const artifacts = Object.values(run.state.traversal?.artifacts ?? {}).filter((artifact) =>
    ["screenshot", "download-content"].includes(artifact.type),
  );
  const binding =
    Number.isInteger(candidateRevision) && Number.isInteger(run.workflow?.metadata?.candidateRevision)
      ? run.workflow.metadata.candidateRevision === candidateRevision
        ? "current"
        : "historical"
      : "unknown";
  return {
    runId: run.manifest.runId,
    createdAt: run.manifest.createdAt,
    phase: run.state.phase,
    status: run.state.status,
    journeyOutcome: run.state.traversal?.journeyOutcome ?? null,
    terminalOutcome: run.state.terminalOutcome ?? null,
    cleanupOutcome: run.state.cleanupOutcome ?? null,
    revision: run.state.revision,
    platform: run.manifest.platform,
    profile: run.manifest.profile,
    workflow: workflowIdentity(run),
    classification: "training",
    candidateRevision: Number.isInteger(run.workflow?.metadata?.candidateRevision)
      ? run.workflow.metadata.candidateRevision
      : null,
    binding,
    disposition: ["completed", "blocked", "failed", "abandoned"].includes(run.state.status) ? "evidence" : "unfinished",
    dispositionReason: ["completed", "blocked", "failed", "abandoned"].includes(run.state.status)
      ? "This terminal run remains available as immutable evidence."
      : "This run has not reached a terminal outcome.",
    artifactSummary: { total: artifacts.length, verified: 0, failed: 0 },
    proof: {
      state: "not-loaded",
      decisionReady: false,
      evidenceOutcome: "not-loaded",
      reasons: ["Exact evidence integrity has not been loaded for this recorded attempt."],
    },
    replay: "not-loaded",
  };
}

export function trainingSummaryDecision(run, inventoryTrusted) {
  if (!inventoryTrusted) {
    return {
      state: "unavailable",
      reason: "Training inventory is partial, so a newer or current candidate attempt may be unreadable.",
      action: "Refresh review data",
      destination: "refresh",
    };
  }
  if (!run) {
    return {
      state: "no-current-proof",
      reason: "Trusted inventory contains no Training attempt bound to the current candidate.",
      action: "Review current candidate Training prerequisites and history",
      destination: "training-history",
    };
  }
  return {
    state: "evidence-not-loaded",
    reason: "A current Training attempt is recorded, but its exact evidence has not been loaded.",
    action: "Load decisive evidence",
    destination: "training-run",
  };
}

export function projectEvaluationGroupSummary(group, runs) {
  const byRunId = new Map(runs.map((run) => [run.runId, run]));
  return {
    groupId: group.groupId,
    workflowId: group.workflowId,
    revision: group.revision,
    contentHash: group.contentHash,
    resetContractHash: group.resetContractHash,
    createdAt: group.createdAt,
    integrity: "not-loaded",
    outcome: "not-loaded",
    members: group.members.map((member) => {
      const run = byRunId.get(member.runId);
      return {
        runId: member.runId,
        platform: member.platform,
        viewport: member.viewport ?? null,
        qualificationId: member.qualificationId,
        effectiveHash: member.effectiveHash,
        integrity: "not-loaded",
        qualification: null,
        receipt: null,
        run: run ? { status: run.status, journeyOutcome: run.journeyOutcome } : null,
      };
    }),
  };
}
