import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { WorkflowError } from "./errors.js";
import { listPerspectives } from "./evaluation-perspectives.js";
import { PerspectiveAssessmentStore, recordPerspectiveAssessment } from "./perspective-assessment-store.js";
import { PerspectiveBatchStore } from "./perspective-batch-store.js";
import { inspectPerspectiveBatch, launchPerspectiveBatch } from "./perspective-batches.js";
import { RunControlStore } from "./run-control-store.js";
import { LifecycleStore } from "./lifecycle-store.js";
import { EvaluationQuestionPolicyStore } from "./evaluation-question-policy-store.js";
import { readEvaluationRequirements } from "./evaluation-requirements.js";
import { catalogProjectWorkflows, verifyCatalogWorkflowSource } from "./project-workflow-catalog.js";
import {
  projectSelectionSnapshot,
  selectVerifiedApplicationTarget,
  selectVerifiedCatalogSource,
} from "./project-surface-snapshot.js";

function invalid(message) {
  throw new WorkflowError("INVALID_USAGE", message, { exitCode: 2 });
}
function flagsOnly(flags, allowed) {
  for (const name of flags.keys()) if (!allowed.includes(name)) invalid(`Unexpected --${name}`);
}
async function inputFile(path) {
  if (!path) invalid("A JSON --file is required");
  try {
    return JSON.parse(await readFile(resolve(path), "utf8"));
  } catch (error) {
    throw new WorkflowError("INVALID_JSON", "Unable to read JSON input", {
      exitCode: 2,
      details: { cause: error.message },
    });
  }
}
function stores(root, registry) {
  return {
    runStore: new RunControlStore(root, { registry }),
    batchStore: new PerspectiveBatchStore(root, { registry }),
    assessmentStore: new PerspectiveAssessmentStore(root, { registry }),
    lifecycleStore: new LifecycleStore(root, { registry }),
  };
}
export async function executePerspectivesCommand(args, flags, registry) {
  const [operation, id] = args;
  flagsOnly(flags, operation === "assess" ? ["store", "json", "file"] : ["store", "json"]);
  if (operation === "list" && args.length === 1) return { perspectives: listPerspectives() };
  if (!id || args.length !== 2) invalid("perspectives requires list, assess RUN_ID, or inspect BATCH_ID");
  const local = stores(resolve(flags.get("store") ?? ".workflows/local"), registry);
  if (operation === "inspect") return inspectPerspectiveBatch({ batchId: id, ...local });
  if (operation === "assess") {
    const input = await inputFile(flags.get("file"));
    if (
      !input ||
      Object.keys(input).some(
        (key) =>
          ![
            "criterionId",
            "outcome",
            "reason",
            "observations",
            "unassessedReason",
            "questionIds",
            "supersedesAssessmentId",
          ].includes(key),
      )
    )
      invalid("Assessment input contains unsupported fields");
    await local.assessmentStore.init();
    return {
      assessment: await recordPerspectiveAssessment({
        ...input,
        store: local.assessmentStore,
        runStore: local.runStore,
        runId: id,
      }),
    };
  }
  invalid(`Unknown perspectives operation: ${operation}`);
}
export async function executePerspectiveEvaluation(args, flags, registry, getContext) {
  flagsOnly(flags, [
    "journey",
    "selection",
    "source",
    "target",
    "target-url",
    "root",
    "config",
    "store",
    "json",
    "batch",
    "inquiry-depth",
  ]);
  if (args.length !== 1 || !flags.get("journey")?.trim() || !flags.get("selection"))
    invalid("evaluate perspectives requires --journey and --selection");
  if (!flags.has("source")) invalid("evaluate perspectives requires --source candidate or --source promoted");
  const sourceKind = flags.get("source");
  if (!["candidate", "promoted"].includes(sourceKind)) invalid("--source must be candidate or promoted");
  if (flags.has("target") && flags.has("target-url")) invalid("Choose --target or --target-url");
  const selection = await inputFile(flags.get("selection"));
  if (!selection || Object.keys(selection).some((key) => !["selections", "policy"].includes(key)))
    invalid("Selection file accepts selections and policy");
  const projectContext = await getContext();
  const catalog = await catalogProjectWorkflows(projectContext, { registry });
  const snapshot = await projectSelectionSnapshot(projectContext, {
    binding: "current",
    catalog,
    registry,
    terms: flags.get("journey"),
    targetTerms: flags.get("target"),
  });
  const workflowSource = selectVerifiedCatalogSource(snapshot, catalog);
  await verifyCatalogWorkflowSource(workflowSource);
  const root = flags.has("store")
    ? resolve(flags.get("store"))
    : resolve(projectContext.projectRoot, ...projectContext.paths.localStore.split("/"));
  const local = stores(root, registry);
  await local.runStore.init();
  await local.batchStore.init();
  const requirementsCatalog = await readEvaluationRequirements(projectContext, { registry });
  const storedInquiryPolicy = await new EvaluationQuestionPolicyStore(root, { registry }).read(
    projectContext.project.id,
  );
  const requestedDepth = flags.get("inquiry-depth");
  if (requestedDepth && !["focused", "balanced", "exploratory"].includes(requestedDepth))
    invalid("--inquiry-depth must be focused, balanced, or exploratory");
  const inquiryPolicy = { ...storedInquiryPolicy, ...(requestedDepth ? { depth: requestedDepth } : {}) };
  const source = {
    sourceKind,
    workflowId: workflowSource.workflow.metadata.id,
    ...(sourceKind === "candidate" ? { workflowSource } : {}),
  };
  const receipt = await launchPerspectiveBatch({
    ...(flags.has("batch") ? { batchId: flags.get("batch") } : {}),
    source,
    target: {
      projectContext,
      ...(flags.has("target-url")
        ? { targetUrl: flags.get("target-url") }
        : { applicationTarget: selectVerifiedApplicationTarget(snapshot) }),
    },
    ...selection,
    inquiryPolicy,
    requirementsCatalog,
    ...local,
  });
  if (!receipt.ok)
    throw new WorkflowError(
      "PERSPECTIVE_BATCH_PARTIAL",
      "Some batch members could not launch; preserve surviving run cards and resume the same batch",
      { exitCode: receipt.exitCode, details: receipt },
    );
  return receipt;
}
