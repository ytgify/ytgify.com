import { orderedMapEvidence } from "./app-map-contract.js";
import { readMapRegistry } from "./app-map-registry.js";
import { createStudioProjectionContext, projectStudioRun, trainingProof } from "./studio-projection.js";

function summary(source, workflows) {
  const manifest = source.manifest;
  const workflowId = manifest.workflowRef?.id ?? source.workflow?.metadata?.id;
  if (!workflowId) throw new Error("Run workflow identity unavailable");
  const candidate = workflows.find((item) => item.id === workflowId)?.draft?.candidateRevision;
  const pinned = source.workflow?.metadata?.candidateRevision;
  const binding =
    Number.isInteger(candidate) && Number.isInteger(pinned)
      ? candidate === pinned
        ? "current"
        : "historical"
      : "unknown";
  const target = manifest.target;
  const targetKey = target
    ? JSON.stringify([target.targetId, target.environment, target.canonicalUrl, target.effectiveUrl, target.source])
    : null;
  const appId = source.workflow?.target?.app ?? null;
  return {
    runId: manifest.runId,
    workflowId,
    workflowName: source.workflow?.metadata?.name ?? workflowId,
    appId,
    platform: manifest.platform ?? null,
    targetKey,
    targetLabel: target?.label ?? null,
    phase: manifest.phase,
    status: source.state.status,
    createdAt: manifest.createdAt ?? null,
    binding,
    defaultEligible: false,
    defaultCandidate: Boolean(
      binding === "current" &&
      manifest.phase === "training" &&
      source.state.status === "completed" &&
      appId &&
      targetKey,
    ),
  };
}
export async function projectMapCatalog(store, workflows, registry) {
  const diagnostics = [];
  let ids;
  try {
    ids = await store.listRunIds();
  } catch {
    return { schema: "workflows-app-map/v1", runs: [], diagnostics: ["Run inventory unavailable"] };
  }
  let assignments = null;
  if (registry) {
    try {
      assignments = (await readMapRegistry(store, registry)).assignments;
    } catch {
      diagnostics.push("Screen assignment coverage unavailable");
    }
  }
  const runs = [];
  for (const id of ids) {
    try {
      const source = await store.readRun(id);
      if (source.manifest.phase === "exploration") continue;
      const metadata = summary(source, workflows);
      const visits = orderedMapEvidence(source.events);
      const byVisit = new Map(
        (assignments ?? []).filter((item) => item.appId === metadata.appId).map((item) => [item.visitId, item]),
      );
      const matched = visits.map((visit) => byVisit.get(visit.visitId)).filter(Boolean);
      runs.push({
        ...metadata,
        screenCoverage:
          assignments === null
            ? null
            : {
                captures: visits.length,
                identified: matched.length,
                variants: matched.filter((item) => item.variantId).length,
              },
      });
    } catch {
      diagnostics.push(`Run ${id} is unavailable`);
    }
  }
  if (diagnostics.length) for (const run of runs) run.defaultCandidate = false;
  runs.sort(
    (a, b) => String(b.createdAt ?? "").localeCompare(String(a.createdAt ?? "")) || a.runId.localeCompare(b.runId),
  );
  return { schema: "workflows-app-map/v1", runs, diagnostics };
}
export async function projectMapRun(store, registry, runId, workflows) {
  const context = createStudioProjectionContext(store);
  const source = await context.runStore.readRun(runId);
  if (source.manifest.phase === "exploration") throw new Error("Exploration runs have a separate review surface");
  const metadata = summary(source, workflows);
  const projected = await projectStudioRun(context.runStore, runId, context);
  const diagnostics = [];
  let assignments = [];
  try {
    assignments = (await readMapRegistry(store, registry)).assignments;
  } catch {
    diagnostics.push("Screen registry unavailable or invalid; captures remain unresolved");
  }
  const projectedArtifacts = new Map(projected.artifacts.map((item) => [item.artifactId, item]));
  const assignmentsByVisit = new Map(
    assignments.filter((item) => item.appId === metadata.appId).map((item) => [item.visitId, item]),
  );
  const assignedArtifacts = new Set(
    assignments
      .map((item) => JSON.parse(item.visitId))
      .filter((identity) => identity[0] === runId)
      .map((identity) => identity[3]),
  );
  const visits = orderedMapEvidence(source.events).map((visit) => {
    const artifact = visit.artifact;
    const evidence = projectedArtifacts.get(artifact.artifactId);
    const assignment = assignmentsByVisit.get(visit.visitId);
    const stale = !assignment && assignedArtifacts.has(artifact.artifactId);
    return {
      visitId: visit.visitId,
      sequence: visit.sequence,
      ordinal: visit.ordinal,
      stepId: artifact.relation?.stepId ?? null,
      reviewQuery:
        metadata.phase === "training"
          ? new URLSearchParams(
              (projected.steps.find((step) => step.id === artifact.relation?.stepId)?.evidence ?? []).map((item) => [
                "evidence",
                JSON.stringify([
                  item.artifactId,
                  item.contentHash ?? null,
                  item.checkpoint ?? null,
                  item.integrity ?? null,
                ]),
              ]),
            ).toString()
          : null,
      checkpoint: artifact.relation?.checkpoint ?? null,
      artifactId: artifact.artifactId,
      contentHash: artifact.contentHash,
      url: visit.registered && evidence?.integrity === "verified" ? evidence.url : null,
      integrity: evidence?.integrity ?? "unavailable",
      availability:
        visit.registered && evidence?.integrity === "verified"
          ? "available"
          : evidence?.sourceIntegrity === "verified"
            ? "unavailable"
            : (evidence?.sourceIntegrity ?? "missing"),
      screenId: assignment?.screenId ?? null,
      screenLabel: assignment?.screenLabel ?? null,
      stateLabel: assignment?.stateLabel ?? null,
      variantId: assignment?.variantId ?? null,
      variantLabel: assignment?.variantLabel ?? null,
      journeyLabel: assignment?.journeyLabel ?? null,
      identityIssue: assignment
        ? null
        : stale
          ? "Assignment no longer matches exact evidence"
          : "Screen identity unresolved",
    };
  });
  const proof = trainingProof({
    ...projected,
    disposition: ["completed", "blocked", "failed", "abandoned"].includes(projected.status) ? "evidence" : "unfinished",
  });
  return {
    ...metadata,
    defaultEligible: Boolean(
      metadata.defaultCandidate && proof.state === "verified" && projected.replay === "verified" && visits.length,
    ),
    visits,
    requiredCaptures: projected.evidenceReview.required,
    diagnostics,
  };
}
