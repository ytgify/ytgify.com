import { readFile } from "node:fs/promises";
import { resolve } from "node:path";

import { recordOptionalReview, resumeRun } from "./acceptance-authority.js";
import {
  appendNeutralReviewIntent,
  applyNeutralRunMutation,
  verifyReviewIntentSource,
} from "./collaboration-mutations.js";
import { WorkflowError } from "./errors.js";
import { resolveProjectContext } from "./project-context.js";
import { projectSurfaceSnapshot } from "./project-surface-snapshot.js";
import { ReviewIntentStore } from "./review-intent-store.js";
import { RunControlStore } from "./run-control-store.js";

const RUN_OPERATIONS = new Set(["pause", "stop", "emergency-stop", "resume"]);

export const collaborationUsage = [
  "workflow review-intent record --file PATH [--root PATH] [--config PATH] [--json]",
  "workflow review-intent list [WORKFLOW_ID] [--root PATH] [--config PATH] [--json]",
  "workflow review-intent show INTENT_ID [--root PATH] [--config PATH] [--json]",
  "workflow acceptance record --file PATH [--root PATH] [--config PATH] [--json] (verified state; no approval required)",
  "workflow acceptance list [WORKFLOW_ID] [--root PATH] [--config PATH] [--json]",
  "workflow acceptance show ACCEPTANCE_ID [--root PATH] [--config PATH] [--json]",
  "workflow run pause RUN_ID --file PATH [--store PATH] [--json]",
  "workflow run stop RUN_ID --file PATH [--store PATH] [--json]",
  "workflow run emergency-stop RUN_ID --file PATH [--store PATH] [--json]",
  "workflow run resume RUN_ID --file PATH [--store PATH] [--json] (verified state; no approval required)",
];

function fail(message, details) {
  throw new WorkflowError("INVALID_USAGE", message, { exitCode: 2, details });
}

function unsupportedFlags(flags, allowed, command) {
  const unsupported = [...flags.keys()].filter((name) => !allowed.includes(name));
  if (unsupported.length) fail(`${command} does not accept --${unsupported[0]}`);
}

function exactObject(value, allowed, label) {
  if (!value || Array.isArray(value) || typeof value !== "object") fail(`${label} must be a JSON object`);
  const extras = Object.keys(value).filter((key) => !allowed.includes(key));
  if (extras.length) fail(`${label} contains unknown or authority-bearing fields`, { extras });
  return structuredClone(value);
}

async function fileRequest(flags, label) {
  const path = flags.get("file");
  if (!path) {
    fail(`${label} requires --file PATH for structured request input`);
  }
  let text;
  try {
    text = await readFile(resolve(path), "utf8");
  } catch (error) {
    throw new WorkflowError("INVALID_JSON", `Could not read ${label} JSON`, {
      exitCode: 2,
      details: { cause: error.message },
    });
  }
  try {
    return JSON.parse(text);
  } catch (error) {
    throw new WorkflowError("INVALID_JSON", `Could not parse ${label} JSON`, {
      exitCode: 2,
      details: { cause: error.message },
    });
  }
}

async function contextFor(flags, registry) {
  return resolveProjectContext({
    ...(flags.has("root") ? { projectRoot: resolve(flags.get("root")) } : {}),
    ...(flags.has("config") ? { configPath: flags.get("config") } : {}),
    registry,
  });
}

function filterWorkflow(records, workflowId) {
  return workflowId ? records.filter((record) => record.workflowId === workflowId) : records;
}

function notFound(kind) {
  throw new WorkflowError("NOT_FOUND", `The requested ${kind} is unavailable`, { exitCode: 8 });
}

async function reviewIntentCommand(args, flags, registry) {
  const [operation, identity] = args;
  if (!new Set(["record", "list", "show"]).has(operation) || args.length > 2) {
    fail("review-intent requires record, list, or show");
  }
  unsupportedFlags(flags, ["config", "file", "json", "root"], `review-intent ${operation}`);
  const context = await contextFor(flags, registry);
  const store = new ReviewIntentStore(context, { registry });

  if (operation === "record") {
    if (identity) fail("review-intent record does not accept a positional identity");
    const input = exactObject(
      await fileRequest(flags, "review-intent record"),
      ["workflowId", "runId", "source", "expectedRevision", "idempotencyKey", "action", "supersedesIntentId"],
      "Review-intent request",
    );
    await store.init();
    const runStore = new RunControlStore(resolve(context.projectRoot, context.paths.localStore), { registry });
    const record = await appendNeutralReviewIntent({
      store,
      request: { ...input, channel: "cli" },
      verifySource: (workflowId, source) => verifyReviewIntentSource(runStore, workflowId, source),
    });
    return { command: "review-intent record", data: { record } };
  }
  if (flags.has("file")) fail(`review-intent ${operation} does not accept --file`);
  const records = (await projectSurfaceSnapshot(context, { registry })).reviewIntents;
  if (operation === "list") {
    return { command: "review-intent list", data: { records: filterWorkflow(records, identity) } };
  }
  if (!identity) fail("review-intent show requires an intent identity");
  const record = records.find(({ intentId }) => intentId === identity);
  if (!record) notFound("review request");
  return { command: "review-intent show", data: { record } };
}

async function acceptanceCommand(args, flags, registry) {
  const [operation, identity] = args;
  if (!new Set(["record", "list", "show"]).has(operation) || args.length > 2) {
    fail("acceptance requires record, list, or show");
  }
  unsupportedFlags(flags, ["config", "file", "json", "root"], `acceptance ${operation}`);
  const context = await contextFor(flags, registry);

  if (operation === "record") {
    if (identity) fail("acceptance record does not accept a positional identity");
    const record = exactObject(
      await fileRequest(flags, "acceptance record"),
      [
        "schema",
        "acceptanceId",
        "workflowId",
        "revision",
        "contentHash",
        "decision",
        "evidence",
        "supersedesAcceptanceId",
      ],
      "Acceptance request",
    );
    return {
      command: "acceptance record",
      data: { record: await recordOptionalReview({ projectContext: context, record, registry }) },
    };
  }
  if (flags.has("file")) fail(`acceptance ${operation} does not accept --file`);
  const records = (await projectSurfaceSnapshot(context, { registry })).acceptanceSupport.records;
  if (operation === "list") {
    return { command: "acceptance list", data: { records: filterWorkflow(records, identity) } };
  }
  if (!identity) fail("acceptance show requires an acceptance identity");
  const record = records.find(({ acceptanceId }) => acceptanceId === identity);
  if (!record) notFound("acceptance decision");
  return { command: "acceptance show", data: { record } };
}

async function runCollaborationCommand(operation, runId, flags, registry) {
  unsupportedFlags(flags, ["file", "json", "store"], `run ${operation}`);
  const input = exactObject(
    await fileRequest(flags, `run ${operation}`),
    operation === "resume"
      ? ["expectedRevision", "idempotencyKey"]
      : operation === "emergency-stop"
        ? ["expectedRevision", "idempotencyKey", "reason", "leaseId"]
        : ["expectedRevision", "idempotencyKey", "reason"],
    `Run ${operation} request`,
  );
  const store = await new RunControlStore(resolve(flags.get("store") ?? ".workflows/local"), {
    registry,
  }).init();
  const transaction =
    operation === "resume"
      ? await resumeRun({
          store,
          runId,
          expectedRevision: input.expectedRevision,
          idempotencyKey: input.idempotencyKey,
        })
      : await applyNeutralRunMutation({ store, runId, command: operation, request: input });
  return {
    command: `run ${operation}`,
    data: {
      runId,
      replay: transaction.replay,
      receipt: transaction.receipt,
      state: transaction.state,
    },
  };
}

export function isCollaborationRunOperation(operation) {
  return RUN_OPERATIONS.has(operation);
}

/** Dispatch durable collaboration while keeping trusted authority confined to the verified lifecycle writers. */
export async function executeCollaborationCommand(command, args, flags, registry) {
  if (command === "review-intent") return { ok: true, ...(await reviewIntentCommand(args, flags, registry)) };
  if (command === "acceptance") return { ok: true, ...(await acceptanceCommand(args, flags, registry)) };
  const [operation, runId] = args;
  if (command !== "run" || !RUN_OPERATIONS.has(operation) || !runId || args.length !== 2) {
    fail("Unknown collaboration command");
  }
  return { ok: true, ...(await runCollaborationCommand(operation, runId, flags, registry)) };
}
