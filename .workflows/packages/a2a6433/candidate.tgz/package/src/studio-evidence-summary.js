function text(value) {
  return typeof value === "string" ? value : null;
}

export function artifactVerdict(error) {
  return error?.code === "VALIDATION_FAILED" ? "failed" : "unavailable";
}

export function requiredEvidenceReview(workflowSteps, projectedSteps) {
  const requirements = workflowSteps.flatMap((workflowStep) =>
    (workflowStep.evidence ?? [])
      .filter(
        (item) =>
          typeof item === "object" &&
          ["screenshot", "download-artifact"].includes(item.type) &&
          item.required !== false,
      )
      .map((item, requirementIndex) => {
        const evidence =
          projectedSteps
            .find((step) => step.id === workflowStep.id)
            ?.evidence.filter(
              (artifact) =>
                artifact.type === (item.type === "download-artifact" ? "download-content" : item.type) &&
                (item.type !== "download-artifact" ||
                  (artifact.download?.filename === item.verify?.filename &&
                    artifact.mimeType === item.verify?.mimeType &&
                    artifact.sizeBytes >= item.verify?.minimumBytes)) &&
                artifact.checkpoint === item.checkpoint &&
                artifact.optionalHandlerId === null,
            ) ?? [];
        let state = "missing";
        if (evidence.some((artifact) => artifact.integrity === "verified")) state = "verified";
        else if (evidence.some((artifact) => artifact.integrity === "failed")) state = "failed";
        else if (evidence.some((artifact) => artifact.integrity === "unavailable")) state = "unavailable";
        return {
          requirementIndex,
          stepId: workflowStep.id,
          checkpoint: text(item.checkpoint),
          state,
          artifactIds: evidence.map((artifact) => artifact.artifactId),
        };
      }),
  );
  const counts = Object.fromEntries(
    ["verified", "failed", "missing", "unverified", "unavailable"].map((state) => [
      state,
      requirements.filter((requirement) => requirement.state === state).length,
    ]),
  );
  return { expected: requirements.length, ...counts, requirements };
}

function evidenceReason(count, singular, plural) {
  return `${count} required evidence ${count === 1 ? singular : plural}`;
}

export function runEvidenceExplanation(run, required, artifacts) {
  const failures = [];
  const degraded = [];
  const incomplete = [];
  if (run.state.traversal?.journeyOutcome === "failed") failures.push("The supervised journey failed.");
  if (required.failed > 0) {
    failures.push(evidenceReason(required.failed, "item has failed verification.", "items have failed verification."));
  }
  if (artifacts.some((artifact) => artifact.integrity === "failed") && required.failed === 0) {
    degraded.push("Observed evidence outside required coverage failed integrity verification.");
  }
  if (required.unavailable > 0) {
    degraded.push(
      evidenceReason(
        required.unavailable,
        "item is unavailable for verification.",
        "items are unavailable for verification.",
      ),
    );
  }
  if (artifacts.some((artifact) => artifact.integrity === "unavailable") && required.unavailable === 0) {
    degraded.push("Observed evidence is unavailable for verification.");
  }
  if (run.state.status !== "completed" || !["passed", "failed"].includes(run.state.traversal?.journeyOutcome)) {
    incomplete.push("The run does not have a completed journey verdict.");
  }
  if (required.missing > 0) {
    incomplete.push(evidenceReason(required.missing, "item is missing.", "items are missing."));
  }
  if (required.unverified > 0) {
    incomplete.push(
      evidenceReason(required.unverified, "item has no verification verdict.", "items have no verification verdict."),
    );
  }
  if (required.expected === 0) incomplete.push("No required evidence is declared for this run.");

  const reasons = [...failures, ...degraded, ...incomplete];
  const outcome = failures.length
    ? "failed"
    : degraded.length
      ? "degraded"
      : incomplete.length
        ? "incomplete"
        : "passed";
  if (outcome === "passed") reasons.push("The journey passed and every required evidence item is verified.");
  const label = outcome[0].toUpperCase() + outcome.slice(1);
  return { outcome, headline: `${label} — ${reasons[0]}`, reasons };
}

function projectedMembers(group) {
  return group.members.map((member) => ({
    runId: member.runId,
    platform: member.platform,
    viewport: member.viewport ?? null,
    integrity: member.integrity,
    qualification: member.qualification ?? null,
    receipt: member.receipt,
    run: member.run
      ? {
          status: member.run.status,
          journeyOutcome: member.run.journeyOutcome,
          cleanupOutcome: member.run.cleanupOutcome,
          terminalOutcome: member.run.terminalOutcome,
          artifactSummary: member.run.artifactSummary,
          evidenceReview: member.run.evidenceReview,
        }
      : null,
  }));
}

function memberReasons(member) {
  const label = member.platform === "desktop-web" ? "Desktop" : "Mobile";
  if (!member.runId) return [`${label} evaluation member is missing.`];
  if (["corrupt", "stale", "unavailable"].includes(member.integrity)) {
    return [`${label} evaluation source is ${member.integrity}.`];
  }
  const reasons = [];
  if (member.integrity !== "verified") reasons.push(`${label} member lineage is not verified.`);
  if (member.qualification?.integrity !== "verified") reasons.push(`${label} qualification is not verified.`);
  if (!member.run) reasons.push(`${label} run evidence is unavailable.`);
  else {
    if (member.run.journeyOutcome === "failed") reasons.push(`${label} journey failed.`);
    else if (member.run.status !== "completed" || member.run.journeyOutcome !== "passed") {
      reasons.push(`${label} journey is incomplete.`);
    }
    if (member.run.evidenceReview?.required?.failed > 0)
      reasons.push(`${label} required evidence failed verification.`);
    if (member.run.evidenceReview?.required?.unavailable > 0)
      reasons.push(`${label} required evidence is unavailable.`);
    if (member.run.evidenceReview?.required?.missing > 0) reasons.push(`${label} required evidence is missing.`);
    if (member.run.evidenceReview?.required?.unverified > 0) reasons.push(`${label} required evidence is unverified.`);
  }
  if (member.receipt?.outcome === "failed") reasons.push(`${label} evaluation receipt failed.`);
  else if (member.receipt?.outcome !== "passed") reasons.push(`${label} evaluation receipt is missing or unverified.`);
  return reasons;
}

export function groupReviewSummary(group) {
  const availableMembers = projectedMembers(group);
  const members = ["desktop-web", "mobile-web"].map(
    (platform) =>
      availableMembers.find((member) => member.platform === platform) ?? {
        runId: null,
        platform,
        viewport: null,
        integrity: "missing",
        qualification: null,
        receipt: null,
        run: null,
      },
  );
  const trustworthyLineage = members.every((member) => member.integrity === "verified");
  const sourceUnavailable = members.some(
    (member) =>
      ["corrupt", "stale", "unavailable"].includes(member.integrity) ||
      member.run?.evidenceReview?.required?.unavailable > 0,
  );
  const explicitFailure = members.some(
    (member) =>
      member.run?.journeyOutcome === "failed" ||
      member.receipt?.outcome === "failed" ||
      member.run?.evidenceReview?.required?.failed > 0,
  );
  const passed =
    trustworthyLineage &&
    members.every(
      (member) =>
        member.qualification?.integrity === "verified" &&
        member.receipt?.outcome === "passed" &&
        member.run?.status === "completed" &&
        member.run?.journeyOutcome === "passed" &&
        member.run?.evidenceReview?.outcome === "passed",
    );
  const outcome = sourceUnavailable
    ? "degraded"
    : trustworthyLineage && explicitFailure
      ? "failed"
      : passed
        ? "passed"
        : "incomplete";
  const reasons = passed
    ? ["Desktop and mobile journeys, receipts, and required evidence are independently verified."]
    : members.flatMap(memberReasons);
  const label = outcome[0].toUpperCase() + outcome.slice(1);
  return {
    groupId: group.groupId,
    workflowId: group.workflowId,
    revision: group.revision,
    createdAt: group.createdAt,
    contentHash: group.contentHash,
    resetContractHash: group.resetContractHash,
    integrity: trustworthyLineage ? "verified" : "degraded",
    outcome,
    headline: `${label} — ${reasons[0]}`,
    reasons,
    members,
  };
}
