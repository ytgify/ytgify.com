const POLICY = Object.freeze({
  INVALID_REQUEST: Object.freeze({
    retryable: false,
    recovery: "Correct the request using the agent command contract, then inspect before sending a mutation.",
  }),
  VALIDATION_FAILED: Object.freeze({
    retryable: false,
    recovery: "Correct the invalid request data, then inspect before sending a mutation.",
  }),
  REVISION_CONFLICT: Object.freeze({
    retryable: true,
    recovery:
      "Inspect the run, rebuild the request against the current revision, and use a new request ID if input changes.",
  }),
  IDEMPOTENCY_CONFLICT: Object.freeze({
    retryable: false,
    recovery: "Inspect the run and caller request-ID bookkeeping; never reuse a request ID with changed input.",
  }),
  ILLEGAL_TRANSITION: Object.freeze({
    retryable: false,
    recovery: "Inspect the run and choose only an operation listed in allowedOperations.",
  }),
  CAPABILITY_UNAVAILABLE: Object.freeze({
    retryable: false,
    recovery: "Inspect the run and either provision the exact capability or record an allowed capability gap.",
  }),
  LOCAL_DOGFOOD_SCOPE_INVALID: Object.freeze({
    retryable: false,
    recovery: "Inspect the current local-dogfood configuration; do not broaden or bypass its pinned scope.",
  }),
  RUN_OWNED: Object.freeze({
    retryable: false,
    recovery: "Stop mutation and inspect ownership; continue only through the explicit release or handoff path.",
  }),
  APPROVAL_REQUIRED: Object.freeze({
    retryable: false,
    recovery: "Inspect the run and current package contract; do not invent or relay approval authority.",
  }),
  NOT_FOUND: Object.freeze({
    retryable: false,
    recovery: "Re-run verified discovery and inspect current project truth instead of guessing an identity.",
  }),
  LEASE_EXPIRED: Object.freeze({
    retryable: false,
    recovery: "Stop browser mutation, inspect the run, and reconcile the exact uncertain lease before continuing.",
  }),
  RECONCILIATION_REQUIRED: Object.freeze({
    retryable: false,
    recovery: "Inspect the run and reconcile the exact uncertain lease; never repeat the external action.",
  }),
  INTERNAL_ERROR: Object.freeze({
    retryable: false,
    recovery: "Inspect durable run state before deciding whether any operation is safe.",
  }),
  PROTOCOL_VERSION_UNSUPPORTED: Object.freeze({
    retryable: false,
    recovery: "Upgrade the agent contract or select a protocol version reported by help or project doctor.",
  }),
});

const ALIASES = Object.freeze({
  INVALID_JSON: "INVALID_REQUEST",
  INVALID_USAGE: "INVALID_REQUEST",
  PROTOCOL_TYPE_MISMATCH: "INVALID_REQUEST",
  UNKNOWN_PROTOCOL_TYPE: "INVALID_REQUEST",
  RUN_NOT_FOUND: "NOT_FOUND",
  AUTH_MARKER_NOT_CONFIGURED: "CAPABILITY_UNAVAILABLE",
  AUTH_MARKER_NOT_FOUND: "CAPABILITY_UNAVAILABLE",
  AUTH_SESSION_CAPABILITY_UNAVAILABLE: "CAPABILITY_UNAVAILABLE",
  AUTH_SESSION_NOT_CONFIGURED: "CAPABILITY_UNAVAILABLE",
  AUTH_SESSION_REVISION_CONFLICT: "CAPABILITY_UNAVAILABLE",
  AUTH_SESSION_STALE: "CAPABILITY_UNAVAILABLE",
});

export const AGENT_PROTOCOL_ERROR_CODES = Object.freeze(Object.keys(POLICY));

export function agentProtocolErrorCode(code) {
  if (Object.hasOwn(POLICY, code)) return code;
  return ALIASES[code] ?? "INTERNAL_ERROR";
}

export function agentRecoveryPolicy(code) {
  return POLICY[agentProtocolErrorCode(code)];
}

const RECOVERY_ACTIONS = Object.freeze({
  INVALID_REQUEST: { id: "inspect-and-rebuild", automatic: false, allowedCommands: ["agent.inspect"] },
  VALIDATION_FAILED: { id: "inspect-and-rebuild", automatic: false, allowedCommands: ["agent.inspect"] },
  REVISION_CONFLICT: { id: "inspect-and-rebuild", automatic: true, allowedCommands: ["agent.inspect"] },
  IDEMPOTENCY_CONFLICT: { id: "stop-and-report", automatic: false, allowedCommands: ["agent.inspect"] },
  ILLEGAL_TRANSITION: { id: "inspect-and-rebuild", automatic: false, allowedCommands: ["agent.inspect"] },
  CAPABILITY_UNAVAILABLE: {
    id: "record-capability-gap",
    automatic: false,
    allowedCommands: ["agent.inspect", "agent.capabilities"],
  },
  LOCAL_DOGFOOD_SCOPE_INVALID: { id: "stop-and-report", automatic: false, allowedCommands: ["agent.inspect"] },
  RUN_OWNED: { id: "wait-for-owner-or-handoff", automatic: false, allowedCommands: ["agent.inspect"] },
  APPROVAL_REQUIRED: { id: "stop-and-report", automatic: false, allowedCommands: ["agent.inspect"] },
  NOT_FOUND: { id: "stop-and-report", automatic: false, allowedCommands: [] },
  LEASE_EXPIRED: {
    id: "inspect-and-reconcile",
    automatic: false,
    allowedCommands: ["agent.inspect", "agent.reconcile"],
  },
  RECONCILIATION_REQUIRED: {
    id: "inspect-and-reconcile",
    automatic: false,
    allowedCommands: ["agent.inspect", "agent.reconcile"],
  },
  INTERNAL_ERROR: { id: "stop-and-report", automatic: false, allowedCommands: ["agent.inspect"] },
  PROTOCOL_VERSION_UNSUPPORTED: { id: "stop-and-report", automatic: false, allowedCommands: [] },
});

export function agentRecoveryAction(code) {
  const authenticationFailure = typeof code === "string" && code.startsWith("AUTH_");
  const action = authenticationFailure
    ? {
        id: "restore-authentication",
        automatic: false,
        allowedCommands: ["agent.inspect", "agent.authentication.verify"],
      }
    : RECOVERY_ACTIONS[agentProtocolErrorCode(code)];
  return Object.freeze({
    ...action,
    allowedCommands: Object.freeze([...action.allowedCommands]),
    preserveRequestId: false,
  });
}
