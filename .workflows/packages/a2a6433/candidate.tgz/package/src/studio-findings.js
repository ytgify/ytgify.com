import { FindingRelationStore } from "./finding-relations.js";
import { verifyFindingResolution } from "./finding-resolution-store.js";
import { verifyFindingVerificationContract } from "./finding-verification-contracts.js";
import { sha256 } from "./stable-json.js";
import { createStudioProjectionContext, projectStudioReport } from "./studio-projection.js";

function integrityFromError(error) {
  if (["ENOENT", "RUN_NOT_FOUND", "NOT_FOUND"].includes(error?.code)) return "missing";
  if (
    error instanceof SyntaxError ||
    /(?:CORRUPT|UNSAFE|VALIDATION_FAILED|INVALID_FINDING_ID|FINDING_ID_MISMATCH|CONTRACT_HASH_MISMATCH)/.test(
      error?.code ?? "",
    )
  )
    return "corrupt";
  return "stale";
}

function sameStep(record, run) {
  const step = run.workflow?.steps?.find((item) => item.id === record.step.id);
  return (
    step &&
    sha256(record.step) === sha256({ id: step.id, name: step.name, action: step.action, expected: step.expected })
  );
}

async function projectResolution(runStore, resolutionStore, finding, contract) {
  if (!resolutionStore) return null;
  let ids;
  try {
    ids = await resolutionStore.listResolutionIds(finding.workflowId, finding.findingId);
  } catch (error) {
    return { state: "unavailable", integrity: integrityFromError(error) };
  }
  const resolutions = await Promise.all(
    ids.map(async (resolutionId) => {
      try {
        const record = await resolutionStore.readResolution(finding.workflowId, finding.findingId, resolutionId);
        const integrity = await verifyFindingResolution(runStore, finding, record, { contract });
        return {
          resolutionId,
          status: record.status,
          state: integrity === "verified" ? "verified" : "reopened",
          integrity,
          fix: structuredClone(record.fix),
          source: structuredClone(record.source),
          createdAt: record.createdAt,
          verification: record.verification.map((proof) => ({
            platform: proof.platform,
            runId: proof.runId,
            reportHash: proof.reportHash,
            effectiveHash: proof.effectiveHash,
            completedAt: proof.completedAt,
            evidence: proof.evidence.map((artifact) => ({
              ...structuredClone(artifact),
              integrity,
              url: `/api/runs/${encodeURIComponent(proof.runId)}/artifacts/${encodeURIComponent(artifact.artifactId)}`,
            })),
          })),
          verificationKind:
            record.schema === "agent-workflow-finding-resolution/v2" ? "finding-specific" : "canonical-only",
          correction: record.correction ? structuredClone(record.correction) : null,
        };
      } catch (error) {
        return { resolutionId, state: "reopened", integrity: integrityFromError(error) };
      }
    }),
  );
  resolutions.sort(
    (left, right) =>
      Number(right.integrity === "verified") - Number(left.integrity === "verified") ||
      String(right.createdAt ?? "").localeCompare(String(left.createdAt ?? "")) ||
      left.resolutionId.localeCompare(right.resolutionId),
  );
  return resolutions[0] ?? null;
}

async function projectContract(contractStore, record) {
  if (!contractStore) return { kind: "correction-not-recorded", message: "Correction criteria not recorded" };
  try {
    const contract = await contractStore.readContract(record.workflowId, record.findingId);
    verifyFindingVerificationContract(record, contract);
    return {
      kind: "finding-specific",
      contractHash: contract.contractHash,
      findingHash: contract.findingHash,
      scope: structuredClone(contract.scope),
      provenance: structuredClone(contract.provenance),
      criteria: structuredClone(contract.criteria),
      integrity: "verified",
    };
  } catch (error) {
    if (error?.code === "ENOENT")
      return { kind: "correction-not-recorded", message: "Correction criteria not recorded" };
    return {
      kind: "correction-unavailable",
      message: "Correction criteria unavailable",
      integrity: integrityFromError(error),
    };
  }
}

async function projectFinding(runStore, resolutionStore, contractStore, record, context) {
  let run;
  let report;
  let integrity = "verified";
  try {
    [run, report] = await Promise.all([
      runStore.readRun(record.runId),
      projectStudioReport(runStore, record.runId, context, { skipPerspective: true }),
    ]);
    const reportStep = report.steps.find((step) => step.id === record.step.id);
    const note = reportStep?.notes?.[record.source.noteIndex];
    const evidence = new Map(reportStep?.evidence.map((item) => [item.artifactId, item]) ?? []);
    const sourceMatches =
      report.workflow.id === record.workflowId &&
      report.platform === record.platform &&
      note?.kind === record.source.kind &&
      note?.text === record.source.text &&
      sameStep(record, run) &&
      sha256(report) === record.source.reportHash;
    const evidenceMatches = record.evidence.every((item) => {
      const current = evidence.get(item.artifactId);
      return (
        current?.contentHash === item.contentHash &&
        current?.checkpoint === item.checkpoint &&
        current?.integrity === "verified"
      );
    });
    if (!sourceMatches || !evidenceMatches) integrity = "stale";
  } catch (error) {
    integrity = integrityFromError(error);
  }
  const verificationContract = await projectContract(contractStore, record);
  let rawContract;
  if (verificationContract.kind === "finding-specific") {
    try {
      rawContract = await contractStore.readContract(record.workflowId, record.findingId);
    } catch {}
  }
  const resolution = await projectResolution(runStore, resolutionStore, record, rawContract);
  return {
    findingId: record.findingId,
    workflowId: record.workflowId,
    workflowRevision: record.workflowRevision,
    runId: record.runId,
    evaluationGroupId: record.evaluationGroupId ?? null,
    platform: record.platform,
    step: structuredClone(record.step),
    source: structuredClone(record.source),
    lens: structuredClone(record.lens),
    severity: record.severity,
    status: resolution?.integrity === "verified" ? "verified-resolved" : record.status,
    title: record.title,
    summary: record.summary,
    recommendation: record.recommendation,
    createdAt: record.createdAt,
    integrity,
    evidence: record.evidence.map((item) => ({
      ...structuredClone(item),
      integrity: report
        ? (report.steps
            .find((step) => step.id === record.step.id)
            ?.evidence.find((artifact) => artifact.artifactId === item.artifactId)?.integrity ?? "missing")
        : "missing",
      url: `/api/runs/${encodeURIComponent(record.runId)}/artifacts/${encodeURIComponent(item.artifactId)}`,
    })),
    handoff: {
      reproduce: record.step.action,
      inspect: record.summary,
      change: record.recommendation,
      canonicalChecks: structuredClone(record.step.expected),
      verify: verificationContract,
    },
    resolution,
  };
}

export async function projectStudioFindings(
  runStore,
  findingStore,
  workflowId,
  resolutionStore,
  contractStore,
  context = null,
) {
  const requestContext = context ?? createStudioProjectionContext(runStore);
  const scopedRunStore = requestContext.runStore;
  let ids;
  try {
    ids = await findingStore.listFindingIds(workflowId);
  } catch (error) {
    return {
      findings: [],
      candidateRepair: { status: "unavailable", candidateRevision: null, findingCount: 0 },
      summary: {
        status: "unavailable",
        open: null,
        reopened: null,
        resolved: null,
        degraded: null,
        unavailable: null,
      },
      sourceIntegrity: integrityFromError(error),
    };
  }
  const findings = await Promise.all(
    ids.map(async (findingId) => {
      try {
        return await projectFinding(
          scopedRunStore,
          resolutionStore,
          contractStore,
          await findingStore.readFinding(workflowId, findingId),
          requestContext,
        );
      } catch (error) {
        return { findingId, workflowId, integrity: integrityFromError(error) };
      }
    }),
  );
  const relationStore = scopedRunStore.root
    ? new FindingRelationStore(scopedRunStore.root, { registry: scopedRunStore.registry })
    : null;
  for (const finding of findings) {
    if (finding.integrity !== "verified") continue;
    try {
      const relations = relationStore ? await relationStore.listRelations(workflowId, finding.findingId) : [];
      finding.relations = relations.map((relation) => ({
        ...relation,
        integrity: relation.findingIds.every((id) =>
          findings.some((peer) => peer.findingId === id && peer.integrity === "verified"),
        )
          ? "verified"
          : "unavailable",
      }));
    } catch {
      finding.relations = [];
      finding.relationsIntegrity = "unavailable";
    }
  }
  findings.sort(
    (left, right) =>
      Number(right.status === "open") - Number(left.status === "open") ||
      String(right.createdAt ?? "").localeCompare(String(left.createdAt ?? "")) ||
      left.findingId.localeCompare(right.findingId),
  );
  const open = findings.filter((item) => item.status === "open");
  const resolved = findings.filter((item) => item.status === "verified-resolved");
  const reopened = open.filter((item) => item.resolution?.state === "reopened");
  const unavailable = findings.filter(
    (item) => !item.status || item.integrity !== "verified" || item.resolution?.state === "unavailable",
  );
  const verifiedCandidateRevisions = new Set(
    resolved.map((item) => item.resolution?.fix?.candidateRevision).filter(Number.isInteger),
  );
  const verifiedSourceBytesHashes = new Set(
    resolved.map((item) => item.resolution?.fix?.sourceBytesHash).filter(Boolean),
  );
  const verifiedContentHashes = new Set(resolved.map((item) => item.resolution?.fix?.contentHash).filter(Boolean));
  const oneVerifiedCandidate =
    verifiedCandidateRevisions.size === 1 && verifiedSourceBytesHashes.size === 1 && verifiedContentHashes.size === 1;
  const candidateRepair =
    findings.length === 0
      ? { status: "none", candidateRevision: null, findingCount: 0 }
      : resolved.length === findings.length && unavailable.length === 0 && oneVerifiedCandidate
        ? {
            status: "verified",
            candidateRevision: [...verifiedCandidateRevisions][0],
            sourceBytesHash: [...verifiedSourceBytesHashes][0],
            contentHash: [...verifiedContentHashes][0],
            findingCount: resolved.length,
          }
        : resolved.length > 0
          ? {
              status: "finding-scoped",
              candidateRevision: oneVerifiedCandidate ? [...verifiedCandidateRevisions][0] : null,
              findingCount: resolved.length,
            }
          : { status: unavailable.length > 0 ? "unavailable" : "none", candidateRevision: null, findingCount: 0 };
  return {
    findings,
    candidateRepair,
    summary: {
      status: "available",
      open: open.length,
      reopened: reopened.length,
      resolved: resolved.length,
      degraded: findings.filter(
        (item) => item.integrity !== "verified" || (item.resolution && item.resolution.integrity !== "verified"),
      ).length,
      unavailable: unavailable.length,
    },
    sourceIntegrity: "verified",
  };
}
