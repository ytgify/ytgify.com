import { constants } from "node:fs";
import { lstat, open, rename, unlink } from "node:fs/promises";
import { randomUUID } from "node:crypto";
import { join } from "node:path";
import { isDeepStrictEqual } from "node:util";

import { projectExploration } from "./exploration-proposals.js";
import { RunControlStore } from "./run-control-store.js";
import { sha256 } from "./stable-json.js";
import { StudioMutationError } from "./studio-mutation-security.js";
import { hasSupervisedFixtureSource, projectSupervisedFixtureNeed } from "./supervised-fixture-needs.js";
import { hasYtgifyFixtureSource, projectYtgifyFixtureNeed } from "./ytgify-fixture-needs.js";

const filename = "fixture-need-decisions.json";
const empty = () => ({ schema: "agent-workflow-fixture-need-decisions/v1", revision: 0, decisions: [], history: [] });
const fail = (status, code) => {
  throw new StudioMutationError(status, code);
};
const decisionKey = (runId, needId) => `${runId}:${needId}`;

async function safeRoot(store) {
  const entry = await lstat(store.root);
  if (!entry.isDirectory() || entry.isSymbolicLink()) fail(503, "FIXTURE_NEED_STORE_UNAVAILABLE");
}

function validateDocument(document, registry) {
  registry.validate("fixtureNeedDecisions", document);
  if (document.history.length !== document.revision) fail(503, "FIXTURE_NEED_AUDIT_INVALID");
  const latest = new Map();
  const keys = new Set();
  for (const [index, entry] of document.history.entries()) {
    if (entry.revision !== index || keys.has(entry.idempotencyKey)) fail(503, "FIXTURE_NEED_AUDIT_INVALID");
    keys.add(entry.idempotencyKey);
    latest.set(decisionKey(entry.decision.runId, entry.decision.needId), entry.decision);
  }
  if (latest.size !== document.decisions.length) fail(503, "FIXTURE_NEED_AUDIT_INVALID");
  for (const decision of document.decisions) {
    if (!isDeepStrictEqual(latest.get(decisionKey(decision.runId, decision.needId)), decision)) {
      fail(503, "FIXTURE_NEED_AUDIT_INVALID");
    }
  }
  return document;
}

async function readFixtureNeedDecisions(store, registry) {
  await safeRoot(store);
  let file;
  try {
    file = await open(join(store.root, filename), constants.O_RDONLY | constants.O_NOFOLLOW);
    const stat = await file.stat();
    if (!stat.isFile() || stat.size > 1024 * 1024) fail(503, "FIXTURE_NEED_STORE_INVALID");
    return validateDocument(JSON.parse(await file.readFile("utf8")), registry);
  } catch (error) {
    if (error.code === "ENOENT") return empty();
    if (error instanceof SyntaxError || error.code === "VALIDATION_FAILED") fail(503, "FIXTURE_NEED_STORE_INVALID");
    throw error;
  } finally {
    await file?.close();
  }
}

function projectDecisions(review, document, runId) {
  return {
    revision: document.revision,
    needs: review.fixtureNeeds.map((need) => {
      const candidateHash = sha256(need);
      const saved = document.decisions.find((item) => item.runId === runId && item.needId === need.id);
      return {
        ...need,
        candidateHash,
        decision: saved
          ? saved.candidateHash === candidateHash
            ? { status: saved.status, reason: saved.reason, recordedAt: saved.recordedAt, actor: saved.actor }
            : { status: "stale", reason: saved.reason, recordedAt: saved.recordedAt, actor: saved.actor }
          : null,
      };
    }),
  };
}

/** Re-verify the source on every read; decisions never mutate exploration or App Map truth. */
export async function readFixtureNeedReview(store, registry, runId) {
  const review = await sourceReview(store, runId);
  const document = await readFixtureNeedDecisions(store, registry);
  return projectDecisions(review, document, runId);
}

async function sourceReview(store, runId) {
  const [supervised, ytgify] = await Promise.all([
    hasSupervisedFixtureSource(store, runId),
    hasYtgifyFixtureSource(store, runId),
  ]);
  if (supervised && ytgify) fail(503, "FIXTURE_NEED_SOURCE_AMBIGUOUS");
  if (supervised) return projectSupervisedFixtureNeed(store, runId);
  if (ytgify) return projectYtgifyFixtureNeed(store, runId);
  return projectExploration(store, runId);
}

function validateRequest(runId, request) {
  const fields = ["needId", "candidateHash", "status", "reason", "expectedRevision", "idempotencyKey"];
  if (
    !/^run_[A-Za-z0-9_-]+$/u.test(runId) ||
    !request ||
    typeof request !== "object" ||
    Array.isArray(request) ||
    Object.keys(request).some((field) => !fields.includes(field)) ||
    fields.some((field) => !Object.hasOwn(request, field)) ||
    !/^fixture_need_[A-Za-z0-9_-]+$/u.test(request.needId) ||
    !/^sha256:[a-f0-9]{64}$/u.test(request.candidateHash) ||
    !new Set(["accepted", "rejected", "needs-information"]).has(request.status) ||
    typeof request.reason !== "string" ||
    !request.reason.trim() ||
    request.reason !== request.reason.trim() ||
    request.reason.length > 2000 ||
    !Number.isSafeInteger(request.expectedRevision) ||
    request.expectedRevision < 0 ||
    !/^req_[A-Za-z0-9_-]{4,196}$/u.test(request.idempotencyKey)
  ) {
    fail(400, "FIXTURE_NEED_DECISION_INVALID");
  }
}

export async function decideFixtureNeed(
  store,
  registry,
  runId,
  request,
  { now = () => new Date(), channel = "direct" } = {},
) {
  validateRequest(runId, request);
  if (!new Set(["cli", "studio", "direct"]).has(channel)) fail(400, "FIXTURE_NEED_DECISION_INVALID");
  await safeRoot(store);
  // The store's fixture lock recovers dead owners while serializing live writers.
  // Use a lock instance rooted at the same store so source projections can keep their supplied store.
  try {
    return await new RunControlStore(store.root).withExclusiveFixtures(async () => {
      let temporary;
      try {
        const document = await readFixtureNeedDecisions(store, registry);
        const requestHash = sha256({ runId, ...request });
        const replay = document.history.find((entry) => entry.idempotencyKey === request.idempotencyKey);
        if (replay) {
          if (replay.requestHash !== requestHash) fail(409, "FIXTURE_NEED_IDEMPOTENCY_CONFLICT");
          return { ...(await readFixtureNeedReview(store, registry, runId)), replay: true };
        }
        if (document.revision !== request.expectedRevision) fail(409, "FIXTURE_NEED_REVISION_CONFLICT");
        const review = await sourceReview(store, runId);
        const candidate = review.fixtureNeeds.find((need) => need.id === request.needId);
        if (!candidate || sha256(candidate) !== request.candidateHash) fail(409, "FIXTURE_NEED_CANDIDATE_STALE");
        const decision = {
          runId,
          needId: request.needId,
          candidateHash: request.candidateHash,
          status: request.status,
          reason: request.reason,
          recordedAt: now().toISOString(),
          actor: { kind: "local-operator", channel },
        };
        const next = {
          schema: document.schema,
          revision: document.revision + 1,
          decisions: [
            ...document.decisions.filter(
              (item) => decisionKey(item.runId, item.needId) !== decisionKey(runId, request.needId),
            ),
            decision,
          ],
          history: [
            ...document.history,
            { revision: document.revision, idempotencyKey: request.idempotencyKey, requestHash, decision },
          ],
        };
        validateDocument(next, registry);
        temporary = join(store.root, `.fixture-need-decisions-${randomUUID()}.tmp`);
        const output = await open(temporary, "wx", 0o600);
        try {
          await output.writeFile(`${JSON.stringify(next, null, 2)}\n`);
          await output.sync();
        } finally {
          await output.close();
        }
        await rename(temporary, join(store.root, filename));
        return { ...projectDecisions(review, next, runId), replay: false };
      } finally {
        if (temporary) await unlink(temporary).catch(() => {});
      }
    });
  } catch (error) {
    if (error.code === "RUN_STORE_LOCKED") fail(409, "FIXTURE_NEED_DECISION_BUSY");
    throw error;
  }
}
