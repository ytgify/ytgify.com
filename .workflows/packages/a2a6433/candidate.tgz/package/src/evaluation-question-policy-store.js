import { randomUUID } from "node:crypto";
import { mkdir, readFile, rename, unlink, writeFile } from "node:fs/promises";
import { dirname, join, resolve } from "node:path";

import { WorkflowError } from "./errors.js";
import { assertSafeProjectPath } from "./project-path-safety.js";
import { sha256 } from "./stable-json.js";

const DEFAULT_ALLOWANCES = Object.freeze({ optionalQuestionsPerStep: 2, optionalQuestionsPerRun: 16 });

function fail(code, message, details = {}, exitCode = 3) {
  throw new WorkflowError(code, message, { details, exitCode });
}

export class EvaluationQuestionPolicyStore {
  #queues = new Map();

  constructor(root, { registry, now = () => new Date() } = {}) {
    this.root = resolve(root);
    this.registry = registry;
    this.now = now;
  }

  path(projectId) {
    if (!/^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$/u.test(projectId)) {
      fail("QUESTION_POLICY_PROJECT_INVALID", "Question policy project ID is invalid");
    }
    return join(this.root, "question-policies", `${projectId}.json`);
  }

  queued(projectId, operation) {
    const prior = this.#queues.get(projectId) ?? Promise.resolve();
    const current = prior.catch(() => {}).then(operation);
    this.#queues.set(projectId, current);
    return current.finally(() => {
      if (this.#queues.get(projectId) === current) this.#queues.delete(projectId);
    });
  }

  async read(projectId) {
    const path = this.path(projectId);
    await assertSafeProjectPath(this.root, path, "Evaluation question policy", {
      finalType: "file",
      allowMissing: true,
    });
    try {
      const record = JSON.parse(await readFile(path, "utf8"));
      this.registry.validate("evaluationQuestionPolicy", record);
      if (record.projectId !== projectId) fail("QUESTION_POLICY_PROJECT_MISMATCH", "Question policy project mismatch");
      return { ...record, recorded: true };
    } catch (error) {
      if (error.code === "ENOENT") {
        return {
          schema: "agent-workflow-question-policy/v1",
          revision: 0,
          projectId,
          depth: "balanced",
          ...DEFAULT_ALLOWANCES,
          updatedAt: null,
          recorded: false,
        };
      }
      if (error instanceof SyntaxError || error.code === "VALIDATION_FAILED") {
        fail("QUESTION_POLICY_CORRUPT", "Evaluation question policy is invalid");
      }
      throw error;
    }
  }

  set(projectId, expectedRevision, depth, allowances = {}, { idempotencyKey } = {}) {
    return this.queued(projectId, async () => {
      const current = await this.read(projectId);
      const inputHash = sha256({
        expectedRevision,
        depth,
        optionalQuestionsPerStep: allowances.optionalQuestionsPerStep ?? current.optionalQuestionsPerStep,
        optionalQuestionsPerRun: allowances.optionalQuestionsPerRun ?? current.optionalQuestionsPerRun,
      });
      if (idempotencyKey && current.lastMutation?.idempotencyKey === idempotencyKey) {
        if (current.lastMutation.inputHash !== inputHash)
          fail("QUESTION_POLICY_IDEMPOTENCY_CONFLICT", "Question policy idempotency key was reused", {}, 6);
        return current;
      }
      if (current.revision !== expectedRevision) {
        fail(
          "QUESTION_POLICY_REVISION_CONFLICT",
          "Evaluation question policy changed; reload and retry",
          { expectedRevision, actualRevision: current.revision },
          6,
        );
      }
      const record = {
        schema: "agent-workflow-question-policy/v1",
        revision: current.revision + 1,
        projectId,
        depth,
        optionalQuestionsPerStep: allowances.optionalQuestionsPerStep ?? current.optionalQuestionsPerStep,
        optionalQuestionsPerRun: allowances.optionalQuestionsPerRun ?? current.optionalQuestionsPerRun,
        updatedAt: new Date(this.now()).toISOString(),
        ...(idempotencyKey ? { lastMutation: { idempotencyKey, inputHash } } : {}),
      };
      this.registry.validate("evaluationQuestionPolicy", record);
      const path = this.path(projectId);
      const temporary = `${path}.${randomUUID()}.tmp`;
      await assertSafeProjectPath(this.root, path, "Evaluation question policy", {
        finalType: "file",
        allowMissing: true,
      });
      await mkdir(dirname(path), { recursive: true });
      await assertSafeProjectPath(this.root, dirname(path), "Evaluation question policy directory", {
        finalType: "directory",
        allowMissing: false,
      });
      await assertSafeProjectPath(this.root, temporary, "Evaluation question policy temporary file", {
        finalType: "file",
        allowMissing: true,
      });
      let published = false;
      try {
        await writeFile(temporary, `${JSON.stringify(record, null, 2)}\n`, { flag: "wx", mode: 0o600 });
        await rename(temporary, path);
        published = true;
      } finally {
        if (!published) await unlink(temporary).catch(() => {});
      }
      return { ...record, recorded: true };
    });
  }
}
