import { randomUUID as nodeRandomUUID } from "node:crypto";
import { mkdir, readFile, rename, unlink, writeFile } from "node:fs/promises";
import { dirname, join, resolve } from "node:path";

import { WorkflowError } from "./errors.js";
import { assertSafeProjectPath } from "./project-path-safety.js";
import { sha256 } from "./stable-json.js";

const ID = /^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$/u;
const ENVIRONMENTS = new Set(["local", "preview", "staging", "production", "other"]);

function authError(code, message, details = {}) {
  return new WorkflowError(code, message, { exitCode: code === "AUTH_SESSION_REVISION_CONFLICT" ? 6 : 3, details });
}

function normalizedOrigin(value) {
  let parsed;
  try {
    parsed = new URL(value);
  } catch {
    return null;
  }
  if (
    !["http:", "https:"].includes(parsed.protocol) ||
    parsed.username ||
    parsed.password ||
    parsed.hash ||
    parsed.search ||
    !["", "/"].includes(parsed.pathname)
  ) {
    return null;
  }
  return value;
}

function assertScope(scope) {
  if (
    !scope ||
    typeof scope !== "object" ||
    Array.isArray(scope) ||
    !ID.test(scope.projectId ?? "") ||
    !ID.test(scope.targetId ?? "") ||
    !ENVIRONMENTS.has(scope.environment) ||
    !normalizedOrigin(scope.origin)
  ) {
    throw authError("AUTH_SESSION_STALE", "Authentication session scope is invalid");
  }
  return scope;
}

function exactScope(record, scope) {
  return ["projectId", "targetId", "environment", "origin"].every((field) => record[field] === scope[field]);
}

function exactBrowserProfile(record) {
  const opaqueId = record.sessionId.slice("authsession_".length);
  return record.browserProfileId === `workflows-${record.projectId}-${record.targetId}-${opaqueId}`;
}

function markerHashMatches(record) {
  return record.marker === undefined || sha256(record.marker) === record.markerHash;
}

function assertRevision(record, expectedRevision) {
  if (record.revision !== expectedRevision) {
    throw new WorkflowError("AUTH_SESSION_REVISION_CONFLICT", "Authentication session changed; reload and retry", {
      exitCode: 6,
      details: { expectedRevision, actualRevision: record.revision },
    });
  }
}

function timestamp(now) {
  const value = now();
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.valueOf())) throw authError("AUTH_SESSION_STALE", "Authentication session clock is invalid");
  return date.toISOString();
}

/** Derive the exact authenticated target identity from resolved project truth. */
export function authSessionScope(projectContext, applicationTarget) {
  return {
    projectId: projectContext?.project?.id,
    targetId: applicationTarget?.id,
    environment: applicationTarget?.environment,
    origin: applicationTarget?.baseUrl,
  };
}

/** Pin an opaque generation of a Studio-owned session without exposing its local identifiers. */
export function authSessionBindingHash(record) {
  if (
    !/^authsession_[A-Za-z0-9_-]+$/u.test(record?.sessionId ?? "") ||
    !/^workflows-[A-Za-z0-9._-]+$/u.test(record?.browserProfileId ?? "")
  ) {
    throw authError("AUTH_SESSION_STALE", "Authentication session binding is invalid");
  }
  return sha256({ sessionId: record.sessionId, browserProfileId: record.browserProfileId });
}

/** Persist sanitized browser-session coordination metadata beneath a local-store root. */
export class AuthSessionStore {
  #queues = new Map();

  constructor(root, { registry, now = () => new Date(), randomUUID = nodeRandomUUID } = {}) {
    this.root = resolve(root);
    this.sessionsRoot = join(this.root, "auth-sessions");
    this.registry = registry;
    this.now = now;
    this.randomUUID = randomUUID;
  }

  scopeKey(scope) {
    assertScope(scope);
    return `${scope.projectId}/${scope.targetId}`;
  }

  recordPath(scope) {
    return join(this.sessionsRoot, scope.projectId, `${scope.targetId}.json`);
  }

  validate(value) {
    if (!this.registry) {
      throw new WorkflowError("SCHEMA_NOT_LOADED", "Authentication session schema is not loaded", { exitCode: 1 });
    }
    return this.registry.validate("authSession", value);
  }

  async safe(path, finalType, allowMissing = true) {
    await assertSafeProjectPath(this.root, path, "Authentication session record", {
      finalType,
      allowMissing,
    });
  }

  async replaceRecord(path, value) {
    const temporary = `${path}.${this.randomUUID()}.tmp`;
    await this.safe(path, "file", true);
    await this.safe(temporary, "file", true);
    let replaced = false;
    try {
      await writeFile(temporary, `${JSON.stringify(value, null, 2)}\n`, {
        flag: "wx",
        mode: 0o600,
      });
      await rename(temporary, path);
      replaced = true;
    } finally {
      if (!replaced) await unlink(temporary).catch(() => {});
    }
  }

  queued(scope, operation) {
    const key = this.scopeKey(scope);
    const previous = this.#queues.get(key) ?? Promise.resolve();
    const current = previous.catch(() => {}).then(operation);
    this.#queues.set(key, current);
    return current.finally(() => {
      if (this.#queues.get(key) === current) this.#queues.delete(key);
    });
  }

  async readRecord(scope) {
    assertScope(scope);
    const path = this.recordPath(scope);
    await this.safe(path, "file", true);
    let value;
    try {
      value = JSON.parse(await readFile(path, "utf8"));
      this.validate(value);
    } catch (error) {
      if (error.code === "ENOENT") {
        throw authError("AUTH_SESSION_NOT_CONFIGURED", "Authentication session is not configured");
      }
      if (error instanceof SyntaxError || error.code === "VALIDATION_FAILED") {
        throw authError("AUTH_SESSION_STALE", "Authentication session metadata is invalid");
      }
      throw error;
    }
    if (!exactScope(value, scope) || !exactBrowserProfile(value) || !markerHashMatches(value)) {
      throw authError("AUTH_SESSION_STALE", "Authentication session does not match the configured target");
    }
    return value;
  }

  async read(scope) {
    return this.readRecord(scope);
  }

  async readForRecovery(scope) {
    assertScope(scope);
    const recoveryScope = { ...scope };
    const path = this.recordPath(scope);
    await this.safe(path, "file", true);
    let value;
    try {
      value = JSON.parse(await readFile(path, "utf8"));
      this.validate(value);
    } catch (error) {
      if (error.code === "ENOENT")
        throw authError("AUTH_SESSION_NOT_CONFIGURED", "Authentication session is not configured");
      if (error instanceof SyntaxError || error.code === "VALIDATION_FAILED") {
        throw authError("AUTH_SESSION_STALE", "Authentication session metadata is invalid");
      }
      throw error;
    }
    recoveryScope.environment = value.environment;
    recoveryScope.origin = value.origin;
    if (
      value.projectId !== scope.projectId ||
      value.targetId !== scope.targetId ||
      !exactScope(value, recoveryScope) ||
      !exactBrowserProfile(value) ||
      !markerHashMatches(value)
    ) {
      throw authError("AUTH_SESSION_STALE", "Authentication session cannot be recovered safely");
    }
    return value;
  }

  async provision(scope) {
    return this.queued(scope, async () => {
      try {
        return await this.readRecord(scope);
      } catch (error) {
        if (error.code !== "AUTH_SESSION_NOT_CONFIGURED") throw error;
      }

      const path = this.recordPath(scope);
      await this.safe(path, "file", true);
      await mkdir(dirname(path), { recursive: true });
      await this.safe(dirname(path), "directory", false);
      const createdAt = timestamp(this.now);
      const opaqueId = this.randomUUID();
      const record = this.validate({
        schema: "agent-workflow-auth-session/v1",
        revision: 1,
        sessionId: `authsession_${opaqueId}`,
        projectId: scope.projectId,
        targetId: scope.targetId,
        environment: scope.environment,
        origin: scope.origin,
        browserProfileId: `workflows-${scope.projectId}-${scope.targetId}-${opaqueId}`,
        state: "setup",
        createdAt,
        updatedAt: createdAt,
      });
      await this.replaceRecord(path, record);
      return record;
    });
  }

  mutate(scope, expectedRevision, transform) {
    return this.queued(scope, async () => {
      const current = await this.readRecord(scope);
      assertRevision(current, expectedRevision);
      const updatedAt = timestamp(this.now);
      const next = this.validate({
        ...current,
        ...transform(current, updatedAt),
        revision: current.revision + 1,
        updatedAt,
      });
      await this.replaceRecord(this.recordPath(scope), next);
      return next;
    });
  }

  async confirmMarker(scope, expectedRevision, marker) {
    return this.mutate(scope, expectedRevision, (_current, updatedAt) => ({
      marker: structuredClone(marker),
      markerHash: sha256(marker),
      state: "ready",
      lastVerifiedAt: updatedAt,
    }));
  }

  async recordVerification(scope, expectedRevision, outcome) {
    if (!["verified", "needs-login"].includes(outcome)) {
      throw authError("AUTH_SESSION_STALE", "Authentication verification outcome is invalid");
    }
    return this.mutate(scope, expectedRevision, (current, updatedAt) => {
      if (!current.marker || !current.markerHash) {
        throw authError("AUTH_SESSION_STALE", "Authentication marker is not configured");
      }
      if (outcome === "verified") {
        return { state: "ready", lastVerifiedAt: updatedAt };
      }
      return { state: "needs-login" };
    });
  }

  async markClearFailed(scope, expectedRevision) {
    return this.mutate(scope, expectedRevision, () => ({ state: "clear-failed" }));
  }

  async remove(scope, expectedRevision) {
    return this.queued(scope, async () => {
      const current = await this.readRecord(scope);
      assertRevision(current, expectedRevision);
      const path = this.recordPath(scope);
      const tombstone = `${path}.${this.randomUUID()}.tombstone`;
      await this.safe(path, "file", false);
      await this.safe(tombstone, "file", true);
      await rename(path, tombstone);
      await unlink(tombstone);
    });
  }
}
