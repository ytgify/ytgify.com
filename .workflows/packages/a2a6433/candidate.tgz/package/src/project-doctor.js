import { constants } from "node:fs";
import { access, lstat, open } from "node:fs/promises";
import { isAbsolute, join, relative, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";

import { planCodexSkillInstallation } from "./codex-skill.js";
import { verifyInstalledPackage } from "./package-provenance.js";
import { inspectProjectGitSafety } from "./project-git-safety.js";
import { catalogProjectWorkflows } from "./project-workflow-catalog.js";
import { createSchemaRegistry } from "./schema-registry.js";
import { loadStudioAssets } from "./studio-assets.js";
import { projectUserSessionReadiness } from "./project-surface-snapshot.js";
import { readEvaluationRequirements } from "./evaluation-requirements.js";
import { PREFERRED_PROTOCOL_VERSION, SUPPORTED_PROTOCOL_VERSIONS } from "./protocol.js";
import { EvaluationQuestionPolicyStore } from "./evaluation-question-policy-store.js";
import { EvaluationQuestionStore } from "./evaluation-question-store.js";

const PACKAGE_NAME = "@lineagehq/workflows";
const PACKAGE_ROOT = fileURLToPath(new URL("..", import.meta.url));
const REGISTRY = "https://npm.pkg.github.com";
const CHECK_ORDER = Object.freeze([
  "runtime",
  "package-identity",
  "package-provenance",
  "studio-assets",
  "project-context",
  "workflow-catalog",
  "local-store",
  "evaluation-questions",
  "user-sessions",
  "local-git-safety",
  "codex-skill",
  "registry-mapping",
  "authentication",
  "registry-availability",
]);
const LOCAL_CHECKS = Object.freeze([
  "runtime",
  "package-identity",
  "studio-assets",
  "project-context",
  "workflow-catalog",
  "local-store",
  "user-sessions",
  "local-git-safety",
  "codex-skill",
]);
const PACKAGE_CHECKS = Object.freeze(["package-identity", "package-provenance", "studio-assets"]);
const REGISTRY_CHECKS = Object.freeze(["registry-mapping", "authentication", "registry-availability"]);

function check(id, status, summary, details = {}) {
  return { id, status, summary, details };
}

function unavailable(id, summary) {
  return check(id, "unavailable", summary);
}

function readiness(checks, ids, { requested = true } = {}) {
  const selected = ids.map((id) => checks.find((item) => item.id === id));
  if (!requested) return { status: "not-requested", checks: ids };
  const status = selected.every((item) => ["ready", "not-applicable"].includes(item?.status)) ? "ready" : "not-ready";
  return { status, checks: ids };
}

async function guarded(id, summary, inspect) {
  try {
    return await inspect();
  } catch {
    return unavailable(id, summary);
  }
}

async function readJsonFile(path) {
  const entry = await lstat(path);
  if (!entry.isFile() || entry.isSymbolicLink()) throw new Error("unsafe file");
  const handle = await open(path, constants.O_RDONLY | (constants.O_NOFOLLOW ?? 0));
  try {
    const opened = await handle.stat();
    if (!opened.isFile() || opened.dev !== entry.dev || opened.ino !== entry.ino) throw new Error("changed file");
    return JSON.parse(await handle.readFile("utf8"));
  } finally {
    await handle.close();
  }
}

function versionTuple(value) {
  const match = /^v?(\d+)\.(\d+)\.(\d+)$/u.exec(value);
  return match ? match.slice(1).map(Number) : null;
}

function minimumEngine(value) {
  const match = /^>=(\d+)\.(\d+)\.(\d+)$/u.exec(value);
  return match ? match.slice(1).map(Number) : null;
}

function atLeast(actual, expected) {
  for (let index = 0; index < 3; index += 1) {
    if (actual[index] !== expected[index]) return actual[index] > expected[index];
  }
  return true;
}

function runtimeCheck(packageInfo, nodeVersion) {
  const actual = versionTuple(nodeVersion);
  const expected = minimumEngine(packageInfo?.engines?.node);
  if (!actual || !expected) return unavailable("runtime", "Node compatibility could not be verified");
  const ready = atLeast(actual, expected);
  return check(
    "runtime",
    ready ? "ready" : "not-ready",
    ready ? "Node runtime is compatible" : "Node runtime is incompatible",
    {
      node: `v${actual.join(".")}`,
      required: `>=${expected.join(".")}`,
    },
  );
}

function packageIdentityCheck(packageInfo) {
  const ready =
    packageInfo?.name === PACKAGE_NAME &&
    typeof packageInfo?.version === "string" &&
    /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/u.test(packageInfo.version);
  return check(
    "package-identity",
    ready ? "ready" : "not-ready",
    ready ? "Package identity is verified" : "Package identity is invalid",
    ready ? { name: packageInfo.name, version: packageInfo.version } : {},
  );
}

function installedSkillPins(plan) {
  const baseline = plan.items.find(({ kind }) => kind === "skill-baseline");
  if (baseline?.status === "unchanged") return plan.pins;
  if (baseline?.status !== "update" || typeof baseline.previousContents !== "string") return null;
  try {
    const parsed = JSON.parse(baseline.previousContents);
    return parsed.pins && typeof parsed.pins === "object" && !Array.isArray(parsed.pins) ? parsed.pins : null;
  } catch {
    return null;
  }
}

function contextPath(projectContext, logical) {
  const root = resolve(projectContext.projectRoot);
  if (
    typeof logical !== "string" ||
    logical.length === 0 ||
    isAbsolute(logical) ||
    /^[A-Za-z]:[/\\]/u.test(logical) ||
    logical.split(/[\\/]+/u).some((part) => !part || part === "..")
  ) {
    throw new Error("unsafe ProjectContext path");
  }
  const absolute = resolve(root, ...logical.split(/[\\/]+/u));
  const suffix = relative(root, absolute);
  if (suffix === ".." || suffix.startsWith(`..${sep}`) || isAbsolute(suffix)) throw new Error("escaping path");
  return { root, absolute, logical: logical.split(/\\/u).join("/") };
}

async function inspectLocalStore(projectContext) {
  const path = contextPath(projectContext, projectContext.paths.localStore);
  const rootEntry = await lstat(path.root);
  if (!rootEntry.isDirectory() || rootEntry.isSymbolicLink()) throw new Error("unsafe root");
  let cursor = path.root;
  for (const part of relative(path.root, path.absolute).split(sep).filter(Boolean)) {
    cursor = join(cursor, part);
    const entry = await lstat(cursor);
    if (entry.isSymbolicLink() || !entry.isDirectory()) throw new Error("unsafe local store");
  }
  await access(path.absolute, constants.R_OK);
  return check("local-store", "ready", "Local store is contained and readable", { path: path.logical });
}

async function inspectEvaluationQuestions(projectContext, registry) {
  if (!projectContext.project?.id) {
    return check(
      "evaluation-questions",
      "not-applicable",
      "Evaluation questions require a configured project identity",
    );
  }
  const root = contextPath(projectContext, projectContext.paths.localStore).absolute;
  const [requirements, policy, questions] = await Promise.all([
    readEvaluationRequirements(projectContext, { registry }),
    new EvaluationQuestionPolicyStore(root, { registry }).read(projectContext.project.id),
    new EvaluationQuestionStore(root, { registry }).listAllRecords(),
  ]);
  return check("evaluation-questions", "ready", "Evaluation questions and requirements are readable", {
    requirements: {
      recorded: requirements.recorded,
      count: requirements.catalog.requirements.length,
    },
    inquiryPolicy: { recorded: policy.recorded, revision: policy.revision, depth: policy.depth },
    questions: {
      verified: questions.filter((item) => item.integrity === "verified").length,
      degraded: questions.filter((item) => item.integrity === "degraded").length,
    },
  });
}

function configuredRegistry(packageInfo) {
  const registry = packageInfo?.publishConfig?.registry;
  const ready = packageInfo?.name === PACKAGE_NAME && registry === REGISTRY;
  return check(
    "registry-mapping",
    ready ? "ready" : "not-ready",
    ready ? "Package registry mapping is verified" : "Package registry mapping is invalid",
    ready ? { registry, scope: "@lineagehq" } : {},
  );
}

function authenticationCheck(environment) {
  const keys = new Set(Object.keys(environment ?? {}));
  const present = ["NODE_AUTH_TOKEN", "NPM_TOKEN", "GITHUB_TOKEN"].some((name) => keys.has(name));
  return check(
    "authentication",
    present ? "ready" : "not-ready",
    present ? "Registry authentication is present" : "Registry authentication is absent",
    { present },
  );
}

async function registryAvailabilityCheck({ checkRegistry, fetchImplementation, registryTimeoutMs }) {
  if (!checkRegistry) {
    return check("registry-availability", "skipped", "Registry availability was not requested", {
      network: "offline",
    });
  }
  const timeout =
    Number.isSafeInteger(registryTimeoutMs) && registryTimeoutMs > 0 ? Math.min(registryTimeoutMs, 5_000) : 1_000;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const response = await (fetchImplementation ?? globalThis.fetch)(REGISTRY, {
      method: "HEAD",
      redirect: "follow",
      signal: controller.signal,
    });
    const responseStatus = Number.isSafeInteger(response?.status) ? response.status : null;
    const ready = Boolean(response?.ok) || (responseStatus !== null && responseStatus >= 200 && responseStatus < 500);
    return check(
      "registry-availability",
      ready ? "ready" : "unavailable",
      ready ? "Registry is reachable" : "Registry is unavailable",
      responseStatus === null ? { requested: true } : { requested: true, responseStatus },
    );
  } catch {
    return unavailable("registry-availability", "Registry is unavailable");
  } finally {
    clearTimeout(timer);
  }
}

/** Inspect one resolved ProjectContext without changing project or package state. */
export async function inspectProjectReadiness(projectContext, options = {}) {
  const packageRoot = resolve(options.packageRoot ?? PACKAGE_ROOT);
  const packageInfo = await guarded("package-identity", "Package identity could not be verified", async () =>
    readJsonFile(join(packageRoot, "package.json")),
  );
  const manifest = packageInfo?.id ? null : packageInfo;
  const checks = [];

  checks.push(
    manifest
      ? runtimeCheck(manifest, options.nodeVersion ?? process.version)
      : unavailable("runtime", "Node compatibility could not be verified"),
  );
  checks.push(manifest ? packageIdentityCheck(manifest) : packageInfo);
  checks.push(
    await guarded("package-provenance", "Package provenance could not be verified", async () => {
      const verified = verifyInstalledPackage(packageRoot);
      return check("package-provenance", "ready", "Package provenance is verified", {
        packageDigest: verified.packageDigest,
        provenanceDigest: verified.provenanceDigest,
        studioManifestDigest: verified.studioManifestDigest,
      });
    }),
  );
  checks.push(
    await guarded("studio-assets", "Studio assets could not be verified", async () => {
      const studio = await loadStudioAssets(options.assetRoot ?? join(packageRoot, "dist", "studio-next"));
      return check("studio-assets", "ready", "Studio assets are verified", {
        assets: studio.manifest.assets.length,
        manifestDigest: studio.manifest.manifestDigest,
      });
    }),
  );

  const registry = options.registry ?? (await createSchemaRegistry());
  const contextReady = await guarded("project-context", "ProjectContext could not be verified", async () => {
    registry.validate("projectContext", projectContext);
    return check("project-context", "ready", "ProjectContext is verified", {
      mode: projectContext.resolution.mode,
      source: projectContext.resolution.source,
      configPath: projectContext.resolution.configPath,
    });
  });
  checks.push(contextReady);

  if (contextReady.status === "ready") {
    checks.push(
      await guarded("workflow-catalog", "Workflow catalog could not be verified", async () => {
        const catalog = await catalogProjectWorkflows(projectContext, { registry });
        const ready = catalog.status === "verified";
        return check(
          "workflow-catalog",
          ready ? "ready" : "not-ready",
          ready ? "Workflow catalog is verified" : "Workflow catalog is degraded",
          {
            definitionsRoot: catalog.definitionsRoot,
            workflows: catalog.workflows.length,
            issues: catalog.issues.map(({ code }) => code),
          },
        );
      }),
    );
    checks.push(
      await guarded("local-store", "Local store could not be verified", () => inspectLocalStore(projectContext)),
    );
    checks.push(
      await guarded("evaluation-questions", "Evaluation questions or requirements could not be verified", () =>
        inspectEvaluationQuestions(projectContext, registry),
      ),
    );
    checks.push(
      await guarded("user-sessions", "User-managed sessions could not be inspected", async () => {
        const result = await projectUserSessionReadiness(projectContext, {
          registry,
          authSessionStore: options.authSessionStore,
        });
        const status =
          result.sessions.length === 0
            ? "not-applicable"
            : result.sessions.every((session) => session.status === "ready")
              ? "ready"
              : "not-ready";
        return check(
          "user-sessions",
          status,
          status === "not-applicable"
            ? "No configured target requires a user-managed session"
            : status === "ready"
              ? "User-managed sessions are ready"
              : "One or more user-managed sessions need attention",
          { sessions: result.sessions },
        );
      }),
    );
    checks.push(
      await guarded("local-git-safety", "Local Git safety could not be verified", async () => {
        const result = await inspectProjectGitSafety(projectContext);
        const ready = result.status === "safe";
        return check(
          "local-git-safety",
          ready ? "ready" : "not-ready",
          ready ? "Local evidence is ignored and untracked" : "Local evidence is not Git-safe",
          { ignored: result.ignored, localStore: result.localStore, tracked: result.tracked },
        );
      }),
    );
    checks.push(
      await guarded("codex-skill", "Codex skill readiness could not be verified", async () => {
        const plan = await planCodexSkillInstallation(projectContext.projectRoot);
        const statuses = plan.items.map(({ path, status }) => ({ path: path.split(sep).join("/"), status }));
        const ready = statuses.every(({ status }) => status === "unchanged");
        return check(
          "codex-skill",
          ready ? "ready" : "not-ready",
          ready ? "Codex skill files match this package" : "Codex skill needs initialization or has local edits",
          { items: statuses, pins: installedSkillPins(plan), expectedPins: plan.pins },
        );
      }),
    );
  } else {
    checks.push(unavailable("workflow-catalog", "Workflow catalog could not be verified"));
    checks.push(unavailable("local-store", "Local store could not be verified"));
    checks.push(unavailable("evaluation-questions", "Evaluation questions or requirements could not be verified"));
    checks.push(unavailable("user-sessions", "User-managed sessions could not be inspected"));
    checks.push(unavailable("local-git-safety", "Local Git safety could not be verified"));
    checks.push(unavailable("codex-skill", "Codex skill readiness could not be verified"));
  }

  checks.push(
    manifest
      ? configuredRegistry(manifest)
      : unavailable("registry-mapping", "Package registry mapping could not be verified"),
  );
  checks.push(authenticationCheck(options.environment ?? process.env));
  checks.push(await registryAvailabilityCheck(options));

  if (checks.length !== CHECK_ORDER.length || checks.some((item, index) => item.id !== CHECK_ORDER[index])) {
    throw new Error("Project doctor check ordering changed");
  }
  const local = readiness(checks, LOCAL_CHECKS);
  const packageReadiness = readiness(checks, PACKAGE_CHECKS);
  const registryReadiness = readiness(checks, REGISTRY_CHECKS, { requested: options.checkRegistry === true });
  const skillPins = checks.find(({ id }) => id === "codex-skill")?.details?.pins ?? null;
  const protocolCompatible =
    typeof manifest?.version === "string" &&
    skillPins !== null &&
    skillPins.packageName === manifest.name &&
    skillPins.packageVersion === manifest.version &&
    SUPPORTED_PROTOCOL_VERSIONS.includes(skillPins.protocolVersion);
  return {
    schema: "agent-workflow-project-doctor/v1",
    status: local.status,
    localStatus: local.status,
    packageStatus: packageReadiness.status,
    registryStatus: registryReadiness.status,
    mode: options.checkRegistry ? "online-requested" : "offline",
    compatibility: {
      status: protocolCompatible ? "ready" : "not-ready",
      packageVersion: manifest?.version ?? null,
      supportedProtocolVersions: SUPPORTED_PROTOCOL_VERSIONS,
      preferredProtocolVersion: PREFERRED_PROTOCOL_VERSION,
      generatedSkillPins: skillPins,
      diagnosis: protocolCompatible
        ? "Package and generated skill protocol versions are compatible."
        : "Initialize or upgrade the generated Codex skill before agent execution.",
    },
    readiness: {
      local,
      package: packageReadiness,
      registry: registryReadiness,
      execution: {
        status: "not-verified",
        checks: ["browser-connection", "target-reachability"],
        nextStep: "Select a journey and run its readiness preflight before execution.",
      },
    },
    checks,
  };
}
