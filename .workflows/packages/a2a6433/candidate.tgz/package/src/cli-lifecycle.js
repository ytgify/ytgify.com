import { readCliFixtureRecipe } from "./cli-training.js";
import { WorkflowError } from "./errors.js";
import { launchCandidateReplay } from "./lifecycle.js";
import { executeLifecycleOperation } from "./lifecycle-store.js";
import {
  resolveCurrentApplicationTarget,
  resolveCurrentJourneySource,
  selectedStoreRoot,
} from "./cli-journey-source.js";
import { RunControlStore } from "./run-control-store.js";

function invalid(message) {
  throw new WorkflowError("INVALID_USAGE", message, { exitCode: 2 });
}

/** Dispatch semantic current-candidate lifecycle forms while preserving every legacy operation. */
export async function executeCliLifecycleOperation({ command, args, flags, registry, resolveProjectContext }) {
  if (!flags.has("journey")) {
    const configuredTargetLaunch =
      flags.has("target") &&
      ((command === "replay" && ["candidate", "promoted"].includes(args[0])) ||
        (command === "evaluate" && args[0] === "launch"));
    if (!configuredTargetLaunch) return executeLifecycleOperation({ command, args, flags, registry });
    if (!flags.get("target").trim()) invalid(`${command} ${args[0]} --target requires product words`);
    if (flags.has("target-url")) invalid(`${command} ${args[0]} cannot combine --target with --target-url`);
    const allowed =
      command === "replay"
        ? ["config", "fixture-recipe", "json", "platform", "profile", "root", "store", "target"]
        : [
            "config",
            "fixture-recipe",
            "desktop-qualification",
            "json",
            "mobile-qualification",
            "root",
            "store",
            "target",
          ];
    const unsupported = [...flags.keys()].filter((name) => !allowed.includes(name));
    if (unsupported.length) invalid(`${command} ${args[0]} does not accept --${unsupported[0]}`);
    const selected = await resolveCurrentApplicationTarget({
      target: flags.get("target"),
      registry,
      resolveProjectContext,
    });
    return executeLifecycleOperation({
      command,
      args,
      flags,
      registry,
      applicationTarget: selected.applicationTarget,
      projectContext: selected.projectContext,
      storeRoot: selectedStoreRoot(selected.projectContext, flags.get("store")),
    });
  }
  const semanticReplay = command === "replay" && args[0] === "candidate";
  const semanticPromotion = command === "promote";
  if (!semanticReplay && !semanticPromotion) invalid(`${command} does not accept --journey`);
  if (!flags.get("journey").trim()) invalid(`${command} --journey requires product words`);
  if ((semanticReplay && args.length !== 1) || (semanticPromotion && args.length !== 0)) {
    invalid(`${command} --journey cannot be combined with PATH or immutable identity arguments`);
  }
  const allowed = semanticReplay
    ? ["config", "fixture-recipe", "journey", "json", "platform", "profile", "root", "store", "target", "target-url"]
    : ["config", "journey", "json", "replay", "root", "store"];
  const unsupported = [...flags.keys()].filter((name) => !allowed.includes(name));
  if (unsupported.length) invalid(`${command} does not accept --${unsupported[0]}`);
  if (semanticReplay && !flags.get("platform")) invalid("replay candidate --journey requires --platform");
  if (semanticPromotion && !flags.get("replay")) invalid("promote --journey requires --replay RUN_ID");
  if (semanticReplay && flags.has("target") && !flags.get("target").trim()) {
    invalid("replay candidate --target requires product words");
  }
  if (semanticReplay && flags.has("target") && flags.has("target-url")) {
    invalid("replay candidate cannot combine --target with --target-url");
  }

  const selected = await resolveCurrentJourneySource({
    journey: flags.get("journey"),
    target: flags.get("target"),
    selectTarget: semanticReplay && !flags.has("target-url"),
    registry,
    resolveProjectContext,
  });
  const storeRoot = selectedStoreRoot(selected.projectContext, flags.get("store"));
  if (semanticReplay) {
    const runStore = await new RunControlStore(storeRoot, { registry }).init();
    const data = await launchCandidateReplay({
      fixtureRecipe: await readCliFixtureRecipe(flags, registry),
      fixtureProjectRoot: selected.projectContext.projectRoot,
      workflowSource: selected.source,
      platform: flags.get("platform"),
      profile: flags.get("profile"),
      runStore,
      registry,
      applicationTarget: selected.applicationTarget,
      targetUrl: flags.get("target-url"),
      projectContext: selected.projectContext,
    });
    return { command: "replay candidate", data };
  }
  return executeLifecycleOperation({
    command,
    args,
    flags,
    registry,
    workflowSource: selected.source,
    applicationTarget: selected.applicationTarget,
    projectContext: selected.projectContext,
    storeRoot,
  });
}
