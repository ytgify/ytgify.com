import { randomUUID } from "node:crypto";
import { constants } from "node:fs";
import { link, lstat, mkdir, open, readdir, unlink } from "node:fs/promises";
import { dirname, join, relative, resolve, sep } from "node:path";

import { WorkflowError } from "./errors.js";
import { sha256 } from "./stable-json.js";

const FINDING_ID = /^finding_[a-f0-9]{32}$/;
const WORKFLOW_ID = /^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$/;
const CRITERION_ID = /^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$/;
const SUPPORTED_PLATFORMS = new Set(["desktop-web", "mobile-web"]);
const WRITE_AUTHORITY = Symbol("finding-contract-write-authority");

function fail(code, message) {
  throw new WorkflowError(code, message, { exitCode: 3 });
}

function assertIdentity(pattern, value, label) {
  if (!pattern.test(value ?? "")) fail("INVALID_FINDING_CONTRACT_ID", `Invalid ${label}`);
}

function assertInside(root, path) {
  const suffix = relative(resolve(root), resolve(path));
  if (suffix.startsWith("..") || resolve(root, suffix) !== resolve(path))
    fail("PATH_TRAVERSAL", "Finding contract path escapes its root");
}

async function assertDirectory(path) {
  const entry = await lstat(path);
  if (!entry.isDirectory() || entry.isSymbolicLink())
    fail("FINDING_CONTRACT_STORE_UNSAFE", "Finding contract paths cannot be symlinks");
}

async function assertSafeAncestry(root, path) {
  assertInside(root, path);
  let cursor = resolve(root);
  await assertDirectory(cursor);
  for (const part of relative(cursor, resolve(path)).split(sep).filter(Boolean)) {
    cursor = join(cursor, part);
    try {
      const entry = await lstat(cursor);
      if (entry.isSymbolicLink())
        fail("FINDING_CONTRACT_STORE_UNSAFE", "Finding contract ancestry cannot contain symlinks");
      if (cursor !== resolve(path) && !entry.isDirectory())
        fail("FINDING_CONTRACT_STORE_UNSAFE", "Finding contract ancestry must contain only directories");
    } catch (error) {
      if (error.code === "ENOENT") break;
      throw error;
    }
  }
}

async function syncDirectory(path) {
  const handle = await open(path, "r");
  try {
    await handle.sync();
  } finally {
    await handle.close();
  }
}

async function readRegular(path) {
  await assertDirectory(dirname(path));
  const entry = await lstat(path);
  if (!entry.isFile() || entry.isSymbolicLink())
    fail("FINDING_CONTRACT_RECORD_CORRUPT", "Finding contract is not a regular file");
  const handle = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    const opened = await handle.stat();
    if (opened.dev !== entry.dev || opened.ino !== entry.ino || opened.size !== entry.size)
      fail("FINDING_CONTRACT_RECORD_CORRUPT", "Finding contract changed while being read");
    return await handle.readFile("utf8");
  } finally {
    await handle.close();
  }
}

async function immutableWrite(path, bytes) {
  const temporary = `${path}.${randomUUID()}.tmp`;
  const handle = await open(temporary, "wx", 0o600);
  try {
    await handle.writeFile(bytes);
    await handle.sync();
  } finally {
    await handle.close();
  }
  try {
    await link(temporary, path);
    await syncDirectory(dirname(path));
  } catch (error) {
    if (error.code === "EEXIST")
      fail("IMMUTABLE_FINDING_CONTRACT_EXISTS", "Finding verification contracts cannot be replaced");
    throw error;
  } finally {
    await unlink(temporary).catch(() => {});
  }
}

function requiredText(value, label) {
  if (typeof value !== "string" || !value.trim() || value.length > 4000) throw new TypeError(`${label} is invalid`);
  return value.trim();
}

function normalizeCriteria(criteria) {
  if (!Array.isArray(criteria) || criteria.length === 0) throw new TypeError("criteria must not be empty");
  const seen = new Set();
  return criteria.map((criterion, index) => {
    const allowed = new Set(["id", "expectedCorrection", "applicablePlatforms", "evidenceRequirements"]);
    if (!criterion || typeof criterion !== "object" || Array.isArray(criterion))
      throw new TypeError(`criteria[${index}] is invalid`);
    if (Object.keys(criterion).some((key) => !allowed.has(key)))
      throw new TypeError(`criteria[${index}] contains unsupported provenance or evidence fields`);
    if (!CRITERION_ID.test(criterion.id ?? "") || seen.has(criterion.id))
      throw new TypeError(`criteria[${index}].id is invalid or duplicated`);
    seen.add(criterion.id);
    if (!Array.isArray(criterion.applicablePlatforms) || criterion.applicablePlatforms.length === 0)
      throw new TypeError(`criteria[${index}].applicablePlatforms is invalid`);
    const applicablePlatforms = [...new Set(criterion.applicablePlatforms)];
    if (applicablePlatforms.some((platform) => !SUPPORTED_PLATFORMS.has(platform)))
      throw new TypeError(`criteria[${index}] contains an unsupported platform`);
    if (!Array.isArray(criterion.evidenceRequirements) || criterion.evidenceRequirements.length === 0)
      throw new TypeError(`criteria[${index}].evidenceRequirements is invalid`);
    return {
      id: criterion.id,
      expectedCorrection: requiredText(criterion.expectedCorrection, `criteria[${index}].expectedCorrection`),
      applicablePlatforms,
      evidenceRequirements: criterion.evidenceRequirements.map((item) =>
        requiredText(item, `criteria[${index}].evidenceRequirements`),
      ),
    };
  });
}

function hashedContract(record) {
  const { contractHash: _contractHash, ...content } = record;
  return sha256(content);
}

export function verifyFindingVerificationContract(finding, contract) {
  if (contract.workflowId !== finding.workflowId || contract.findingId !== finding.findingId)
    fail("FINDING_CONTRACT_ID_MISMATCH", "Finding contract references another finding");
  if (contract.findingHash !== sha256(finding))
    fail("FINDING_CONTRACT_FINDING_MISMATCH", "Finding contract no longer matches the immutable finding");
  if (contract.contractHash !== hashedContract(contract))
    fail("FINDING_CONTRACT_HASH_MISMATCH", "Finding contract content hash does not match its content");
  if (!contract.criteria.some((criterion) => criterion.applicablePlatforms.includes(finding.platform)))
    fail(
      "FINDING_CONTRACT_SOURCE_PLATFORM_UNCOVERED",
      "Finding correction criteria must cover the finding source platform",
    );
  return "verified";
}

export class FindingVerificationContractStore {
  constructor(root, { registry } = {}) {
    this.root = resolve(root);
    this.contractsRoot = join(this.root, "finding-verification-contracts");
    this.registry = registry;
  }

  async init() {
    await mkdir(this.root, { recursive: true });
    await assertDirectory(this.root);
    await mkdir(this.contractsRoot, { recursive: true });
    await assertDirectory(this.contractsRoot);
    return this;
  }

  workflowRoot(workflowId) {
    assertIdentity(WORKFLOW_ID, workflowId, "workflow ID");
    const path = resolve(this.contractsRoot, workflowId);
    assertInside(this.contractsRoot, path);
    return path;
  }

  recordPath(workflowId, findingId) {
    assertIdentity(FINDING_ID, findingId, "finding ID");
    const root = this.workflowRoot(workflowId);
    const path = resolve(root, `${findingId}.json`);
    assertInside(root, path);
    return path;
  }

  async writeContract(record, authority) {
    if (authority !== WRITE_AUTHORITY)
      fail("FINDING_CONTRACT_WRITE_FORBIDDEN", "Finding contracts require a verified finding boundary");
    this.registry?.validate("findingVerificationContract", record);
    const root = this.workflowRoot(record.workflowId);
    await assertSafeAncestry(this.contractsRoot, root);
    await mkdir(root).catch((error) => {
      if (error.code !== "EEXIST") throw error;
    });
    await assertDirectory(root);
    const path = this.recordPath(record.workflowId, record.findingId);
    await assertSafeAncestry(this.contractsRoot, path);
    await immutableWrite(path, Buffer.from(`${JSON.stringify(record, null, 2)}\n`));
    return structuredClone(record);
  }

  async readContract(workflowId, findingId) {
    const path = this.recordPath(workflowId, findingId);
    await assertSafeAncestry(this.contractsRoot, path);
    let record;
    try {
      record = JSON.parse(await readRegular(path));
    } catch (error) {
      if (error instanceof SyntaxError) fail("FINDING_CONTRACT_RECORD_CORRUPT", "Finding contract is invalid JSON");
      throw error;
    }
    this.registry?.validate("findingVerificationContract", record);
    if (record.workflowId !== workflowId || record.findingId !== findingId)
      fail("FINDING_CONTRACT_ID_MISMATCH", "Finding contract path does not match its identity");
    if (record.contractHash !== hashedContract(record))
      fail("FINDING_CONTRACT_HASH_MISMATCH", "Finding contract content hash does not match its content");
    return structuredClone(record);
  }

  async listFindingIds(workflowId) {
    const root = this.workflowRoot(workflowId);
    try {
      await assertSafeAncestry(this.contractsRoot, root);
      await assertDirectory(root);
    } catch (error) {
      if (error.code === "ENOENT") return [];
      throw error;
    }
    return (await readdir(root))
      .filter((name) => /^finding_[a-f0-9]{32}\.json$/.test(name))
      .sort()
      .map((name) => name.slice(0, -5));
  }
}

export async function recordFindingVerificationContract({
  findingStore,
  contractStore,
  workflowId,
  findingId,
  criteria,
}) {
  const finding = await findingStore.readFinding(workflowId, findingId);
  const normalizedCriteria = normalizeCriteria(criteria);
  if (!normalizedCriteria.some((criterion) => criterion.applicablePlatforms.includes(finding.platform)))
    fail(
      "FINDING_CONTRACT_SOURCE_PLATFORM_UNCOVERED",
      "Finding correction criteria must cover the finding source platform",
    );
  const content = {
    schema: "agent-workflow-finding-verification-contract/v1",
    workflowId: finding.workflowId,
    findingId: finding.findingId,
    findingHash: sha256(finding),
    scope: {
      workflowRevision: finding.workflowRevision,
      sourcePlatform: finding.platform,
    },
    provenance: { actor: "agent", source: "agent-authored" },
    criteria: normalizedCriteria,
    createdAt: new Date().toISOString(),
  };
  const record = { ...content, contractHash: sha256(content) };
  try {
    return await contractStore.writeContract(record, WRITE_AUTHORITY);
  } catch (error) {
    if (error.code !== "IMMUTABLE_FINDING_CONTRACT_EXISTS") throw error;
    const existing = await contractStore.readContract(workflowId, findingId);
    verifyFindingVerificationContract(finding, existing);
    if (sha256(existing.criteria) !== sha256(record.criteria)) throw error;
    return existing;
  }
}
