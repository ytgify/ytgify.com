import { randomUUID } from "node:crypto";
import { link, lstat, mkdir, open, readFile, readdir, rename, unlink, writeFile } from "node:fs/promises";
import { dirname, join, relative, resolve } from "node:path";

import { WorkflowError } from "./errors.js";

const BATCH_ID = /^batch_[a-f0-9]{24}$/;

function fail(code, message, details) {
  throw new WorkflowError(code, message, { exitCode: 3, details });
}

function inside(root, path) {
  const resolvedRoot = resolve(root);
  const resolvedPath = resolve(path);
  const suffix = relative(resolvedRoot, resolvedPath);
  if (suffix.startsWith("..") || resolve(resolvedRoot, suffix) !== resolvedPath)
    fail("PATH_TRAVERSAL", "Batch path escapes its store");
  return resolvedPath;
}

async function atomicJson(path, value) {
  const temporary = `${path}.${randomUUID()}.tmp`;
  const handle = await open(temporary, "wx", 0o600);
  try {
    await handle.writeFile(`${JSON.stringify(value, null, 2)}\n`);
    await handle.sync();
  } finally {
    await handle.close();
  }
  await rename(temporary, path);
  const directory = await open(dirname(path), "r");
  try {
    await directory.sync();
  } finally {
    await directory.close();
  }
}

export class PerspectiveBatchStore {
  constructor(root, { registry, interruption } = {}) {
    this.root = resolve(root);
    this.batchesRoot = join(this.root, "perspective-batches");
    this.registry = registry;
    this.interruption = interruption;
    this.lockPath = join(this.batchesRoot, ".launch.lock");
  }

  async init() {
    await mkdir(this.batchesRoot, { recursive: true });
    return this;
  }

  path(batchId) {
    if (!BATCH_ID.test(batchId)) fail("INVALID_BATCH_ID", `Invalid perspective batch ID: ${batchId}`);
    return inside(this.batchesRoot, join(this.batchesRoot, `${batchId}.json`));
  }

  validate(record) {
    if (this.registry?.kinds?.().includes("perspectiveBatch")) this.registry.validate("perspectiveBatch", record);
    return record;
  }

  async read(batchId) {
    await this.assertSafeAncestry(this.path(batchId));
    let entry;
    try {
      entry = await lstat(this.path(batchId));
    } catch (error) {
      if (error.code === "ENOENT") fail("PERSPECTIVE_BATCH_NOT_FOUND", `Perspective batch not found: ${batchId}`);
      throw error;
    }
    if (!entry.isFile() || entry.isSymbolicLink())
      fail("PERSPECTIVE_BATCH_CORRUPT", "Perspective batch is not a regular file");
    const record = this.validate(JSON.parse(await readFile(this.path(batchId), "utf8")));
    if (record.batchId !== batchId)
      fail("PERSPECTIVE_BATCH_CORRUPT", "Perspective batch identity does not match its filename");
    return structuredClone(record);
  }

  async list() {
    await this.assertSafeAncestry(this.batchesRoot);
    let entries;
    try {
      entries = await readdir(this.batchesRoot);
    } catch (error) {
      if (error.code === "ENOENT") return [];
      throw error;
    }
    const names = entries.filter((name) => /^batch_[a-f0-9]{24}\.json$/.test(name)).sort();
    return Promise.all(names.map((name) => this.read(name.slice(0, -5))));
  }

  async createIntent(record) {
    await this.assertSafeAncestry(this.batchesRoot);
    const path = this.path(record.batchId);
    try {
      await writeFile(path, `${JSON.stringify(this.validate(record), null, 2)}\n`, { flag: "wx", mode: 0o600 });
    } catch (error) {
      if (error.code !== "EEXIST") throw error;
      const existing = await this.read(record.batchId);
      if (existing.inputHash !== record.inputHash)
        fail("PERSPECTIVE_BATCH_CONFLICT", "Batch inputs changed after launch intent was journaled");
      return existing;
    }
    await this.interruption?.("intent-journaled", { batchId: record.batchId });
    return structuredClone(record);
  }

  async update(record) {
    const current = await this.read(record.batchId);
    if (current.inputHash !== record.inputHash)
      fail("PERSPECTIVE_BATCH_CONFLICT", "Batch inputs cannot change during launch");
    this.validate(record);
    await atomicJson(this.path(record.batchId), record);
    return structuredClone(record);
  }

  async assertSafeAncestry(path) {
    const resolvedPath = inside(this.root, path);
    const rootEntry = await lstat(this.root);
    if (!rootEntry.isDirectory() || rootEntry.isSymbolicLink())
      fail("PERSPECTIVE_BATCH_CORRUPT", "Batch store root must be a regular directory");
    let cursor = this.root;
    for (const part of relative(this.root, resolvedPath).split("/").filter(Boolean)) {
      cursor = join(cursor, part);
      try {
        const entry = await lstat(cursor);
        if (entry.isSymbolicLink()) fail("PERSPECTIVE_BATCH_CORRUPT", "Batch path ancestry cannot contain symlinks");
      } catch (error) {
        if (error.code === "ENOENT" && cursor === resolvedPath) return;
        throw error;
      }
    }
  }

  async withLaunchLock(operation) {
    await this.assertSafeAncestry(this.batchesRoot);
    for (;;) {
      const temporary = `${this.lockPath}.${randomUUID()}.tmp`;
      let published = false;
      try {
        const handle = await open(temporary, "wx", 0o600);
        try {
          await handle.writeFile(`${JSON.stringify({ pid: process.pid })}\n`);
          await handle.sync();
        } finally {
          await handle.close();
        }
        await link(temporary, this.lockPath);
        published = true;
        const identity = await lstat(this.lockPath);
        await unlink(temporary);
        try {
          return await operation();
        } finally {
          const current = await lstat(this.lockPath).catch(() => null);
          if (current?.dev === identity.dev && current?.ino === identity.ino) await unlink(this.lockPath);
        }
      } catch (error) {
        if (!published) await unlink(temporary).catch(() => {});
        if (published || error.code !== "EEXIST") throw error;
        let owner;
        let observed;
        try {
          observed = await lstat(this.lockPath);
          owner = JSON.parse(await readFile(this.lockPath, "utf8"));
        } catch (caught) {
          if (caught.code === "ENOENT") continue;
          fail("PERSPECTIVE_BATCH_LOCK_CORRUPT", "Batch launch lock is invalid JSON");
        }
        if (!Number.isSafeInteger(owner?.pid) || owner.pid < 1)
          fail("PERSPECTIVE_BATCH_LOCK_CORRUPT", "Batch launch lock has an invalid owner");
        let alive = true;
        try {
          process.kill(owner.pid, 0);
        } catch (caught) {
          if (caught.code === "ESRCH") alive = false;
          else throw caught;
        }
        if (!alive) {
          const current = await lstat(this.lockPath).catch(() => null);
          if (current?.dev === observed.dev && current?.ino === observed.ino) await unlink(this.lockPath);
          continue;
        }
        await new Promise((resolveWait) => setTimeout(resolveWait, 10));
      }
    }
  }
}
