import { retirePendingApproval } from "./retire-pending-approval.js";
/* eslint-disable max-lines -- protocol execution and evidence validation share one transactional boundary. */
import { randomUUID } from "node:crypto";
import { setTimeout as delay } from "node:timers/promises";

import { localDogfoodBatch, revalidateLocalDogfood } from "./local-dogfood.js";
import { authSessionBindingHash, authSessionScope } from "./auth-session-store.js";
import {
  assertAuthenticatedExecutionCompleted,
  authenticatedExecutionRecovery,
  validateAuthenticatedActions,
} from "./authenticated-browser-execution.js";
import { consumeAuthenticatedUploadsForLease } from "./authenticated-upload-artifact.js";
import { WorkflowError } from "./errors.js";
import { DEFAULT_SCREENSHOT_MAX_BYTES } from "./evidence.js";
import { matchesExplorationFile, verifyExplorationFile } from "./exploration-fixtures.js";
import { matchesRepositoryFixtureUpload } from "./fixture-lifecycle.js";
import { deriveHeartbeatExpiry, deriveLeaseTimes, leasePolicyForManifest } from "./lease-policy.js";
import { protocolRequestHash, validateProtocolMessage, validateProtocolRequest } from "./protocol.js";
import { resolveRunTarget } from "./run-target.js";
import { resolveFixtureRouteBinding, runRouteBindingId } from "./run-route-binding.js";
import { sha256 } from "./stable-json.js";

function id(prefix) {
  return `${prefix}_${randomUUID().replaceAll("-", "")}`;
}

function responseTiming(state, runnerNow) {
  const activeLease = state.activeLease;
  if (!activeLease) return { runnerNow: runnerNow.toISOString(), activeLease: null };
  const leasePolicy = activeLease.leasePolicy ?? leasePolicyForManifest(state.manifest);
  const remainingSeconds = Math.max(0, (new Date(activeLease.expiresAt).valueOf() - runnerNow.valueOf()) / 1000);
  const hardRemainingSeconds = Math.max(
    0,
    (new Date(activeLease.hardExpiresAt).valueOf() - runnerNow.valueOf()) / 1000,
  );
  return {
    runnerNow: runnerNow.toISOString(),
    activeLease: {
      leaseId: activeLease.leaseId,
      expiresAt: activeLease.expiresAt,
      hardExpiresAt: activeLease.hardExpiresAt,
      remainingSeconds,
      hardRemainingSeconds,
      heartbeatThresholdSeconds: leasePolicy.heartbeatThresholdSeconds,
      heartbeatRecommended: remainingSeconds > 0 && remainingSeconds <= leasePolicy.heartbeatThresholdSeconds,
    },
  };
}

function allowedOperations(state, actorId, workflow) {
  const operations = ["agent.inspect"];
  if (["completed", "blocked", "failed", "abandoned"].includes(state.status)) return operations;
  if (!state.ownerHostId) return [...operations, "agent.claim"];
  if (state.ownerHostId !== actorId) return operations;
  if (state.status === "reconciling") return [...operations, "agent.reconcile"];
  if (state.authentication?.status === "verifying") {
    return [...operations, "agent.authentication.verify"];
  }
  if (state.status === "awaiting-authentication") {
    return [...operations, "agent.capabilities", "agent.authentication.verify", "agent.release"];
  }
  if (["preparing", "preflight"].includes(state.status)) return [...operations, "agent.capabilities", "agent.release"];
  if (state.status === "active" && state.activeLease) {
    if (state.activeOptionalAuthorization) return [...operations, "agent.optional-state.complete"];
    return [
      ...operations,
      "agent.heartbeat",
      "agent.evidence",
      ...(state.activeLease.extensions?.["routine.action"]?.id ? ["agent.optional-state.authorize"] : []),
      "agent.commit",
    ];
  }
  if (state.status === "active") {
    return [
      ...operations,
      ...((workflow?.fixtureRoutes ?? []).length ? ["agent.route.bind"] : []),
      "agent.propose",
      ...(state.exploration ? ["agent.exploration.finish"] : []),
      "agent.release",
    ];
  }
  if (state.status === "paused" && state.exploration)
    return [...operations, "agent.exploration.finish", "agent.release"];
  return [...operations, "agent.release"];
}

function authenticationDto(state) {
  const authentication = state.authentication;
  if (!authentication?.required) return null;
  if (authentication.status === "verified") {
    return {
      status: "verified",
      targetId: authentication.targetId,
      lastVerifiedAt: authentication.lastVerifiedAt,
    };
  }
  return {
    status: "required",
    targetId: authentication.targetId,
    recoveryAction: { id: "open-authentication-session", targetId: authentication.targetId },
  };
}

function authenticationError(code, message) {
  return new WorkflowError(code, message, { exitCode: 3 });
}

function requiredAuthenticationDto(targetId) {
  return {
    status: "required",
    targetId,
    recoveryAction: { id: "open-authentication-session", targetId },
  };
}

function exactAuthenticationScope(run, projectContext) {
  const pinned = run.manifest.authentication;
  const pinnedTarget = run.manifest.target;
  if (!projectContext || !pinned || pinnedTarget?.source !== "application-target") {
    throw authenticationError("AUTH_SESSION_NOT_CONFIGURED", "Authenticated run context is not configured");
  }
  const matches = (projectContext.applicationTargets?.inventory ?? []).filter(
    (target) => target.id === pinned.targetId,
  );
  if (matches.length !== 1) {
    throw authenticationError("AUTH_SESSION_NOT_CONFIGURED", "Authenticated run target is not configured");
  }
  const configured = matches[0];
  let configuredOrigin;
  let pinnedOrigin;
  try {
    configuredOrigin = new URL(configured.baseUrl).origin;
    pinnedOrigin = new URL(pinnedTarget.canonicalUrl).origin;
  } catch {
    throw authenticationError("AUTH_SESSION_STALE", "Authenticated run target no longer matches its configuration");
  }
  if (
    configured.authentication?.mode !== "user-session" ||
    configured.provenance !== "configured-v1" ||
    pinnedTarget.targetId !== configured.id ||
    pinnedTarget.environment !== configured.environment ||
    pinnedTarget.provenance !== configured.provenance ||
    configuredOrigin !== pinnedOrigin
  ) {
    throw authenticationError("AUTH_SESSION_STALE", "Authenticated run target no longer matches its configuration");
  }
  return authSessionScope(projectContext, configured);
}

function requiredAuthenticationReason(error) {
  if (error?.code === "AUTH_SESSION_NOT_CONFIGURED" || error?.code === "AUTH_MARKER_NOT_CONFIGURED") {
    return "not-configured";
  }
  if (error?.code === "AUTH_SESSION_STALE" || error?.code === "AUTH_SESSION_REVISION_CONFLICT") return "stale";
  if (error?.code === "AUTH_MARKER_NOT_FOUND") return "marker-not-found";
  return "capability-unavailable";
}

function hasBoundUserSessionCapability(run) {
  const capabilities = Object.values(run.state.capabilities ?? {});
  const session = capabilities.find(
    (capability) => capability.id === "browser.user-session" && capability.contractVersion === "1.0",
  );
  if (!session) return false;
  const browserCapabilities = capabilities.filter(
    (capability) => capability.id === "browser.control" || capability.operations.includes("browser.control"),
  );
  return (
    browserCapabilities.length > 0 &&
    browserCapabilities.every((capability) => capability.adapter.id === session.adapter.id)
  );
}

function currentStep(run) {
  if (run.manifest.phase === "exploration" && run.state.status === "active")
    return {
      id: "explore",
      name: "Explore local application",
      action: "Follow one declared exploration intent",
      expected: ["Capture a visit or record a blocked branch"],
      evidence: [{ type: "screenshot", checkpoint: "visit", required: true }],
    };
  if (!run.workflow || !run.state.traversal || run.state.status !== "active") return null;
  return (
    run.workflow.steps.find((step) => {
      if (run.state.traversal.steps[step.id]?.outcome !== "pending") return false;
      return (step.dependsOn ?? []).every((dependency) =>
        ["passed", "passed_with_deviation"].includes(run.state.traversal.steps[dependency]?.outcome),
      );
    }) ?? null
  );
}

function declaredStepEvidence(step) {
  return (step?.evidence ?? [])
    .filter((item) => item && typeof item === "object" && ["screenshot", "download-artifact"].includes(item.type))
    .map(({ type, checkpoint, exactViewport, verify }) => ({
      type,
      checkpoint,
      ...(exactViewport ? { exactViewport } : {}),
      ...(verify ? { verify: structuredClone(verify) } : {}),
    }));
}

function requiredEvidence(step) {
  return (step?.evidence ?? [])
    .filter((item) => item && typeof item === "object" && item.required !== false)
    .map(({ type, checkpoint, exactViewport }) => ({ type, checkpoint, ...(exactViewport ? { exactViewport } : {}) }));
}

function optionalHandler(run, step, handlerId) {
  if (run.manifest.leasePolicy?.name !== "routine-codex-browser-v1" || !step?.optionalHandlers?.includes(handlerId)) {
    return null;
  }
  return run.workflow.optionalStateHandlers.find((handler) => handler.id === handlerId) ?? null;
}

function optionalEvidence(handler) {
  return handler?.evidence?.filter((item) => item && typeof item === "object") ?? [];
}

function inspection(run, actorId) {
  const step = currentStep(run);
  const pinnedBatches =
    run.manifest.leasePolicy?.name === "routine-codex-browser-v1" || Boolean(run.manifest.localDogfood);
  const authentication = authenticationDto(run.state);
  return {
    kind: "inspection",
    state: { phase: run.state.phase, status: run.state.status },
    allowedOperations: allowedOperations(run.state, actorId, run.workflow),
    pendingHumanControl: Boolean(run.state.pendingApproval),
    activeLease: run.state.activeLease,
    leasePolicy: leasePolicyForManifest(run.manifest),
    target:
      run.manifest.target ?? (run.workflow?.schema === "agent-workflow/v0" ? resolveRunTarget(run.workflow) : null),
    nextInstruction: step?.action ?? null,
    step: step
      ? {
          id: step.id,
          name: step.name,
          action: step.action,
          ...(step.actionGuidance ? { actionGuidance: step.actionGuidance } : {}),
          expected: step.expected,
          requiredEvidence: requiredEvidence(step),
          ...(pinnedBatches ? { routineActionBatches: structuredClone(step.routineActionBatches ?? []) } : {}),
        }
      : null,
    capabilityGaps: run.state.capabilityGaps ?? [],
    ...(authentication ? { authentication } : {}),
  };
}

function evidenceResult(event) {
  return event.type === "evidence.slot-issued"
    ? { kind: "evidence", action: "issue", slot: event.payload.slot }
    : { kind: "evidence", action: "register", artifact: event.payload.artifact };
}

function capabilityAvailable(capabilities, requirement, platform) {
  return Object.values(capabilities).some((capability) => {
    if (platform && !capability.constraints?.platforms?.includes(platform)) return false;
    if (capability.id === requirement || capability.id.startsWith(`${requirement}.`)) return true;
    if (capability.operations.includes(requirement)) return true;
    if (requirement === "screenshot") return capability.evidenceTypes.includes("screenshot");
    if (requirement === "media-inspection") {
      return capability.operations.includes("media-inspection") || capability.evidenceTypes.includes("audio");
    }
    if (requirement === "download-artifact") {
      return capability.evidenceTypes.some((type) => type.startsWith("download-"));
    }
    return false;
  });
}

function explorationCapabilityAvailable(capabilities, requirement, platform) {
  if (requirement === "browser.control") {
    const browser = capabilities["browser.control"];
    return Boolean(
      browser?.constraints?.platforms?.includes(platform) && browser.operations.includes("browser.control"),
    );
  }
  return Object.values(capabilities).some(
    (capability) =>
      capability.constraints?.platforms?.includes(platform) &&
      capability.evidenceTypes.includes("screenshot") &&
      (capability.constraints.maxBytes ?? DEFAULT_SCREENSHOT_MAX_BYTES) > 0,
  );
}

function evidenceMatches(requirement, artifact) {
  if (artifact.relation.optionalHandlerId !== undefined) return false;
  if (artifact.relation.stepId !== requirement.stepId) return false;
  if (artifact.relation.checkpoint !== requirement.checkpoint) return false;
  if (requirement.type === "screenshot")
    return (
      artifact.type === "screenshot" && (!requirement.exactViewport || artifact.captureGeometry === "viewport-match")
    );
  if (requirement.type === "media-inspection") return ["audio", "video", "assertion"].includes(artifact.type);
  if (requirement.type === "download-artifact") {
    return (
      artifact.type === "download-content" &&
      artifact.mimeType === requirement.verify.mimeType &&
      artifact.download?.filename === requirement.verify.filename &&
      artifact.sizeBytes >= requirement.verify.minimumBytes
    );
  }
  return true;
}

function requirementCapability(requirement) {
  return requirement.type;
}

function validateAssessment(run, request) {
  const step = currentStep(run);
  const { assessment, artifacts: artifactReferences = [], result } = request.payload;
  if (!assessment) {
    throw new WorkflowError("VALIDATION_FAILED", "Executable workflow commits require a structured step assessment", {
      exitCode: 3,
    });
  }
  if (!step || assessment.stepId !== step.id) {
    throw new WorkflowError("ILLEGAL_TRANSITION", "Commit does not assess the current step", {
      exitCode: 4,
      details: { expected: step?.id ?? null, actual: assessment.stepId },
    });
  }
  if (run.state.activeOptionalAuthorization) {
    throw new WorkflowError("ILLEGAL_TRANSITION", "Optional-state authorization must be applied before commit", {
      exitCode: 4,
    });
  }
  const expected = step.expected;
  const received = assessment.expectations.map((item) => item.expectation);
  if (new Set(received).size !== received.length || JSON.stringify(received) !== JSON.stringify(expected)) {
    throw new WorkflowError("VALIDATION_FAILED", "Every workflow expectation must be assessed once and in order", {
      exitCode: 3,
      details: { expected, received },
    });
  }
  if (artifactReferences.some((artifact) => typeof artifact !== "string")) {
    throw new WorkflowError(
      "VALIDATION_FAILED",
      "Commit requests must reference runner-registered artifact IDs, not artifact metadata",
      { exitCode: 3 },
    );
  }
  const artifactIds = new Set(artifactReferences);
  const artifacts = artifactReferences.map((artifactId) => run.state.traversal?.artifacts?.[artifactId]);
  if (artifacts.some((artifact) => !artifact)) {
    throw new WorkflowError("NOT_FOUND", "Committed evidence is not registered for this run", {
      exitCode: 8,
    });
  }
  if (artifactIds.size !== artifacts.length || result.evidence.some((artifactId) => !artifactIds.has(artifactId))) {
    throw new WorkflowError("VALIDATION_FAILED", "Committed evidence must be registered in the same bounded batch", {
      exitCode: 3,
    });
  }
  if ((result.notes ?? []).some((note) => (note.evidence ?? []).some((artifactId) => !artifactIds.has(artifactId)))) {
    throw new WorkflowError(
      "VALIDATION_FAILED",
      "Agent notes may reference only evidence committed in the same batch",
      {
        exitCode: 3,
      },
    );
  }
  if (
    assessment.expectations.some((item) => (item.evidence ?? []).some((artifactId) => !artifactIds.has(artifactId)))
  ) {
    throw new WorkflowError("VALIDATION_FAILED", "Assessment evidence must be included in the commit", {
      exitCode: 3,
    });
  }
  for (const artifact of artifacts) {
    if (artifact.runId !== run.manifest.runId || artifact.relation.stepId !== step.id) {
      throw new WorkflowError("VALIDATION_FAILED", "Evidence identity does not match the active run and step", {
        exitCode: 3,
      });
    }
  }
  for (const application of run.state.optionalApplications?.[step.id] ?? []) {
    if (
      application.evidenceIds.some(
        (artifactId) =>
          !artifactIds.has(artifactId) ||
          run.state.traversal.artifacts[artifactId]?.relation.optionalHandlerId !== application.handlerId,
      )
    ) {
      throw new WorkflowError(
        "VALIDATION_FAILED",
        "Applied optional-state evidence must be included in the step commit",
        {
          exitCode: 3,
        },
      );
    }
  }
  const blockedForEvidence =
    assessment.proposedOutcome === "blocked" && assessment.block?.code === "evidence_unavailable";
  const blockedForGap = assessment.proposedOutcome === "blocked" && assessment.block?.code === "capability_unavailable";
  if (blockedForEvidence) {
    if (
      assessment.block.capability !== "screenshot" ||
      !requiredEvidence(step).some((item) => item.type === "screenshot") ||
      assessment.expectations.some((item) => item.outcome !== "blocked")
    ) {
      throw new WorkflowError(
        "VALIDATION_FAILED",
        "Unavailable screenshot proof requires a blocked screenshot-dependent step",
        { exitCode: 3 },
      );
    }
  } else if (blockedForGap) {
    const gap = assessment.block.capability;
    const proven = (run.state.capabilityGaps ?? []).includes(gap);
    const requiredHere = requiredEvidence(step).some((requirement) => requirementCapability(requirement) === gap);
    if (!proven || !requiredHere || assessment.expectations.some((item) => item.outcome !== "blocked")) {
      throw new WorkflowError(
        "VALIDATION_FAILED",
        "capability_unavailable requires a recorded capability gap at the current requiring step",
        { exitCode: 3, details: { capability: gap } },
      );
    }
  } else {
    if (assessment.block) {
      throw new WorkflowError("VALIDATION_FAILED", "A capability block requires a blocked assessment", {
        exitCode: 3,
      });
    }
    for (const requirement of requiredEvidence(step)) {
      if (
        !artifacts.some((artifact) =>
          evidenceMatches(
            {
              ...requirement,
              verify: step.evidence.find(
                (item) => item.checkpoint === requirement.checkpoint && item.type === requirement.type,
              )?.verify,
              stepId: step.id,
            },
            artifact,
          ),
        )
      ) {
        throw new WorkflowError("CAPABILITY_UNAVAILABLE", `Required evidence is missing: ${requirement.checkpoint}`, {
          exitCode: 5,
          details: requirement,
        });
      }
    }
  }
  const outcomes = assessment.expectations.map((item) => item.outcome);
  let derivedOutcome = "passed";
  if (outcomes.includes("failed")) derivedOutcome = "failed";
  else if (outcomes.includes("blocked")) derivedOutcome = "blocked";
  else if (assessment.proposedOutcome === "passed_with_deviation") derivedOutcome = "passed_with_deviation";
  if (assessment.proposedOutcome !== derivedOutcome) {
    throw new WorkflowError("VALIDATION_FAILED", "Proposed outcome conflicts with expectation verdicts", {
      exitCode: 3,
      details: { proposed: assessment.proposedOutcome, derived: derivedOutcome },
    });
  }
  return { step, artifacts, derivedOutcome };
}

function assertActiveLease(run, actorId, leaseId, now) {
  const lease = run.state.activeLease;
  if (!lease || lease.leaseId !== leaseId || lease.hostId !== actorId) {
    throw new WorkflowError("ILLEGAL_TRANSITION", "Evidence does not match the active lease", {
      exitCode: 4,
    });
  }
  if (now.valueOf() >= new Date(lease.expiresAt).valueOf()) {
    throw new WorkflowError("LEASE_EXPIRED", "The active action lease has expired", {
      exitCode: 4,
      details: { leaseId },
    });
  }
  return lease;
}

function validateEvidenceRegistration(run, actorId, payload, now) {
  const lease = assertActiveLease(run, actorId, payload.leaseId, now);
  if (
    run.manifest.phase === "exploration" &&
    now.valueOf() - new Date(run.manifest.createdAt).valueOf() >= run.manifest.exploration.limits.minutes * 60_000
  ) {
    throw new WorkflowError("VALIDATION_FAILED", "Exploration time budget exhausted", { exitCode: 3 });
  }
  const slot = run.state.evidenceSlots?.[payload.slotId];
  if (!slot) {
    throw new WorkflowError("NOT_FOUND", `Evidence slot not found: ${payload.slotId}`, {
      exitCode: 8,
    });
  }
  const issuedSlot = run.events.find(
    (event) => event.type === "evidence.slot-issued" && event.payload.slot.slotId === slot.slotId,
  )?.payload.slot;
  if (
    !issuedSlot ||
    JSON.stringify(issuedSlot) !== JSON.stringify(slot) ||
    slot.runId !== run.state.runId ||
    slot.hostId !== actorId ||
    slot.leaseId !== lease.leaseId ||
    slot.leaseRequestId !== run.state.activeLeaseRequestId ||
    slot.stepId !== currentStep(run)?.id ||
    new Date(slot.expiresAt).valueOf() > new Date(lease.expiresAt).valueOf() ||
    now.valueOf() >= new Date(lease.hardExpiresAt).valueOf()
  ) {
    throw new WorkflowError("VALIDATION_FAILED", "Evidence slot binding does not match the active lease", {
      exitCode: 3,
    });
  }
  return { lease, slot };
}

function validateEvidenceIssue(run, actorId, payload, now) {
  const lease = assertActiveLease(run, actorId, payload.leaseId, now);
  if (
    run.manifest.phase === "exploration" &&
    now.valueOf() - new Date(run.manifest.createdAt).valueOf() >= run.manifest.exploration.limits.minutes * 60_000
  ) {
    throw new WorkflowError("VALIDATION_FAILED", "Exploration time budget exhausted", { exitCode: 3 });
  }
  if (
    run.manifest.phase === "exploration" &&
    run.state.exploration.capturesUsed >= run.manifest.exploration.limits.captures
  ) {
    throw new WorkflowError("VALIDATION_FAILED", "Exploration capture budget exhausted", { exitCode: 3 });
  }
  const step = currentStep(run);
  if (!step || step.id !== payload.stepId) {
    throw new WorkflowError("ILLEGAL_TRANSITION", "Evidence does not target the active workflow step", {
      exitCode: 4,
    });
  }
  const handler = payload.optionalHandlerId ? optionalHandler(run, step, payload.optionalHandlerId) : null;
  if (payload.optionalHandlerId && !handler) {
    throw new WorkflowError("VALIDATION_FAILED", "Optional evidence handler is not attached to the active step", {
      exitCode: 3,
    });
  }
  const declared = handler ? optionalEvidence(handler) : declaredStepEvidence(step);
  const requirement = declared.find(
    (item) =>
      item.type === (payload.type === "download-content" ? "download-artifact" : payload.type) &&
      item.checkpoint === payload.checkpoint,
  );
  if (!requirement) {
    throw new WorkflowError("VALIDATION_FAILED", "Evidence is not declared for this step checkpoint", {
      exitCode: 3,
    });
  }
  if (
    payload.type === "download-content" &&
    (requirement.verify?.mimeType !== "image/gif" || payload.filename !== requirement.verify.filename)
  ) {
    throw new WorkflowError(
      "VALIDATION_FAILED",
      "Download filename or supported MIME type differs from the declared requirement",
      { exitCode: 3 },
    );
  }
  if (handler && handler.routineDismissal?.capabilityId !== payload.capabilityId) {
    throw new WorkflowError("VALIDATION_FAILED", "Handler evidence capability does not match its pinned contract", {
      exitCode: 3,
    });
  }
  const capability = run.state.capabilities[payload.capabilityId];
  if (!capability || !capability.evidenceTypes.includes(payload.type)) {
    throw new WorkflowError("CAPABILITY_UNAVAILABLE", "The registered host capability cannot capture this evidence", {
      exitCode: 5,
    });
  }
  const configuredLimit = capability.constraints.maxBytes;
  const maximumBytes =
    configuredLimit == null ? DEFAULT_SCREENSHOT_MAX_BYTES : Math.min(configuredLimit, DEFAULT_SCREENSHOT_MAX_BYTES);
  if (maximumBytes < 1) {
    throw new WorkflowError("CAPABILITY_UNAVAILABLE", "The registered evidence byte limit is zero", {
      exitCode: 5,
    });
  }
  const leasedEvent = [...run.events]
    .reverse()
    .find((event) => event.type === "action.leased" && event.payload.lease.leaseId === lease.leaseId);
  return {
    lease,
    step,
    capability,
    maximumBytes,
    leaseRequestId: leasedEvent.transaction.requestId,
    ...(handler ? { optionalHandlerId: handler.id } : {}),
    ...(payload.type === "download-content" ? { download: structuredClone(requirement.verify) } : {}),
  };
}

function optionalAuthorizationContract(run, actorId, payload, now) {
  const lease = assertActiveLease(run, actorId, payload.parentLeaseId, now);
  const step = currentStep(run);
  const handler = optionalHandler(run, step, payload.handlerId);
  if (
    lease.policy.decision !== "allowed" ||
    !lease.extensions?.["routine.action"]?.id ||
    !handler?.routineDismissal ||
    handler.maxApplications !== 1 ||
    run.state.activeOptionalAuthorization ||
    (run.state.optionalApplications?.[step.id] ?? []).some((item) => item.handlerId === handler.id)
  ) {
    throw new WorkflowError("ILLEGAL_TRANSITION", "Optional-state dismissal is not available for this parent lease", {
      exitCode: 4,
    });
  }
  const requirements = optionalEvidence(handler);
  if (requirements.length !== 1 || payload.evidenceIds.length !== 1) {
    throw new WorkflowError(
      "VALIDATION_FAILED",
      "Optional-state dismissal requires its one exact before-state screenshot",
      {
        exitCode: 3,
      },
    );
  }
  const leasedEvent = run.events.find(
    (event) => event.type === "action.leased" && event.payload.lease.leaseId === lease.leaseId,
  );
  const artifacts = payload.evidenceIds.map((artifactId) => run.state.traversal?.artifacts?.[artifactId]);
  const requirement = requirements[0];
  if (
    !leasedEvent?.transaction ||
    artifacts.some(
      (artifact) =>
        !artifact ||
        artifact.runId !== run.manifest.runId ||
        artifact.type !== "screenshot" ||
        artifact.relation.stepId !== step.id ||
        artifact.relation.checkpoint !== requirement.checkpoint ||
        artifact.relation.optionalHandlerId !== handler.id ||
        artifact.relation.batchRequestId !== leasedEvent.transaction.requestId ||
        artifact.capability.id !== handler.routineDismissal.capabilityId,
    )
  ) {
    throw new WorkflowError("VALIDATION_FAILED", "Optional-state evidence is not bound to this run, step, and lease", {
      exitCode: 3,
    });
  }
  const scope = structuredClone(handler.routineDismissal);
  return {
    lease,
    step,
    handler,
    evidenceIds: [...payload.evidenceIds],
    scope,
    contractHash: sha256({
      handlerId: handler.id,
      maxApplications: handler.maxApplications,
      evidence: handler.evidence,
      routineDismissal: scope,
    }),
  };
}

async function verifyOptionalEvidence(store, runId, checked) {
  await Promise.all(checked.evidenceIds.map((artifactId) => store.readVerifiedEvidence(runId, artifactId)));
}

function matchedRoutineAction(step, proposal) {
  if (
    proposal.actions.some(
      (action) => action.inputRef && !(action.kind === "upload-file" && action.inputRef.kind === "synthetic-file"),
    )
  )
    return null;
  const proposed = { actions: proposal.actions, requestedCapabilities: proposal.requestedCapabilities };
  return (step.routineActionBatches ?? []).find(
    (batch) =>
      sha256({ actions: batch.actions, requestedCapabilities: batch.requestedCapabilities }) === sha256(proposed),
  );
}

function policyDecision(run, step, proposal, now = new Date()) {
  const repositoryFileUpload = matchesRepositoryFixtureUpload(run.manifest, proposal);
  const explorationFileUpload =
    run.manifest.phase === "exploration" &&
    matchesExplorationFile(run.manifest, proposal.actions[0], proposal.requestedCapabilities);
  if (run.manifest.phase === "exploration") {
    const action = proposal.actions[0];
    const origin = new URL(run.manifest.target.canonicalUrl).origin;
    let navigationAllowed = true;
    if (action?.kind === "navigate") {
      navigationAllowed = false;
      if (action.target) {
        try {
          const destination = new URL(action.target, origin);
          navigationAllowed =
            destination.origin === origin && !destination.username && !destination.password && !destination.hash;
        } catch {
          navigationAllowed = false;
        }
      }
    }
    if (
      proposal.actions.length !== 1 ||
      !action ||
      (!explorationFileUpload &&
        !["observe", "activate-control", "enter-text", "navigate", "scroll", "wait", "capture-evidence"].includes(
          action.kind,
        )) ||
      !["observation-only", "reversible-ui"].includes(proposal.risk.category) ||
      (explorationFileUpload && proposal.risk.category !== "reversible-ui") ||
      proposal.risk.externallyVisible ||
      proposal.risk.destructive ||
      (action.inputRef && !explorationFileUpload) ||
      !navigationAllowed ||
      !proposal.requestedCapabilities.includes("browser.control") ||
      proposal.requestedCapabilities.some(
        (item) => !["browser.control", "screenshot", ...(explorationFileUpload ? ["file-upload"] : [])].includes(item),
      )
    ) {
      return {
        decision: "denied",
        reason: "Exploration allows one anonymous local, origin-bound, reversible browser action per lease.",
      };
    }
    const elapsed = now.valueOf() - new Date(run.manifest.createdAt).valueOf();
    if (
      elapsed < 0 ||
      elapsed >= run.manifest.exploration.limits.minutes * 60_000 ||
      run.state.exploration.actionsUsed >= run.manifest.exploration.limits.actions ||
      run.state.exploration.capturesUsed >= run.manifest.exploration.limits.captures
    ) {
      return { decision: "denied", reason: "Exploration budget exhausted; review the partial record." };
    }
  }
  const missing = proposal.requestedCapabilities.filter((item) => !run.state.capabilities[item]);
  if (missing.length) return { decision: "denied", reason: `Capabilities unavailable: ${missing.join(", ")}` };
  if (
    repositoryFileUpload &&
    (!run.state.capabilities["browser.control"]?.constraints?.platforms?.includes(run.manifest.platform) ||
      !run.state.capabilities["browser.control"]?.operations?.includes("browser.control") ||
      !run.state.capabilities["file-upload"]?.constraints?.platforms?.includes(run.manifest.platform) ||
      !run.state.capabilities["file-upload"]?.operations?.includes("upload-file"))
  )
    return { decision: "denied", reason: "Exact local fixture upload capabilities are unavailable." };
  const hasUpload = proposal.actions.some((action) => action.kind === "upload-file");
  if (
    hasUpload &&
    ((!explorationFileUpload && !repositoryFileUpload && !run.manifest.authentication) ||
      !proposal.requestedCapabilities.includes("browser.control") ||
      !proposal.requestedCapabilities.includes("file-upload"))
  ) {
    return {
      decision: "denied",
      reason:
        "File upload requires an authenticated session or an exact ready local fixture and both browser.control and file-upload capabilities.",
    };
  }
  if (run.manifest.authentication) {
    try {
      validateAuthenticatedActions(proposal.actions, { routeBindings: run.state.routeBindings });
    } catch {
      return { decision: "denied", reason: "Authenticated execution does not support this action batch." };
    }
  }
  if (proposal.actions.length > 3) {
    return {
      decision: "needs-refinement",
      reason: "A bounded batch may contain at most three actions.",
    };
  }
  if (run.manifest.localDogfood) {
    const routineAction = localDogfoodBatch(run.manifest, step, proposal);
    return routineAction
      ? { decision: "allowed", routineAction }
      : {
          decision: "denied",
          reason: "Local synthetic policy requires an exact pinned browser action batch without credential inputs.",
        };
  }
  const routine = run.manifest.leasePolicy?.name === "routine-codex-browser-v1";
  if (routine) {
    const bindingId =
      proposal.actions.length === 1 && proposal.actions[0].kind === "navigate"
        ? runRouteBindingId(proposal.actions[0].target)
        : null;
    if (bindingId && run.state.routeBindings?.[bindingId]) return { decision: "allowed" };
    const routineAction = matchedRoutineAction(step, proposal);
    return routineAction
      ? { decision: "allowed", routineAction }
      : {
          decision: "denied",
          reason: "Routine evaluation accepts only an exact immutable reviewed action batch.",
        };
  }
  return { decision: "allowed" };
}

export class AgentService {
  constructor(store, registry, { now = () => new Date(), authSessionService, projectContext, fixtureService } = {}) {
    this.store = store;
    this.registry = registry;
    this.now = now;
    this.authSessionService = authSessionService;
    this.projectContext = projectContext;
    this.fixtureService = fixtureService;
  }

  async appendTransaction(runId, transaction) {
    let lockedError;
    for (let attempt = 0; attempt < 8; attempt += 1) {
      try {
        return await this.store.appendTransaction(runId, transaction);
      } catch (error) {
        if (error.code !== "RUN_STORE_LOCKED") throw error;
        lockedError = error;
        if (attempt === 7) {
          const current = await this.store.readRun(runId);
          if (transaction.expectedRevision !== undefined && transaction.expectedRevision !== current.state.revision) {
            throw new WorkflowError("REVISION_CONFLICT", "The run revision has changed", {
              exitCode: 4,
              details: { expected: transaction.expectedRevision, current: current.state.revision },
            });
          }
          throw lockedError;
        }
        await delay(2 ** attempt);
      }
    }
    throw new Error("unreachable");
  }

  async append(runId, request, type, source, payload, result, beforeAppend, expectedRevision) {
    return this.appendTransaction(runId, {
      operation: request.command,
      requestId: request.requestId,
      request,
      result,
      receiptId: id("receipt"),
      eventId: id("evt"),
      occurredAt: this.now().toISOString(),
      type,
      source,
      payload,
      beforeAppend,
      ...(expectedRevision === undefined ? {} : { expectedRevision }),
    });
  }

  async system(runId, operation, expectedRevision, type, payload) {
    const requestId = id("req");
    return this.appendTransaction(runId, {
      operation,
      requestId,
      request: { command: operation, expectedRevision },
      result: payload,
      receiptId: id("receipt"),
      eventId: id("evt"),
      occurredAt: this.now().toISOString(),
      type,
      source: "runner",
      payload,
    });
  }

  async requireAuthentication(runId, expectedRevision, targetId, reason, request, result) {
    if (!request) {
      return this.system(runId, "authentication.require", expectedRevision, "authentication.required", {
        targetId,
        reason,
      });
    }
    return this.appendTransaction(runId, {
      operation: "authentication.require",
      requestId: request.requestId,
      request,
      result,
      receiptId: id("receipt"),
      eventId: id("evt"),
      occurredAt: this.now().toISOString(),
      type: "authentication.required",
      source: "runner",
      payload: { targetId, reason },
      expectedRevision,
    });
  }

  async liveAuthentication(run) {
    const authentication = run.manifest.authentication;
    if (!authentication) return { verified: true, record: null, reason: null };
    let record;
    let reason;
    try {
      if (!this.authSessionService) {
        throw authenticationError("AUTH_SESSION_CAPABILITY_UNAVAILABLE", "Authentication capability is unavailable");
      }
      if (!hasBoundUserSessionCapability(run)) {
        throw authenticationError(
          "AUTH_SESSION_CAPABILITY_UNAVAILABLE",
          "Authenticated browser actions require the centralized session capability",
        );
      }
      const scope = exactAuthenticationScope(run, this.projectContext);
      record = await this.authSessionService.verify(scope);
      if (
        record.targetId !== authentication.targetId ||
        record.markerHash !== authentication.markerHash ||
        (record.sessionBindingHash ?? authSessionBindingHash(record)) !== authentication.sessionBindingHash
      ) {
        throw authenticationError("AUTH_SESSION_STALE", "Authentication session no longer matches the pinned run");
      }
      if (record.state === "needs-login") reason = "marker-not-found";
      else if (
        record.state !== "ready" ||
        !record.lastVerifiedAt ||
        !/^usersession_[A-Za-z0-9_-]+$/u.test(record.browserSessionRef ?? "")
      ) {
        throw authenticationError("AUTH_SESSION_STALE", "Authentication verification outcome is stale");
      }
    } catch (error) {
      reason = requiredAuthenticationReason(error);
    }
    return { verified: !reason, record, reason };
  }

  async verifyAuthentication(run, { request, failureResult, successResult } = {}) {
    const authentication = run.manifest.authentication;
    if (!authentication) return { verified: true, run, transaction: null, authentication: null };
    const started = await this.system(
      run.state.runId,
      "authentication.verify",
      run.state.revision,
      "authentication.verification_started",
      { targetId: authentication.targetId, markerHash: authentication.markerHash },
    );
    const live = await this.liveAuthentication(run);
    let transaction;
    if (!live.verified) {
      transaction = await this.requireAuthentication(
        run.state.runId,
        started.state.revision,
        authentication.targetId,
        live.reason,
        request,
        failureResult,
      );
    } else if (request && successResult) {
      transaction = await this.append(
        run.state.runId,
        request,
        "authentication.verified",
        "runner",
        {
          targetId: authentication.targetId,
          markerHash: authentication.markerHash,
          verifiedAt: live.record.lastVerifiedAt,
        },
        successResult(live.record),
        undefined,
        started.state.revision,
      );
    } else {
      transaction = await this.system(
        run.state.runId,
        "authentication.verify",
        started.state.revision,
        "authentication.verified",
        {
          targetId: authentication.targetId,
          markerHash: authentication.markerHash,
          verifiedAt: live.record.lastVerifiedAt,
        },
      );
    }
    const nextRun = { ...run, state: transaction.state };
    return {
      verified: live.verified,
      run: nextRun,
      transaction,
      authentication: authenticationDto(transaction.state),
      browserSessionRef: live.record?.browserSessionRef ?? null,
    };
  }

  async recoverExpiredLease(run) {
    const lease = run.state.activeLease;
    const runnerNow = this.now();
    if (!lease || runnerNow.valueOf() < new Date(lease.expiresAt).valueOf()) return run;
    const requestId = id("req");
    try {
      const transaction = await this.appendTransaction(run.state.runId, {
        operation: "lease.expire",
        requestId,
        request: { command: "lease.expire", expectedRevision: run.state.revision },
        result: { leaseId: lease.leaseId, status: "reconciling" },
        receiptId: id("receipt"),
        eventId: id("evt"),
        occurredAt: runnerNow.toISOString(),
        type: "lease.expired",
        source: "runner",
        payload: { leaseId: lease.leaseId, hostId: lease.hostId, expiredAt: lease.expiresAt },
        beforeAppend: async ({ current }) => {
          const currentLease = current.state.activeLease;
          if (
            !currentLease ||
            currentLease.leaseId !== lease.leaseId ||
            currentLease.hostId !== lease.hostId ||
            currentLease.expiresAt !== lease.expiresAt ||
            runnerNow.valueOf() < new Date(currentLease.expiresAt).valueOf()
          ) {
            throw new WorkflowError("REVISION_CONFLICT", "The active lease changed before expiry recovery", {
              exitCode: 4,
            });
          }
          await consumeAuthenticatedUploadsForLease(current, lease.leaseId, {
            outcome: "expired",
            now: () => runnerNow,
          });
        },
      });
      return { ...run, state: transaction.state, events: [...run.events, transaction.event] };
    } catch (error) {
      if (error.code !== "REVISION_CONFLICT") throw error;
      return this.store.readRun(run.state.runId);
    }
  }

  response(request, transaction, result, workflow) {
    const state = transaction.state;
    const runnerNow = new Date(transaction.event.occurredAt);
    const response = {
      schema: "agent-workflow-protocol-response/v1",
      ok: true,
      protocolVersion: request.protocolVersion,
      requestId: request.requestId,
      receiptId: transaction.receipt.receiptId,
      runId: request.runId,
      previousRevision: request.expectedRevision ?? state.revision,
      revision: state.revision,
      state: { phase: state.phase, status: state.status },
      allowedOperations: allowedOperations(state, request.actor.id, workflow),
      result,
      timing: responseTiming(state, runnerNow),
      warnings: [],
    };
    validateProtocolMessage(response, this.registry, { expectedType: "response" });
    return response;
  }

  async requireFixtureReady(run) {
    const recipe = run.manifest.fixtureContract?.recipe;
    if (!recipe) return;
    if (recipe.kind === "repository-file") {
      const instance = await this.store.readFixtureInstance(run.manifest.runId, {
        projectRoot: this.projectContext?.projectRoot,
      });
      if (!instance || instance.state !== "ready")
        throw new WorkflowError("CAPABILITY_UNAVAILABLE", "A freshly verified fixture instance is required", {
          exitCode: 4,
        });
    } else if (recipe.kind === "application-record") {
      if (!this.fixtureService)
        throw new WorkflowError(
          "CAPABILITY_UNAVAILABLE",
          "Application fixture requires a registered host adapter through AgentService and FixtureApplicationService",
          { exitCode: 4 },
        );
      try {
        await this.fixtureService.readReady(run.manifest.runId);
      } catch (error) {
        if (error?.code !== "FIXTURE_NOT_READY" && error?.code !== "FIXTURE_LEASE_REQUIRED") throw error;
        throw new WorkflowError("CAPABILITY_UNAVAILABLE", "A freshly verified fixture instance is required", {
          exitCode: 4,
        });
      }
    } else throw new Error("Unsupported fixture recipe kind");
  }

  async checkedFixtureProposalRun(request) {
    let run = await this.store.readRun(request.runId);
    if (run.state.status === "awaiting-approval") {
      await retirePendingApproval({ store: this.store, runId: request.runId, now: this.now });
      run = await this.store.readRun(request.runId);
    }
    const expiredLease = run.state.activeLease;
    run = await this.recoverExpiredLease(run);
    if (expiredLease && run.state.uncertainLeaseId === expiredLease.leaseId && !run.state.activeLease)
      throw new WorkflowError("LEASE_EXPIRED", "The active action lease has expired and requires reconciliation", {
        exitCode: 4,
        details: { leaseId: expiredLease.leaseId, revision: run.state.revision },
      });
    validateProtocolRequest(request, this.registry, { currentRevision: run.state.revision });
    if (!allowedOperations(run.state, request.actor.id, run.workflow).includes(request.command))
      throw new WorkflowError(
        run.state.ownerHostId && run.state.ownerHostId !== request.actor.id ? "RUN_OWNED" : "ILLEGAL_TRANSITION",
        "The requested operation is not currently allowed",
        { exitCode: run.state.ownerHostId && run.state.ownerHostId !== request.actor.id ? 6 : 4 },
      );
    return run;
  }

  async handle(request) {
    if (request?.command === "agent.propose") {
      validateProtocolMessage(request, this.registry, { expectedType: "request" });
      const prior = await this.store.readProtocolResponse(request.runId, request.requestId);
      if (prior) {
        if (prior.requestHash !== protocolRequestHash(request))
          throw new WorkflowError(
            "IDEMPOTENCY_CONFLICT",
            `Request ID was already used with different input: ${request.requestId}`,
            { exitCode: 4 },
          );
        return prior.response;
      }
      const run = await this.store.readRun(request.runId);
      if (run.manifest.fixtureContract) {
        return this.store.withExclusiveFixtures(async () => {
          const cached = await this.store.readProtocolResponse(request.runId, request.requestId);
          if (cached) {
            if (cached.requestHash !== protocolRequestHash(request))
              throw new WorkflowError(
                "IDEMPOTENCY_CONFLICT",
                `Request ID was already used with different input: ${request.requestId}`,
                { exitCode: 4 },
              );
            return cached.response;
          }
          await this.requireFixtureReady(await this.checkedFixtureProposalRun(request));
          return this.handleUnlocked(request);
        });
      }
    }
    return this.handleUnlocked(request);
  }

  async handleUnlocked(request) {
    validateProtocolMessage(request, this.registry, { expectedType: "request" });
    const cached = await this.store.readProtocolResponse(request.runId, request.requestId);
    if (cached) {
      if (cached.requestHash !== protocolRequestHash(request)) {
        throw new WorkflowError(
          "IDEMPOTENCY_CONFLICT",
          `Request ID was already used with different input: ${request.requestId}`,
          { exitCode: 4 },
        );
      }
      if (request.command.startsWith("agent.optional-state.")) {
        throw new WorkflowError("IDEMPOTENCY_CONFLICT", "Optional-state authorization requests cannot be replayed", {
          exitCode: 4,
        });
      }
      return cached.response;
    }
    if (request.command === "agent.evidence") {
      const recovered = await this.store.readTransaction(request.runId, request.requestId);
      if (recovered) {
        if (recovered.event.transaction.requestHash !== protocolRequestHash(request)) {
          throw new WorkflowError(
            "IDEMPOTENCY_CONFLICT",
            `Request ID was already used with different input: ${request.requestId}`,
            { exitCode: 4 },
          );
        }
        const result = evidenceResult(recovered.event);
        const response = this.response(request, recovered, result);
        const published = await this.store.writeProtocolResponse(
          request.runId,
          request.requestId,
          protocolRequestHash(request),
          response,
        );
        return published.response;
      }
    }
    let run = await this.store.readRun(request.runId);
    if (run.state.status === "awaiting-approval") {
      await retirePendingApproval({ store: this.store, runId: request.runId, now: this.now });
      run = await this.store.readRun(request.runId);
    }
    const expiredLease = run.state.activeLease;
    run = await this.recoverExpiredLease(run);
    if (
      request.command !== "agent.inspect" &&
      expiredLease &&
      run.state.uncertainLeaseId === expiredLease.leaseId &&
      !run.state.activeLease
    ) {
      throw new WorkflowError("LEASE_EXPIRED", "The active action lease has expired and requires reconciliation", {
        exitCode: 4,
        details: { leaseId: expiredLease.leaseId, revision: run.state.revision },
      });
    }
    validateProtocolRequest(request, this.registry, { currentRevision: run.state.revision });
    if (request.command === "agent.inspect") {
      const result = inspection(run, request.actor.id);
      const recovery = await authenticatedExecutionRecovery(run);
      const runnerNow = this.now();
      const response = {
        schema: "agent-workflow-protocol-response/v1",
        ok: true,
        protocolVersion: request.protocolVersion,
        requestId: request.requestId,
        receiptId: id("receipt"),
        runId: request.runId,
        previousRevision: run.state.revision,
        revision: run.state.revision,
        state: { phase: run.state.phase, status: run.state.status },
        allowedOperations: result.allowedOperations,
        result,
        timing: responseTiming(run.state, runnerNow),
        warnings: recovery ? [recovery] : [],
      };
      validateProtocolMessage(response, this.registry, { expectedType: "response" });
      const published = await this.store.writeProtocolResponse(
        request.runId,
        request.requestId,
        protocolRequestHash(request),
        response,
      );
      return published.response;
    }

    const actorId = request.actor.id;
    if (request.command === "agent.claim") {
      if (run.state.ownerHostId) {
        throw new WorkflowError(
          run.state.ownerHostId === actorId ? "ILLEGAL_TRANSITION" : "RUN_OWNED",
          run.state.ownerHostId === actorId
            ? "This host already owns the run"
            : "The run is owned by another agent host",
          { exitCode: run.state.ownerHostId === actorId ? 4 : 6 },
        );
      }
    } else if (!allowedOperations(run.state, actorId, run.workflow).includes(request.command)) {
      throw new WorkflowError(
        run.state.ownerHostId && run.state.ownerHostId !== actorId ? "RUN_OWNED" : "ILLEGAL_TRANSITION",
        "The requested operation is not currently allowed",
        { exitCode: run.state.ownerHostId && run.state.ownerHostId !== actorId ? 6 : 4 },
      );
    }
    let transaction;
    let result;
    switch (request.command) {
      case "agent.claim":
        if (actorId !== request.payload.hostInstanceId) {
          throw new WorkflowError("INVALID_REQUEST", "Actor and claimed host instance must match", {
            exitCode: 2,
          });
        }
        transaction = await this.append(
          request.runId,
          request,
          "host.claimed",
          "agent-host",
          { hostId: actorId, reconciliationRequired: false },
          { kind: "acknowledgement" },
        );
        result = { kind: "acknowledgement" };
        break;

      case "agent.route.bind": {
        const resolved = resolveFixtureRouteBinding(run.workflow, {
          ...request.payload,
          target: `run-route:binding_${request.payload.routeId}`,
        });
        if (!capabilityAvailable(run.state.capabilities, resolved.capability, run.manifest.platform)) {
          throw new WorkflowError("CAPABILITY_UNAVAILABLE", "The reviewed fixture route capability is unavailable", {
            exitCode: 3,
          });
        }
        const bindingId = id("binding");
        transaction = await this.append(
          request.runId,
          request,
          "route.bound",
          "agent-host",
          { ...request.payload, hostId: actorId, bindingId },
          { kind: "route-binding", bindingId, routeId: resolved.routeId },
        );
        result = {
          kind: "route-binding",
          bindingId: transaction.event.payload.bindingId,
          routeId: transaction.event.payload.routeId,
        };
        break;
      }

      case "agent.capabilities": {
        transaction = await this.append(
          request.runId,
          request,
          "capabilities.registered",
          "agent-host",
          { hostId: actorId, capabilities: request.payload.capabilities },
          { kind: "capabilities" },
        );
        const commandReceipt = transaction.receipt;
        const accepted = request.payload.capabilities.map((item) => item.id);
        const probeReceipts = [];
        let missing = transaction.state.capabilityGaps ?? [];
        if (transaction.state.preflightOutcome === null) {
          let started;
          let startedReceiptId;
          if (transaction.state.status === "preflight") {
            started = transaction;
            startedReceiptId = [...run.events].reverse().find(({ type }) => type === "preflight.started")
              ?.transaction?.receiptId;
          } else {
            started = await this.system(
              request.runId,
              "preflight.start",
              transaction.state.revision,
              "preflight.started",
              {},
            );
            startedReceiptId = started.receipt.receiptId;
          }
          missing = (
            run.manifest.phase === "exploration"
              ? ["browser.control", "screenshot"]
              : run.workflow.start.preflightCapabilities
          ).filter((requirement) =>
            run.manifest.phase === "exploration"
              ? !explorationCapabilityAvailable(transaction.state.capabilities, requirement, run.manifest.platform)
              : !capabilityAvailable(transaction.state.capabilities, requirement, run.manifest.platform),
          );
          const preflightOutcome =
            run.state.phase === "training" ||
            (run.state.phase !== "exploration" && missing.every((item) => item === "screenshot")) ||
            !missing.length
              ? "passed"
              : "blocked";
          transaction = await this.system(
            request.runId,
            "preflight.complete",
            started.state.revision,
            "preflight.completed",
            {
              outcome: preflightOutcome,
              ...(missing.length
                ? {
                    missingCapabilities: missing,
                    reason: `Missing capabilities: ${missing.join(", ")}`,
                  }
                : {}),
            },
          );
          if (startedReceiptId) probeReceipts.push(startedReceiptId);
          probeReceipts.push(transaction.receipt.receiptId);
        }
        let authentication;
        if (transaction.state.status === "awaiting-authentication") {
          const verification = await this.verifyAuthentication({ ...run, state: transaction.state });
          transaction = verification.transaction;
          authentication = verification.authentication;
        }
        if (transaction.state.status === "cleanup") {
          const cleanupStarted = await this.system(
            request.runId,
            "cleanup.start",
            transaction.state.revision,
            "cleanup.started",
            { reason: "Preflight did not permit workflow execution." },
          );
          transaction = await this.system(
            request.runId,
            "cleanup.complete",
            cleanupStarted.state.revision,
            "cleanup.completed",
            { outcome: "passed" },
          );
        }
        transaction = { ...transaction, receipt: commandReceipt };
        result = {
          kind: "capabilities",
          accepted,
          probeReceipts,
          ...(missing.length ? { missingCapabilities: missing } : {}),
          ...(authentication ? { authentication } : {}),
        };
        break;
      }

      case "agent.authentication.verify": {
        const targetId = run.manifest.authentication?.targetId;
        if (!targetId) {
          throw new WorkflowError("ILLEGAL_TRANSITION", "This run does not require authentication", { exitCode: 4 });
        }
        const verification = await this.verifyAuthentication(run, {
          request,
          failureResult: {
            kind: "authentication",
            authentication: requiredAuthenticationDto(targetId),
          },
          successResult: (record) => ({
            kind: "authentication",
            authentication: { status: "verified", targetId, lastVerifiedAt: record.lastVerifiedAt },
          }),
        });
        transaction = verification.transaction;
        result = { kind: "authentication", authentication: verification.authentication };
        break;
      }

      case "agent.propose": {
        let browserSessionRef = null;
        let step = currentStep(run);
        if (!step)
          throw new WorkflowError("ILLEGAL_TRANSITION", "No workflow step is ready", {
            exitCode: 4,
          });
        await revalidateLocalDogfood(this.projectContext, run.manifest, this.registry);
        let policy = policyDecision(run, step, request.payload.proposal, this.now());
        if (
          run.manifest.phase === "exploration" &&
          request.payload.branchAttempt &&
          run.state.exploration.branchesUsed >= run.manifest.exploration.limits.branches
        ) {
          policy = { decision: "denied", reason: "Exploration branch budget exhausted; review the partial record." };
        }
        if (run.manifest.authentication && policy.decision === "allowed") {
          const authenticationFailure = {
            kind: "lease",
            decision: "denied",
            reason: "Authentication is required before another action lease.",
            authentication: requiredAuthenticationDto(run.manifest.authentication.targetId),
          };
          const verification = await this.verifyAuthentication(run, {
            request,
            failureResult: authenticationFailure,
          });
          if (!verification.verified) {
            transaction = verification.transaction;
            result = authenticationFailure;
            break;
          }
          browserSessionRef = verification.browserSessionRef;
          run = verification.run;
          step = currentStep(run);
          if (!step) {
            throw new WorkflowError("ILLEGAL_TRANSITION", "No workflow step is ready", { exitCode: 4 });
          }
          policy = policyDecision(run, step, request.payload.proposal, this.now());
        }
        if (
          run.manifest.phase === "exploration" &&
          policy.decision === "allowed" &&
          request.payload.proposal.actions[0]?.kind === "upload-file"
        ) {
          const action = request.payload.proposal.actions[0];
          const fixture = run.manifest.exploration.fixtures.find((item) => item.name === action.inputRef.name);
          try {
            if (!this.projectContext?.projectRoot || !fixture) throw new Error("Fixture project is unavailable");
            const verified = await verifyExplorationFile(this.projectContext.projectRoot, fixture);
            if (verified.mimeType !== fixture.mimeType) throw new Error("Fixture MIME type changed");
          } catch {
            policy = {
              decision: "denied",
              reason: "Exploration fixture is unavailable or differs from the pinned bytes.",
            };
          }
        }
        if (policy.decision !== "allowed") {
          transaction = await this.append(request.runId, request, "action.rejected", "runner", policy, {
            kind: "lease",
            ...policy,
          });
          result = { kind: "lease", ...policy };
          break;
        }
        const authorizedAt = this.now();
        const leasePolicy = leasePolicyForManifest(run.manifest);
        const leaseTimes = deriveLeaseTimes(authorizedAt, leasePolicy);
        const leasedProposal = policy.routineAction
          ? {
              ...request.payload.proposal,
              actions: structuredClone(policy.routineAction.actions),
              requestedCapabilities: structuredClone(policy.routineAction.requestedCapabilities),
            }
          : request.payload.proposal;
        const lease = {
          schema: "agent-workflow-action-lease/v1",
          leaseId: id("lease"),
          runId: request.runId,
          revision: run.state.revision + 1,
          hostId: actorId,
          target: {
            adapterSessionId: browserSessionRef ?? `session_${actorId.slice(5)}`,
            platform: run.manifest.platform,
          },
          proposal: leasedProposal,
          policy: { decision: "allowed", receiptId: id("receipt") },
          leasePolicy,
          authorizedAt: authorizedAt.toISOString(),
          ...leaseTimes,
          ...(policy.routineAction ? { extensions: { "routine.action": { id: policy.routineAction.id } } } : {}),
        };
        result = { kind: "lease", decision: "allowed", lease };
        transaction = await this.append(
          request.runId,
          request,
          "action.leased",
          "runner",
          {
            stepId: step.id,
            lease,
            ...(run.manifest.phase === "exploration" ? { branchAttempt: Boolean(request.payload.branchAttempt) } : {}),
          },
          result,
          undefined,
          run.state.revision,
        );
        break;
      }

      case "agent.evidence": {
        if (request.payload.action === "issue") {
          validateEvidenceIssue(run, actorId, request.payload, this.now());
          transaction = await this.appendTransaction(request.runId, {
            operation: request.command,
            requestId: request.requestId,
            request,
            result: null,
            receiptId: id("receipt"),
            eventId: id("evt"),
            occurredAt: this.now().toISOString(),
            type: "evidence.slot-issued",
            source: "runner",
            payload: null,
            beforeAppend: async ({ current, directory }) => {
              const currentChecked = validateEvidenceIssue(current, actorId, request.payload, this.now());
              const slot = await this.store.prepareEvidenceSlot(directory, {
                runId: request.runId,
                hostId: actorId,
                leaseId: currentChecked.lease.leaseId,
                leaseRequestId: currentChecked.leaseRequestId,
                stepId: currentChecked.step.id,
                checkpoint: request.payload.checkpoint,
                ...(currentChecked.optionalHandlerId ? { optionalHandlerId: currentChecked.optionalHandlerId } : {}),
                capability: {
                  id: currentChecked.capability.id,
                  contractVersion: currentChecked.capability.contractVersion,
                  adapterId: currentChecked.capability.adapter.id,
                },
                type: request.payload.type,
                ...(currentChecked.download ? { download: currentChecked.download } : {}),
                maximumBytes: currentChecked.maximumBytes,
                expiresAt: currentChecked.lease.expiresAt,
                ...(request.payload.type === "screenshot" && current.manifest.viewport
                  ? { viewport: structuredClone(current.manifest.viewport) }
                  : {}),
                ...(request.payload.type === "screenshot" && current.manifest.viewport ? { fullPage: false } : {}),
              });
              return {
                payload: { slot },
                result: { kind: "evidence", action: "issue", slot },
              };
            },
          });
          result = transaction.result ?? evidenceResult(transaction.event);
          break;
        }

        const { slot } = validateEvidenceRegistration(run, actorId, request.payload, this.now());
        transaction = await this.appendTransaction(request.runId, {
          operation: request.command,
          requestId: request.requestId,
          request,
          result: null,
          receiptId: id("receipt"),
          eventId: id("evt"),
          occurredAt: this.now().toISOString(),
          type: "evidence.registered",
          source: "runner",
          payload: null,
          beforeAppend: async ({ current, directory }) => {
            const { slot: currentSlot } = validateEvidenceRegistration(current, actorId, request.payload, this.now());
            if (JSON.stringify(currentSlot) !== JSON.stringify(slot)) {
              throw new WorkflowError("VALIDATION_FAILED", "Evidence slot binding changed", {
                exitCode: 3,
              });
            }
            const registered = await this.store.ingestEvidenceSlot(directory, currentSlot, {
              requestId: request.requestId,
              requestHash: protocolRequestHash(request),
              observedAt: current.state.activeLease.authorizedAt,
            });
            assertActiveLease(current, actorId, request.payload.leaseId, this.now());
            return {
              payload: { slotId: slot.slotId, artifact: registered.artifact },
              result: { kind: "evidence", action: "register", artifact: registered.artifact },
            };
          },
        });
        result = transaction.result ?? evidenceResult(transaction.event);
        break;
      }

      case "agent.commit": {
        assertActiveLease(run, actorId, request.payload.result.leaseId, this.now());
        await assertAuthenticatedExecutionCompleted(run, request.payload.result.leaseId);
        if (run.manifest.phase === "exploration") {
          const observation = request.payload.exploration;
          let observedUrl;
          try {
            observedUrl = new URL(observation?.url);
          } catch {
            observedUrl = null;
          }
          const leasedAction = run.state.activeLease.proposal.actions[0];
          const declared = request.payload.result.declaredActions;
          const actual = request.payload.result.actualActions;
          if (
            this.now().valueOf() - new Date(run.manifest.createdAt).valueOf() >=
              run.manifest.exploration.limits.minutes * 60_000 ||
            request.payload.assessment ||
            request.payload.artifacts !== undefined ||
            !observation ||
            !run.manifest.exploration.intents.includes(observation.intent) ||
            observedUrl?.origin !== new URL(run.manifest.target.canonicalUrl).origin ||
            observedUrl.username ||
            observedUrl.password ||
            observedUrl.hash ||
            declared.length !== 1 ||
            declared[0] !== leasedAction.description ||
            actual.length > 1 ||
            actual.some((item) => item !== leasedAction.description) ||
            (observation.state === "visited" && actual.length !== 1) ||
            (observation.state === "visited" && !request.payload.result.evidence.includes(observation.evidenceId)) ||
            request.payload.result.evidence.some((id) => id !== observation.evidenceId)
          ) {
            throw new WorkflowError(
              "VALIDATION_FAILED",
              "Exploration commit requires one in-scope observation and exact visit evidence",
              { exitCode: 3 },
            );
          }
          const artifact = observation.evidenceId ? run.state.exploration.artifacts[observation.evidenceId] : null;
          if (
            observation.state === "visited" &&
            (!artifact || artifact.relation.batchRequestId !== run.state.activeLeaseRequestId)
          ) {
            throw new WorkflowError("VALIDATION_FAILED", "Exploration visit evidence is not bound to this lease", {
              exitCode: 3,
            });
          }
          if (artifact) await this.store.readVerifiedEvidenceFromRun(run, observation.evidenceId);
          result = {
            kind: "commit",
            acceptedEvidence: artifact ? [artifact.artifactId] : [],
            derivedOutcome: "recorded",
          };
          transaction = await this.append(
            request.runId,
            request,
            "action.committed",
            "agent-host",
            {
              result: request.payload.result,
              exploration: observation,
              artifacts: artifact ? [artifact] : [],
            },
            result,
            async ({ current }) => {
              assertActiveLease(current, actorId, request.payload.result.leaseId, this.now());
              if (artifact) await this.store.readVerifiedEvidenceFromRun(current, observation.evidenceId);
            },
          );
          break;
        }
        if (request.payload.exploration) {
          throw new WorkflowError("VALIDATION_FAILED", "Exploration observations require an exploration run", {
            exitCode: 3,
          });
        }
        const checked = validateAssessment(run, request);
        result = {
          kind: "commit",
          acceptedEvidence: checked.artifacts.map((item) => item.artifactId),
          derivedOutcome: checked.derivedOutcome,
        };
        transaction = await this.append(
          request.runId,
          request,
          "action.committed",
          "agent-host",
          {
            result: request.payload.result,
            assessment: request.payload.assessment,
            artifacts: checked.artifacts,
            derivedOutcome: checked.derivedOutcome,
          },
          result,
          async ({ current }) => {
            assertActiveLease(current, actorId, request.payload.result.leaseId, this.now());
            await assertAuthenticatedExecutionCompleted(current, request.payload.result.leaseId);
            validateAssessment(current, request);
          },
        );
        const commandReceipt = transaction.receipt;
        if (transaction.state.status === "cleanup") {
          const started = await this.system(
            request.runId,
            "cleanup.start",
            transaction.state.revision,
            "cleanup.started",
            { reason: "Every reachable workflow step is terminal." },
          );
          transaction = await this.system(
            request.runId,
            "cleanup.complete",
            started.state.revision,
            "cleanup.completed",
            { outcome: "passed" },
          );
        }
        transaction = { ...transaction, receipt: commandReceipt };
        break;
      }

      case "agent.optional-state.authorize": {
        let checked = optionalAuthorizationContract(run, actorId, request.payload, this.now());
        await verifyOptionalEvidence(this.store, request.runId, checked);
        const authorizationId = id("optional");
        const payload = {
          authorizationId,
          parentLeaseId: checked.lease.leaseId,
          handlerId: checked.handler.id,
          stepId: checked.step.id,
          hostId: actorId,
          contractHash: checked.contractHash,
          scope: checked.scope,
          evidenceIds: checked.evidenceIds,
        };
        result = {
          kind: "optional-state",
          action: "authorized",
          authorizationId,
          parentLeaseId: payload.parentLeaseId,
          handlerId: payload.handlerId,
          contractHash: payload.contractHash,
          scope: payload.scope,
          evidenceIds: payload.evidenceIds,
        };
        transaction = await this.append(
          request.runId,
          request,
          "optional-state.authorized",
          "runner",
          payload,
          result,
          async ({ current }) => {
            checked = optionalAuthorizationContract(current, actorId, request.payload, this.now());
            await verifyOptionalEvidence(this.store, request.runId, checked);
          },
        );
        break;
      }

      case "agent.optional-state.complete": {
        const authorization = run.state.activeOptionalAuthorization;
        if (
          !authorization ||
          authorization.authorizationId !== request.payload.authorizationId ||
          authorization.parentLeaseId !== request.payload.parentLeaseId ||
          authorization.handlerId !== request.payload.handlerId ||
          JSON.stringify(authorization.evidenceIds) !== JSON.stringify(request.payload.evidenceIds)
        ) {
          throw new WorkflowError(
            "ILLEGAL_TRANSITION",
            "Optional-state completion does not match the active authorization",
            {
              exitCode: 4,
            },
          );
        }
        assertActiveLease(run, actorId, request.payload.parentLeaseId, this.now());
        await verifyOptionalEvidence(this.store, request.runId, authorization);
        const payload = structuredClone(authorization);
        result = {
          kind: "optional-state",
          action: "applied",
          authorizationId: payload.authorizationId,
          parentLeaseId: payload.parentLeaseId,
          handlerId: payload.handlerId,
          contractHash: payload.contractHash,
          scope: payload.scope,
          evidenceIds: payload.evidenceIds,
        };
        transaction = await this.append(
          request.runId,
          request,
          "optional-state.applied",
          "agent-host",
          payload,
          result,
          async ({ current }) => {
            assertActiveLease(current, actorId, request.payload.parentLeaseId, this.now());
            if (JSON.stringify(current.state.activeOptionalAuthorization) !== JSON.stringify(authorization)) {
              throw new WorkflowError("REVISION_CONFLICT", "Optional-state authority is no longer adjacent", {
                exitCode: 4,
              });
            }
            await verifyOptionalEvidence(this.store, request.runId, authorization);
          },
        );
        break;
      }

      case "agent.heartbeat": {
        const heartbeatAt = this.now();
        const lease = assertActiveLease(run, actorId, request.payload.leaseId, heartbeatAt);
        const leasePolicy = leasePolicyForManifest(run.manifest);
        const expiresAt = deriveHeartbeatExpiry(heartbeatAt, lease.hardExpiresAt, leasePolicy);
        result = { kind: "acknowledgement" };
        transaction = await this.appendTransaction(request.runId, {
          operation: request.command,
          requestId: request.requestId,
          request,
          result,
          receiptId: id("receipt"),
          eventId: id("evt"),
          occurredAt: heartbeatAt.toISOString(),
          type: "lease.heartbeat",
          source: "agent-host",
          payload: {
            leaseId: request.payload.leaseId,
            expiresAt,
            progress: request.payload.progress,
          },
          beforeAppend: async ({ current }) => {
            assertActiveLease(current, actorId, request.payload.leaseId, this.now());
          },
        });
        break;
      }

      case "agent.reconcile": {
        result = { kind: "reconciliation", classification: request.payload.classification };
        const reconciledLeaseId = request.payload.leaseId ?? run.state.uncertainLeaseId;
        transaction = await this.append(
          request.runId,
          request,
          "reconciliation.completed",
          "agent-host",
          {
            ...(request.payload.leaseId ? { leaseId: request.payload.leaseId } : {}),
            ...(request.payload.previousHostId ? { previousHostId: request.payload.previousHostId } : {}),
            classification: request.payload.classification,
            rationale: request.payload.rationale,
          },
          result,
          reconciledLeaseId
            ? async ({ current }) => {
                await consumeAuthenticatedUploadsForLease(current, reconciledLeaseId, {
                  outcome: "reconciled",
                  now: this.now,
                });
              }
            : undefined,
        );
        const commandReceipt = transaction.receipt;
        if (transaction.state.status === "cleanup") {
          const cleanupStarted = await this.system(
            request.runId,
            "cleanup.start",
            transaction.state.revision,
            "cleanup.started",
            { reason: "Indeterminate reconciliation requires terminal cleanup." },
          );
          transaction = await this.system(
            request.runId,
            "cleanup.complete",
            cleanupStarted.state.revision,
            "cleanup.completed",
            { outcome: "passed" },
          );
        } else if (run.manifest.nonResumable && transaction.state.status === "paused") {
          transaction = await this.system(
            request.runId,
            "reconciliation.non-resumable",
            transaction.state.revision,
            "run.abandoned",
            {
              reason:
                "A reconciled evaluation cannot resume or support clean proof; preserve this run and launch a fresh evaluation.",
            },
          );
        } else if (run.manifest.authentication && request.payload.classification === "not-executed") {
          transaction = await this.requireAuthentication(
            request.runId,
            transaction.state.revision,
            run.manifest.authentication.targetId,
            "marker-not-found",
          );
        }
        transaction = { ...transaction, receipt: commandReceipt };
        break;
      }

      case "agent.exploration.finish": {
        if (!run.state.exploration || run.state.activeLease || run.state.uncertainLeaseId) {
          throw new WorkflowError("ILLEGAL_TRANSITION", "Exploration cannot finish with an active or uncertain lease", {
            exitCode: 4,
          });
        }
        const uncovered = run.manifest.exploration.intents.filter(
          (intent) => !run.state.exploration.visits.some((visit) => visit.intent === intent),
        );
        if (
          request.payload.coverage.length !== uncovered.length ||
          new Set(request.payload.coverage.map((item) => item.intent)).size !== uncovered.length ||
          request.payload.coverage.some((item) => !uncovered.includes(item.intent)) ||
          (request.payload.disposition === "complete" &&
            request.payload.coverage.some((item) => item.state === "unvisited"))
        ) {
          throw new WorkflowError("VALIDATION_FAILED", "Finish must classify each uncovered intent exactly once", {
            exitCode: 3,
          });
        }
        result = { kind: "acknowledgement" };
        transaction = await this.append(
          request.runId,
          request,
          "exploration.finished",
          "agent-host",
          { ...request.payload, hostId: actorId },
          result,
        );
        break;
      }

      case "agent.release":
        result = { kind: "acknowledgement" };
        transaction = await this.append(
          request.runId,
          request,
          "host.released",
          "agent-host",
          { hostId: actorId, reason: request.payload.reason },
          result,
        );
        break;

      default:
        throw new WorkflowError("INVALID_REQUEST", `Unsupported agent command: ${request.command}`, { exitCode: 2 });
    }
    const response = this.response(request, transaction, result, run.workflow);
    const published = await this.store.writeProtocolResponse(
      request.runId,
      request.requestId,
      protocolRequestHash(request),
      response,
    );
    if (request.command === "agent.evidence" && request.payload.action === "register") {
      await this.store.evidenceCutPoint("after-response-cache", {
        artifact: structuredClone(published.response.result.artifact),
        response: structuredClone(published.response),
      });
    }
    return published.response;
  }
}
