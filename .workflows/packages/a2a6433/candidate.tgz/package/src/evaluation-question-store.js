import { randomUUID } from "node:crypto";
import { constants } from "node:fs";
import { link, lstat, mkdir, open, readdir, unlink } from "node:fs/promises";
import { dirname, join, relative, resolve, sep } from "node:path";

import { WorkflowError } from "./errors.js";

const RUN_ID = /^run_[A-Za-z0-9_-]+$/u;
const QUESTION_ID = /^question_[a-f0-9]{32}$/u;
export const QUESTION_WRITE_AUTHORITY = Symbol("evaluation-question-write-authority");

function fail(code, message) {
  throw new WorkflowError(code, message, { exitCode: 3 });
}

function assertInside(root, path) {
  const suffix = relative(resolve(root), resolve(path));
  if (suffix.startsWith("..") || resolve(root, suffix) !== resolve(path))
    fail("PATH_TRAVERSAL", "Evaluation question path escapes its root");
}

async function assertDirectory(path) {
  const entry = await lstat(path);
  if (!entry.isDirectory() || entry.isSymbolicLink())
    fail("QUESTION_STORE_UNSAFE", "Evaluation question paths cannot be symlinks");
}

async function assertSafeAncestry(root, path) {
  assertInside(root, path);
  let cursor = resolve(root);
  await assertDirectory(cursor);
  for (const part of relative(cursor, resolve(path)).split(sep).filter(Boolean)) {
    cursor = join(cursor, part);
    try {
      const entry = await lstat(cursor);
      if (entry.isSymbolicLink()) fail("QUESTION_STORE_UNSAFE", "Question ancestry cannot contain symlinks");
      if (cursor !== resolve(path) && !entry.isDirectory())
        fail("QUESTION_STORE_UNSAFE", "Question ancestry must contain only directories");
    } catch (error) {
      if (error.code === "ENOENT") break;
      throw error;
    }
  }
}

async function syncDirectory(path) {
  const handle = await open(path, "r");
  try {
    await handle.sync();
  } finally {
    await handle.close();
  }
}

async function immutableWrite(path, bytes) {
  const temporary = `${path}.${randomUUID()}.tmp`;
  const handle = await open(temporary, "wx", 0o600);
  try {
    await handle.writeFile(bytes);
    await handle.sync();
  } finally {
    await handle.close();
  }
  try {
    await link(temporary, path);
    await syncDirectory(dirname(path));
  } catch (error) {
    if (error.code === "EEXIST") fail("IMMUTABLE_QUESTION_EXISTS", "Evaluation questions cannot be replaced");
    throw error;
  } finally {
    await unlink(temporary).catch(() => {});
  }
}

async function readRegular(path) {
  await assertDirectory(dirname(path));
  const entry = await lstat(path);
  if (!entry.isFile() || entry.isSymbolicLink()) fail("QUESTION_RECORD_CORRUPT", "Question is not a file");
  const handle = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    const opened = await handle.stat();
    if (opened.dev !== entry.dev || opened.ino !== entry.ino || opened.size !== entry.size)
      fail("QUESTION_RECORD_CORRUPT", "Question changed while being read");
    return await handle.readFile("utf8");
  } finally {
    await handle.close();
  }
}

export class EvaluationQuestionStore {
  constructor(root, { registry } = {}) {
    this.root = resolve(root);
    this.questionsRoot = join(this.root, "evaluation-questions");
    this.registry = registry;
  }

  async init() {
    await mkdir(this.root, { recursive: true });
    await assertDirectory(this.root);
    await mkdir(this.questionsRoot, { recursive: true });
    await assertDirectory(this.questionsRoot);
    return this;
  }

  runRoot(runId) {
    if (!RUN_ID.test(runId)) fail("INVALID_QUESTION_ID", "Invalid run ID");
    const path = resolve(this.questionsRoot, runId);
    assertInside(this.questionsRoot, path);
    return path;
  }

  recordPath(runId, questionId) {
    if (!QUESTION_ID.test(questionId)) fail("INVALID_QUESTION_ID", "Invalid question ID");
    const root = this.runRoot(runId);
    const path = resolve(root, `${questionId}.json`);
    assertInside(root, path);
    return path;
  }

  async writeQuestion(record, authority) {
    if (authority !== QUESTION_WRITE_AUTHORITY)
      fail("QUESTION_WRITE_FORBIDDEN", "Questions require verified evaluation evidence");
    this.registry?.validate("evaluationQuestion", record);
    const root = this.runRoot(record.runId);
    await assertSafeAncestry(this.questionsRoot, root);
    await mkdir(root).catch((error) => {
      if (error.code !== "EEXIST") throw error;
    });
    await assertDirectory(root);
    const path = this.recordPath(record.runId, record.questionId);
    await assertSafeAncestry(this.questionsRoot, path);
    await immutableWrite(path, Buffer.from(`${JSON.stringify(record, null, 2)}\n`));
    return structuredClone(record);
  }

  async readQuestion(runId, questionId) {
    const path = this.recordPath(runId, questionId);
    await assertSafeAncestry(this.questionsRoot, path);
    let record;
    try {
      record = JSON.parse(await readRegular(path));
    } catch (error) {
      if (error instanceof SyntaxError) fail("QUESTION_RECORD_CORRUPT", "Question is invalid JSON");
      throw error;
    }
    this.registry?.validate("evaluationQuestion", record);
    if (record.runId !== runId || record.questionId !== questionId)
      fail("QUESTION_ID_MISMATCH", "Question path does not match record identity");
    return record;
  }

  async listQuestionIds(runId) {
    const root = this.runRoot(runId);
    try {
      await assertSafeAncestry(this.questionsRoot, root);
      await assertDirectory(root);
    } catch (error) {
      if (error.code === "ENOENT") return [];
      throw error;
    }
    return (await readdir(root))
      .filter((name) => /^question_[a-f0-9]{32}\.json$/u.test(name))
      .sort()
      .map((name) => name.slice(0, -5));
  }

  async listQuestions(runId) {
    return Promise.all((await this.listQuestionIds(runId)).map((id) => this.readQuestion(runId, id)));
  }

  async listAll() {
    let entries;
    try {
      entries = await readdir(this.questionsRoot, { withFileTypes: true });
    } catch (error) {
      if (error.code === "ENOENT") return [];
      throw error;
    }
    const runIds = entries.filter((entry) => entry.isDirectory() && RUN_ID.test(entry.name)).map((entry) => entry.name);
    return (await Promise.all(runIds.sort().map((runId) => this.listQuestions(runId)))).flat();
  }

  async listAllRecords() {
    let entries;
    try {
      entries = await readdir(this.questionsRoot, { withFileTypes: true });
    } catch (error) {
      if (error.code === "ENOENT") return [];
      throw error;
    }
    const records = [];
    for (const entry of entries.filter((item) => item.isDirectory() && RUN_ID.test(item.name)).sort()) {
      for (const questionId of await this.listQuestionIds(entry.name)) {
        try {
          records.push({ integrity: "verified", record: await this.readQuestion(entry.name, questionId) });
        } catch (error) {
          records.push({
            integrity: "degraded",
            runId: entry.name,
            questionId,
            errorCode: error.code ?? "QUESTION_RECORD_CORRUPT",
          });
        }
      }
    }
    return records;
  }
}
