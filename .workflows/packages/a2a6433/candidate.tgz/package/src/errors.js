export class WorkflowError extends Error {
  constructor(code, message, { exitCode = 1, details = {} } = {}) {
    super(message);
    this.name = "WorkflowError";
    this.code = code;
    this.exitCode = exitCode;
    this.details = details;
  }
}

export function asWorkflowError(error) {
  if (error instanceof WorkflowError) return error;

  return new WorkflowError("INTERNAL_ERROR", error?.message ?? String(error), {
    exitCode: 1,
  });
}
