/* eslint-disable max-lines -- batch preflight, durable launch, recovery, and truthful projection share one integrity boundary. */
import { randomUUID } from "node:crypto";
import { readFile } from "node:fs/promises";

import { parse as parseYaml } from "yaml";

import { WorkflowError } from "./errors.js";
import { assertPerspectiveSnapshot, resolvePerspective } from "./evaluation-perspectives.js";
import { resolveApplicableRequirements } from "./evaluation-requirements.js";
import { sha256Bytes } from "./evidence.js";
import { FindingStore } from "./finding-store.js";
import { verifyPromotionTruth, verifyQualificationTruth } from "./lifecycle.js";
import { verifyCatalogWorkflowSource } from "./project-workflow-catalog.js";
import { launchPinnedRun, resolveLaunchAuthentication } from "./run-launch.js";
import { buildRunReport } from "./run-report.js";
import { resolveRunTarget } from "./run-target.js";
import { sha256 } from "./stable-json.js";
import { resolveWorkflow, validateWorkflowSemantics } from "./workflow.js";
import { resolvePlatformViewport } from "./platform-viewport.js";
import { validateAuthenticatedActions } from "./authenticated-browser-execution.js";
import { verifyRoutineActionReviewAttestation } from "./routine-action-review-attestation.js";

const VIEWPORTS = Object.freeze({
  "desktop-web": Object.freeze({ width: 1440, height: 900 }),
  "mobile-web": Object.freeze({ width: 393, height: 852 }),
});

function fail(code, message, details) {
  throw new WorkflowError(code, message, { exitCode: 3, details });
}

function errorReceipt(error) {
  return { code: error.code ?? "PERSPECTIVE_MEMBER_LAUNCH_FAILED", message: error.message };
}

function normalizedSelections(selections) {
  if (!Array.isArray(selections) || selections.length === 0)
    fail("PERSPECTIVE_SELECTION_REQUIRED", "At least one evaluation perspective is required");
  const selected = selections.map((selection) => {
    if (!selection || typeof selection !== "object" || Array.isArray(selection))
      fail("PERSPECTIVE_SELECTION_INVALID", "Perspective selections must be objects");
    const platform = selection.platform;
    if (!VIEWPORTS[platform])
      fail("PERSPECTIVE_PLATFORM_UNAVAILABLE", `Perspective batches do not support platform ${platform}`);
    let perspective;
    try {
      perspective = resolvePerspective({ id: selection.perspectiveId, platform });
    } catch (error) {
      fail("PERSPECTIVE_SELECTION_INVALID", error.message);
    }
    return { perspectiveId: perspective.id, platform, required: selection.required !== false, perspective };
  });
  const identities = selected.map(({ perspectiveId, platform }) => `${perspectiveId}:${platform}`);
  if (new Set(identities).size !== identities.length)
    fail("PERSPECTIVE_SELECTION_DUPLICATE", "Perspective selections must be unique");
  const platforms = [...new Set(selected.map(({ platform }) => platform))].sort();
  for (const platform of platforms) {
    if (!selected.some((item) => item.platform === platform && item.perspectiveId === "neutral")) {
      selected.push({
        perspectiveId: "neutral",
        platform,
        required: true,
        perspective: resolvePerspective({ id: "neutral", platform }),
      });
    }
  }
  return selected.sort(
    (a, b) =>
      a.platform.localeCompare(b.platform) ||
      (a.perspectiveId === "neutral"
        ? -1
        : b.perspectiveId === "neutral"
          ? 1
          : a.perspectiveId.localeCompare(b.perspectiveId)),
  );
}

async function candidateSource(source, { runStore }) {
  const bytes = source.workflowSource?.bytes ?? (source.workflowPath ? await readFile(source.workflowPath) : null);
  if (!bytes) fail("PERSPECTIVE_SOURCE_INVALID", "Candidate source requires verified workflow bytes");
  const parsedWorkflow = parseYaml(bytes.toString("utf8"));
  if (source.workflowSource?.workflow && sha256(source.workflowSource.workflow) !== sha256(parsedWorkflow))
    fail("PERSPECTIVE_SOURCE_CONFLICT", "Candidate workflow does not match its pinned source bytes");
  const assertedHash = source.workflowSource?.sourceBytesHash;
  const actualHash = sha256Bytes(bytes);
  if (assertedHash && assertedHash !== actualHash)
    fail("PERSPECTIVE_SOURCE_CONFLICT", "Candidate source hash does not match its pinned bytes");
  if (source.workflowSource?.provenance) await verifyCatalogWorkflowSource(source.workflowSource);
  const workflow = parsedWorkflow;
  const validated = runStore.registry?.validate("workflow", workflow) ?? workflow;
  validateWorkflowSemantics(validated);
  if (validated.metadata.lifecycle !== "candidate" || !Number.isSafeInteger(validated.metadata.candidateRevision))
    fail("PERSPECTIVE_SOURCE_INVALID", "Candidate batch requires an exact candidate revision");
  if (!["anonymous", "named-profile"].includes(validated.target.identity.requirement))
    fail("PERSPECTIVE_SOURCE_INVALID", "Candidate batch requires an anonymous or named-profile workflow identity");
  if (!validated.evaluation?.resetStepId || !validated.evaluation?.cleanupStepId)
    fail("PERSPECTIVE_SOURCE_INVALID", "Candidate batch requires reset and cleanup steps");
  for (const step of validated.steps) {
    if (!step.routineActionBatches?.length)
      fail("PERSPECTIVE_SOURCE_INVALID", `Candidate batch step ${step.id} requires a pinned routine action batch`);
    const batchIds = step.routineActionBatches.map((batch) => batch.id);
    if (new Set(batchIds).size !== batchIds.length)
      fail("PERSPECTIVE_SOURCE_INVALID", `Candidate batch step ${step.id} has duplicate routine action identities`);
    for (const handlerId of step.optionalHandlers ?? []) {
      const handler = validated.optionalStateHandlers.find((item) => item.id === handlerId);
      const evidence = handler?.evidence;
      if (
        handler?.maxApplications !== 1 ||
        evidence?.length !== 1 ||
        evidence[0]?.type !== "screenshot" ||
        !handler.routineDismissal
      )
        fail(
          "PERSPECTIVE_SOURCE_INVALID",
          `Candidate batch optional handler ${handlerId} requires one scoped routine dismissal and screenshot`,
        );
    }
    for (const batch of step.routineActionBatches) {
      const hasUpload = batch.actions.some((action) => action.kind === "upload-file");
      if (
        !batch.requestedCapabilities.includes("browser.control") ||
        (hasUpload && !batch.requestedCapabilities.includes("file-upload"))
      )
        fail(
          "PERSPECTIVE_SOURCE_INVALID",
          `Candidate batch step ${step.id} batch ${batch.id} has an invalid capability contract`,
        );
    }
  }
  const sourceBytesHash = actualHash;
  if (!sourceBytesHash) fail("PERSPECTIVE_SOURCE_INVALID", "Candidate source bytes must be pinned");
  return {
    sourceKind: "candidate",
    workflow: validated,
    pinned: {
      sourceKind: "candidate",
      workflowId: validated.metadata.id,
      candidateRevision: validated.metadata.candidateRevision,
      sourceBytesHash,
    },
  };
}

async function promotedSource(source, { lifecycleStore, runStore, platforms }) {
  if (!lifecycleStore) fail("PERSPECTIVE_LIFECYCLE_REQUIRED", "Promoted batches require lifecycle verification");
  let revision = source.revision;
  if (!revision) {
    let versions;
    try {
      versions = await lifecycleStore.listVersions(source.workflowId);
    } catch (error) {
      if (error.code === "ENOENT") fail("PROMOTION_NOT_FOUND", "No promoted revision is available");
      throw error;
    }
    revision = versions.at(-1)?.revision;
  }
  if (!revision) fail("PROMOTION_NOT_FOUND", "No promoted revision is available");
  const truth = await verifyPromotionTruth({ workflowId: source.workflowId, revision, lifecycleStore, runStore });
  const qualifications = {};
  const records = await lifecycleStore.listRecords("qualification");
  for (const platform of platforms) {
    const requested = source.qualifications?.[platform];
    const record = requested
      ? records.find((item) => item.qualificationId === requested)
      : [...records]
          .reverse()
          .find(
            (item) => item.workflowId === source.workflowId && item.revision === revision && item.platform === platform,
          );
    if (!record) fail("QUALIFICATION_MISSING", `Verified qualification is required for ${platform}`);
    let checked;
    try {
      checked = await verifyQualificationTruth({
        qualification: record,
        lifecycleStore,
        runStore,
        expected: { workflowId: source.workflowId, revision, platform },
      });
    } catch (error) {
      if (error instanceof WorkflowError) throw error;
      fail("QUALIFICATION_MISMATCH", `Qualification proof for ${platform} is unavailable or invalid`, {
        cause: error.code,
      });
    }
    qualifications[platform] = checked.qualification;
  }
  return {
    sourceKind: "promoted",
    workflow: truth.source,
    qualifications,
    pinned: {
      sourceKind: "promoted",
      workflowId: source.workflowId,
      revision,
      contentHash: truth.promoted.record.contentHash,
      qualifications: Object.fromEntries(
        Object.entries(qualifications).map(([platform, value]) => [platform, value.qualificationId]),
      ),
    },
  };
}

function pinInquiryPolicy(policy = {}) {
  const content = {
    revision: policy.revision ?? 0,
    depth: policy.depth ?? "balanced",
    optionalQuestionsPerStep: policy.optionalQuestionsPerStep ?? 2,
    optionalQuestionsPerRun: policy.optionalQuestionsPerRun ?? 16,
  };
  return { ...content, policyHash: sha256(content) };
}

async function preflight({
  source,
  target = {},
  selections,
  policy = {},
  inquiryPolicy,
  requirementsCatalog,
  runStore,
  lifecycleStore,
}) {
  if (!source || !["candidate", "promoted"].includes(source.sourceKind))
    fail("PERSPECTIVE_SOURCE_INVALID", "sourceKind must be candidate or promoted");
  const normalized = normalizedSelections(selections);
  const platforms = [...new Set(normalized.map(({ platform }) => platform))];
  const resolvedSource =
    source.sourceKind === "candidate"
      ? await candidateSource(source, { runStore })
      : await promotedSource(source, { lifecycleStore, runStore, platforms });
  const runs = normalized.map((selection) => {
    const resolved = resolveWorkflow(resolvedSource.workflow, selection.platform, "platform-v2");
    const qualification = resolvedSource.qualifications?.[selection.platform];
    if (qualification && qualification.effectiveHash !== resolved.effectiveHash)
      fail("QUALIFICATION_STALE", `${selection.platform} qualification hash is stale`);
    return { ...selection, resolved, qualification };
  });
  const fallbackCatalog = {
    schema: "agent-workflow-requirements/v1",
    projectId: resolvedSource.pinned.workflowId,
    requirements: [],
  };
  const catalog = requirementsCatalog?.catalog ?? fallbackCatalog;
  const catalogHash = requirementsCatalog?.catalogHash ?? sha256(fallbackCatalog);
  const requirementSelections = runs.map(({ perspectiveId, platform, perspective }) => ({
    perspectiveId,
    platform,
    ...resolveApplicableRequirements({
      catalog,
      workflowId: resolvedSource.pinned.workflowId,
      platform,
      perspectiveId,
      criterionIds: perspective.criteria.map((criterion) => criterion.id),
    }),
  }));
  for (const run of runs) {
    run.requirementSelection = requirementSelections.find(
      (item) => item.perspectiveId === run.perspectiveId && item.platform === run.platform,
    );
    run.effectiveRubricHash = sha256({
      rubricHash: run.perspective.rubricHash,
      requirementsHash: run.requirementSelection.requirementsHash,
    });
  }
  const pinnedInquiryPolicy = pinInquiryPolicy(inquiryPolicy);
  const applicationTarget = target.applicationTarget;
  const selectedTarget = resolveRunTarget(runs[0].resolved.workflow, {
    applicationTarget,
    targetUrl: target.targetUrl,
  });
  for (const run of runs.slice(1)) {
    if (
      sha256(resolveRunTarget(run.resolved.workflow, { applicationTarget, targetUrl: target.targetUrl })) !==
      sha256(selectedTarget)
    )
      fail("PERSPECTIVE_TARGET_MISMATCH", "Every batch member must use the same target");
  }
  const authenticationSession = await resolveLaunchAuthentication({
    identityRequirement: resolvedSource.workflow.target.identity.requirement,
    projectContext: target.projectContext,
    applicationTarget,
    storeRoot: runStore.root,
    authSessionStore: target.authSessionStore,
    registry: runStore.registry,
  });
  if (resolvedSource.workflow.target.identity.requirement === "named-profile" && !authenticationSession)
    fail(
      "PERSPECTIVE_AUTHENTICATION_REQUIRED",
      "Named-profile perspective evaluation requires the configured Studio-owned user session",
    );
  if (
    resolvedSource.workflow.steps.some((step) =>
      (step.routineActionBatches ?? []).some((batch) => batch.actions.some((action) => action.kind === "upload-file")),
    ) &&
    !authenticationSession
  )
    fail(
      "PERSPECTIVE_AUTHENTICATION_REQUIRED",
      "Perspective file upload requires the configured Studio-owned user session",
    );
  if (resolvedSource.sourceKind === "candidate" && authenticationSession) {
    for (const step of resolvedSource.workflow.steps) {
      for (const batch of step.routineActionBatches) {
        try {
          validateAuthenticatedActions(batch.actions);
        } catch {
          fail(
            "PERSPECTIVE_SOURCE_INVALID",
            `Candidate batch step ${step.id} batch ${batch.id} uses an unsupported authenticated action`,
          );
        }
      }
    }
    await verifyRoutineActionReviewAttestation(runStore, resolvedSource.workflow);
  }
  const pinnedPolicy = { findingSeverityGate: policy.findingSeverityGate ?? "high", ...structuredClone(policy) };
  const pinned = {
    source: resolvedSource.pinned,
    target: selectedTarget,
    identity: structuredClone(resolvedSource.workflow.target.identity),
    authentication: authenticationSession ? structuredClone(authenticationSession) : null,
    policy: pinnedPolicy,
    inquiryPolicy: pinnedInquiryPolicy,
    requirementSnapshot: { catalogHash, selections: requirementSelections },
    selections: runs.map(({ perspectiveId, platform, required, perspective, effectiveRubricHash }) => ({
      perspectiveId,
      platform,
      required,
      rubric: perspective,
      effectiveRubricHash,
    })),
  };
  return { ...pinned, runs, workflow: resolvedSource.workflow, authenticationSession };
}

function memberIdentity(batchId, selection) {
  return `run_batch_${sha256({ batchId, perspectiveId: selection.perspectiveId, platform: selection.platform }).slice(7, 31)}`;
}

function controlId(members, platform) {
  return members.find((member) => member.platform === platform && member.perspectiveId === "neutral").runId;
}

function assertBatchJournal(batch) {
  const actualInputHash = sha256({
    source: batch.source,
    target: batch.target,
    ...(Object.hasOwn(batch, "identity") ? { identity: batch.identity } : {}),
    ...(Object.hasOwn(batch, "authentication") ? { authentication: batch.authentication } : {}),
    policy: batch.policy,
    ...(batch.inquiryPolicy ? { inquiryPolicy: batch.inquiryPolicy } : {}),
    ...(batch.requirementSnapshot ? { requirementSnapshot: batch.requirementSnapshot } : {}),
    selections: batch.selections,
  });
  if (actualInputHash !== batch.inputHash) fail("PERSPECTIVE_BATCH_CORRUPT", "Batch pinned input hash does not match");
  if (batch.inquiryPolicy) {
    const { policyHash, ...content } = batch.inquiryPolicy;
    if (sha256(content) !== policyHash)
      fail("PERSPECTIVE_BATCH_CORRUPT", "Batch inquiry policy hash does not match its content");
  }
  const expected = batch.selections.map((selection) => {
    assertPerspectiveSnapshot(selection.rubric, { platform: selection.platform });
    if (selection.rubric.id !== selection.perspectiveId || typeof selection.required !== "boolean")
      fail("PERSPECTIVE_BATCH_CORRUPT", "Batch selection does not match its pinned rubric");
    if (batch.requirementSnapshot) {
      const applicable = batch.requirementSnapshot.selections.filter(
        (item) => item.perspectiveId === selection.perspectiveId && item.platform === selection.platform,
      );
      if (
        applicable.length !== 1 ||
        sha256({ requirements: applicable[0].requirements }) !== applicable[0].requirementsHash
      )
        fail("PERSPECTIVE_BATCH_CORRUPT", "Batch applicable requirement snapshot is inconsistent");
      if (
        selection.effectiveRubricHash !==
        sha256({ rubricHash: selection.rubric.rubricHash, requirementsHash: applicable[0].requirementsHash })
      )
        fail("PERSPECTIVE_BATCH_CORRUPT", "Batch effective rubric hash is inconsistent");
    }
    return {
      perspectiveId: selection.perspectiveId,
      platform: selection.platform,
      required: selection.required,
      runId: memberIdentity(batch.batchId, selection),
      controlRunId: null,
    };
  });
  for (const member of expected)
    if (member.perspectiveId !== "neutral") member.controlRunId = controlId(expected, member.platform);
  if (batch.members.length !== expected.length)
    fail("PERSPECTIVE_BATCH_CORRUPT", "Batch membership does not match pinned selections");
  for (const wanted of expected) {
    const actual = batch.members.find((member) => member.runId === wanted.runId);
    if (!actual || Object.entries(wanted).some(([key, value]) => actual[key] !== value))
      fail("PERSPECTIVE_BATCH_CORRUPT", "Batch membership was changed after launch intent");
  }
  return batch;
}

function assertExistingMember(existing, { batchId, member, selection, prepared, sessionPredecessorRunId }) {
  const perspective = existing.manifest.evaluationPerspective;
  const workflowRef = existing.manifest.workflowRef;
  if (
    perspective?.batchId !== batchId ||
    perspective?.id !== member.perspectiveId ||
    perspective?.rubricHash !== selection.perspective.rubricHash ||
    (selection.effectiveRubricHash && perspective?.effectiveRubricHash !== selection.effectiveRubricHash) ||
    (prepared.inquiryPolicy && sha256(perspective?.inquiryPolicy) !== sha256(prepared.inquiryPolicy)) ||
    (selection.requirementSelection &&
      sha256(perspective?.requirementSnapshot) !==
        sha256({
          catalogHash: prepared.requirementSnapshot.catalogHash,
          requirementsHash: selection.requirementSelection.requirementsHash,
          requirements: selection.requirementSelection.requirements,
        })) ||
    perspective?.controlRunId !== member.controlRunId ||
    perspective?.sessionPredecessorRunId !== sessionPredecessorRunId ||
    existing.manifest.platform !== member.platform ||
    workflowRef?.sourceKind !== prepared.source.sourceKind ||
    workflowRef?.effectiveHash !== selection.resolved.effectiveHash ||
    workflowRef?.effectiveHashVersion !== selection.resolved.effectiveHashVersion ||
    sha256(existing.manifest.target) !== sha256(prepared.target) ||
    sha256(existing.manifest.identity) !== sha256(prepared.identity) ||
    sha256(existing.manifest.authentication ?? null) !== sha256(prepared.authentication) ||
    (prepared.source.sourceKind === "candidate" &&
      (workflowRef.candidateRevision !== prepared.source.candidateRevision ||
        workflowRef.sourceBytesHash !== prepared.source.sourceBytesHash)) ||
    (prepared.source.sourceKind === "promoted" && workflowRef.revision !== prepared.source.revision)
  )
    fail("PERSPECTIVE_RUN_CONFLICT", `Deterministic run identity ${member.runId} does not match its batch member`);
}

function launchCardFromRun(run) {
  return {
    runId: run.manifest.runId,
    phase: run.manifest.phase,
    workflow: run.manifest.workflowRef,
    platform: run.manifest.platform,
    profile: run.manifest.profile,
    viewport: run.manifest.viewport ?? null,
    resetContractHash: run.manifest.resetContractHash,
    leasePolicy: run.manifest.leasePolicy,
    policyHash: run.manifest.policyHash,
    target: run.manifest.target,
  };
}

async function launchPerspectiveBatchLocked({
  batchId: requestedBatchId,
  source,
  target,
  selections,
  policy,
  inquiryPolicy,
  requirementsCatalog,
  runStore,
  batchStore,
  lifecycleStore,
  now = () => new Date(),
  launchRun = launchPinnedRun,
  observedBatchIds = new Set(),
}) {
  const prepared = await preflight({
    source,
    target,
    selections,
    policy,
    inquiryPolicy,
    requirementsCatalog,
    runStore,
    lifecycleStore,
  });
  const inputHash = sha256({
    source: prepared.source,
    target: prepared.target,
    identity: prepared.identity,
    authentication: prepared.authentication,
    policy: prepared.policy,
    inquiryPolicy: prepared.inquiryPolicy,
    requirementSnapshot: prepared.requirementSnapshot,
    selections: prepared.selections,
  });
  let batchId = requestedBatchId;
  if (!batchId) {
    const recoverable = (await batchStore.list()).find(
      (batch) =>
        batch.inputHash === inputHash &&
        (["launching", "partial"].includes(batch.status) || !observedBatchIds.has(batch.batchId)),
    );
    batchId = recoverable?.batchId ?? `batch_${randomUUID().replaceAll("-", "").slice(0, 24)}`;
  }
  const members = prepared.runs.map((selection) => ({
    perspectiveId: selection.perspectiveId,
    platform: selection.platform,
    required: selection.required,
    runId: memberIdentity(batchId, selection),
    controlRunId: null,
    status: "pending",
  }));
  for (const member of members)
    if (member.perspectiveId !== "neutral") member.controlRunId = controlId(members, member.platform);
  let journal = await batchStore.createIntent({
    schema: "agent-workflow-perspective-batch/v1",
    batchId,
    inputHash,
    createdAt: now().toISOString(),
    source: prepared.source,
    target: prepared.target,
    identity: prepared.identity,
    authentication: prepared.authentication,
    policy: prepared.policy,
    inquiryPolicy: prepared.inquiryPolicy,
    requirementSnapshot: prepared.requirementSnapshot,
    selections: prepared.selections,
    members,
    status: "launching",
  });
  assertBatchJournal(journal);
  for (const member of journal.members) {
    const memberIndex = journal.members.findIndex((item) => item.runId === member.runId);
    const sessionPredecessorRunId =
      prepared.identity.requirement === "named-profile" ? (journal.members[memberIndex - 1]?.runId ?? null) : undefined;
    if (member.status === "launched") {
      try {
        const durable = await runStore.readRun(member.runId);
        const selection = prepared.runs.find(
          (item) => item.perspectiveId === member.perspectiveId && item.platform === member.platform,
        );
        assertExistingMember(durable, { batchId, member, selection, prepared, sessionPredecessorRunId });
        continue;
      } catch (error) {
        if (error.code !== "RUN_NOT_FOUND") throw error;
        member.status = "pending";
        delete member.launchCard;
      }
    }
    const selection = prepared.runs.find(
      (item) => item.perspectiveId === member.perspectiveId && item.platform === member.platform,
    );
    try {
      try {
        const existing = await runStore.readRun(member.runId);
        assertExistingMember(existing, { batchId, member, selection, prepared, sessionPredecessorRunId });
      } catch (error) {
        if (error.code !== "RUN_NOT_FOUND") throw error;
        await launchRun({
          phase: "evaluation",
          workflow: selection.resolved.workflow,
          workflowRef: {
            id: prepared.source.workflowId,
            sourceKind: prepared.source.sourceKind,
            ...(prepared.source.candidateRevision
              ? {
                  candidateRevision: prepared.source.candidateRevision,
                  sourceBytesHash: prepared.source.sourceBytesHash,
                }
              : { revision: prepared.source.revision }),
            contentHash: selection.resolved.sourceHash,
            platform: member.platform,
            effectiveHash: selection.resolved.effectiveHash,
            effectiveHashVersion: selection.resolved.effectiveHashVersion,
          },
          platform: member.platform,
          profile: member.platform === "desktop-web" ? "desktop-evaluation" : "mobile-evaluation",
          store: runStore,
          now,
          runId: member.runId,
          viewport: resolvePlatformViewport(selection.resolved.workflow, member.platform),
          leasePolicyName:
            prepared.source.sourceKind === "candidate" ? "routine-codex-browser-v1" : "authorized-codex-browser-v1",
          qualificationId: selection.qualification?.qualificationId,
          capabilitySnapshot: selection.qualification?.capabilitySnapshot,
          sourceReplayRunId: selection.qualification?.replayRunId,
          applicationTarget: target?.applicationTarget,
          targetUrl: target?.targetUrl,
          authenticationSession: prepared.authenticationSession,
          evaluationPerspective: {
            ...selection.perspective,
            effectiveRubricHash: selection.effectiveRubricHash,
            inquiryPolicy: prepared.inquiryPolicy,
            requirementSnapshot: {
              catalogHash: prepared.requirementSnapshot.catalogHash,
              requirementsHash: selection.requirementSelection.requirementsHash,
              requirements: selection.requirementSelection.requirements,
            },
            batchId,
            controlRunId: member.controlRunId,
            ...(prepared.identity.requirement === "named-profile" ? { sessionPredecessorRunId } : {}),
          },
        });
      }
      await batchStore.interruption?.("member-launched", { batchId, runId: member.runId });
      member.status = "launched";
      delete member.error;
    } catch (error) {
      if (error.message === "simulated crash") throw error;
      member.status = "failed";
      member.error = errorReceipt(error);
    }
    journal = await batchStore.update({
      ...journal,
      members: journal.members.map((item) => (item.runId === member.runId ? structuredClone(member) : item)),
      status: "launching",
    });
  }
  const failed = journal.members.some((member) => member.status === "failed");
  journal = await batchStore.update({ ...journal, status: failed ? "partial" : "launched" });
  const receiptMembers = await Promise.all(
    journal.members.map(async (member) =>
      member.status === "launched"
        ? { ...member, launchCard: launchCardFromRun(await runStore.readRun(member.runId)) }
        : member,
    ),
  );
  return {
    batchId,
    ok: !failed,
    exitCode: failed ? 4 : 0,
    source: journal.source,
    target: journal.target,
    identity: journal.identity,
    authentication: journal.authentication,
    policy: journal.policy,
    inquiryPolicy: journal.inquiryPolicy,
    requirementSnapshot: journal.requirementSnapshot,
    members: receiptMembers,
  };
}

export async function launchPerspectiveBatch(options) {
  const observedBatchIds = new Set((await options.batchStore.list()).map((batch) => batch.batchId));
  return options.batchStore.withLaunchLock(() => launchPerspectiveBatchLocked({ ...options, observedBatchIds }));
}

function coverageAggregate(coverage) {
  if (coverage?.coverage?.status === "complete") return "complete";
  if (coverage?.coverage?.status === "incomplete") return "unassessed";
  if (coverage?.status) return coverage.status;
  const outcomes = (coverage?.criteria ?? coverage?.assessments ?? []).map((item) => item.outcome);
  if (!outcomes.length || outcomes.includes("unassessed")) return "unassessed";
  if (outcomes.includes("finding")) return "findings";
  return "complete";
}

const SEVERITY = Object.freeze({ info: 0, low: 1, medium: 2, high: 3, critical: 4 });

async function findingSeverities({ coverage, assessmentStore, findingStore, runId, workflowId }) {
  const severities = [];
  for (const criterion of coverage?.criteria ?? []) {
    if (criterion.outcome !== "finding") continue;
    if (criterion.severity && Object.hasOwn(SEVERITY, criterion.severity)) {
      severities.push(criterion.severity);
      continue;
    }
    if (!criterion.assessmentId || !assessmentStore || !findingStore) continue;
    const assessment = await assessmentStore.readAssessment(runId, criterion.assessmentId);
    const findingIds = [...new Set(assessment.observations.flatMap((item) => item.findingId ?? []))];
    for (const findingId of findingIds)
      severities.push((await findingStore.readFinding(workflowId, findingId)).severity);
  }
  return severities;
}

export async function inspectPerspectiveBatch({
  batchId,
  runStore,
  batchStore,
  assessmentStore,
  findingStore = new FindingStore(runStore.root, { registry: runStore.registry }),
  projectCoverage,
  projectRunReport = buildRunReport,
}) {
  const batch = await batchStore.read(batchId);
  assertBatchJournal(batch);
  let coverageProjector = projectCoverage;
  if (!coverageProjector)
    ({ projectPerspectiveCoverage: coverageProjector } = await import("./perspective-assessment-store.js").catch(
      () => ({}),
    ));
  const members = await Promise.all(
    batch.members.map(async (member) => {
      if (member.status === "failed")
        return {
          ...member,
          canonicalStatus: "unavailable",
          qualityStatus: "unavailable",
          coverageStatus: "unavailable",
          coverage: null,
        };
      try {
        const run = await runStore.readRun(member.runId);
        const report = await projectRunReport(runStore, member.runId, { skipPerspective: true });
        const canonicalStatus =
          report.status === "completed"
            ? report.outcome === "passed" &&
              report.cleanupOutcome === "passed" &&
              report.integrity?.overall === "verified"
              ? "passed"
              : "failed"
            : ["failed", "blocked", "abandoned"].includes(report.status)
              ? "failed"
              : "in-progress";
        const coverage = coverageProjector
          ? await coverageProjector({ runStore, assessmentStore, runId: member.runId })
          : null;
        const coverageStatus = coverageAggregate(coverage);
        const qualityStatus =
          coverage?.qualityOutcome ??
          (coverageStatus === "findings" ? "findings" : coverageStatus === "complete" ? "clear" : "unassessed");
        const findingSeveritiesForRun = await findingSeverities({
          coverage,
          assessmentStore,
          findingStore,
          runId: member.runId,
          workflowId: run.manifest.workflowRef.id,
        });
        return {
          ...member,
          canonicalStatus,
          qualityStatus,
          coverageStatus,
          coverage,
          findingSeverities: findingSeveritiesForRun,
        };
      } catch (error) {
        return {
          ...member,
          canonicalStatus: "unavailable",
          qualityStatus: "unavailable",
          coverageStatus: "unavailable",
          coverage: null,
          readError: errorReceipt(error),
        };
      }
    }),
  );
  const required = members.filter((member) => member.required);
  const threshold = SEVERITY[batch.policy.findingSeverityGate] ?? SEVERITY.high;
  const gateOutcome = required.some(
    (member) =>
      member.canonicalStatus === "failed" ||
      member.qualityStatus === "unavailable" ||
      member.findingSeverities?.some((severity) => SEVERITY[severity] >= threshold),
  )
    ? "failed"
    : required.some((member) => member.canonicalStatus === "in-progress")
      ? "in-progress"
      : required.some((member) => member.coverageStatus === "unassessed")
        ? "blocked"
        : "passed";
  return {
    batchId,
    source: batch.source,
    target: batch.target,
    ...(Object.hasOwn(batch, "identity") ? { identity: batch.identity } : {}),
    ...(Object.hasOwn(batch, "authentication") ? { authentication: batch.authentication } : {}),
    policy: batch.policy,
    inquiryPolicy: batch.inquiryPolicy,
    requirementSnapshot: batch.requirementSnapshot,
    selections: batch.selections,
    members,
    gateOutcome,
  };
}
