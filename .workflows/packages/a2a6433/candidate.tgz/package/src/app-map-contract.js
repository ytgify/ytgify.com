/** Map occurrence identity comes from the verified append-only event sequence, never timestamps. */
export function orderedMapEvidence(events) {
  const seen = new Set();
  const introduced = new Set();
  return [...events]
    .sort((a, b) => a.sequence - b.sequence)
    .flatMap((event) => {
      const artifacts =
        event.type === "evidence.registered"
          ? [event.payload?.artifact]
          : event.type === "action.committed"
            ? (event.payload?.artifacts ?? [])
            : [];
      if (!artifacts.length) return [];
      if (!Number.isInteger(event.sequence) || event.sequence < 1 || seen.has(event.sequence))
        throw new Error("Map evidence sequence is unavailable or ambiguous");
      seen.add(event.sequence);
      return artifacts.flatMap((artifact, ordinal) => {
        if (artifact?.type !== "screenshot" || introduced.has(artifact.artifactId)) return [];
        introduced.add(artifact.artifactId);
        return [
          {
            visitId: JSON.stringify([event.runId, event.sequence, ordinal, artifact.artifactId, artifact.contentHash]),
            sequence: event.sequence,
            ordinal,
            registered: event.type === "evidence.registered",
            artifact,
          },
        ];
      });
    });
}

/** Prefer current eligible training only. Historical evidence always requires explicit selection. */
export function defaultMapRuns(runs) {
  const selected = new Map();
  for (const run of [...runs].sort(
    (a, b) => String(b.createdAt ?? "").localeCompare(String(a.createdAt ?? "")) || a.runId.localeCompare(b.runId),
  )) {
    if (!run.defaultEligible || run.binding !== "current" || run.phase !== "training" || !run.targetKey || !run.appId)
      continue;
    const key = JSON.stringify([run.appId, run.workflowId, run.platform, run.targetKey]);
    if (!selected.has(key)) selected.set(key, run);
  }
  return [...selected.values()];
}
