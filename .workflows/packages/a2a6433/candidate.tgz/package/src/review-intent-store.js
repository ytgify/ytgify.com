import { randomUUID } from "node:crypto";
import { constants } from "node:fs";
import { link, lstat, mkdir, open, readdir, unlink } from "node:fs/promises";
import { dirname, isAbsolute, join, relative, resolve, sep } from "node:path";

import { WorkflowError } from "./errors.js";
import { createSchemaRegistry } from "./schema-registry.js";
import { sha256 } from "./stable-json.js";

const INTENT_ID = /^intent_[A-Za-z0-9_-]+$/;

function fail(code, message, details) {
  throw new WorkflowError(code, message, { exitCode: 3, details });
}

function storePath(context) {
  const root = resolve(context?.projectRoot ?? "");
  const logical = context?.paths?.localStore;
  if (!logical || isAbsolute(logical) || logical.split(/[\\/]+/u).some((part) => !part || part === "..")) {
    fail("PROJECT_CONTEXT_INVALID", "Review intent storage requires a repository-relative ProjectContext local store");
  }
  const absolute = resolve(root, ...logical.split(/[\\/]+/u));
  const suffix = relative(root, absolute);
  if (suffix === ".." || suffix.startsWith(`..${sep}`) || isAbsolute(suffix)) {
    fail("PATH_TRAVERSAL", "Review intent storage escapes the project");
  }
  return { root, absolute: join(absolute, "review-intents") };
}

async function assertDirectory(path) {
  const entry = await lstat(path);
  if (!entry.isDirectory() || entry.isSymbolicLink()) {
    fail("REVIEW_INTENT_STORE_UNSAFE", "Review intent paths must be real directories");
  }
}

async function assertSafeAncestry(root, target) {
  const suffix = relative(root, target);
  if (suffix === ".." || suffix.startsWith(`..${sep}`) || isAbsolute(suffix)) {
    fail("PATH_TRAVERSAL", "Review intent path escapes its project");
  }
  let cursor = root;
  await assertDirectory(cursor);
  for (const part of suffix.split(sep).filter(Boolean)) {
    cursor = join(cursor, part);
    try {
      const entry = await lstat(cursor);
      if (entry.isSymbolicLink()) fail("REVIEW_INTENT_STORE_UNSAFE", "Review intent ancestry cannot contain symlinks");
      if (cursor !== target && !entry.isDirectory()) {
        fail("REVIEW_INTENT_STORE_UNSAFE", "Review intent ancestry must contain only directories");
      }
    } catch (error) {
      if (error.code === "ENOENT") break;
      throw error;
    }
  }
}

function recordPath(root, intentId) {
  if (!INTENT_ID.test(intentId ?? "")) fail("INVALID_REVIEW_INTENT_ID", "Invalid review intent ID");
  return join(root, `${intentId}.json`);
}

async function readRegular(path) {
  const entry = await lstat(path);
  if (!entry.isFile() || entry.isSymbolicLink()) {
    fail("REVIEW_INTENT_RECORD_CORRUPT", "Review intent is not a regular file");
  }
  const handle = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    const opened = await handle.stat();
    if (opened.dev !== entry.dev || opened.ino !== entry.ino || opened.size !== entry.size) {
      fail("REVIEW_INTENT_RECORD_CORRUPT", "Review intent changed while being read");
    }
    return await handle.readFile("utf8");
  } finally {
    await handle.close();
  }
}

async function syncDirectory(path) {
  const handle = await open(path, "r");
  try {
    await handle.sync();
  } finally {
    await handle.close();
  }
}

async function immutableWrite(path, bytes) {
  const temporary = `${path}.${randomUUID()}.tmp`;
  const handle = await open(temporary, "wx", 0o600);
  try {
    await handle.writeFile(bytes);
    await handle.sync();
  } finally {
    await handle.close();
  }
  try {
    await link(temporary, path);
    await syncDirectory(dirname(path));
  } catch (error) {
    if (error.code === "EEXIST") {
      fail("IMMUTABLE_REVIEW_INTENT_EXISTS", "Review intent records cannot be replaced", { path });
    }
    throw error;
  } finally {
    await unlink(temporary).catch(() => {});
  }
}

function sameIntent(left, right) {
  return sha256(left) === sha256(right);
}

/** Append-only storage for non-authoritative, action-shaped review intent. */
export class ReviewIntentStore {
  constructor(projectContext, { registry } = {}) {
    const path = storePath(projectContext);
    this.projectRoot = path.root;
    this.root = path.absolute;
    this.registry = registry;
  }

  async init() {
    await assertSafeAncestry(this.projectRoot, this.root);
    await mkdir(this.root, { recursive: true });
    await assertDirectory(this.root);
    this.registry ??= await createSchemaRegistry();
    return this;
  }

  async readIntent(intentId) {
    this.registry ??= await createSchemaRegistry();
    const path = recordPath(this.root, intentId);
    await assertSafeAncestry(this.projectRoot, path);
    let record;
    try {
      record = JSON.parse(await readRegular(path));
    } catch (error) {
      if (error instanceof SyntaxError) fail("REVIEW_INTENT_RECORD_CORRUPT", "Review intent is invalid JSON");
      throw error;
    }
    this.registry.validate("reviewIntent", record);
    if (record.intentId !== intentId) fail("REVIEW_INTENT_ID_MISMATCH", "Review intent path and identity differ");
    return structuredClone(record);
  }

  async listIntentIds() {
    try {
      await assertSafeAncestry(this.projectRoot, this.root);
      await assertDirectory(this.root);
    } catch (error) {
      if (error.code === "ENOENT") return [];
      throw error;
    }
    return (await readdir(this.root))
      .filter((name) => /^intent_[A-Za-z0-9_-]+\.json$/u.test(name))
      .sort()
      .map((name) => name.slice(0, -5));
  }

  async listIntentRecords() {
    const records = await Promise.all(
      (await this.listIntentIds()).map(async (intentId) => {
        try {
          return { intentId, integrity: "verified", record: await this.readIntent(intentId) };
        } catch (error) {
          return { intentId, integrity: "degraded", issue: error.code ?? "REVIEW_INTENT_RECORD_UNREADABLE" };
        }
      }),
    );
    return records.sort(
      (left, right) =>
        String(left.record?.createdAt ?? "").localeCompare(String(right.record?.createdAt ?? "")) ||
        left.intentId.localeCompare(right.intentId),
    );
  }

  async appendIntent(record) {
    await this.init();
    this.registry.validate("reviewIntent", record);
    if (record.supersedesIntentId === record.intentId) {
      fail("REVIEW_INTENT_SUPERSESSION_INVALID", "Review intent cannot supersede itself");
    }
    if (record.supersedesIntentId) {
      const superseded = await this.readIntent(record.supersedesIntentId);
      if (superseded.workflowId !== record.workflowId) {
        fail("REVIEW_INTENT_SUPERSESSION_INVALID", "Review intent may supersede only the same journey");
      }
    }

    const records = await this.listIntentRecords();
    const replay = records.find(({ record: existing }) =>
      record.idempotencyKey ? existing?.idempotencyKey === record.idempotencyKey : false,
    );
    if (replay) {
      if (replay.integrity === "verified" && sameIntent(replay.record, record)) return structuredClone(replay.record);
      fail("REVIEW_INTENT_IDEMPOTENCY_CONFLICT", "Idempotency key already identifies another review intent");
    }

    const path = recordPath(this.root, record.intentId);
    await assertSafeAncestry(this.projectRoot, path);
    await immutableWrite(path, Buffer.from(`${JSON.stringify(record, null, 2)}\n`));
    return structuredClone(record);
  }
}
