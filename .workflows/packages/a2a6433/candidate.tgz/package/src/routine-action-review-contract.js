import { validateAuthenticatedActions } from "./authenticated-browser-execution.js";
import { WorkflowError } from "./errors.js";
import { buildRunReport } from "./run-report.js";
import { sha256 } from "./stable-json.js";

const TAINT = new Set([
  "action.rejected",
  "run.pause_requested",
  "run.paused",
  "run.resumed",
  "run.emergency_stopped",
  "reconciliation.completed",
]);

function invalid(message, details) {
  throw new WorkflowError("ROUTINE_ACTION_REVIEW_REQUIRED", message, { exitCode: 3, details });
}

export function validateReviewedRoutineBatch(stepId, batch) {
  try {
    validateAuthenticatedActions(batch.actions);
  } catch {
    invalid(`Reviewed step ${stepId} contains an unsupported authenticated action`);
  }
  if (
    !batch.requestedCapabilities.includes("browser.control") ||
    (batch.actions.some((action) => action.kind === "upload-file") &&
      !batch.requestedCapabilities.includes("file-upload"))
  )
    invalid(`Reviewed step ${stepId} has an invalid authenticated capability contract`);
  return batch;
}

/** Reconstruct exact reviewable actions from durable clean supervised Training truth. */
export async function exportSupervisedRoutineActions({ runStore, runId }) {
  const run = await runStore.readRun(runId);
  const report = await buildRunReport(runStore, runId, { skipPerspective: true });
  if (
    run.manifest.phase !== "training" ||
    run.state.status !== "completed" ||
    run.state.preflightOutcome !== "passed" ||
    run.state.cleanupOutcome !== "passed" ||
    run.state.traversal?.journeyOutcome !== "passed" ||
    Object.values(run.state.traversal?.steps ?? {}).some((step) => step.outcome !== "passed" || step.attempts !== 1) ||
    run.events.some((event) => TAINT.has(event.type)) ||
    report.integrity.overall !== "verified" ||
    report.integrity.evidence !== "verified" ||
    report.integrity.cleanup !== "verified"
  )
    invalid("Routine action export requires one clean, single-attempt supervised Training run");
  const batches = run.workflow.steps.map((step) => {
    const leases = run.events.filter((event) => event.type === "action.leased" && event.payload.stepId === step.id);
    if (leases.length !== 1) invalid(`Training step ${step.id} does not have one exact supervised lease`);
    const lease = leases[0].payload.lease;
    const commits = run.events.filter(
      (event) => event.type === "action.committed" && event.payload.result?.leaseId === lease.leaseId,
    );
    const commit = commits[0];
    const expectedDescriptions = lease.proposal.actions.map((action) => action.description);
    const expectedKinds = lease.proposal.actions.map((action) => action.kind);
    const declaredActions = commit?.payload.result?.declaredActions;
    const actualActions = commit?.payload.result?.actualActions;
    const declaredMatchesLease =
      JSON.stringify(declaredActions) === JSON.stringify(expectedDescriptions) ||
      JSON.stringify(declaredActions) === JSON.stringify(expectedKinds);
    if (
      commits.length !== 1 ||
      commit.payload.derivedOutcome !== "passed" ||
      !declaredMatchesLease ||
      !Array.isArray(actualActions) ||
      actualActions.length !== lease.proposal.actions.length ||
      commit.payload.result?.unexpectedStates?.length ||
      commit.payload.result?.uncertainty?.length
    )
      invalid(`Training step ${step.id} does not have one passing committed lease`);
    const content = {
      actions: structuredClone(lease.proposal.actions),
      requestedCapabilities: structuredClone(lease.proposal.requestedCapabilities),
    };
    const actionHash = sha256(content);
    const batch = validateReviewedRoutineBatch(step.id, {
      id: `reviewed-${step.id}-${actionHash.slice(7, 19)}`,
      ...content,
    });
    return { stepId: step.id, leaseId: lease.leaseId, actionHash, batch };
  });
  return {
    schema: "agent-workflow-routine-action-review/v1",
    source: {
      runId,
      workflowId: run.manifest.workflowRef.id,
      contentHash: run.manifest.workflowRef.contentHash,
      platform: run.manifest.platform,
    },
    reviewed: false,
    batches,
  };
}
