import { StudioMutationError } from "./studio-mutation-security.js";
import { DECISION_WRITE_AUTHORITY } from "./requirement-decision-store.js";
import { readEvaluationRequirements, writeEvaluationRequirement } from "./evaluation-requirements.js";
import { sha256 } from "./stable-json.js";

const MUTATION_QUEUES = new Map();

function queued(key, operation) {
  const prior = MUTATION_QUEUES.get(key) ?? Promise.resolve();
  const current = prior.catch(() => {}).then(operation);
  MUTATION_QUEUES.set(key, current);
  return current.finally(() => {
    if (MUTATION_QUEUES.get(key) === current) MUTATION_QUEUES.delete(key);
  });
}

function reject(status, code) {
  throw new StudioMutationError(status, code);
}
function exact(value, fields) {
  if (
    !value ||
    typeof value !== "object" ||
    Array.isArray(value) ||
    Object.keys(value).some((key) => !fields.includes(key))
  )
    reject(400, "INVALID_REQUEST");
  return value;
}
function safeIdempotencyKey(value) {
  if (!/^req_[A-Za-z0-9_-]{4,196}$/u.test(value ?? "")) reject(400, "INVALID_REQUEST");
}
function secretLike(value) {
  return (
    typeof value === "string" &&
    /(?:\bBearer\s+[A-Za-z0-9._-]{12,}|\b(?:sk|ghp|github_pat)_[A-Za-z0-9_-]{12,})/u.test(value)
  );
}
function typedAnswer(question, body) {
  const spec = question.answerSpec;
  let value;
  if (body.suggestionId !== undefined) {
    if (body.answer !== undefined) reject(400, "INVALID_REQUEST");
    const suggestion = question.suggestions.find((item) => item.id === body.suggestionId);
    if (!suggestion) reject(400, "QUESTION_SUGGESTION_UNAVAILABLE");
    value = suggestion.value;
  } else value = body.answer;
  if (spec.type === "boolean") {
    if (typeof value !== "boolean") reject(400, "QUESTION_ANSWER_INVALID");
    return { type: "boolean", value };
  }
  if (spec.type === "quantity") {
    if (
      !Number.isSafeInteger(value) ||
      value < (spec.minimum ?? 0) ||
      value > (spec.maximum ?? Number.MAX_SAFE_INTEGER)
    )
      reject(400, "QUESTION_ANSWER_INVALID");
    return { type: "quantity", value, unit: spec.unit };
  }
  if (spec.type === "single-choice") {
    if (typeof value !== "string" || !spec.options.some((option) => option.id === value))
      reject(400, "QUESTION_ANSWER_INVALID");
    return { type: "single-choice", value };
  }
  if (typeof value !== "string" || !value.trim() || value.length > (spec.maxLength ?? 4000) || secretLike(value))
    reject(400, "QUESTION_ANSWER_INVALID");
  return { type: "text", value: value.trim() };
}
function requirementScope(question, scope) {
  if (!question.allowedScopes.includes(scope)) reject(400, "QUESTION_SCOPE_INVALID");
  return {
    kind: scope,
    ...(scope === "journey" ? { workflowIds: [question.workflowId] } : {}),
    platforms: [question.platform],
    perspectiveIds: [question.perspectiveId],
  };
}
async function locateQuestion(questionStore, questionId) {
  const questions = questionStore.listAllRecords
    ? (await questionStore.listAllRecords()).filter((item) => item.integrity === "verified").map((item) => item.record)
    : await questionStore.listAll();
  const matched = questions.filter((question) => question.questionId === questionId);
  if (matched.length !== 1) reject(404, "QUESTION_UNAVAILABLE");
  return matched[0];
}
async function verifyQuestionEvidence(question, runStore) {
  const run = await runStore.readRun(question.runId);
  const perspective = run.manifest.evaluationPerspective;
  if (
    run.manifest.phase !== "evaluation" ||
    perspective?.id !== question.perspectiveId ||
    perspective?.rubricHash !== question.rubricHash ||
    (perspective.effectiveRubricHash ?? perspective.rubricHash) !== question.effectiveRubricHash
  )
    reject(409, "QUESTION_INTEGRITY_CONFLICT");
  for (const observation of question.observations) {
    if (observation.artifactId) {
      try {
        await runStore.readVerifiedEvidence(question.runId, observation.artifactId);
      } catch {
        reject(409, "QUESTION_EVIDENCE_UNAVAILABLE");
      }
    }
  }
}
function projectQuestion(question, records) {
  const decision = records.find((record) => record.schema === "agent-workflow-requirement-decision/v1");
  const dismissal = records.find((record) => record.schema === "agent-workflow-evaluation-question-dismissal/v1");
  const responses = records
    .filter((record) => record.schema === "agent-workflow-evaluation-question-response/v1")
    .sort((left, right) => left.createdAt.localeCompare(right.createdAt))
    .map((record) => ({
      responseId: record.responseId,
      sourceQuestionId: record.questionId,
      text: record.text,
      actor: record.actor,
      channel: record.channel,
      createdAt: record.createdAt,
    }));
  return {
    questionId: question.questionId,
    workflowId: question.workflowId,
    runId: question.runId,
    batchId: question.batchId,
    platform: question.platform,
    perspectiveId: question.perspectiveId,
    criterionId: question.criterionId,
    scenarioId: question.scenarioId,
    stepId: question.stepId,
    requirementKey: question.requirementKey,
    prompt: question.prompt,
    rationale: question.rationale,
    priority: question.priority,
    assessmentImpact: question.assessmentImpact,
    answerSpec: structuredClone(question.answerSpec),
    suggestions: structuredClone(question.suggestions),
    allowedScopes: structuredClone(question.allowedScopes),
    observations: question.observations.map((item) => ({
      ...structuredClone(item),
      ...(item.artifactId
        ? {
            evidenceUrl: `/api/runs/${encodeURIComponent(question.runId)}/artifacts/${encodeURIComponent(item.artifactId)}`,
          }
        : {}),
    })),
    status: decision ? "answered" : dismissal ? "dismissed" : "open",
    questionIntegrity: sha256(question),
    responses,
    ...(decision
      ? {
          decision: {
            decisionId: decision.decisionId,
            answer: decision.answer,
            scope: decision.scope,
            catalogHash: decision.catalogHash,
            createdAt: decision.createdAt,
          },
        }
      : {}),
    ...(dismissal
      ? { dismissal: { dismissalId: dismissal.dismissalId, reason: dismissal.reason, createdAt: dismissal.createdAt } }
      : {}),
  };
}

function questionGroupKey(question) {
  return sha256({
    workflowId: question.workflowId,
    platform: question.platform,
    perspectiveId: question.perspectiveId,
    requirementKey: question.requirementKey,
    answerSpec: question.answerSpec,
    allowedScopes: question.allowedScopes,
    priority: question.priority,
    assessmentImpact: question.assessmentImpact,
  });
}

function aggregateQuestionGroup(questions, preferredQuestionId) {
  const preferred = questions.find((question) => question.questionId === preferredQuestionId);
  const answered = questions.find((question) => question.status === "answered");
  const open = questions.find((question) => question.status === "open");
  const primary = preferred ?? answered ?? open ?? questions[0];
  const status = answered ? "answered" : open ? "open" : "dismissed";
  return {
    ...primary,
    status,
    ...(answered?.decision ? { decision: answered.decision } : {}),
    responses: questions
      .flatMap((question) => question.responses)
      .sort((left, right) => left.createdAt.localeCompare(right.createdAt)),
    sourceQuestions: questions.map((question) => ({
      questionId: question.questionId,
      runId: question.runId,
      platform: question.platform,
      criterionId: question.criterionId,
      scenarioId: question.scenarioId,
      stepId: question.stepId,
      rationale: question.rationale,
      observations: structuredClone(question.observations),
      status: question.status,
    })),
  };
}

function aggregateQuestions(questions, preferredQuestionId) {
  const groups = new Map();
  for (const question of questions) {
    const key = questionGroupKey(question);
    groups.set(key, [...(groups.get(key) ?? []), question]);
  }
  return [...groups.values()].map((group) => aggregateQuestionGroup(group, preferredQuestionId));
}

export async function projectStudioQuestions({ questionStore, decisionStore, workflowId }) {
  const records = questionStore.listAllRecords
    ? await questionStore.listAllRecords()
    : (await questionStore.listAll()).map((record) => ({ integrity: "verified", record }));
  const questions = records
    .filter((item) => item.integrity === "verified" && item.record.workflowId === workflowId)
    .map((item) => item.record);
  return {
    workflowId,
    degraded: records.filter((item) => item.integrity === "degraded").length,
    questions: aggregateQuestions(
      await Promise.all(
        questions.map(async (question) => projectQuestion(question, await decisionStore.list(question.questionId))),
      ),
    ),
  };
}

export async function projectStudioQuestion({ questionStore, decisionStore, questionId }) {
  const question = await locateQuestion(questionStore, questionId);
  const records = questionStore.listAllRecords
    ? await questionStore.listAllRecords()
    : (await questionStore.listAll()).map((record) => ({ integrity: "verified", record }));
  const compatible = records
    .filter(
      (item) =>
        item.integrity === "verified" &&
        item.record.workflowId === question.workflowId &&
        questionGroupKey(item.record) === questionGroupKey(question),
    )
    .map((item) => item.record);
  const projected = await Promise.all(
    compatible.map(async (item) => projectQuestion(item, await decisionStore.list(item.questionId))),
  );
  return aggregateQuestionGroup(projected, questionId);
}

async function answerStudioQuestionUnlocked({
  questionStore,
  decisionStore,
  runStore,
  projectContext,
  registry,
  questionId,
  body,
  interruption,
  now = () => new Date(),
}) {
  exact(body, [
    "expectedQuestionIntegrity",
    "expectedCatalogHash",
    "scope",
    "answer",
    "suggestionId",
    "idempotencyKey",
  ]);
  safeIdempotencyKey(body.idempotencyKey);
  const question = await locateQuestion(questionStore, questionId);
  if (question.workflowId === undefined || projectContext?.project?.id === undefined)
    reject(503, "PROJECT_CONTEXT_UNAVAILABLE");
  const questionIntegrity = sha256(question);
  if (body.expectedQuestionIntegrity !== questionIntegrity) reject(409, "QUESTION_INTEGRITY_CONFLICT");
  await verifyQuestionEvidence(question, runStore);
  const answer = typedAnswer(question, body);
  const scope = requirementScope(question, body.scope);
  const existing = await decisionStore.findIdempotencyKey(body.idempotencyKey);
  if (existing) {
    if (
      existing.schema !== "agent-workflow-requirement-decision/v1" ||
      existing.questionId !== questionId ||
      existing.questionIntegrity !== questionIntegrity ||
      sha256(existing.answer) !== sha256(answer) ||
      sha256(existing.scope) !== sha256(scope)
    )
      reject(409, "IDEMPOTENCY_CONFLICT");
    return {
      replay: true,
      question: await projectStudioQuestion({ questionStore, decisionStore, questionId }),
      decision: existing,
    };
  }
  const entry = { key: question.requirementKey, label: question.prompt, answer, scope };
  const current = await readEvaluationRequirements(projectContext, { registry });
  let written;
  if (current.catalogHash === body.expectedCatalogHash) {
    written = await writeEvaluationRequirement({
      projectContext,
      expectedHash: body.expectedCatalogHash,
      entry,
      registry,
    });
    await interruption?.("catalog-written", written);
  } else {
    const matching = current.catalog.requirements.some((candidate) => sha256(candidate) === sha256(entry));
    if (!matching) reject(409, "REQUIREMENTS_REVISION_CONFLICT");
    written = {
      catalog: current.catalog,
      catalogHash: current.catalogHash,
      previousCatalogHash: body.expectedCatalogHash,
    };
  }
  const basis = { questionId, questionIntegrity, idempotencyKey: body.idempotencyKey };
  const decision = {
    schema: "agent-workflow-requirement-decision/v1",
    decisionId: `decision_${sha256(basis).slice(7, 39)}`,
    questionId,
    questionIntegrity,
    workflowId: question.workflowId,
    requirementKey: question.requirementKey,
    scope,
    answer,
    previousCatalogHash: body.expectedCatalogHash,
    catalogHash: written.catalogHash,
    idempotencyKey: body.idempotencyKey,
    actor: "human",
    channel: "studio",
    createdAt: now().toISOString(),
  };
  await decisionStore.write(decision, DECISION_WRITE_AUTHORITY);
  return {
    replay: false,
    question: await projectStudioQuestion({ questionStore, decisionStore, questionId }),
    decision,
  };
}

export function answerStudioQuestion(options) {
  return queued(`${options.decisionStore.root}:questions`, () => answerStudioQuestionUnlocked(options));
}

async function respondStudioQuestionUnlocked({
  questionStore,
  decisionStore,
  questionId,
  body,
  now = () => new Date(),
}) {
  exact(body, ["expectedQuestionIntegrity", "text", "idempotencyKey"]);
  safeIdempotencyKey(body.idempotencyKey);
  if (typeof body.text !== "string" || !body.text.trim() || body.text.length > 4000 || secretLike(body.text))
    reject(400, "QUESTION_RESPONSE_INVALID");
  const question = await locateQuestion(questionStore, questionId);
  const questionIntegrity = sha256(question);
  if (body.expectedQuestionIntegrity !== questionIntegrity) reject(409, "QUESTION_INTEGRITY_CONFLICT");
  const text = body.text.trim();
  const existing = await decisionStore.findIdempotencyKey(body.idempotencyKey);
  if (existing) {
    if (
      existing.schema !== "agent-workflow-evaluation-question-response/v1" ||
      existing.questionId !== questionId ||
      existing.questionIntegrity !== questionIntegrity ||
      existing.text !== text
    )
      reject(409, "IDEMPOTENCY_CONFLICT");
    return {
      replay: true,
      question: await projectStudioQuestion({ questionStore, decisionStore, questionId }),
      response: existing,
    };
  }
  const basis = { questionId, questionIntegrity, text, idempotencyKey: body.idempotencyKey };
  const response = {
    schema: "agent-workflow-evaluation-question-response/v1",
    responseId: `response_${sha256(basis).slice(7, 39)}`,
    ...basis,
    actor: "human",
    channel: "studio",
    createdAt: now().toISOString(),
  };
  await decisionStore.write(response, DECISION_WRITE_AUTHORITY);
  return {
    replay: false,
    question: await projectStudioQuestion({ questionStore, decisionStore, questionId }),
    response,
  };
}

export function respondStudioQuestion(options) {
  return queued(`${options.decisionStore.root}:questions`, () => respondStudioQuestionUnlocked(options));
}

async function dismissStudioQuestionUnlocked({
  questionStore,
  decisionStore,
  questionId,
  body,
  now = () => new Date(),
}) {
  exact(body, ["expectedQuestionIntegrity", "reason", "idempotencyKey"]);
  safeIdempotencyKey(body.idempotencyKey);
  if (typeof body.reason !== "string" || body.reason.trim().length < 3 || body.reason.length > 2000)
    reject(400, "INVALID_REQUEST");
  const question = await locateQuestion(questionStore, questionId);
  const questionIntegrity = sha256(question);
  if (body.expectedQuestionIntegrity !== questionIntegrity) reject(409, "QUESTION_INTEGRITY_CONFLICT");
  const existing = await decisionStore.findIdempotencyKey(body.idempotencyKey);
  if (existing) {
    if (
      existing.schema !== "agent-workflow-evaluation-question-dismissal/v1" ||
      existing.questionId !== questionId ||
      existing.reason !== body.reason.trim()
    )
      reject(409, "IDEMPOTENCY_CONFLICT");
    return {
      replay: true,
      question: await projectStudioQuestion({ questionStore, decisionStore, questionId }),
      dismissal: existing,
    };
  }
  const basis = { questionId, questionIntegrity, reason: body.reason.trim(), idempotencyKey: body.idempotencyKey };
  const dismissal = {
    schema: "agent-workflow-evaluation-question-dismissal/v1",
    dismissalId: `dismissal_${sha256(basis).slice(7, 39)}`,
    ...basis,
    actor: "human",
    channel: "studio",
    createdAt: now().toISOString(),
  };
  await decisionStore.write(dismissal, DECISION_WRITE_AUTHORITY);
  return {
    replay: false,
    question: await projectStudioQuestion({ questionStore, decisionStore, questionId }),
    dismissal,
  };
}

export function dismissStudioQuestion(options) {
  return queued(`${options.decisionStore.root}:questions`, () => dismissStudioQuestionUnlocked(options));
}
