import { inflateSync } from "node:zlib";
import { WorkflowError } from "./errors.js";

export const DEFAULT_SCREENSHOT_MAX_BYTES = 10 * 1024 * 1024;

const PNG_SIGNATURE = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
const MAX_DIMENSION = 16384;
const MAX_PIXELS = 100_000_000;
const CRC_TABLE = Array.from({ length: 256 }, (_, value) => {
  let crc = value;
  for (let bit = 0; bit < 8; bit += 1) crc = crc & 1 ? 0xedb88320 ^ (crc >>> 1) : crc >>> 1;
  return crc >>> 0;
});

function invalidScreenshot(message) {
  throw new WorkflowError("VALIDATION_FAILED", message, { exitCode: 3 });
}

function crc32(bytes) {
  let crc = 0xffffffff;
  for (const byte of bytes) crc = CRC_TABLE[(crc ^ byte) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}

function assertDimensions(width, height) {
  if (!width || !height || width > MAX_DIMENSION || height > MAX_DIMENSION || width * height > MAX_PIXELS) {
    invalidScreenshot("Screenshot dimensions are invalid or exceed the bounded image limit");
  }
}

function pngPasses(width, height, interlace) {
  if (!interlace) return [[width, height]];
  return [
    [0, 0, 8, 8],
    [4, 0, 8, 8],
    [0, 4, 4, 8],
    [2, 0, 4, 4],
    [0, 2, 2, 4],
    [1, 0, 2, 2],
    [0, 1, 1, 2],
  ].map(([x, y, dx, dy]) => [
    width > x ? Math.ceil((width - x) / dx) : 0,
    height > y ? Math.ceil((height - y) / dy) : 0,
  ]);
}

function validatePng(bytes) {
  let offset = PNG_SIGNATURE.length;
  let ihdr;
  let palette = false;
  let sawIdat = false;
  let idatEnded = false;
  let sawIend = false;
  const compressed = [];
  while (offset < bytes.length) {
    if (offset + 12 > bytes.length) invalidScreenshot("PNG chunk is truncated");
    const length = bytes.readUInt32BE(offset);
    const end = offset + 12 + length;
    if (end > bytes.length) invalidScreenshot("PNG chunk payload is truncated");
    const typeBytes = bytes.subarray(offset + 4, offset + 8);
    const type = typeBytes.toString("ascii");
    if (!/^[A-Za-z]{4}$/.test(type)) invalidScreenshot("PNG chunk type is invalid");
    if ((typeBytes[2] & 0x20) !== 0) invalidScreenshot("PNG chunk type has its reserved bit set");
    const data = bytes.subarray(offset + 8, offset + 8 + length);
    if (crc32(Buffer.concat([typeBytes, data])) !== bytes.readUInt32BE(offset + 8 + length)) {
      invalidScreenshot("PNG chunk CRC is invalid");
    }
    if (!ihdr && type !== "IHDR") invalidScreenshot("PNG IHDR must be the first chunk");
    if (type === "IHDR") {
      if (ihdr || length !== 13) invalidScreenshot("PNG must contain one valid IHDR chunk");
      const width = data.readUInt32BE(0);
      const height = data.readUInt32BE(4);
      const bitDepth = data[8];
      const colorType = data[9];
      const validDepths = {
        0: [1, 2, 4, 8, 16],
        2: [8, 16],
        3: [1, 2, 4, 8],
        4: [8, 16],
        6: [8, 16],
      };
      if (
        !validDepths[colorType]?.includes(bitDepth) ||
        data[10] !== 0 ||
        data[11] !== 0 ||
        ![0, 1].includes(data[12])
      ) {
        invalidScreenshot("PNG IHDR encoding is unsupported or invalid");
      }
      assertDimensions(width, height);
      ihdr = { width, height, bitDepth, colorType, interlace: data[12] };
    } else if (type === "PLTE") {
      if (sawIdat || palette || !length || length % 3 || length > 768 || [0, 4].includes(ihdr.colorType)) {
        invalidScreenshot("PNG palette is invalid or misplaced");
      }
      if (ihdr.colorType === 3 && length / 3 > 2 ** ihdr.bitDepth) invalidScreenshot("PNG palette exceeds bit depth");
      palette = true;
    } else if (type === "IDAT") {
      if (idatEnded || (ihdr.colorType === 3 && !palette)) invalidScreenshot("PNG IDAT ordering is invalid");
      sawIdat = true;
      compressed.push(data);
    } else if (type === "IEND") {
      if (!sawIdat || sawIend || length !== 0 || end !== bytes.length)
        invalidScreenshot("PNG IEND is invalid or not at EOF");
      sawIend = true;
    } else {
      if (sawIdat) idatEnded = true;
      if ((typeBytes[0] & 0x20) === 0) invalidScreenshot(`Unsupported critical PNG chunk: ${type}`);
    }
    offset = end;
    if (sawIend) break;
  }
  if (!sawIend || offset !== bytes.length) invalidScreenshot("PNG is truncated or has trailing data");
  const channels = { 0: 1, 2: 3, 3: 1, 4: 2, 6: 4 }[ihdr.colorType];
  const rows = pngPasses(ihdr.width, ihdr.height, ihdr.interlace).filter(([width, height]) => width && height);
  const expected = rows.reduce(
    (total, [width, height]) => total + (1 + Math.ceil((width * channels * ihdr.bitDepth) / 8)) * height,
    0,
  );
  let inflated;
  try {
    const input = Buffer.concat(compressed);
    const result = inflateSync(input, { maxOutputLength: expected + 1, info: true });
    if (result.engine.bytesWritten !== input.length) invalidScreenshot("PNG image data has trailing compressed bytes");
    inflated = result.buffer;
  } catch {
    invalidScreenshot("PNG image data is corrupt or exceeds its declared dimensions");
  }
  if (inflated.length !== expected) invalidScreenshot("PNG image data length does not match IHDR dimensions");
  let rowOffset = 0;
  for (const [width, height] of rows) {
    const stride = Math.ceil((width * channels * ihdr.bitDepth) / 8);
    for (let row = 0; row < height; row += 1) {
      if (inflated[rowOffset] > 4) invalidScreenshot("PNG scanline filter is invalid");
      rowOffset += stride + 1;
    }
  }
  return { mimeType: "image/png", extension: "png", width: ihdr.width, height: ihdr.height };
}

function parseHuffmanTable(counts, symbols) {
  let available = 1;
  let code = 0;
  let symbolOffset = 0;
  const table = new Map();
  for (let length = 1; length <= 16; length += 1) {
    available = available * 2 - counts[length - 1];
    if (available < 0) invalidScreenshot("JPEG Huffman table is oversubscribed");
    for (let index = 0; index < counts[length - 1]; index += 1) {
      table.set(`${length}:${code}`, symbols[symbolOffset]);
      code += 1;
      symbolOffset += 1;
    }
    code *= 2;
  }
  if (!symbols.length) invalidScreenshot("JPEG Huffman table is empty");
  return table;
}

function decodeJpegScan(data, frame, scan, tables) {
  let bitOffset = 0;
  const readBit = () => {
    if (bitOffset >= data.length * 8) invalidScreenshot("JPEG entropy scan is truncated");
    const bit = (data[Math.floor(bitOffset / 8)] >> (7 - (bitOffset % 8))) & 1;
    bitOffset += 1;
    return bit;
  };
  const decode = (table) => {
    let code = 0;
    for (let length = 1; length <= 16; length += 1) {
      code = (code << 1) | readBit();
      const symbol = table.get(`${length}:${code}`);
      if (symbol !== undefined) return symbol;
    }
    invalidScreenshot("JPEG entropy code is not present in its Huffman table");
  };
  const consume = (count) => {
    for (let index = 0; index < count; index += 1) readBit();
  };
  const maxH = Math.max(...frame.components.map((component) => component.h));
  const maxV = Math.max(...frame.components.map((component) => component.v));
  const mcus = Math.ceil(frame.width / (8 * maxH)) * Math.ceil(frame.height / (8 * maxV));
  for (let mcu = 0; mcu < mcus; mcu += 1) {
    for (const selector of scan) {
      const component = frame.components.find((item) => item.id === selector.id);
      for (let block = 0; block < component.h * component.v; block += 1) {
        const dcSize = decode(tables.get(`0:${selector.dc}`));
        if (dcSize > 11) invalidScreenshot("JPEG baseline DC coefficient is invalid");
        consume(dcSize);
        let coefficient = 1;
        while (coefficient < 64) {
          const symbol = decode(tables.get(`1:${selector.ac}`));
          if (symbol === 0) break;
          const run = symbol >> 4;
          const size = symbol & 0x0f;
          if (!size) {
            if (run !== 15) invalidScreenshot("JPEG AC run is invalid");
            coefficient += 16;
          } else {
            if (size > 10) invalidScreenshot("JPEG baseline AC coefficient is invalid");
            coefficient += run;
            if (coefficient >= 64) invalidScreenshot("JPEG AC run exceeds its block");
            consume(size);
            coefficient += 1;
          }
        }
      }
    }
  }
  while (bitOffset < data.length * 8) {
    if (readBit() !== 1) invalidScreenshot("JPEG entropy scan has non-padding trailing bits");
  }
}

function validateJfif(bytes) {
  if (bytes.length < 4 || bytes[0] !== 0xff || bytes[1] !== 0xd8) invalidScreenshot("JPEG SOI is missing");
  let offset = 2;
  let first = true;
  let jfif = false;
  let frame;
  let sawSos = false;
  const quantization = new Set();
  const huffman = new Map();
  while (offset < bytes.length) {
    if (bytes[offset] !== 0xff) invalidScreenshot("JPEG marker alignment is invalid");
    while (bytes[offset] === 0xff) offset += 1;
    if (offset >= bytes.length) invalidScreenshot("JPEG marker is truncated");
    const marker = bytes[offset];
    offset += 1;
    if (marker === 0xd9) invalidScreenshot("JPEG ended before a scan");
    if (marker === 0x00 || marker === 0x01 || marker === 0xd8 || (marker >= 0xd0 && marker <= 0xd7)) {
      invalidScreenshot("JPEG contains an invalid standalone marker");
    }
    if (![0xe0, 0xdb, 0xc0, 0xc4, 0xda].includes(marker)) {
      invalidScreenshot("JPEG marker is outside the bounded baseline JFIF allowlist");
    }
    if (offset + 2 > bytes.length) invalidScreenshot("JPEG segment length is truncated");
    const length = bytes.readUInt16BE(offset);
    if (length < 2 || offset + length > bytes.length) invalidScreenshot("JPEG segment is truncated");
    const data = bytes.subarray(offset + 2, offset + length);
    offset += length;
    if (first) {
      if (marker !== 0xe0) invalidScreenshot("Baseline JPEG evidence must begin with a JFIF APP0 segment");
      first = false;
    }
    if (marker === 0xe0 && !jfif) {
      if (data.length < 14 || !data.subarray(0, 5).equals(Buffer.from("JFIF\0")) || data[5] !== 1 || data[7] > 2) {
        invalidScreenshot("JPEG JFIF header is invalid");
      }
      const thumbnailBytes = 3 * data[12] * data[13];
      if (data.length !== 14 + thumbnailBytes || data[7] > 2 || !data.readUInt16BE(8) || !data.readUInt16BE(10)) {
        invalidScreenshot("JPEG JFIF density or thumbnail is invalid");
      }
      jfif = true;
    } else if (marker === 0xe0) {
      invalidScreenshot("JPEG contains more than one JFIF APP0 segment");
    } else if (marker === 0xdb) {
      let cursor = 0;
      while (cursor < data.length) {
        const spec = data[cursor];
        cursor += 1;
        if (spec >> 4 !== 0 || (spec & 0x0f) > 3 || cursor + 64 > data.length)
          invalidScreenshot("JPEG quantization table is invalid");
        quantization.add(spec & 0x0f);
        cursor += 64;
      }
    } else if (marker === 0xc4) {
      let cursor = 0;
      while (cursor < data.length) {
        const spec = data[cursor];
        cursor += 1;
        const tableClass = spec >> 4;
        const tableId = spec & 0x0f;
        if (tableClass > 1 || tableId > 3 || cursor + 16 > data.length)
          invalidScreenshot("JPEG Huffman table selector is invalid");
        const counts = [...data.subarray(cursor, cursor + 16)];
        cursor += 16;
        const count = counts.reduce((sum, value) => sum + value, 0);
        if (cursor + count > data.length) invalidScreenshot("JPEG Huffman symbols are truncated");
        const symbols = data.subarray(cursor, cursor + count);
        if (tableClass === 0 && [...symbols].some((symbol) => symbol > 11))
          invalidScreenshot("JPEG DC Huffman symbol is invalid");
        if (
          tableClass === 1 &&
          [...symbols].some(
            (symbol) => (symbol & 0x0f) > 10 || ((symbol & 0x0f) === 0 && ![0, 15].includes(symbol >> 4)),
          )
        ) {
          invalidScreenshot("JPEG AC Huffman symbol is invalid");
        }
        huffman.set(`${tableClass}:${tableId}`, parseHuffmanTable(counts, symbols));
        cursor += count;
      }
    } else if (marker === 0xc0) {
      if (frame || data.length < 9 || data[0] !== 8) invalidScreenshot("JPEG must contain one 8-bit baseline frame");
      const height = data.readUInt16BE(1);
      const width = data.readUInt16BE(3);
      const componentCount = data[5];
      if (![1, 3].includes(componentCount) || data.length !== 6 + 3 * componentCount)
        invalidScreenshot("JPEG frame components are invalid");
      assertDimensions(width, height);
      const components = [];
      for (let index = 0; index < componentCount; index += 1) {
        const cursor = 6 + 3 * index;
        const component = {
          id: data[cursor],
          h: data[cursor + 1] >> 4,
          v: data[cursor + 1] & 0x0f,
          quant: data[cursor + 2],
        };
        if (
          !component.id ||
          !component.h ||
          !component.v ||
          component.h > 4 ||
          component.v > 4 ||
          component.quant > 3
        ) {
          invalidScreenshot("JPEG component sampling is invalid");
        }
        components.push(component);
      }
      if (new Set(components.map((item) => item.id)).size !== components.length)
        invalidScreenshot("JPEG component IDs are duplicated");
      if (components.reduce((sum, item) => sum + item.h * item.v, 0) > 10)
        invalidScreenshot("JPEG MCU sampling exceeds the baseline limit");
      frame = { width, height, components };
    } else if (marker === 0xda) {
      if (!jfif || !frame || sawSos || data.length < 6) invalidScreenshot("JPEG scan header is invalid or misplaced");
      const count = data[0];
      if (count !== frame.components.length || data.length !== 1 + 2 * count + 3)
        invalidScreenshot("JPEG scan must contain every frame component once");
      const scan = [];
      for (let index = 0; index < count; index += 1) {
        const id = data[1 + 2 * index];
        const selector = data[2 + 2 * index];
        if (!frame.components.some((item) => item.id === id) || scan.some((item) => item.id === id))
          invalidScreenshot("JPEG scan component is invalid");
        scan.push({ id, dc: selector >> 4, ac: selector & 0x0f });
      }
      if (data.at(-3) !== 0 || data.at(-2) !== 63 || data.at(-1) !== 0)
        invalidScreenshot("JPEG scan is not baseline sequential");
      for (const component of frame.components)
        if (!quantization.has(component.quant))
          invalidScreenshot("JPEG component references a missing quantization table");
      for (const selector of scan) {
        if (!huffman.has(`0:${selector.dc}`) || !huffman.has(`1:${selector.ac}`))
          invalidScreenshot("JPEG scan references a missing Huffman table");
      }
      const entropy = [];
      let foundEoi = false;
      while (offset < bytes.length) {
        const byte = bytes[offset];
        offset += 1;
        if (byte !== 0xff) {
          entropy.push(byte);
          continue;
        }
        if (offset >= bytes.length) invalidScreenshot("JPEG entropy marker is truncated");
        let next = bytes[offset];
        offset += 1;
        while (next === 0xff && offset < bytes.length) {
          next = bytes[offset];
          offset += 1;
        }
        if (next === 0x00) entropy.push(0xff);
        else if (next === 0xd9) {
          foundEoi = true;
          break;
        } else invalidScreenshot("JPEG contains an unsupported marker inside its entropy scan");
      }
      if (!foundEoi || offset !== bytes.length || !entropy.length)
        invalidScreenshot("JPEG is truncated or has trailing/polyglot data");
      decodeJpegScan(Buffer.from(entropy), frame, scan, huffman);
      sawSos = true;
      break;
    }
  }
  if (!jfif || !frame || !sawSos) invalidScreenshot("JPEG is missing required baseline JFIF structure");
  return { mimeType: "image/jpeg", extension: "jpg", width: frame.width, height: frame.height };
}

function sniffScreenshotFormat(bytes) {
  if (bytes.length >= PNG_SIGNATURE.length && bytes.subarray(0, PNG_SIGNATURE.length).equals(PNG_SIGNATURE)) {
    return validatePng(bytes);
  }
  if (bytes.length >= 2 && bytes[0] === 0xff && bytes[1] === 0xd8) return validateJfif(bytes);
  invalidScreenshot("Screenshot evidence is neither a conforming PNG nor baseline JFIF JPEG");
}

export function inspectScreenshotBytes(bytes, maxBytes = DEFAULT_SCREENSHOT_MAX_BYTES) {
  const isRawBytes =
    ArrayBuffer.isView(bytes) &&
    bytes.BYTES_PER_ELEMENT === 1 &&
    Object.prototype.toString.call(bytes) === "[object Uint8Array]";
  if (!isRawBytes) {
    invalidScreenshot("Screenshot evidence must be raw Uint8Array bytes");
  }
  if (!Number.isSafeInteger(maxBytes) || maxBytes <= 0)
    invalidScreenshot("Screenshot byte limit must be a positive safe integer");
  if (!bytes.byteLength || bytes.byteLength > maxBytes)
    invalidScreenshot("Evidence size is outside the screenshot byte limit");

  let rawBytes;
  try {
    rawBytes = Buffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  } catch {
    invalidScreenshot("Screenshot evidence bytes are unavailable");
  }
  return sniffScreenshotFormat(rawBytes);
}
