import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";

import Ajv2020 from "ajv/dist/2020.js";
import addFormats from "ajv-formats";
import { parse as parseYaml } from "yaml";

import { WorkflowError } from "./errors.js";
import { assertSafeAuthMarker } from "./auth-session-adapter.js";
import { assertPerspectiveSnapshot } from "./evaluation-perspectives.js";

const SCHEMA_FILES = {
  acceptance: "acceptance.schema.json",
  appMapRegistry: "app-map-registry.schema.json",
  appMapProjection: "app-map-registry.schema.json#/$defs/projection",
  authSession: "auth-session.schema.json",
  config: "config.schema.json",
  discoverySnapshot: "discovery-snapshot.schema.json",
  explorationProposal: "exploration-proposal.schema.json",
  evaluationPerspective: "evaluation-perspective.schema.json",
  evaluationQuestionPolicy: "evaluation-question-policy.schema.json",
  evaluationQuestion: "evaluation-question.schema.json",
  evaluationQuestionDismissal: "evaluation-question-dismissal.schema.json",
  evaluationQuestionResponse: "evaluation-question-response.schema.json",
  evaluationRequirements: "evaluation-requirements.schema.json",
  event: "event.schema.json",
  finding: "finding.schema.json",
  findingVerification: "finding-verification.schema.json",
  findingRelation: "finding-relation.schema.json",
  perspectiveBatch: "perspective-batch.schema.json",
  perspectiveAssessment: "perspective-assessment.schema.json",
  findingVerificationContract: "finding-verification-contract.schema.json",
  findingInput: "finding-input.schema.json",
  findingResolution: "finding-resolution.schema.json",
  protocol: "protocol.schema.json",
  lifecycle: "lifecycle.schema.json",
  packageProvenance: "package-provenance.schema.json",
  projectContext: "project-context.schema.json",
  response: "response.schema.json",
  fixtureRecipe: "fixture-recipe.schema.json",
  fixtureNeedDecisions: "fixture-need-decisions.schema.json",
  fixtureInstance: "fixture-instance.schema.json",
  fixtureHandoff: "fixture-handoff.schema.json",
  fixtureTransition: "fixture-transition.schema.json",
  runControl: "run-control.schema.json",
  reviewIntent: "review-intent.schema.json",
  requirementDecision: "requirement-decision.schema.json",
  studioAssetManifest: "studio-asset-manifest.schema.json",
  workflow: "workflow.schema.json",
};

function schemaPath(filename) {
  return fileURLToPath(new URL(`../schemas/${filename}`, import.meta.url));
}

function formatErrors(errors = []) {
  return errors.map((error) => ({
    instancePath: error.instancePath || "/",
    keyword: error.keyword,
    message: error.message,
    params: error.params,
  }));
}

export class SchemaRegistry {
  #schemaIds = new Map();
  #validators = new Map();

  constructor({ ajv } = {}) {
    this.ajv =
      ajv ??
      addFormats(
        new Ajv2020({
          allErrors: true,
          allowUnionTypes: false,
          strict: true,
          strictRequired: false,
          strictTypes: false,
        }),
      );
  }

  async load() {
    const loaded = new Map();
    for (const [kind, source] of Object.entries(SCHEMA_FILES)) {
      const [filename, fragment] = source.split("#", 2);
      let schema = loaded.get(filename);
      if (!schema) {
        schema = JSON.parse(await readFile(schemaPath(filename), "utf8"));
        loaded.set(filename, schema);
        this.ajv.addSchema(schema);
      }
      // Register IDs (including nested references) now, but compile only the
      // schemas this command uses. CLI subprocesses otherwise compile all 17.
      this.#schemaIds.set(kind, `${schema.$id}${fragment ? `#${fragment}` : ""}`);
    }
    return this;
  }

  kinds() {
    return [...this.#schemaIds.keys()].sort();
  }

  validate(kind, value) {
    if (!this.#schemaIds.has(kind)) {
      throw new WorkflowError("SCHEMA_NOT_LOADED", `Schema is not loaded: ${kind}`, {
        exitCode: 1,
      });
    }

    let validator = this.#validators.get(kind);
    if (!validator) {
      validator = this.ajv.getSchema(this.#schemaIds.get(kind));
      this.#validators.set(kind, validator);
    }

    if (!validator(value)) {
      throw new WorkflowError("VALIDATION_FAILED", `${kind} validation failed`, {
        exitCode: 3,
        details: { errors: formatErrors(validator.errors) },
      });
    }

    if (kind === "authSession" && value.marker) {
      try {
        assertSafeAuthMarker(value.marker);
      } catch {
        throw new WorkflowError("VALIDATION_FAILED", "authSession validation failed", {
          exitCode: 3,
          details: { errors: [{ instancePath: "/marker", keyword: "safeAuthMarker", message: "must be safe" }] },
        });
      }
    }

    const perspective =
      kind === "evaluationPerspective" ? value : kind === "runControl" ? value.evaluationPerspective : null;
    if (perspective)
      assertPerspectiveSnapshot(perspective, { platform: kind === "runControl" ? value.platform : undefined });

    return value;
  }
}

export async function createSchemaRegistry() {
  return new SchemaRegistry().load();
}

export async function readYaml(path) {
  try {
    return parseYaml(await readFile(path, "utf8"));
  } catch (error) {
    throw new WorkflowError("INVALID_YAML", `Could not parse YAML: ${path}`, {
      exitCode: 3,
      details: { cause: error.message },
    });
  }
}

export function parseJsonLine(line, { path, lineNumber }) {
  try {
    return JSON.parse(line);
  } catch (error) {
    throw new WorkflowError("INVALID_JSONL", `Invalid JSON at ${path}:${lineNumber}`, {
      exitCode: 3,
      details: { cause: error.message },
    });
  }
}
