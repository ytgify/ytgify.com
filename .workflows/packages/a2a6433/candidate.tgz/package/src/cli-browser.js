import { readFile } from "node:fs/promises";
import { resolve } from "node:path";

import { stageAuthenticatedUpload } from "./authenticated-upload-artifact.js";
import { WorkflowError } from "./errors.js";
import { resolveProjectContext } from "./project-context.js";
import { RunControlStore } from "./run-control-store.js";
import { BrokeredAuthSessionService } from "./user-session-browser-broker.js";

export async function executeBrowserCommand(positionals, flags, registry) {
  const unsupported = [...flags.keys()].filter((name) => !["file", "root", "config", "store", "json"].includes(name));
  if (unsupported.length)
    throw new WorkflowError("INVALID_USAGE", `browser does not support --${unsupported[0]}`, { exitCode: 2 });
  if (positionals.length !== 1 || !["execute", "stage-upload"].includes(positionals[0]) || !flags.has("file")) {
    throw new WorkflowError("INVALID_USAGE", "browser requires execute or stage-upload with --file PATH", {
      exitCode: 2,
    });
  }
  const context = await resolveProjectContext({
    ...(flags.has("root") ? { projectRoot: resolve(flags.get("root")) } : {}),
    ...(flags.has("config") ? { configPath: flags.get("config") } : {}),
    registry,
  });
  const root = flags.has("store")
    ? resolve(flags.get("store"))
    : resolve(context.projectRoot, context.paths.localStore);
  const request = JSON.parse(await readFile(resolve(flags.get("file")), "utf8"));
  return positionals[0] === "stage-upload"
    ? {
        command: "browser stage-upload",
        data: await stageAuthenticatedUpload({
          store: await new RunControlStore(root, { registry }).init(),
          request,
        }),
      }
    : {
        command: "browser execute",
        data: await new BrokeredAuthSessionService({ storeRoot: root }).execute(request),
      };
}
