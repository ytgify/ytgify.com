import { randomUUID } from "node:crypto";
import { constants } from "node:fs";
import { link, lstat, mkdir, open, readdir, unlink } from "node:fs/promises";
import { dirname, join, relative, resolve, sep } from "node:path";

import { WorkflowError } from "./errors.js";

const RECORD_ID = /^(?:decision|dismissal|response)_[a-f0-9]{32}$/u;
const QUESTION_ID = /^question_[a-f0-9]{32}$/u;
export const DECISION_WRITE_AUTHORITY = Symbol("requirement-decision-write-authority");

function fail(code, message) {
  throw new WorkflowError(code, message, { exitCode: 3 });
}
function inside(root, path) {
  const suffix = relative(resolve(root), resolve(path));
  if (suffix.startsWith("..") || resolve(root, suffix) !== resolve(path))
    fail("PATH_TRAVERSAL", "Decision path escapes store");
  return resolve(path);
}
async function safe(root, path) {
  inside(root, path);
  let cursor = resolve(root);
  const rootEntry = await lstat(cursor);
  if (!rootEntry.isDirectory() || rootEntry.isSymbolicLink()) fail("DECISION_STORE_UNSAFE", "Decision store is unsafe");
  for (const part of relative(cursor, resolve(path)).split(sep).filter(Boolean)) {
    cursor = join(cursor, part);
    try {
      const entry = await lstat(cursor);
      if (entry.isSymbolicLink()) fail("DECISION_STORE_UNSAFE", "Decision ancestry cannot contain symlinks");
    } catch (error) {
      if (error.code === "ENOENT") return;
      throw error;
    }
  }
}
async function immutable(path, value) {
  const temporary = `${path}.${randomUUID()}.tmp`;
  const handle = await open(temporary, "wx", 0o600);
  try {
    await handle.writeFile(`${JSON.stringify(value, null, 2)}\n`);
    await handle.sync();
  } finally {
    await handle.close();
  }
  try {
    await link(temporary, path);
    const directory = await open(dirname(path), "r");
    try {
      await directory.sync();
    } finally {
      await directory.close();
    }
  } catch (error) {
    if (error.code === "EEXIST") fail("IMMUTABLE_DECISION_EXISTS", "Decision records cannot be replaced");
    throw error;
  } finally {
    await unlink(temporary).catch(() => {});
  }
}
async function regularJson(path) {
  const entry = await lstat(path);
  if (!entry.isFile() || entry.isSymbolicLink()) fail("DECISION_RECORD_CORRUPT", "Decision is not a regular file");
  const handle = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    return JSON.parse(await handle.readFile("utf8"));
  } catch (error) {
    if (error instanceof SyntaxError) fail("DECISION_RECORD_CORRUPT", "Decision is invalid JSON");
    throw error;
  } finally {
    await handle.close();
  }
}

export class RequirementDecisionStore {
  constructor(root, { registry, interruption } = {}) {
    this.root = resolve(root);
    this.recordsRoot = join(this.root, "requirement-decisions");
    this.registry = registry;
    this.interruption = interruption;
  }
  async init() {
    await mkdir(this.recordsRoot, { recursive: true });
    await safe(this.root, this.recordsRoot);
    return this;
  }
  questionRoot(questionId) {
    if (!QUESTION_ID.test(questionId)) fail("INVALID_QUESTION_ID", "Invalid question ID");
    return inside(this.recordsRoot, join(this.recordsRoot, questionId));
  }
  path(questionId, recordId) {
    if (!RECORD_ID.test(recordId)) fail("INVALID_DECISION_ID", "Invalid decision ID");
    return inside(this.questionRoot(questionId), join(this.questionRoot(questionId), `${recordId}.json`));
  }
  async write(record, authority) {
    if (authority !== DECISION_WRITE_AUTHORITY)
      fail("DECISION_WRITE_FORBIDDEN", "Human question records require a verified Studio mutation");
    const kind = recordKind(record);
    this.registry?.validate(kind, record);
    const root = this.questionRoot(record.questionId);
    await safe(this.recordsRoot, root);
    await mkdir(root).catch((error) => {
      if (error.code !== "EEXIST") throw error;
    });
    const recordId = record.decisionId ?? record.dismissalId ?? record.responseId;
    await immutable(this.path(record.questionId, recordId), record);
    const publishedEvent =
      kind === "requirementDecision"
        ? "decision-published"
        : kind === "evaluationQuestionDismissal"
          ? "dismissal-published"
          : "response-published";
    await this.interruption?.(publishedEvent, record);
    return structuredClone(record);
  }
  async list(questionId) {
    const root = this.questionRoot(questionId);
    try {
      await safe(this.recordsRoot, root);
      const names = (await readdir(root))
        .filter((name) => /^(?:decision|dismissal|response)_[a-f0-9]{32}\.json$/u.test(name))
        .sort();
      const records = [];
      for (const name of names) {
        const record = await regularJson(join(root, name));
        const kind = recordKind(record);
        this.registry?.validate(kind, record);
        records.push(record);
      }
      return records;
    } catch (error) {
      if (error.code === "ENOENT") return [];
      throw error;
    }
  }
  async findIdempotencyKey(idempotencyKey) {
    let questions;
    try {
      questions = (await readdir(this.recordsRoot, { withFileTypes: true })).filter((entry) => entry.isDirectory());
    } catch (error) {
      if (error.code === "ENOENT") return null;
      throw error;
    }
    for (const question of questions) {
      const record = (await this.list(question.name)).find((item) => item.idempotencyKey === idempotencyKey);
      if (record) return record;
    }
    return null;
  }
}

function recordKind(record) {
  if (record.schema === "agent-workflow-requirement-decision/v1") return "requirementDecision";
  if (record.schema === "agent-workflow-evaluation-question-dismissal/v1") return "evaluationQuestionDismissal";
  if (record.schema === "agent-workflow-evaluation-question-response/v1") return "evaluationQuestionResponse";
  fail("DECISION_RECORD_CORRUPT", "Decision record has an unsupported schema");
}
