# Workflows

Workflows is a Codex plugin and repository-local runner for training, evaluating, and improving repeatable application journeys. Codex performs the walkthroughs, the runner preserves exact evidence and provenance, and Studio gives people a focused place to review results, answer questions, and record acceptance.

## Install

Workflows has two coordinated parts:

- The **Codex plugin** supplies the `$workflows` agent experience.
- The private **`@lineagehq/workflows` npm package** supplies the `workflow` CLI, runner, and Studio.

You need Node.js 22.13.0 or newer, a Git repository for the application being tested, and read access to the private `lineagehq/workflows` repository and package.

The `main` branch currently describes the `0.4.0` release candidate. It must be paired with a locally constructed
`0.4.0` candidate tarball until the protected publication workflow completes. For the published `0.3.2` release,
use the [v0.3.2 documentation](https://github.com/lineagehq/workflows/tree/v0.3.2) and its matching plugin instead of
mixing stable and candidate components.

### 1. Install the Codex plugin

```bash
codex plugin marketplace add lineagehq/workflows
codex plugin add workflows@lineagehq-workflows
```

The plugin is a skills-only Codex plugin. It does not hold application credentials or replace the repository-local runner.

### 2. Authenticate to GitHub Packages

Map only the `@lineagehq` scope to GitHub Packages in the application repository:

```bash
npm config set @lineagehq:registry https://npm.pkg.github.com --location=project
```

Then authenticate with your GitHub username and a classic personal access token that has `read:packages` and access to the package:

```bash
npm login --scope=@lineagehq --auth-type=legacy --registry=https://npm.pkg.github.com
```

Enter the token as the password. Keep the token in your user-level npm credentials; never commit it to the application repository.

### 3. Install and initialize Workflows

From a clean Workflows checkout at the reviewed commit, construct the candidate once:

```bash
npm run package:release-candidate -- --commit FULL_SHA --output /absolute/new/candidate-directory
```

Then, from the application repository, install that exact tarball and initialize the matching generated skill:

```bash
npm install --save-dev --save-exact /absolute/new/candidate-directory/candidate.tgz
npx workflow init --host codex \
  --local-url http://workflows.localhost:3000 \
  --start-route /app/
npx workflow doctor --json
```

Initialization creates `.workflows/` configuration, a starter journey, an ignored local evidence store, and a pinned repository-local agent contract. It does not install its own package, change application dependencies beyond the explicit `npm install`, or overwrite locally edited guidance.

`data.localStatus: "ready"` from `workflow doctor --json` means the repository is ready for local training and evaluation. Registry checks are optional after installation; use `workflow doctor --registry --json` when diagnosing package access.

A fresh Codex task is not a Workflows approval gate or a readiness requirement. Start one only if Codex has not loaded a newly installed or updated plugin in the current task.

## Use Workflows

Ask Codex in product language. The plugin resolves journey names and keeps internal paths, run IDs, revisions, and evidence identities out of the conversation.

Examples:

- “Train the core MVP journeys in this app.”
- “Evaluate the checkout journey on desktop and mobile.”
- “Run the UX, accessibility, performance, and adversarial perspectives independently.”
- “Open the latest findings and questions in Studio.”
- “Apply the authorized fixes, rerun the affected evaluations, and show me the evidence.”

For direct CLI use:

```bash
npx workflow list checkout --json
npx workflow train --journey "checkout" --json
npx workflow evaluate desktop --journey "checkout" --json
npx workflow evaluate mobile --journey "checkout" --json
npx workflow studio
```

Use `workflow help` for the task-oriented command overview and `workflow help --json` for exact machine-readable forms.

## Review in Studio

Start Studio from the application repository:

```bash
npx workflow studio
```

Studio uses a `workflows.localhost` URL and reads the repository-local evidence store. Journey overview, evaluations, perspectives, questions, findings, fixes, and acceptance remain distinct so agent execution, user decisions, and human acceptance preserve accurate provenance.

## Update

Update both coordinated parts to the same release:

```bash
codex plugin marketplace upgrade lineagehq-workflows
codex plugin add workflows@lineagehq-workflows
npm install --save-dev --save-exact /absolute/new/candidate-directory/candidate.tgz
npx workflow init --host codex
npx workflow doctor --json
```

The tarball command above is for the `0.4.0` candidate on `main`. After `0.4.0` is published, replace it with the
exact registry dependency `@lineagehq/workflows@0.4.0`.

`workflow init` upgrades generated guidance only when it still matches a known Workflows baseline. It preserves local edits and reports a conflict instead of overwriting them.

## Architecture and guarantees

The Codex plugin provides the installable agent experience. The npm package remains the executable implementation and generates a pinned repository-local skill so each project records the package and protocol contract it was initialized against. Both skills are generated from the same templates and checked for drift in CI.

Workflows has no approval gates for routine local or production execution. Existing user authorization is sufficient for launch, execution, retry, resume, replay, promotion, qualification, evaluation, and cleanup. Leases, revisions, authentication boundaries, evidence integrity, and truthful reporting remain enforced. Agent execution and passing evaluation remain evidence; neither becomes human acceptance unless a person records acceptance.

Stable private npm releases are distributed through GitHub Packages using the protected tagged workflow described in [private distribution](docs/private-distribution.md).

## Current capabilities

- Draft 2020-12 schemas for project config, workflows, agent responses, and run events.
- YAML and JSONL loading and validation.
- Semantic workflow validation for IDs, references, overrides, dependency cycles, and media intervals.
- Desktop/mobile platform override resolution with canonical and effective hashes.
- Pure event reducer enforcing the initial runner state machine.
- Append-only filesystem run store with atomic manifests, flushed JSONL appends, path containment, and a single-writer lock.
- Strict transactional protocol contracts for requests, responses, capabilities, action proposals and leases, committed results, approvals, evidence, and receipts.
- Protocol fixtures and validation helpers for revision conflicts, idempotency identity, strict core fields, and namespaced extensions.
- Pure outer run-control reducer plus an append-only local store with atomic revisions, host handoff, lease reconciliation, and rebuildable idempotency receipts.
- Executable training-run coordinator with a pinned workflow snapshot, authoritative step cursor, expectation and evidence enforcement, policy-gated action leases, cleanup, and exact idempotent protocol responses.
- `train` and `run inspect` commands plus the stateful `workflow agent` transaction surface.
- Repo-local Codex host generation through `workflow init --host codex`, with package and protocol pins.
- Runner-issued neutral screenshot slots, strict PNG and bounded baseline JFIF validation, exact-byte preservation, runner-owned MIME/extension/hash metadata, atomic evidence registration, and registered-ID-only commits.
- Phase-aware capability gaps: training reaches the requiring step and blocks honestly while stricter phases remain preflight-blocked.
- Deterministic Bleep proof with three screenshot-backed passes, a media capability block, dependency-blocked descendants, cleanup, and replay parity.
- Live-mapped anonymous Bleep desktop/mobile acceptance definition with pinned screenshot-only routine batches, fixed viewport behavior, and a checked-in evidence audit that preserves invalid and missing lifecycle states.
- Minimal `doctor`, `validate`, and platform-resolved `show` CLI commands.
- Local Run Review Studio with restart-stable reports, replayed timelines, independently degradable run listings, journal-verified PNG/JPEG delivery, and narrowly allowlisted non-authoritative collaboration controls over IPv4 loopback only.
- Immutable finding resolutions that reverify one newer candidate revision across clean desktop and mobile evaluations, preserve the source finding, and reopen the derived status when proof degrades.
- Read-only Fix review with original evidence beside verified desktop/mobile repair evidence, revision and implementation-commit provenance, and CLI resolution inspection.
- Deterministic offline examples and a real-Chromium gate join complete desktop/mobile lifecycle histories to Studio navigation, Evaluation filters and comparison, evidence review, accessibility checks, responsive geometry, reduced-motion behavior, and per-module browser coverage. This local proof does not claim production parity or semantic media correctness.

The Codex skill and runner seam are implemented and tested offline. A genuine browser Bleep run has also exercised the runner and preserved local screenshots. The current acceptance audit records three verified 1440x900 runner artifacts from a partial desktop run, but the run is intentionally invalid because host uncertainty occurred before completion. It therefore does not claim a clean replay, promotion, desktop/mobile qualification, evaluation group, trustworthy audio inspection, or verified downloads. See `examples/bleep-browser-demo.acceptance.json` for the exact observed, blocked, and missing states. Playwright generation and iOS simulator support remain deferred.

## Development

```bash
npm ci
npm run check:fast
```

Use the smallest validation level that can disprove the current change:

- Run the directly affected test file while implementing.
- Run `npm run check:fast` before committing. It checks formatting, lint, unused code, types, and test capability classification without repeating the focused test you already ran.
- Run `npm run check` before handoff when backend behavior or coverage may change. It adds repository readiness, example validation, and the unchanged 80% line, 75% branch, and 90% function coverage gates.
- Run `npm run test:linux -- <lane>` to reproduce a specific CI lane in clean pinned Linux when platform behavior or a remote failure warrants it.
- Run `npm run check:full` for release-scale changes or when the complete browser, visual, accessibility, package, and audit surface is required. It is the local alias for the full `ci` gate, not the routine inner loop.

CI enforces Prettier formatting, ESLint, unused-code analysis, coverage thresholds, integration proofs, browser proofs, and package installability. Dependency auditing runs independently on the main branch and on its scheduled/manual workflow. Run `npm run format` to apply the repository style locally.
Development requires Node.js 22.13.0 or newer.

Package policy checks also lock the `@lineagehq/workflows` identity, preserve the `workflow` executable, require `private: true`, and pin any future publication to GitHub Packages rather than npmjs.org. The repository `.npmrc` contains only the registry mapping and never a token.

Validate the concrete Bleep examples:

```bash
node ./bin/workflow.js validate \
  examples/workflows.config.yaml \
  examples/bleep-browser-demo.workflow.yaml \
  examples/bleep-browser-demo.visual-check.workflow.yaml \
  examples/bleep-browser-demo.events.jsonl
```

Inspect the resolved mobile workflow:

```bash
node ./bin/workflow.js show \
  examples/bleep-browser-demo.visual-check.workflow.yaml \
  --platform mobile-web \
  --json
```

Launch a training run and let the agent claim it directly:

```bash
workflow train examples/bleep-browser-demo.workflow.yaml \
  --platform desktop-web \
  --json
```

New Training uses the runner-selected `authorized-codex-browser-v1` lease policy (120-second rolling expiry,
300-second hard expiry, heartbeat at 90 seconds remaining). Explicit legacy Training may select `standard`
(30/120/15) or `supervised-codex-browser` (120/300/90). Routine desktop evaluation pins the runner-only
`routine-codex-browser-v1` policy (120/300/90); agents cannot select or enlarge it.

Install the pinned Codex host skill in a consumer repository:

```bash
npx workflow init --host codex --local-url http://workflows.localhost:3000 --start-route /app/
```

Run initialization from an inspectable Git repository (or pass `--root` for one); initialize Git first for a new
consumer. This one post-install command creates `.workflows/` and `.agents/skills/agent-workflows/` without
overwriting local edits. The generated skill uses the same `workflow agent` protocol as other hosts. Its entrypoint routes operation-specific guidance to bundled references. Maintain `templates/agent-workflows/` and keep the repository-local copy synchronized; installer tests verify content and reference availability.

`workflow doctor --json` verifies local operation offline and reports package provenance separately from registry
readiness. Registry authentication and availability are never inferred. Request those checks explicitly with
`workflow doctor --registry --json`.

Run the deterministic end-to-end orchestration proof without controlling a browser:

```bash
npm run demo:scripted
```

The scripted proof validates the expected honest partial outcome and durable records. It does not claim that the live Bleep application passed or that audio was inspected.

Run the private, deterministic Bleep workflow benchmark:

```bash
npm run benchmark:bleep
```

The printed `http://workflows.localhost:…/` address contains a stable reference surface and an editable candidate
surface driven by one checked-in desktop/mobile workflow. The candidate contains one deliberate mobile defect for
exercising evaluation, durable findings, code fixing, targeted verification, and fresh full evaluation. The
benchmark is excluded from the published package and makes no production-parity claim. See
[`benchmarks/bleep-lab/README.md`](benchmarks/bleep-lab/README.md).

### Representative local Studio proof

Two additional offline laboratories exercise supervised workflow review without reaching their namesake production applications:

- Debt Is Fun uses explicitly fictional university and financial data for selection, card inspection, exact-route, and inert in-page share/copy-state proof.
- YTgify uses a small repository-owned WebM fixture for fixed trim, FPS, resolution, caption, structural GIF/download proof, a terminal resource-limit finding source, and a separate unavailable optional preview. Its pinned signature, dimensions, bytes, and hash do not establish semantic visual correctness.

The browser gate starts fresh runner-written histories and the real local Studio, sets 1440x900 and 393x852 before navigation, and uses `workflows.localhost` for every user-facing Studio URL. It verifies the decision-first hierarchy from rendered DOM geometry and semantics: one workflow identity, textual phase/status, evidence, recommended action, and the first phase decision precede closed technical workflow detail. The gate repeats route and contextual Back, phase navigation, disclosure, filter/clear, Refresh pending/terminal, comparison Back, and evidence-detail navigation with both normal and reduced-motion preferences.

Transition feedback is intentionally immediate and non-motion. Focus, active-state text, busy state, live announcements, and revealed content already make causality explicit; the accepted browser audit found that authored animation would add timing risk without improving understanding. Normal and reduced-motion journeys must remain semantically identical, and the proof uses condition-based state checks rather than sleeps or screenshot assertions. The committed [expected proof contract](docs/proofs/studio-browser-proof.expected.json) freezes inputs, assertions, coverage minimums, and privacy boundaries; it is not an observed result and makes no production-parity claim. Run the pair with:

```bash
node scripts/studio-browser-proof.mjs \
  --scenario benchmarks/debtisfun-lab/scenario-manifest.json \
  --scenario benchmarks/ytgify-lab/scenario-manifest.json
```

Training may pin the same workflow to the known-good reference without changing its bytes:

```bash
workflow train benchmarks/bleep-lab/workflow/bleep-lab.workflow.yaml \
  --platform desktop-web \
  --target-url http://workflows.localhost:41738/reference/ \
  --store .workflows/bleep-lab --json
```

After `workflow status shared fictional card --json` returns fresh, verified, selected truth, launch fresh candidate evaluations independently at the fixed desktop and mobile viewports. Keep the returned IDs internal:

```bash
workflow evaluate desktop --journey "shared fictional card" --store .workflows/debtisfun-lab --json
workflow evaluate mobile --journey "shared fictional card" --store .workflows/debtisfun-lab --json
```

The positional PATH forms remain available for compatibility with existing trusted automation; they are not required from a human.

The same stable product words drive the candidate lifecycle; the agent consumes returned IDs internally:

```bash
workflow train --journey "shared fictional card" --platform desktop-web --json
workflow replay candidate --journey "shared fictional card" --platform desktop-web --json
workflow promote --journey "shared fictional card" --replay RUN_ID --json
```

After restart, rerun `workflow status shared fictional card --json` rather than scanning files or asking a human for a path, ID, or revision. Its lifecycle projection recovers the exact latest promotion, qualifications, evaluation group, members, and routes for immutable follow-on commands. The positional `train PATH`, `replay candidate PATH`, and `promote PATH` forms remain compatibility-only.

Workflows has no approval gates for local or production execution. Complete requested launch, execution, retry, resume, replay, promotion, qualification, and evaluation without asking for permission in Workflows. Preserve leases, revision checks, evidence integrity, authentication, and cleanup. Record agent execution and runner validation accurately; optional review never gates completion and must never be presented as human acceptance unless a human actually recorded it.

Review a local durable store and make the narrow durable collaboration requests exposed by Studio:

```bash
workflow studio --store .workflows/local --port 41737
```

Open the printed `http://workflows.localhost:…/` URL. Studio binds internally only to IPv4 loopback, accepts only
the `workflows.localhost` host, and does not launch runs or upload evidence. Its allowlisted,
same-origin mutation controls can persist neutral review requests and pause, stop, or emergency-stop requests;
optional review records never gate execution, and Studio has no approval panel.
The agent rechecks state and evidence before committing. Screenshot captures may contain sensitive material; privacy
review and deletion remain user-managed.

Turn one note from a terminal completed or failed evaluation into a durable finding:

```json
{
  "schema": "agent-workflow-finding-input/v1",
  "stepId": "review-result",
  "noteIndex": 0,
  "lens": { "id": "ux", "label": "UX" },
  "severity": "medium",
  "title": "Result state needs clearer hierarchy",
  "recommendation": "Make the primary result and next action visually distinct."
}
```

```bash
workflow findings create RUN_ID --file finding-input.json --store .workflows/local --json
workflow findings list WORKFLOW_ID --store .workflows/local --json
```

The strict input supplies only step/note selection, lens, severity, title, and recommendation. Run identity,
workflow revision, platform, note text, evidence, hashes, and timestamps are reconstructed from durable records.
Studio reflects the new finding on refresh; its collaboration controls remain non-authoritative.

After a newer candidate passes both platforms in the same store as an open finding, record the independently
verified resolution without rewriting that finding:

```bash
workflow findings resolve WORKFLOW_ID FINDING_ID \
  --desktop-run RUN_ID --mobile-run RUN_ID --commit FULL_GIT_SHA \
  --store .workflows/local --json
```

## Design documents

- [`docs/product-usage-map.md`](docs/product-usage-map.md)
- [`docs/agent-first-review-plan.md`](docs/agent-first-review-plan.md)
- [`docs/product-spec.md`](docs/product-spec.md)
- [`docs/studio-spec.md`](docs/studio-spec.md)
- [`docs/workflow-protocol.md`](docs/workflow-protocol.md)
- [`docs/state-machine.md`](docs/state-machine.md)
- [`docs/cli-contract.md`](docs/cli-contract.md)
- [`docs/private-distribution.md`](docs/private-distribution.md)
- [`docs/repository-layout.md`](docs/repository-layout.md)

For multiple repositories, each `workflow studio` uses an available port by default.
After a package upgrade, preview generated guidance changes with
`workflow init --host codex --dry-run --json`, then rerun without `--dry-run` to apply.
Omit setup flags on repeat initialization to preserve existing project configuration.
See [multi-repository installation and upgrades](docs/private-distribution.md#multiple-repositories-and-upgrades).

## Evaluation questions and Performance

Perspective evaluations can now raise immutable, evidence-bound product questions when a criterion depends on undefined intent. Studio groups compatible occurrences into one product decision while showing every exact lens, platform, criterion, run, step, note, or artifact. A person can first send free-text discussion responses that agents read with the supported questions CLI; these leave the question open and create no requirement, approval, or acceptance. A typed human answer writes the resulting future-facing lens requirement to `.workflows/requirements.yaml`; the original questions and evaluations stay unchanged. Questions, discussion, findings, action execution, runner verification, requirement decisions, and human acceptance retain separate provenance.

New batches pin a Focused, Balanced, or Exploratory inquiry policy and the applicable requirements catalog. The native Performance lens runs independently on desktop and mobile and evaluates only trained large-input, progress, completion, limit, and recovery scenarios. It supplies no workload or latency threshold; missing product limits become questions, while unsupported browser timing or device-resource claims remain capability gaps.
