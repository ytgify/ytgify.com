import { resolve } from "node:path";

import { createSchemaRegistry, launchTrainingRun, RunControlStore } from "../src/index.js";

const registry = await createSchemaRegistry();
const store = await new RunControlStore(resolve(process.argv[2] ?? ".workflows/scripted-demo"), {
  registry,
}).init();
const launched = await launchTrainingRun({
  workflowPath: new URL("./bleep-browser-demo.workflow.yaml", import.meta.url),
  platform: "desktop-web",
  profile: "scripted-demo",
  store,
  registry,
});
const runId = launched.launchCard.runId;

process.stdout.write(
  `${JSON.stringify(
    {
      runId,
      status: launched.state.status,
      store: store.root,
      next: `workflow run approve ${runId} --store ${store.root}`,
    },
    null,
    2,
  )}\n`,
);
