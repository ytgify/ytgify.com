# Local Studio — Production Specification

Status: packaged Next.js/React Studio; read-only review plus frozen future intent and authority boundaries

## Purpose

Studio is the local human review surface for repository-owned agent workflows. One installed Workflows package serves one application's journeys. The CLI remains the mutation and automation surface; Studio reads the same durable records and never becomes a second source of truth.

Workflows has no approval gates. Runner validation, agent execution, and optional human review remain distinct. See [Execution without approval gates](approval-authority.md).

Application targets follow the same bridge. Studio consumes DiscoverySnapshot v2 target inventory and selection; it does not parse repository config or resolve URLs independently. People see target labels and environment names. Internal IDs and exact URLs remain machine data. A sole non-production target or configured non-production default may select deterministically, while production requires an explicit product-language match and never silently wins an empty or ambiguous choice.

Workflow v1 detail is route-relative and never exposes an environment URL as workflow meaning. Run, report, replay, and evaluation DTOs instead present the immutable launch target supplied by verified discovery: label and environment are primary product language, while target ID, selection/config provenance, route, canonical URL, and effective URL remain technical disclosure. Studio renders that record and never recomputes a URL, changes target identity after launch, or treats selection as approval. Workflow v0 target records remain readable during 0.2.x.

The supported command is:

```text
workflow studio --store PATH --definitions PATH [--port PORT]
```

The server binds to loopback and every user-facing URL uses `http://workflows.localhost:<port>`. Other Host values are rejected.

## Packaged frontend

The production frontend is a strict-TypeScript Next.js/React static export built from `studio-web/` into `dist/studio-next/`. The generated manifest is the only static-file allowlist. Its frozen manifest contract records one package-relative entry point, every served asset's positive byte size and SHA-256, and the canonical manifest digest. The package includes the generated export and root runtime modules; it excludes Next build caches, TypeScript source, source maps, and the superseded `src/studio/` frontend.

The legacy HTML entry point has been removed. Legacy JavaScript review helpers remain only in the repository while existing trusted regression tests import them; they are neither packaged nor served by a supported route. `/app.js` and every unlisted static path return 404.

The Node server remains authoritative for workflow discovery, lifecycle reconstruction, run reports, findings, resolutions, and verified evidence bytes. The frontend consumes only same-origin DTOs.

## Information architecture

Review is the default surface. It presents current attention items first, then recent verified outcomes, with full history in a disclosure. Screen coverage and app-map administration stay in their supporting contexts and do not precede review work.

The Journeys page is a reorderable table for one application. Each row provides journey status, Training evidence status, persona, and the next review. Pointer drag-and-drop and keyboard arrows share the same persisted local display preference, focus restoration, and transient acknowledgement; neither mutates workflow truth.

App map is a primary destination beside Review and Journeys. Its landing view consumes the deterministic `workflows-semantic-app-map/v1` projection and presents named Screen nodes, never screenshots, as topology. One journey is highlighted at a time; screens outside it remain hidden until the reviewer explicitly asks to disclose them. Selecting a Screen opens its named or unclassified Variants and exact desktop/mobile Observations. Evidence integrity and freshness remain explicit, and technical run, artifact, and hash identities remain in the screenshot inspector or labelled technical disclosures.

At 393×852 the graph is replaced by an ordered journey route. The same Screen selection, variant choice, exact evidence inspection, keyboard behavior, focus restoration, and reduced-motion semantics remain available without document-level horizontal scrolling. Missing, corrupt, unavailable, or stale observations never receive a substitute screenshot or create an implied transition.

Each journey has five views:

```text
Overview | Evaluations | Questions | Fixes | Acceptance
```

- **Overview** shows the accepted Training reference, desktop/mobile distinction, canonical steps, and verified screenshot evidence. An exact recorded attempt is labelled `Recorded Training` in the breadcrumb, tab, and content heading. Missing Training or evidence remains explicit.
- **Evaluations** lists durable evaluation groups and ungrouped evaluation runs newest-first and provides sortable columns on desktop plus equivalent compact controls on mobile. Exact group and run identifiers remain in the route. Each verified detail reuses the Journey step picker and evidence workspace; findings appear inline only at the exact linked step and evaluation record.
- **Questions** presents product decisions raised from exact evaluation evidence and supports bounded discussion and answers.
- **Fixes** is finding-centered. Each detail view reuses the Journey step picker, preserves the exact finding and resolution identities, and compares original evidence with independent verification evidence at the affected step. A bounded verified fix closes only its linked finding; it never accepts the whole journey.
- **Acceptance** is a persona-by-platform review matrix. Passing evaluation proof can support a decision but never creates acceptance. Until a separate human acceptance record exists, every cell says `Acceptance not recorded`.

Primary review content uses journey names, dates, platforms, perspectives, outcomes, and finding titles. Run, group, finding, artifact, resolution, target, and route identifiers remain in exact routes, evidence inspectors, or explicitly labelled technical disclosures. Machine reason codes are translated into readable explanations while their durable values remain unchanged.

Frozen short journey routes resolve against trusted catalog semantics without replacing their URL token. Legacy workflow overview, Training, evaluation run/group, finding, fix, release, and acceptance routes canonicalize to supported journey routes without dropping encoded identifiers or route tails.

Results and evidence links are record-scoped: evaluation groups require verified member lineage, qualifications, receipts, run replay, and artifacts; ungrouped runs require verified inventory, replay, and artifacts; findings and resolutions require their own verified integrity. A missing or degraded dependency displays `Unavailable` and cannot appear passed, resolved, accepted, or verified.

Route identity is equally record-scoped. Frozen `#/journeys/...` routes and supported legacy `#/workflows/...` Training run/step, evaluation run/source/comparison, and resolution routes preserve their encoded identifiers and query tokens while canonicalizing into the current shell. A route renders only when every requested workflow, run, step, evidence/note token, finding, resolution, and platform identity matches the trusted DTOs. Ambiguous application aliases and mismatched or degraded routes render an explicit unavailable state; they never select a first workflow or substitute a nearby record.

## Loading, errors, feedback, and motion

The catalog loads first. Training, evaluation, and finding DTOs then load independently so one slower reconstruction does not block the surrounding shell. Missing or failed sources render durable localized states and never infer a result.

An explicit refresh keeps the existing view while newer DTOs are requested. If catalog refresh fails, the existing view remains and an in-page alert records the failure. Toasts only acknowledge transient refresh and reorder operations; they never carry the only copy of an error, finding, fix, evidence status, or acceptance decision.

Motion is limited to short selected-content and toast transitions. `prefers-reduced-motion: reduce` removes transitions and animations while selected state changes remain immediate.

## Accessibility and responsive contract

The required viewports are 1440×900 and 393×852. Tables become compact stacked rows on narrow screens; journey steps scroll within their picker; the acceptance matrix scrolls within its own boundary. The document must not acquire unscoped horizontal overflow.

Interactive controls expose visible focus, 40–44px targets, current/pressed/busy state, live-region loading and toast feedback, keyboard route navigation, keyboard journey reordering, history restoration, and focus restoration. Automated browser proof covers axe serious/critical findings and reduced-motion behavior on both required viewports.

## Trusted HTTP boundary

The server accepts bodyless `GET` and `HEAD` requests on exact allowlisted static and API routes. It rejects unsupported methods, invalid Host values, traversal or encoded separator forms, query-bearing static paths, and unlisted assets.

Supported read APIs include:

- workflow catalog and Training review;
- evaluation review and evaluation groups;
- findings and verified resolutions;
- run list, run detail, run report, and run comparison;
- selected run evidence artifacts;
- lifecycle summaries.
- the versioned deterministic semantic App Map projection.

DTOs whitelist replayed fields and do not expose raw filesystem paths, leases, slots, request identities, diagnostics, or exception text. One corrupt workflow, run, finding, resolution, or artifact remains isolated from healthy siblings.

Workflows has no approval gates. Runner validation, agent execution, and optional human review remain distinct. See [Execution without approval gates](approval-authority.md).

Before serving evidence, the runtime reopens the selected run, validates registration and journal integrity, rejects unsafe directories and links, and verifies artifact length, hash, MIME type, and bounded image structure. Missing, corrupt, stale, and unavailable records remain distinct.

## Security policy

Every response uses `no-store`, `nosniff`, no-referrer, and frame denial. Static HTML is checked for inline event handlers, inline styles, unsafe URL forms, external resources, base tags, refresh redirects, frames, and other execution escapes.

The CSP keeps `default-src 'none'`, permits only self-hosted scripts plus exact hashes for exported inline bootstrap bytes, permits self-hosted styles/images/connections, and forbids `unsafe-inline`, `unsafe-eval`, `data:`, `blob:`, and font relaxations.

## Release proof

The checked-in [expected proof contract](proofs/studio-browser-proof.expected.json) defines the deterministic local browser scenarios and representative fixture evidence covered by repository CI. That local proof does not claim production parity or replace production-browser proof against independently deployed applications. Screenshot presence and artifact integrity likewise do not establish semantic visual correctness; that remains a human review decision supported by the captured evidence.

The named quality gates are:

- formatting and maximum-file boundaries;
- ESLint;
- Knip;
- strict TypeScript;
- React component coverage;
- Node unit and trusted API/evidence coverage;
- byte-deterministic Studio build;
- desktop and 393×852 browser walkthroughs;
- visual regression for shell, journey, evaluation, fix, and acceptance surfaces;
- accessibility, keyboard, and reduced motion;
- package policy and a fresh installed-package smoke test;
- dependency audit.

The approved mockup oracle is vendored as exact test-only bytes at `test/fixtures/studio-simplified-mockup/index.html`; SHA-256 `e9fb31f0587079d66970e5bfc0a7f22a80f150881a1118f8271249f101abdc7c` is verified without a developer-home or sibling-worktree dependency.

The fresh-package test builds and packs the artifact, installs it into an empty project, creates verified representative workflow evidence, starts through the installed CLI, accesses only `workflows.localhost`, checks every manifest asset/MIME/CSP/byte count, proves an unlisted asset is rejected, reads workflow/run/evidence APIs, and verifies clean shutdown.

## Native perspective review

Evaluation review displays a perspective matrix with rubric version, platform, required/optional membership, canonical journey outcome, quality and criterion coverage. Batch source and severity gate remain visible; neutral controls link to their exact independent run. Operators may select exactly two verified, perspective-tagged runs from the matrix and open an exact comparison. The comparison keeps each persona's rubric membership, platform, journey result, quality result, required coverage, criterion outcomes, and evidence navigation independent; it never computes a combined verdict or human acceptance. Historical records show “Perspective not recorded” and cannot be selected as persona proof. Identity profiles are separate from evaluation perspectives. The UI consumes verified server projections and does not infer missing passes.

Finding review displays explicit related evidence, the agent-authored correction contract, targeted proof and full reevaluation proof. Canonical-only historical resolution is labeled; related findings retain independent status. Captures show actual dimensions and geometry limitations alongside requested viewport, without implying physical-device evaluation.

Visible review resources refresh every five seconds and on focus or visibility return. Requests do not overlap. Hidden/unmounted or abandoned route subscriptions stop; stale responses are discarded. Exact routes wait for a fresh load before declaring a record unavailable. Selected run/platform/step remains stable during background refresh. Refresh failures remain visible and manual Refresh remains available.

## Evaluation questions and requirement decisions

Each journey has a Questions view with independent open, answered, dismissed, and unavailable counts. Compatible source questions from one batch that share a lens, requirement key, answer contract, and scope contract appear as one product decision. The list and detail retain every source question, platform, criterion, exact run and step, note/artifact occurrence, and verified evidence link. Evaluation step and perspective coverage links open the exact source-backed decision; questions never contribute to finding, fix, evaluation, or acceptance counts.

Studio builds native select, boolean, numeric-with-unit, and bounded-text controls from the trusted answer specification. Agent suggestions are labeled and rendered as escaped text with rationale. Agent-authored HTML is never accepted or injected. The form previews the requirement key and journey/project scope, explains that the source evaluation stays unchanged, and preserves the question on stale-catalog conflicts. A successful answer shows the resulting catalog hash and links back to fresh evaluations.

An open question places a separate bounded free-text response control for discussion with the agent directly after the prompt. Each response is appended with human/Studio provenance and displayed chronologically with responses from every grouped source occurrence. Perspective, criteria, steps, platforms, and source evaluations remain available in a collapsed **Evaluation context** section below the discussion. Sending a response leaves the question open, does not mutate the requirement catalog, and does not represent action approval, a requirement decision, or human acceptance. Secrets are rejected. Agents read responses through `workflow questions show` or `workflow questions list`; they do not scan the local store.

The inquiry-depth setting is project policy for future batches. Evaluation detail displays the exact depth pinned to that historical batch. `POST` answer, dismissal, and policy operations use the existing same-origin, fetch-metadata, JSON media type, body limit, CSRF, revision/hash, and idempotency boundary. Only an exact answer action records `actor: human` and `channel: studio`; it is neither approval nor acceptance. Questions remain usable at 1440×900, 393×852, and 320-pixel review widths without document overflow.
