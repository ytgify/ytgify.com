# CLI–Studio Semantic Bridge Contract

Status: Tranche 4 authority foundation

Release target: `@lineagehq/workflows@0.2.0`. Published `0.1.0` is immutable. Release candidates may use `0.2.0-rc.N`; registry `0.2.0` is canonical, while Git installation remains a supported development source.

## Project resolution

The canonical checked-in layout is `.workflows/config.yaml` and `.workflows/workflows/`; mutable local records are under `.workflows/local/`. Every resolved path is repository-contained and must fail closed on traversal or unsafe symlink ancestry.

Resolution has one precedence order:

1. an explicit config path supplied by the current command;
2. `<project-root>/.workflows/config.yaml`;
3. legacy no-config mode.

An explicit path that is missing or invalid is an error; it never falls through. A present canonical config that is invalid is an error; it never falls through. Legacy no-config mode is selected only when neither exists. It preserves the existing definition scan at `.workflows` and uses `.workflows/local` for new local state. This fallback is compatibility, not a second canonical layout. `ProjectContext` records the winning source and effective paths so CLI and Studio cannot resolve independently.

Config v1 replaces the single project URL with `project.targets`: one to sixteen uniquely identified `{id, label, environment, baseUrl, healthPath?}` records. Environments are `local`, `preview`, `staging`, `production`, or `other`; base URLs are HTTP(S) origins with an optional trailing slash and no credentials, pathname, query, or fragment. `project.defaultTargetId` may name a configured target. Config v0 remains valid throughout 0.2.x and is adapted in memory, without rewriting source, to one `legacy-default` target carrying `adapted-config-v0` provenance and a migration warning; its existing URL-bearing behavior is unchanged.

`workflow init --host codex` generates `local` plus optional, distinct `preview` and `production` targets. Only `local`
is the generated default. `--local-url` is canonical and legacy `--base-url` aliases only that local URL; the two forms
cannot be combined. All URL flags use the origin-only rule and fail before mutation. `--start-route` populates only
the starter workflow route, while `--health-path` populates only target readiness paths; both default to `/`. Preview
and production never become fallback choices when local truth is missing or unavailable.

Configured resolution emits ProjectContext v2 with one sanitized, ID-sorted `applicationTargets` inventory. ProjectContext v1 remains schema-valid compatibility input, and legacy no-config emits an empty target inventory. Target projection contains no repository paths. CLI and Studio consume this context rather than reading config or resolving target URLs independently.

`agent-workflow/v1` definitions are application-route intent: `start.route` is one origin-relative route and `target` contains no environment base URL. `agent-workflow/v0` remains valid throughout 0.2.x with its embedded `target.baseUrl` and `start.path`; positional definition paths and config v0 adaptation remain compatibility inputs. Platform resolution may specialize expected state and steps but never supplies or changes an application target.

Run creation does not select or reread a target. Language-first callers pass the already-resolved DiscoverySnapshot target, including its selection reason and configured/adapted provenance, into training, replay, routine evaluation, and evaluation-group launch. The runner validates and snapshots `{targetId, label, environment, selection, provenance}`, joins its verified base URL to the workflow route, and records the route plus normalized `canonicalUrl` and `effectiveUrl` in the immutable run manifest and launch card. Both members of an evaluation group pin the same target record. A v1 launch without resolved target truth fails closed. The expert `--target-url` compatibility adapter remains available and records neutral `target-url-adapter` provenance; when combined with a selected target it changes only `effectiveUrl`. Neither form changes workflow hashes or creates authority.

## Semantic discovery

`DiscoverySnapshot` is a verified, bounded fact projection for agents and Studio. Human-facing text uses journey name, purpose, platform, activity, and state; humans are never asked to find, copy, or provide an internal ID. Machine JSON includes exact workflow/revision identities and encoded Studio route hints.

DiscoverySnapshot v2 also owns `applicationTargets.inventory` and `applicationTargets.selection`. Agents consume exact target IDs and normalized URLs from JSON. Selection matches only product-language label and environment terms. Only a sole local target or configured local default selects automatically. Preview and production always require explicit product-language terms, whether sole, configured as a default, or present among multiple targets. Empty and ambiguous results remain unresolved, and the single human question lists labels and environment names only—never IDs, URLs, paths, or routes.

`projectDiscoverySnapshot(ProjectContext, options)` is the sole semantic projection. It consumes `catalogProjectWorkflows(ProjectContext)` rather than scanning or resolving project paths independently. The snapshot contains a sanitized project label, complete binding-specific workflow inventory, semantic candidates, run activity, findings, pending attention, review intents, lifecycle truth, and acceptance support. Durable source objects are projected through explicit allowlists, so filesystem paths, runner internals, and private evidence fields do not cross the bridge. All arrays use stable identity/time ordering.

Language-first candidate commands are `workflow train --journey "shared fictional card" --platform PLATFORM`, `workflow replay candidate --journey "shared fictional card" --platform PLATFORM`, and `workflow promote --journey "shared fictional card" --replay RUN_ID`. Their positional PATH forms remain compatibility only for trusted automation. Agents never ask humans for paths, IDs, or revisions and never scan, guess, or reconstruct them. After restart, the agent reruns ordinary-language `workflow status shared fictional card --json`; the same canonical lifecycle DTO used by Studio recovers the exact latest promotion, qualifications, evaluation group, members, and routes internally. Immutable lineage commands may then consume those JSON identities. Group identity integrity is separate from evaluation outcome: an awaiting verified group is `not-asserted`, never passed.

`current` means the editable candidate currently bound by repository content. `latest` means the highest verified immutable `vN` revision, comparing the numeric `N`, never timestamps or lexical order. A query uses exactly one binding. Candidate output is ordered by workflow ID. Zero matches returns `empty`; one exact semantic match returns `selected`; more than one plausible match returns `ambiguous` with all candidates and one product-language differentiating question. Implementations must not select the first item, use fuzzy tie-breaking, or substitute a nearby record.

Route hints are `#/journeys/<encoded-workflow-id>/...` and identify an exact trusted DTO. A mismatched, missing, ambiguous, stale, or degraded target renders unavailable or degraded truth; Studio never guesses another identity.

The App Map bridge follows the same human/machine boundary. `workflows-semantic-app-map/v1` exposes human screen, variant, journey, platform, state, integrity, and freshness fields in a deterministic `Screen -> Variant -> Observation` hierarchy. Exact visit, run, workflow, artifact, hash, sequence, and ordinal values remain available to agents in the observation's `technicalIdentity` object. Studio may expose that object only as collapsed technical detail; primary navigation and selection copy use human labels and never require an operational ID. The projection consumes explicit reviewed assignments and exact registered evidence only. It never derives identity from route, URL, screenshot similarity, workflow step, filename, or DOM state.

Freshness and integrity are independent. `freshness.status` is derived from `asOf`, the runner clock, and `maxAgeSeconds`; it never proves integrity. `integrity.status: degraded` retains sanitized known facts and issues but cannot support acceptance, promotion, qualification, or a success claim. Refresh and restart rederive both from durable sources.

Unreadable collaboration records retain their public record ID with `integrity: degraded`; they do not disappear from inventory or pending attention. A stale snapshot can remain independently verified, but neither stale nor degraded truth supports acceptance. Completed or passing activity never creates an acceptance entry. Exact routes are derived only from the selected verified workflow identity and use encoded workflow, run, and finding path components.

## Interaction and authority taxonomy

Workflows has no approval gates. Runner validation, agent execution, and optional human review remain distinct. See [Execution without approval gates](approval-authority.md).

The agent owns discovery, authorized operational commands, leased Browser execution, finalization, and status rereads. Workflow execution needs no Workflows approval. Optional CLI reviews record agent provenance; historical human review remains separately identifiable. Each phase independently reverifies durable truth.

## Immutable records

Review intent is append-only. Correction or cancellation creates another record using `supersedesIntentId`; it never rewrites the source. Acceptance is also append-only and binds exact workflow revision, content hash, verified evaluation group, decision, reviewed-decision hash, and timestamp. An evaluation is evidence only. Acceptance is never inferred from its result, and degraded evidence cannot satisfy acceptance.

`ReviewIntentStore` is rooted only through `ProjectContext.paths.localStore`. `appendIntent` accepts schema-valid `authority: none` records, creates immutable files, returns exact idempotent replays, rejects divergent idempotency reuse, and requires supersession to reference the same journey. Listing retains unreadable identities as degraded records.

`AcceptanceStore` is intentionally read-only: it exposes no append, create, or write method. Its default verifier rereads the latest promoted revision, immutable evaluation group, every member run, qualification, receipt, and artifact lineage. Only an exact current workflow, revision, content hash, and fully passed group returns `support: supported`. Missing verification, stale promotion, corrupt records, invalid or missing supersession, and cross-identity evidence remain visible with unavailable support.

Neutral collaboration mutations accept strict action fields only; caller-supplied actor, provenance, authority, trusted command names, or paths are rejected. Review intent and pause, stop, and emergency-stop require an expected revision and opaque idempotency key. Exact replay returns the original record or receipt; divergent reuse and concurrent revision changes fail closed. Their persisted provenance is server-owned `caller`/channel or run-event `adapter`, never `human`.

Resume records authorized agent execution with exact paused revision and idempotency checks. Optional review commands independently verify evaluation evidence before recording and immediately before immutable commit, with agent-command provenance. No Studio approval decision is required. A request or passing evaluation never creates a human acceptance record.

The Studio asset manifest enumerates the package-relative entry point and every served asset with byte size and SHA-256. Paths use the schema's portable ASCII alphabet, occur exactly once, and are ordered by ascending UTF-8 bytes. The entry point must equal exactly one asset path. Reordered or duplicate paths and an absent entry point are invalid even if the JSON Schema alone accepts the cross-item relationship.

`manifestDigest` is SHA-256 over UTF-8 bytes of exactly one minified JSON object followed by LF. Object keys are emitted in this order: `schema`, `formatVersion`, `entrypoint`, `assets`. Every asset object emits `path`, `size`, `sha256` in that order. Array order is the canonical path order. `manifestDigest` itself is omitted, making the construction non-recursive. No whitespace other than the final LF is present.

Package provenance uses an `agent-workflow-package-inventory/v1` inventory. Starting at the installed package root, the verifier recursively includes every regular shipped file with its package-relative path, byte size, and byte SHA-256. It rejects symlinks and other file types. It excludes `package-provenance.json`, `.git/`, and `node_modules/`; the provenance sidecar exclusion prevents recursion, while the latter two are installation transport rather than shipped package payload. Paths use the same alphabet, uniqueness, and ascending UTF-8 byte order as Studio assets.

`packageDigest` is SHA-256 over the UTF-8 minified inventory object followed by LF. Keys are `schema`, `files`; file keys are `path`, `size`, `sha256`. This one payload algorithm applies unchanged to Git, tarball, and registry installations. Equal shipped bytes produce equal package digests; the separately bound `source` records how those bytes arrived.

`provenanceDigest` binds every other provenance field. Its UTF-8 minified JSON input, followed by LF, emits keys in this order: `schema`, `package`, `source`, `commit`, `packageDigest`, `studioManifestDigest`, `verified`. The nested package emits `name`, `version`, `releaseTarget`. `provenanceDigest` is omitted from its own input. Thus source, commit, installed payload, Studio assets, release identity, and verification cannot change without changing provenance. Runtime or distribution code must recompute all applicable digests before making readiness claims.

## Executable contract

The JSON schemas are registered as `workflow`, `runControl`, `projectContext`, `discoverySnapshot`, `reviewIntent`, `acceptance`, `studioAssetManifest`, and `packageProvenance`. Golden fixtures under `test/fixtures/cli-studio-contract/` freeze route-relative workflow intent, configured and legacy contexts, empty/single/ambiguous/degraded discovery, authority boundaries, assets, the package inventory, and candidate provenance. Known-answer tests recompute all three package digests and reject asset reordering, duplicate paths, and missing entrypoint membership.
