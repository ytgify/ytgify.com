# Agent Workflow Protocol — Design Draft

Status: accepted semantic design baseline

Example target: `https://bleepthat.sh/bleep`

Scope: training, evaluation, fixing, and distinct bounded app exploration control

## 1. Purpose

This package should make agent-led product walkthroughs predictable, repeatable, and measurable without reducing them to brittle automation scripts.

A workflow defines an ordered semantic traversal through an application. The runner—not the agent's conversation memory—owns the active phase, workflow revision, current step, legal transitions, recovery budget, and evidence requirements.

Repeatability means that separate agents follow the same intent and checkpoints. It does not require identical scrolling, coordinates, timing, or low-level interactions. Evaluation runs are independent critical inspections; they are not scored against previous runs.

New lifecycle runs set `effectiveHashVersion: platform-v2` and hash `{ platform, workflow }`; absent version remains the legacy resolved-v1 calculation. Before the immutable manifest is written, the runner resolves the selected platform viewport: `default-desktop` is 1440x900 and an explicit width/height is preserved exactly. Screenshot MIME type, byte hash, actual parsed PNG/JFIF dimensions, and lifecycle `fullPage: false` are runner-derived. A screenshot slot pins the requested geometry; a differing actual capture is recorded as `viewport-mismatch`, and equality is required only where evidence declares `exactViewport`. Retries, guidance/intervention, pause/resume, emergency stop, reconciliation, handoff, unexpected state, uncertainty, deviations, or capability gaps make a run ineligible for lifecycle finalization.

Exploration uses the same run journal, owner, capability, lease, reconciliation, and registered screenshot authority with `phase: exploration` and no workflow reference. Each exact visit cites a byte-verified capture and leased action. Host-reported URLs, screen names, outcomes, and journey or sub-journey containment remain explicit unaccepted hypotheses. The separate [exploration contract](app-exploration-contract.md) defines limits, coverage gaps, and finish semantics.

The identical clean verifier is used before promotion or qualification and on every Studio qualification/evaluation read. It validates every screenshot, not only the reset and cleanup subset, and exact-compares replay/evaluation receipts to reconstructed proof. Qualification validation binds workflow, revision, platform, effective hash, and replay identity. Evaluation groups are persisted with both independent members.

Routine evaluation pins `routine-codex-browser-v1` 120/300/90 and starts directly from `run.created`. Declared reviewed batch executor fields are reconstructed from workflow bytes. A required step without an exact immutable batch is rejected at launch, and an unmatched proposal is denied. Capabilities, authentication, revisions, step order, finite leases, and evidence integrity remain required.

A referenced `routineDismissal` is a separate child trust boundary, never part of the parent proposal. Its workflow bytes pin `dialog` plus exact accessible name, `button` named `Close`, `browser.control`, one screenshot-before checkpoint, and `maxApplications: 1`. The evidence issue request names its attached `optionalHandlerId`, which remains bound through the slot, journal, artifact relation, replay, report, and serving. Ordinary evidence omits the ID and cannot substitute at a shared checkpoint. Authorization and completion requests carry IDs only. The runner reverifies the registered handler screenshot, derives the scope and hash, requires an unexpired automatic parent, and records adjacent `optional-state.authorized` / `optional-state.applied` events. The step commit must include that evidence; reports reverify and display it.

`workflow report` and the Studio report endpoint distinguish application cleanup from runner terminalization. Report `cleanupOutcome` is `passed` only when the runner recorded cleanup completion, the declared `evaluation.cleanupStepId` passed, and its screenshot proof verifies. Before runner cleanup has a terminal result, its existing `null` or absent value is preserved; otherwise unproved, blocked, missing, or failed cleanup reports `failed`. This is a failure to establish cleanup, not evidence that an unattempted cleanup action executed. The raw runner outcome remains in durable run state and the event journal; no additional report field is introduced. Verified successful reports retain their existing shape and hash, preserving findings bound to those reports. Reports whose cleanup was previously overstated intentionally change. Reports reverify evidence on every read, so missing/corrupt cleanup bytes can change the projected application result without rewriting run events or state. A failed earlier step that prevents cleanup can therefore truthfully report application cleanup `failed` and runner cleanup `passed`.

## 2. Durable records

The system has four durable record types:

1. **Workflow YAML** — human-readable actions and expected states.
2. **Local promoted workflow revision** — an immutable snapshot validated after clean replay and stored in the gitignored local registry.
3. **Run event log** — append-only JSONL from which run state and reports are derived.
4. **Evidence store** — screenshots, media inspections, videos, traces, and verified downloads referenced by events.

Reports are projections rather than another durable source of truth. The CLI and Studio reread these records, derive timestamps and outcomes from events, carry committed structured notes, reopen screenshot bytes, and emit the same DTO after restart.

The local studio reads and writes these same records. It must not maintain a separate hidden source of truth. Checked-in workflow YAML is portable; promotion and platform qualification are local operator trust in the first release.

## 3. Lifecycle

```text
human description
    -> agent discovery
    -> candidate workflow + storyboard
    -> human adjustments
    -> supervised replay
    -> immutable local promotion
    -> independent evaluation run(s)
    -> selected finding/failure
    -> fixing run
    -> targeted verification
    -> clean full rerun
```

Phase changes are explicit user actions. An agent cannot promote a workflow, enter fixing, or revise a promoted snapshot implicitly.

## 4. Workflow contract

The concrete example is in [`examples/bleep-browser-demo.workflow.yaml`](../examples/bleep-browser-demo.workflow.yaml).

Its formal shape is defined by [`schemas/workflow.schema.json`](../schemas/workflow.schema.json). Cross-reference, uniqueness, and lifecycle checks that JSON Schema cannot express are defined in [`state-machine.md`](state-machine.md).

### 4.1 Identity and lifecycle

Every workflow has:

- a stable workflow ID;
- a mutable candidate revision during training;
- an immutable local revision (`v1`, `v2`, and so on) plus canonical content hash after promotion;
- a lifecycle status;
- the supervised replay requirement used for promotion.

Changing the intended journey, expected outcome, or meaningful checkpoints creates a new workflow revision. A different low-level route or stale UI wording does not automatically revise the workflow.

### 4.2 Target and start state

The target describes the platform adapter and semantic environment, not browser-specific implementation details. Each run records the concrete browser, model, prompt/skill version, tools, app build fingerprint, viewport, and profile resolution separately.

A workflow declares its required fresh start and preconditions. The runner validates them before step one rather than letting the agent silently repair arbitrary prior state.

Configured v1 targets may require `authentication.mode: user-session`. Authentication is repository context rather than portable workflow content: one local binding names the exact project, configured target, environment, canonical origin, opaque browser profile, and user-confirmed non-secret marker. Config v0, undeclared targets, and expert URL adapters stay anonymous. No profile may be reused across targets.

The host capability `browser.user-session/v1` has four narrow operations: `open`, `propose-markers`, `verify`, and `clear`. The shipped Playwright adapter derives a contained profile directory from `workflows-<project-id>-<target-id>-<random-suffix>` below the ignored local-store root, while callers receive only the opaque identifier. It reports a capability gap when Playwright or its configured headed browser cannot launch and never substitutes another browser session.

Studio is the only process that owns the persistent contexts. It advertises a private loopback broker through a mode-`0600` local-store descriptor; CLI agent commands delegate verification to it and fail closed when the descriptor or owner is unavailable. In protocol capability records this is `id: browser.user-session` plus `contractVersion: 1.0`. Its adapter identity must equal the registered `browser.control` adapter identity. Successful verification yields an opaque `usersession_…` reference for the lease target, and all action/evidence work for that lease resolves the same owner-held context. Studio shutdown closes its contexts and removes only its own descriptor.

Setup opens the exact origin and leaves sign-in, MFA, SSO, passkeys, and similar challenges to the person. Workflows proposes bounded route-and-accessible-role markers and persists only the confirmed non-secret choice. Credentials may not enter chat, flags, standard input, environment variables, protocol payloads, screenshots, recordings, or evidence. Cookies, tokens, and browser storage remain inside the browser-owned profile.

Before every authenticated run and immediately before an already-governed consequential action, the runner performs a fresh exact marker verification and compares a one-way hash of the current Studio session generation to the immutable manifest. New authenticated launches require that binding. Legacy authenticated v1 manifests that predate it remain readable so operators can inspect and reconcile uncertain actions without replay, but a missing binding is stale authority and cannot start a new browser mutation. The runner never synthesizes or rewrites a binding into an immutable legacy run. A profile directory or earlier `lastVerifiedAt` value is never readiness proof, and raw session/profile IDs are not exposed. Clearing and reprovisioning a target invalidates existing runs even if the same marker is selected again. An authentication challenge pauses the run as `awaiting-authentication`; evidence capture stays disabled until the person signs in again and the owning host completes `agent.authentication.verify`. An uncertain action is reconciled first and never repeated: `completed` advances, `indeterminate` remains blocked, and only `not-executed` returns to marker verification. Clear failure retains the local `clear-failed` binding so cleanup can be retried truthfully.

Routine and perspective evaluation may satisfy `target.identity.requirement: named-profile` only with that exact configured opaque user-session contract. Every Neutral or specialist member is a fresh independent run with its own reset, marker verification, evidence, attempt receipts, and cleanup. The immutable member manifests pin a predecessor chain, and a later member cannot mutate the shared session until its predecessor is terminal and its cleanup evidence reopens as verified, so reset-through-cleanup lifecycles cannot interleave. A failed, blocked, or deviated journey does not suppress later perspectives after that verified cleanup. Perspective metadata never widens browser authority, and no generic browser can substitute for the pinned session.

### 4.3 Canonical traversal and platform overrides

One workflow may support multiple platforms when they preserve the same user intent, ordered checkpoints, and completion condition. The canonical steps remain platform-neutral. A platform override may refine:

- start-state wording and platform constraints;
- action guidance where controls or navigation differ;
- explicitly skipped steps when the promoted workflow permits them;
- platform-specific evidence requirements.

An override must not quietly replace the traversal, weaken a required expectation, or create a different completion condition. If the semantic journey differs materially, it is a separate workflow.

### 4.4 Steps

Each step requires:

- a stable step ID;
- a human-readable action;
- one or more human-readable expected states;
- evidence requirements;
- allowed optional-state handlers and recoveries;
- dependencies used to distinguish downstream `blocked` from `failed`.

Expected states remain natural language. The agent returns observations, while the runner enforces that every required expectation receives an explicit verdict.

### 4.5 Optional-state handlers

Optional UI such as onboarding dialogs is modeled separately from the main traversal. A handler defines:

- the state that activates it;
- the allowed action;
- the expected postcondition;
- an application limit.

Applying a handler is always logged. It does not silently alter workflow progress.

### 4.6 Evidence and adapter capabilities

Evidence requirements are semantic capabilities rather than tool commands. Examples include:

- `screenshot` — capture a named visual checkpoint;
- `media-inspection` — inspect rendered audio/video over a declared interval;
- `download-artifact` — verify filename, MIME type, size, and retained evidence reference;
- `failure-video` — retain video or trace when a step fails or deviates.

Required capabilities are safely probed during preflight. Training exploration may continue with a visible capability gap. Clean replay, qualification, and evaluation are `blocked` with reason `capability_unavailable` when they require unavailable evidence. A gap must not be mislabeled as an application failure or silently treated as passed.

## 5. Step outcomes

Every attempted step ends in exactly one outcome:

- `passed` — action completed and all required expectations/evidence passed;
- `passed_with_deviation` — checkpoint succeeded through a materially different route;
- `failed` — the application did not satisfy a required expectation;
- `blocked` — the step could not be judged because a dependency, capability, environment, or precondition was unavailable;
- `skipped` — permitted only by an explicit platform condition in the promoted workflow.

An evaluation is complete when every step is accounted for and cleanup has been attempted. Completion does not imply that every step passed.

## 6. Run event protocol

Run history is append-only JSONL. Existing events are never edited in place. Corrections and superseding decisions are new events.

### 6.1 Common envelope

Every event contains:

```json
{
  "schema": "agent-workflow-event/v0",
  "eventId": "evt_...",
  "runId": "run_...",
  "sequence": 1,
  "occurredAt": "ISO-8601 timestamp",
  "type": "run.started",
  "source": "runner|agent|human|adapter",
  "workflowRef": {
    "id": "bleep.browser-demo.clean-download",
    "revision": "v1",
    "contentHash": "sha256:...",
    "platform": "mobile-web",
    "effectiveHash": "sha256:..."
  },
  "payload": {}
}
```

Rules:

- `sequence` is strictly increasing within a run.
- `eventId` is globally unique.
- `contentHash` identifies the immutable canonical source file.
- `effectiveHash` identifies the resolved canonical definition plus the selected platform override.
- `workflowRef` is repeated so detached event fragments retain platform and provenance.
- agent-supplied observations are untrusted input until accepted by the runner.
- evidence bytes live outside JSONL; events contain hashes and relative references.
- secrets, cookies, authorization headers, and raw credentials are never valid evidence.
- setup and reauthentication produce no screenshots, recordings, DOM captures, failure traces, or other evidence.

### 6.2 Core event types

| Event                                 | Source        | Purpose                                                                |
| ------------------------------------- | ------------- | ---------------------------------------------------------------------- |
| `run.started`                         | runner        | Pin workflow, phase, target, executor, environment, and policies.      |
| `preflight.checked`                   | runner        | Record start-state and capability validation.                          |
| `authentication.verification_started` | runner        | Pin an exact marker verification attempt before any action lease.      |
| `authentication.verified`             | runner        | Record a fresh sanitized success for the pinned target and marker.     |
| `authentication.required`             | runner        | Pause for direct user sign-in without claiming an application failure. |
| `step.started`                        | runner        | Advance the authoritative cursor to one legal step.                    |
| `optional_state.observed`             | agent         | Report a declared optional state.                                      |
| `handler.applied`                     | runner        | Record an allowed handler and its budget use.                          |
| `observation.recorded`                | agent         | Attach structured facts to the current step.                           |
| `evidence.captured`                   | adapter       | Register a hashed evidence artifact.                                   |
| `evidence.inspected`                  | agent/adapter | Record semantic inspection and verdict.                                |
| `deviation.recorded`                  | runner        | Preserve a materially different route or recovery.                     |
| `finding.recorded`                    | agent         | Record a typed lens finding for this run occurrence.                   |
| `step.completed`                      | runner        | Finalize the step outcome after validation.                            |
| `cleanup.started`                     | runner        | Begin always-attempt cleanup.                                          |
| `cleanup.completed`                   | runner        | Record cleanup independently from traversal success.                   |
| `run.completed`                       | runner        | Close the run after every step is accounted for.                       |
| `run.tainted`                         | runner        | Record an environment/build change that invalidates a clean pass.      |

An illustrative successful log is in [`examples/bleep-browser-demo.events.jsonl`](../examples/bleep-browser-demo.events.jsonl).
Every line is validated independently by [`schemas/event.schema.json`](../schemas/event.schema.json); event ordering and state legality are governed by [`state-machine.md`](state-machine.md).

## 7. Legal transition rules

The runner enforces these invariants:

1. Only one step may be active.
2. A step can start only when its dependencies have acceptable outcomes.
3. The agent cannot request an arbitrary next step; it asks the runner for the current instruction.
4. A required evidence capability must be satisfied or explicitly block the step.
5. Optional handlers and recoveries consume declared per-step budgets.
6. A completed step is immutable; a rerun creates a new attempt or run event chain.
7. `run.completed` is illegal until all steps have terminal outcomes and cleanup has a terminal result.
8. A material target-build change emits `run.tainted`; a tainted run cannot be a clean verification.

## 8. CLI/agent protocol boundary

The npm package exposes a host-neutral transactional CLI protocol. A Codex skill is the first host integration; later hosts can implement the same protocol.

The proposed command surface, directive/response loop, idempotency rules, locks, exit codes, and security boundaries are specified in [`cli-contract.md`](cli-contract.md). The consumer repository and local run-store layout are specified in [`repository-layout.md`](repository-layout.md).

Lifecycle operations:

```text
workflow train
workflow evaluate
workflow replay
workflow fix
workflow promote
workflow studio
```

Machine operations live under `workflow agent`: `claim`, `inspect`, `capabilities`, `propose`, `commit`, `heartbeat`, `reconcile`, and `release`. The complete behavioral contract is in [`cli-contract.md`](cli-contract.md).

## 9. Bleep discovery implications

The production walkthrough exposed several required distinctions:

- The first demo launch may show an onboarding dialog. This is an optional-state handler, not a new workflow branch.
- The demo preselects a profanity. The workflow intentionally toggles and reselects it so selection behavior is exercised rather than merely observed.
- Preview success requires inspecting rendered media, not trusting that playback was initiated.
- The app's clean-file-ready state is not proof that the browser downloaded a file.
- A blob URL may not produce a conventional download event in every adapter. Missing artifact-observation capability blocks download verification; it does not prove an app defect.
- Desktop and mobile preserve the same demo traversal, expectations, settings, and completion condition, so they belong to one canonical workflow.
- Mobile changes the initial message and disallows the local-file path, but still offers the built-in demo. This is a platform start-state constraint rather than a branch in the demo workflow.
- Desktop exposes progression through `Step 3, Preview & Download`; mobile exposes a persistent `Preview` action beneath the transcript. This is platform-specific action guidance, not a semantic step difference.
- Both discovered browser surfaces produced blob download links that the current adapter did not observe as conventional download events. The shared failure belongs to adapter capability reporting, not to either platform override.

## 10. Related accepted specifications

- [`product-spec.md`](product-spec.md) defines the agreed training, evaluation, replay, fixing, evidence, lens, and platform behavior.
- [`studio-spec.md`](studio-spec.md) defines the human control plane and storyboard experience.
- [`cli-contract.md`](cli-contract.md) defines action leases, reconciliation, capability registration, and JSON transactions.
- [`repository-layout.md`](repository-layout.md) defines the checked-in versus local trust boundary.

Remaining implementation design includes schema migration after `v0`, audio inspection details, blob-download capture, exact lens rubrics, Playwright mapping schemas, and native iOS capability mappings.

## Evidence-bound product questions

A perspective run pins inquiry depth, requirement catalog hash, applicable normalized requirements, and the effective rubric hash before any member is created. Agents inspect those values before assessment. Requirements guide judgment but cannot add steps, scenarios, action batches, capabilities, evidence access, targets, or leases.

A question is an immutable sidecar to one exact run, lens, criterion, scenario, step, and verified note or artifact. It never changes traversal or pauses unrelated work. Missing product intent produces an unassessed criterion linked to the question; an observed application defect remains a finding; missing instrumentation remains a capability gap. These records cannot substitute for one another.

Studio may append a human discussion response while leaving the question open; agents read it through the questions CLI. Discussion carries no decision authority. Studio may later turn a typed answer into a portable requirement plus a separate local human decision receipt. Existing runs and assessments retain their pinned inputs and result. Only a fresh batch can consume the new catalog hash. Agent execution, runner verification, human discussion, a human requirement decision, and human acceptance remain distinct provenance facts.
