# Consumer Repository and Local Registry — Design Draft

Status: accepted first-release storage boundary; Tranche 0 canonical paths and fallback frozen

## 1. Storage boundary

The package is installed into one application repository. Workflow definitions, logical profiles, and future deterministic test mappings may be checked into Git.

Codex discovers the agent experience through the repository's `workflows` plugin. The plugin packages a `workflows` skill for installation through the `lineagehq-workflows` marketplace; the npm package separately installs the runner, CLI, Studio, and a version-pinned repository contract.

The first release keeps these records local and gitignored:

- raw runs and media;
- studio drafts;
- immutable promoted revisions;
- replay receipts and platform qualifications;
- retention metadata, caches, leases, resolved secrets, and temporary files.
- authenticated-session coordination metadata and browser-owned persistent profiles.

Promotion is local operator trust. Another checkout receives the portable workflow definition but not its qualification status.

The filesystem remains authoritative. The studio does not require or maintain a separate database.

`<store>/lifecycle/workflows/<workflow-id>/vN/` contains immutable snapshot bytes and promotion provenance. Separate append-only `replays`, `qualifications`, `evaluation-groups`, and `evaluations` directories hold receipts. Immutable findings live under `<store>/findings/<workflow-id>/` and bind exact evaluation notes to their run, step, lens, and evidence. Immutable verified resolutions live under `<store>/resolutions/<workflow-id>/<finding-id>/`; they bind the unchanged finding to one newer candidate revision, an implementation commit, and clean desktop/mobile evaluation reports and evidence. Promotion first stages a journaled transaction under `lifecycle/transactions`; startup completes an interrupted publish and index update exactly once. Every existing ancestor under the store is checked as a real directory, never a symlink. Run data remains under `<store>/runs`; group manifests use contained relative evidence-directory identities and never portable qualification trust.

The promotion lock records its owning process and is opened without following links. Startup or the next writer preserves a live owner's lock, but atomically reclaims a dead owner's exact inode before recovering. Recovery handles a journal-only transaction, a partial stage, a complete stage, a published revision, and an indexed revision: incomplete stages roll back; complete stages publish and index once; journals and dead locks are flushed away. Every lifecycle index, transaction, snapshot, record, listing root, and destination checks the full populated ancestry before access.

## 2. Consumer repository layout

The one canonical config path is `.workflows/config.yaml`; configured workflow definitions are in `.workflows/workflows/`, and all mutable local state is in `.workflows/local/`. Resolution precedence is explicit command config, then canonical config, then legacy no-config fallback. Missing or invalid explicit/canonical config is an error, not permission to fall through. Legacy no-config projects continue to scan `.workflows` for definitions and use `.workflows/local` for local state. See `cli-studio-semantic-bridge-contract.md` for the executable `ProjectContext` contract.

Config v1 keeps one to sixteen named application targets under `project.targets`. Each checked-in target has an internal ID, human label, environment class, HTTP(S) origin without credentials, pathname, query, or fragment, and optional origin-relative health path; `project.defaultTargetId` may name a non-production default. Resolution sanitizes these records into ProjectContext v2 and discovery projects the same inventory. Config v0 remains readable through an in-memory legacy-target adapter during 0.2.x and is never rewritten as a side effect.

Fresh initialization always creates the distinct `local` target and makes it the only implicit default. Optional
`preview` and `production` targets are created only from explicit URLs and require explicit product-language selection
at use time. Initializer URL flags accept only origins; `--start-route` independently controls the generated starter
workflow route and `--health-path` independently controls target readiness paths, with `/` as both defaults.
`workflow init` is the sole post-install repository initializer; exact devDependency and lockfile changes remain owned
by the consumer's package manager. Existing config files are compared byte-for-byte and never migrated or rewritten
as an initialization side effect.

Workflow v1 files are portable across those targets: they store an origin-relative `start.route`, never a base URL or target ID. The selected target is repository context, not workflow meaning. Run manifests under `<store>/runs` snapshot the resolved target identity, label, environment, selection/config provenance, route, canonical joined URL, and effective URL. Replay and evaluation reuse that injected snapshot contract; they do not resolve config from lifecycle storage. Workflow v0 URL-bearing files remain valid compatibility inputs through 0.2.x.

```text
app-repository/
├── package.json
├── .gitignore
├── .agents/
│   └── skills/
│       ├── agent-workflows/              # generated, inspectable Codex host
│       └── implementation-slices/         # repository development guardrail
└── .workflows/
    ├── config.yaml
    ├── profiles.yaml
    ├── workflows/
    │   └── bleep.browser-demo.clean-download.yaml
    ├── mappings/
    │   └── playwright/
    │       └── bleep.browser-demo.clean-download/
    │           ├── desktop-web.yaml
    │           └── mobile-web.yaml
    └── local/                         # ignored
        ├── operator.json
        ├── auth-sessions/             # sanitized exact-target bindings
        ├── browser-profiles/          # browser-owned cookies, tokens, and storage
        ├── drafts/
        ├── promotions/
        ├── qualifications/
        ├── evaluation-groups/
        ├── findings/
        ├── resolutions/
        ├── runs/
        ├── cache/
        ├── locks/
        ├── secrets/
        └── tmp/
```

The current package-level `.gitignore` excludes `.workflows/local/`. A later full project initializer will also create a nested ignore guard and verify that local evidence is not tracked before capture.

## 3. Checked-in records

### `config.yaml`

Project paths, lifecycle commands, adapter configuration, evidence policy, retention classes, and studio settings. Canonical path values are `.workflows/workflows` and `.workflows/local`. It contains logical references rather than credentials.

### `profiles.yaml`

Named setup, reset, health-check, fixture, identity, teardown, platform, and secret-reference contracts. Resolved identities and secrets remain local.

### `workflows/*.yaml`

Portable editable workflow definitions. They contain stable intent, expected outcomes, evidence requirements, platform guidance, guards, and recoveries.

A checked-in workflow does not assert that it is promoted or qualified. Git history is useful collaboration history but does not replace local lifecycle records.

### `mappings/playwright/**`

Reviewed deterministic derivatives. A mapping pins the source workflow content hash and platform-effective hash. Any relevant workflow change marks it stale. Generation and review remain future product slices.

## 4. Local registry

### `operator.json`

Local provenance preferences. Human approvals snapshot the repository's current Git author name and email rather than trusting this file as authentication.

### `drafts/`

Recoverable studio edits keyed by workflow ID. A draft records its source content hash, semantic operations, accepted agent proposals, and unresolved conflicts. It is not trusted workflow content until explicitly written to YAML.

### `promotions/`

Immutable local snapshots stored by workflow ID and revision:

```text
promotions/
└── bleep.browser-demo.clean-download/
    ├── index.json
    ├── v1.yaml
    └── v1.provenance.json
```

The index maps the human revision to a canonical content hash. Promotion fails if a revision path already exists or if the replay receipt no longer matches the candidate content.

### `qualifications/`

Per-revision platform status: verified, failing, stale, unsupported, or not configured. Qualification points to one clean replay run and becomes stale when relevant canonical content, platform guidance, evidence requirements, profile policy, or adapter contract changes.

### `evaluation-groups/`

One group manifest lists the neutral run, selected lens runs, required versus optional members, pinned workflow revision and hash, group policy, and derived result. Member findings and evidence remain inside their individual runs.

### `resolutions/`

One immutable record links an unchanged candidate finding to the same newer candidate revision on desktop and mobile. Creation rereads the finding source, both terminal evaluation journals, every required screenshot, cleanup, attempts, uncertainty, intervention events, and canonical hashes. The stored `verified-resolved` value is historical creation truth; list, show, and Studio derive the current finding status again on every read. Missing, corrupt, or changed proof therefore returns the finding to `open` with degraded resolution integrity.

### `runs/`

Append-only events, immutable registered evidence, adapter diagnostics, and rebuildable studio views.

Executable v1 runs also pin the resolved definition as `workflow.json` beside the immutable manifest. Exact protocol responses are cached by request ID under `protocol-responses/`; the event transaction retains their normalized input and result hashes so duplicate requests cannot mutate state.

`workflow init --host codex` installs the package-pinned skill at `.agents/skills/agent-workflows/`. It creates `SKILL.md`, Codex metadata, the complete reference set, and a generated hash baseline. It upgrades only files that still match a known Workflows baseline and refuses to overwrite a locally modified file. The installable plugin skill is generated from the same templates under `plugins/workflows/skills/workflows/`; CI verifies that both copies remain synchronized with the package and protocol version.

### `auth-sessions/` and `browser-profiles/`

`auth-sessions/<project-id>/<target-id>.json` stores only revision-checked coordination metadata for a configured `user-session` target: exact project/target/environment/origin scope, an opaque session/profile ID, a confirmed non-secret route/role/name marker and its hash, sanitized state, and timestamps. It contains no credentials, account identity, cookies, tokens, authorization headers, storage state, form values, or absolute profile paths. A scope mismatch is stale and cannot resolve another target's session.

The `browser.user-session/v1` Playwright adapter maps the opaque `workflows-<project-id>-<target-id>-<random-suffix>` identifier to one contained directory under `browser-profiles/`. Only the browser owns its cookies, tokens, and storage. The host opens that exact persistent profile at the exact origin; callers never receive its directory. Profile existence is not readiness proof—the runner always verifies the confirmed marker before work—and a missing Playwright or headed-browser capability fails closed.

Clearing removes the browser profile before its metadata record. If browser cleanup fails, the record remains `clear-failed` for retry rather than claiming removal. Neither directory is portable, checked in, synced, exported, or included in workflow definitions, releases, run history, screenshots, recordings, or evidence.

### `cache/`

Disposable schema compilation, normalized workflow, graph, thumbnail, and studio caches.

### `locks/`

Expiring filesystem coordination. Locks are not authority and do not permit a replacement agent to claim a run without explicit handoff and reconciliation.

### `secrets/`

Optional local secret-provider metadata. Secret values should remain in environment variables, the OS keychain, or another configured provider whenever possible.

### `tmp/`

Same-filesystem atomic-write staging, adapter working data, and evidence awaiting verification. Unverified temporary files never count as workflow evidence.

## 5. Run layout

```text
.workflows/local/runs/
└── 2026-08-24/
    └── run_01K.../
        ├── manifest.json
        ├── events.jsonl
        ├── view.json
        ├── receipts/
        ├── evidence/
        │   ├── artifact_01K....png
        │   ├── artifact_01M....jpg
        │   └── artifact_01K....webm
        ├── adapter/
        │   ├── diagnostics.jsonl
        │   └── evidence-slots/
        ├── registered-evidence/
        └── links/
            ├── parent-run.json
            ├── source-finding.json
            └── verification.json
```

### `manifest.json`

The immutable run header contains run ID, phase, parent, workflow reference, local revision and hashes when applicable, platform, profile, group membership, executor and adapter identities, environment fingerprint, schema versions, policy, and creation time.

### `events.jsonl`

The authoritative append-only event stream. Each accepted line is flushed before success is returned. Corrections and superseding decisions are new events.

### `view.json`

A disposable materialized view for the studio. It records the source event sequence and can be rebuilt from the manifest, event log, workflow artifact, and evidence metadata.

### `receipts/`

Rebuildable transaction receipt caches keyed by request ID. The authoritative request and result hashes live in the accepted event, so a crash after the event flush but before receipt creation still permits an exact idempotent retry.

### `evidence/`

Artifacts are registered by type, time, source capability, size, content hash, sensitivity flag, and related event or checkpoint. Optional-handler evidence also retains its runner-validated `optionalHandlerId` in the slot, journal, event, and artifact relation; legacy and ordinary artifacts omit it. Filenames are runner-generated. Agent-supplied arbitrary paths never become durable evidence references.

Screenshot capture first uses neutral `.screenshot` names in `adapter/evidence-slots/`; exact legacy runner-issued `.png` slots remain recoverable. The runner records each path's complete lease/checkpoint binding before the host writes bytes. Registration opens without following symlinks, structurally validates a regular conforming PNG or bounded baseline JFIF within the byte limit, and preserves those exact bytes through a flushed atomic publication to `evidence/`. The runner derives `image/png` plus `.png` or `image/jpeg` plus `.jpg`; filenames and callers never select format. `registered-evidence/` supports interruption recovery and is never caller-authored protocol input.

### `adapter/diagnostics.jsonl`

Adapter facts distinguish tooling gaps from application failures. Credentials, cookies, authorization headers, and raw secret values are prohibited.

### `links/`

Typed references connect forked training runs, selected fixing findings, targeted checks, and subsequent full evaluations without duplicating or rewriting source records.

## 6. Atomicity and durability

- Config and workflow writes use same-directory temporary files followed by atomic rename.
- Promotion writes each revision once and verifies the canonical hash before updating its index.
- Events append under a short filesystem write lock and flush before acknowledgement.
- Mutations also enforce expected run revision and idempotency key.
- Evidence is written to `tmp`, verified and hashed, then atomically moved before registration succeeds.
- Materialized views record their source event sequence.
- Draft rebase never writes workflow YAML until all semantic conflicts are resolved and approved.

## 7. Portability

Checked-in paths use forward-slash repository-relative references. Run events use run-relative evidence references. Absolute paths may appear only in local adapter diagnostics.

The project may relocate `.workflows/local` outside the repository, but the logical registry layout and path-containment rules remain the same.

Shared promotion manifests, evidence exports, and remote collaboration are explicitly deferred. The design preserves canonical hashes and provenance so those capabilities can be added without changing workflow meaning.

## Development verification

Node tests are assigned exactly once by `test/capabilities.json` to the default, integration, browser, package, or distribution lane. `npm run test:capabilities` validates that boundary. The dominant authenticated lifecycle process/terminal proof runs independently from the default coverage lane; the default lane retains every other integration test so the repository coverage thresholds remain unchanged. The package lane is offline after the repository dependency snapshot and deterministic Studio artifact are prepared; real Git/npm installation belongs only to the distribution lane.

The repository-local `implementation-slices` skill also defines the implementation workspace contract: inspect repository and worktree state before editing, keep user changes out of implementation worktrees, prune only verified clean completed worktrees, record exact local process ownership, and register teardown before continuing a proof. Cleanup is deliberately exact and conservative; broad process killing and destructive repository resets are not part of the workflow.

`npm run test:linux -- <lane>` runs the selected package script in a pinned Linux image. It stages a read-only source snapshot, installs dependencies into disposable state, and discards generated files and caches after the run. Use it as the pre-push boundary and to reproduce CI-only behavior; local macOS remains the faster inner loop.

## 8. Retention and deletion

Retention is tiered:

- promoted replay evidence is pinned until superseded or explicitly unpinned;
- evaluation evidence follows configured age or count limits;
- training attempts expire sooner;
- abandoned and invalid-preflight captures expire soonest.

Expiry removes media and derived thumbnails while preserving a minimal audit record. Evidence linked to the active promotion receipt or an open fixing run cannot be deleted automatically.

The studio shows exact pending deletion targets. Material manual deletion is explicit and reports whether recovery is possible.

## 9. Studio access

The studio watches checked-in definitions and the local registry. It validates before writing YAML, uses the same runner mutations as the CLI, and never appends events or edits promotion snapshots directly.

The first release binds internally to loopback, presents only `workflows.localhost`, and refuses LAN exposure. The local report is a restart-stable projection of durable records; portable export and automatic uploads are not supported.

Native perspective contracts live in `src/evaluation-perspectives.js`, `src/perspective-assessment-store.js`, `src/perspective-batch-store.js`, and `src/perspective-batches.js`, with corresponding schemas and tests. Local stores add `perspective-assessments/` and `perspective-batches/`. Finding-specific contracts, targeted receipts and explicit issue relations live under `finding-verification-contracts/`, `finding-verifications/`, and `finding-relations/`. These records preserve original run/finding evidence; Studio reconstructs current integrity without rewriting history.

## Evaluation questions and requirements memory

`.workflows/requirements.yaml` is portable, reviewable project memory. It stores a project ID and normalized typed requirements with project or journey scope plus optional platform, perspective, and criterion selectors. It contains no secrets, evidence paths, local actor data, or inferred approvals.

The gitignored local store adds `evaluation-questions/<run-id>/<question-id>.json`, `question-policies/<project-id>.json`, and `requirement-decisions/<question-id>/` for requirement decisions, discussion responses, and question dismissals. Every record is append-only and hash-bound to its source. Inquiry policy is revisioned local preference. Discussion responses retain text, idempotency, `actor: human`, and `channel: studio` but carry no decision authority. Decision receipts additionally retain before/after catalog hashes, answer, and scope. Local records are excluded from the published package and do not rewrite portable history.
