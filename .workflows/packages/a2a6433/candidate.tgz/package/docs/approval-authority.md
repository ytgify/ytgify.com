# Execution without approval gates

Workflows executes requested workflows on local and production targets without terminal challenges, Studio approval panels, or authorization-policy decisions.

| Operation                   | Behavior                                                      | Provenance                               |
| --------------------------- | ------------------------------------------------------------- | ---------------------------------------- |
| Launch, replay, evaluation  | Start immediately after input and lineage validation          | Runner event                             |
| Action lease                | Validate capabilities, step order, revision, and lease timing | Runner lease; agent execution            |
| Retry and resume            | Apply normal recovery and revision checks                     | Agent command                            |
| Promotion and qualification | Reverify immutable evidence and lineage                       | Runner validation                        |
| Stop and emergency stop     | Preserve explicit interruption controls                       | Request provenance                       |
| Optional review             | Record only when explicitly requested; never gate execution   | Agent command or historical human review |

New runs emit no approval events. Historical approvals remain readable and retain their original source. Inspecting a historical pending run validates its technical prerequisites before appending an `approval.retired` migration event from the runner, restoring its prior state, and requiring the next command to use the current revision. Pending promoted evaluations must still match their immutable group and member fields; missing or changed lineage leaves the waiting state untouched. These checks run again immediately before the journal write. No old approval is rewritten or granted. Stored Studio requests are inert; no decision endpoint remains.

Technical blockers remain: unavailable authentication or capabilities, stale revisions, expired leases, uncertain execution, missing or altered evidence, and failed cleanup. A local synthetic test still proves only its recorded test behavior. Target-app and underlying agent-platform permissions are outside Workflows.

CLI review records have agent-command provenance and cannot claim human acceptance. Historical human reviews remain distinguishable. Supersession is resolved across all verified review records before checking the current head’s actor; an agent review can retire an earlier human decision but cannot confer human acceptance. No review record is created by completion, promotion, qualification, or evaluation.
