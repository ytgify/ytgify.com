# Runner State Machine — Design Draft

Status: legacy traversal reducer implemented in `v0`; `run-event/v1` control, durable workflow cursor, store, and first training CLI loop implemented

Schemas: [`workflow.schema.json`](../schemas/workflow.schema.json) and [`event.schema.json`](../schemas/event.schema.json)

## 1. Authority

The runner is the sole authority for run state and sequence allocation. Agents and adapters propose observations or evidence; they do not mutate the cursor, mark their own steps complete, or choose a different phase.

State is derived by replaying the append-only event log. A cache or studio database may materialize that state, but it is disposable and must be reproducible from the log plus the pinned workflow artifact.

This document describes traversal immediately after run creation. Outer run-control statuses such as `preparing`, historical `awaiting-approval`, `paused`, `reconciling`, and agent handoff wrap this traversal state and obey the transactional protocol.

For a pinned authenticated target, `awaiting-authentication` is an outer run-control status independent of traversal. The runner enters it after preflight or a later authentication challenge, records no evidence while it is active, and returns to the same run only after the owning host freshly verifies the exact target and confirmed marker. Authentication readiness never grants launch, production, safety-boundary, mutation, or acceptance authority.

Replay and evaluation use the same journal reducer with strict preflight. Lifecycle finalization accepts only completed, single-attempt, deviation-free state with passed preflight, every step, journey, cleanup, and verified non-full-page screenshots at 1440x900 desktop or 393x852 mobile for the declared reset and cleanup steps. The full journal must contain no intervention, pause/resume, emergency stop, reconciliation, handoff, unexpected state, uncertainty, rejected action, or capability gap. Evaluation manifests are non-resumable, so `run.resumed` is illegal.

This same complete read-only verifier gates promotion, promoted replay launch, qualification, evaluation launch/finalization, and Studio lifecycle projection. Promotion truth is transitive: every use reopens the immutable snapshot, checks its byte and canonical hashes, reconstructs the exact `Promote <workflow> <revision> <hash> from <candidate-run>` confirmation, and revalidates the original candidate replay receipt, clean journal, reset/cleanup screenshots, viewport, and reset contract. Qualification likewise reconstructs its exact workflow/revision/platform/effective-hash/replay challenge. A downstream qualification or evaluation cannot remain trusted when either approval or any upstream promotion proof is missing, corrupt, stale, or divergent. Runner operations occur only after verification succeeds. Evaluation group construction is `two awaiting run manifests -> immutable group record -> desktop authorization -> mobile authorization`; there is no state in which a member is approved without durable group ancestry. An authorization error preserves the immutable group and unapproved member state rather than manufacturing rollback or readiness.

An interrupted initial lifecycle launch can be authorized with `workflow run approve RUN_ID`. The runner rechecks the immutable manifest, exact initial journal, revision, boundary, and durable evaluation group member before recording runner authorization. Concurrent attempts cannot authorize a different revision.

## 2. Effective workflow resolution

Before `run.started`, the runner:

1. loads an immutable local promoted workflow revision for replay or evaluation, or the approved candidate for training;
2. verifies its source `contentHash`;
3. selects one declared platform;
4. applies that platform's override to the canonical definition;
5. validates the resolved definition;
6. computes an `effectiveHash`;
7. repeats the workflow ID, revision when applicable, source hash, platform, and effective hash in every event.

This makes desktop and mobile runs self-describing while preserving one canonical traversal.

## 3. Run states

```mermaid
stateDiagram-v2
    [*] --> Created
    Created --> Preflight: run.started
    Preflight --> Ready: preflight.checked passed
    Preflight --> Cleanup: preflight.checked blocked or failed
    Ready --> Running: step.started
    Running --> Running: observation / evidence / handler / finding
    Running --> Ready: step.completed and steps remain
    Running --> Cleanup: step.completed and all steps accounted for
    Ready --> Cleanup: remaining steps become dependency-blocked
    Cleanup --> Closed: cleanup.completed then run.completed
    Created --> Abandoned: no run.started event persisted
```

`run.tainted` sets a durable taint flag over `Preflight`, `Ready`, `Running`, or `Cleanup`. It does not erase the underlying state. A tainted run may continue gathering diagnostic evidence but cannot close with `passed` or serve as a clean verification.

### Authenticated run-control gate

An authenticated run completes ordinary preflight, then appends `authentication.verification_started` before the first action lease. `authentication.verified` returns the outer control state to `active`; `authentication.required` sets `awaiting-authentication` and exposes only a sanitized recovery action. After an interrupted verification, the host inspects again and retries with the newly inspected current run revision while preserving the same pinned target, marker hash, owning host, and session binding; the pre-start revision is stale.

The same verification occurs immediately before every already-governed consequential action and after any authentication challenge. Failed authentication verification blocks leasing until authentication is restored; it never requests approval. Profile existence and historical verification never satisfy the gate, and setup or reauthentication cannot capture evidence.

Authentication loss never resolves an uncertain lease. Reconciliation runs first and the action is never repeated: `completed` advances normally, `indeterminate` remains blocked for human review, and only `not-executed` may append `authentication.required` and return to marker verification.

## 4. Step states

Each resolved step is in exactly one state:

```text
pending -> active -> passed
                  -> passed_with_deviation
                  -> failed
                  -> blocked
pending --------------------------> blocked
pending --------------------------> skipped
```

- `pending -> active` requires `step.started`.
- `active -> terminal` requires `step.completed` validated by the runner.
- `pending -> blocked` is allowed when a dependency has failed or blocked and the step cannot be meaningfully attempted.
- `pending -> skipped` is allowed only when the effective platform definition explicitly permits the skip.
- Terminal step events are immutable. Retrying creates a new attempt number before a terminal event, or a new run if the previous attempt already closed the step.

## 5. Transition table

| Event request                           | Required current state                        | Guard                                                                                                                   | Result                     |
| --------------------------------------- | --------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------- | -------------------------- |
| `run.started`                           | no run                                        | promoted workflow, hashes, platform, phase, profile, executor, and environment are pinned                               | `Preflight`                |
| `preflight.checked: passed`             | `Preflight`                                   | start state is proven; capabilities required for a clean verdict are available, or training records exact explicit gaps | `Ready`                    |
| `preflight.checked: blocked/failed`     | `Preflight`                                   | reason recorded                                                                                                         | `Cleanup`                  |
| `step.started`                          | `Ready`                                       | no active step; requested step is the next legal step; dependencies permit execution                                    | `Running`                  |
| `optional_state.observed`               | `Running`                                     | handler is declared for active step                                                                                     | no state change            |
| `handler.applied`                       | `Running`                                     | handler budget remains; postcondition is recorded                                                                       | no state change            |
| `observation.recorded`                  | `Running`                                     | observation belongs to active step                                                                                      | no state change            |
| `evidence.captured`                     | `Running`                                     | evidence belongs to active step and artifact hash is valid                                                              | no state change            |
| `evidence.inspected`                    | `Running`                                     | referenced evidence exists and inspection capability is declared                                                        | no state change            |
| `deviation.recorded`                    | `Running`                                     | alternate route is material and checkpoint status is explicit                                                           | no state change            |
| `finding.recorded`                      | `Running`                                     | built-in lens is active; rationale, severity, and confidence validate                                                   | no state change            |
| `step.completed: passed`                | `Running`                                     | every expectation and required evidence item passed                                                                     | `Ready` or `Cleanup`       |
| `step.completed: passed_with_deviation` | `Running`                                     | checkpoint passed and at least one deviation exists                                                                     | `Ready` or `Cleanup`       |
| `step.completed: failed`                | `Running`                                     | at least one application expectation failed                                                                             | `Ready` or `Cleanup`       |
| `step.completed: blocked`               | `Running`                                     | inability to judge is attributed to capability, dependency, precondition, or environment                                | `Ready` or `Cleanup`       |
| `step.completed: skipped`               | `Running` or `Ready`                          | effective platform definition explicitly permits it                                                                     | `Ready` or `Cleanup`       |
| `run.tainted`                           | `Preflight`, `Ready`, `Running`, or `Cleanup` | material environment fingerprint change is recorded                                                                     | same state plus taint flag |
| `cleanup.started`                       | `Cleanup`                                     | traversal accounting is complete or preflight terminated                                                                | `Cleanup`                  |
| `cleanup.completed`                     | `Cleanup`                                     | cleanup has a terminal outcome                                                                                          | ready to close             |
| `run.completed`                         | `Cleanup`                                     | every step is terminal, cleanup is terminal, summary counts reconcile, taint restricts outcome                          | `Closed`                   |

## 6. Runner-derived guards

The runner rejects an event or command when any invariant fails:

1. event sequence is not exactly the next number;
2. event ID already exists;
3. workflow reference differs from the pinned run reference;
4. event payload fails `event.schema.json`, or agent input fails `response.schema.json`;
5. step ID, handler ID, checkpoint, or dependency is absent from the effective workflow;
6. an agent attempts to emit a runner-owned event;
7. evidence is claimed without an adapter-produced artifact reference and hash;
8. required evidence is missing when a pass is requested;
9. recovery or handler budget is exhausted;
10. the app build fingerprint changes without `run.tainted`;
11. step summary counts do not equal the number of effective steps;
12. cleanup or run closure is attempted early.

## 7. Dependency-aware continuation

After a failure or block, the runner calculates reachability from the failed step:

- dependent steps that cannot establish their preconditions become `blocked` without interaction;
- independent observational steps may still run when safe;
- cleanup always remains reachable;
- the agent cannot overrule dependency blocking by improvising a new path.

This preserves the distinction between “the application failed here” and “later behavior could not be judged.”

For executable v1 runs, `evidence.slot-issued` preserves the runner-owned binding while the action lease remains active. Every declared screenshot checkpoint may receive a slot, while only declarations whose `required` value is not false participate in required-evidence completeness. `evidence.registered` is legal only for that slot and lease and adds runner-computed artifact metadata without advancing the step. A subsequent `action.committed` may reference those registered IDs. A training assessment may use `capability_unavailable` only when preflight recorded the named gap and the active step requires it; all unvisited descendants then receive `dependency_blocked`.

Workflows has no approval gates. Runner validation, agent execution, and optional human review remain distinct. See [Execution without approval gates](approval-authority.md).

Successful protocol responses carry runner-authored current time and, when active, rolling/hard remaining budgets plus threshold guidance. Heartbeats derive `min(occurredAt + rolling, hardExpiresAt)` and may not shorten or exceed the lease. At `occurredAt >= expiresAt`, heartbeat, slot issuance, evidence registration, and commit are illegal. Idempotency lookup precedes this boundary, so a previously durable identical transaction reconstructs the exact cached response and original timing after expiry without a new event.

Routine evaluation pins `routine-codex-browser-v1` 120/300/90 and starts directly from `run.created`. Declared batch executor fields are reconstructed from workflow bytes. Other valid proposals lease without approval. Capabilities, revisions, step order, finite leases, and evidence integrity remain required.

An automatic routine parent lease may capture a referenced handler's exact before-state checkpoint. Its issued slot and artifact relation carry the exact attached `optionalHandlerId`; ordinary evidence omits that field and cannot satisfy handler evidence even at a shared checkpoint. `optional-state.authorized` is runner-derived only after the registered screenshot is reverified and bound to the same run, host, lease, step, handler, checkpoint, and pinned `routineDismissal`. It records the derived dialog/Close scope and contract hash. Only an identical `optional-state.applied` may occupy the next revision. Replay state counts the application, forbids a second, blocks commit while authority is active, and requires applied-handler evidence in the step commit.

Evidence ingestion journals the runner-derived artifact before preservation. New slots use neutral `.screenshot` names, and the runner derives format solely from strict PNG or bounded baseline JFIF structure. PNG chunk types must keep the reserved bit clear. JFIF accepts only APP0(JFIF), DQT, SOF0, DHT, SOS, and EOI markers; all extension, hierarchical, arithmetic, progressive, restart, TEM, DHP, EXP, DNL, and JPG markers are invalid. The runner writes unchanged verified bytes to a private temporary file, flushes and atomically publishes them under the canonical extension, and records filesystem identity. At `evidence.registered`, a final journal-backed reopen must match the request and runner-issued slot, pathname and inode, full media structure, canonical MIME/extension when present, exact size, and hash. Recovery works for both formats at every cut point and preserves legacy v1 PNG records without mandatory `mimeType`.

Before `action.committed` appends, every referenced registration receives the same journal, pathname, inode, PNG/JFIF structure, MIME/extension, size, and hash validation. Commit processing never relies on replayed artifact metadata alone, so evidence replaced or corrupted after registration cannot support a successful step assessment.

## 8. Recovery and optional-state budgets

Recoveries do not advance the cursor. For the active step, the runner tracks:

- recovery action count;
- elapsed recovery time;
- optional-handler applications by handler ID;
- evidence captured before and after recovery;
- whether the route became a material deviation.

Exhausting a budget does not automatically mean the application failed. The runner completes the step as `blocked` unless a required application expectation was directly observed to fail.

## 9. Interruption, resume, and handoff

Evaluation runs are never resumed after interruption. An ambiguous evaluation action ends in reconciliation and then `blocked` if its outcome cannot be proven. A completed or not-executed reconciliation closes the non-resumable evaluation as `abandoned`; release and fresh-host claim cannot turn that history into a resumable run.

Training may resume when the agent judges the visible state usable, but the resumed history cannot serve as promotion proof. On training resume or explicit agent handoff:

1. replay the event log and validate its hash chain or storage integrity;
2. identify the run state and active step, if any;
3. restore the pinned effective workflow, executor metadata, environment fingerprint, and budgets;
4. revalidate the live target against the last confirmed checkpoint;
5. record the agent's state-reconciliation rationale, uncertainty, and capability changes;
6. emit `run.tainted` if the environment changed materially;
7. if state is usable, continue the active attempt as non-promotion evidence;
8. otherwise fork a fresh training run or close the active step as blocked.

The new agent does not infer the cursor from prose history. A replacement host also requires an explicit handoff; an expired lock does not confer app-operation authority.

## 10. Outcome derivation

The runner derives the final run outcome:

- `tainted` if the run has a taint flag;
- `failed` if any step failed;
- `blocked` if no step failed and any step is blocked;
- `passed_with_deviation` if all other steps passed or were permitted skips and any step passed with deviation;
- `passed` if all steps passed or were permitted skips and all required evidence passed.

Cleanup failure is reported independently and prevents a wholly clean result even when traversal steps passed. The report must show traversal outcome and cleanup outcome separately.

## 11. Schema validation versus semantic validation

JSON Schema validates record shape. The runner must additionally enforce cross-record and cross-file semantics that JSON Schema cannot express reliably, including:

- unique workflow step and platform IDs;
- dependency references and absence of dependency cycles;
- override keys matching supported platforms and step IDs;
- handler references matching declared handlers;
- end time occurring after start time in media intervals;
- monotonically increasing event sequence and timestamps;
- legal event source for the authenticated caller;
- evidence hashes matching bytes on disk;
- event order and state-transition legality;
- final summary reconciliation.

## Questions do not add lifecycle gates

Question proposal is a side effect of evaluating exact evidence and does not create an awaiting state. A run continues through its remaining declared steps and cleanup. Undefined product intent leaves only the affected criterion unassessed. Dismissal closes the question record without changing coverage; a Studio answer creates a requirement for future batches without changing the active or historical run.

The answer transaction verifies question integrity and evidence, compares the expected requirements catalog hash, publishes the catalog atomically, and appends the human decision receipt. A stale or interrupted transaction remains recoverable and idempotent. It does not grant action authority, runner validation, promotion, qualification, or acceptance.
