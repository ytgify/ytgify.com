# App map live data and local identity

`GET /api/app-map` lists reconstructed run metadata without reading artifact bytes. `defaultCandidate` means a completed current Training run with known application and target may be checked; `defaultEligible` is always false in this inventory. Any unreadable run disables automatic candidates for that inventory. Explicit run selection remains available for healthy records. Candidate binding compares the pinned candidate revision with the configured workflow's candidate revision.

Workflow-less exploration runs are intentionally separate from ordinary App Map references. The catalog skips a valid exploration run without marking Training references unavailable; a genuinely unreadable or corrupt Training run still produces a diagnostic and suppresses automatic candidates. `GET /api/explorations` lists lightweight run summaries without verifying capture bytes and reports unreadable run IDs separately, so one corrupt record does not hide healthy explorations. `GET /api/explorations/:runId` builds a read-only detailed review with coverage and unaccepted screen, journey, and sub-journey proposals; that detailed review verifies capture bytes and exact lease/commit lineage. A reported page URL is a host claim, not an evidence URL or accepted screen identity. See [bounded exploration](app-exploration-contract.md).

`GET /api/app-map/runs/:runId` projects exactly that run using the existing Studio evidence verification boundary. It does not substitute another run. `defaultEligible` additionally requires the existing Training proof rules and verified artifact replay. The client must use this exact verification before presenting an automatic reference. Historical/evaluation records remain explicit selections.

Visits use first artifact introduction in verified event sequence, with within-event ordinal for legacy embedded artifacts. Visit IDs encode run ID, sequence, ordinal, artifact ID and content hash. Repeated checkpoint/step captures are distinct. Later commits referencing an existing artifact do not manufacture another visit. Legacy captures without registered evidence remain unavailable; image URLs are exposed only for registered, verified exact artifacts. Verified bytes have availability `available`; missing/corrupt/stale states stay explicit.

Application IDs come from the pinned workflow target. Target keys conservatively include exact target ID, environment, canonical/effective URL and source. Different route URLs therefore remain separate reference groups; the map never assumes route compatibility. Unknown application/target cannot become automatic references.

Screen identities are optional local metadata in `app-map-registry.json` under the configured run store. There is no automatic URL/image-based assignment. Missing or invalid registry leaves captures unresolved and usable. Screen IDs are scoped by app ID. A shared screen label must be consistent across assignments; labels can be renamed without changing IDs.

`GET /api/app-map/projection` is the versioned, deterministic application-level read model. Its schema is `workflows-semantic-app-map/v1`; the server validates every response before returning it. Applications and screens are ID-sorted, variants are ID-sorted with the unclassified group first, observations are sorted by workflow/run/event identity, and transitions and their occurrences are likewise sorted. Reordering the registry assignments or run enumeration cannot change the response bytes.

The projection has one explicit `Screen -> Variant -> Observation` hierarchy. A capture without a reviewed variant is retained in a `{ variantId: null, variantLabel: null, classification: "unclassified" }` group; that is missing classification, not a synthetic Default variant. Each observation preserves its platform, contextual state, human journey label, exact evidence URL, integrity, and freshness. Missing, corrupt, unavailable, and stale evidence never receives an evidence URL and never contributes a transition. An unresolved observation between two resolved observations interrupts the edge, so the map does not imply an unobserved transition.

Stable operational identities are available to agents under each observation's collapsed `technicalIdentity` object: exact visit, run, workflow, artifact, content hash, event sequence, and within-event ordinal. Primary Studio presentation uses the application, screen, variant, journey, platform, state, integrity, and freshness fields; it must not promote `technicalIdentity` values into ordinary navigation, labels, or selection copy. The hierarchy is built only from explicit reviewed assignments. Routes, screenshot similarity, workflow steps, DOM signatures, and filenames never create or merge screen or variant identities.

Read current registry with `workflow app-map registry --root PROJECT --json`. Import a complete replacement assignment set using `workflow app-map import --root PROJECT --file IMPORT.json --expected-revision 0 --json`. Both commands support `--store` for an explicit store. The import object is:

```json
{
  "schema": "workflows-app-map-registry/v1",
  "assignments": [
    {
      "visitId": "COPY THE EXACT visitId FROM THE RUN ENDPOINT",
      "appId": "application-id",
      "screenId": "stable-screen-id",
      "screenLabel": "Readable screen name",
      "stateLabel": "Optional captured state"
    }
  ]
}
```

The example placeholder must be replaced, not submitted literally. Imports validate every assignment against the exact pinned app, run, occurrence/hash and verified artifact. Conflicting entries, unknown schemas, stale revisions and unsafe registry paths fail closed. Updates use an exclusive writer lock and atomic replacement; every prior assignment set is retained with its revision and update time. Run events and outcomes remain untouched. To rename a screen, update all its labels in the replacement set while retaining screen IDs and exact visit IDs.

## Studio screen assignment

`GET /api/app-map/registry` remains the compatible assignment-editor response and returns `{ revision, assignments, screens }`. Screen choices contain `appId`, `screenId`, and `screenLabel`; consumers must filter choices by the selected run's application. Audit history stays in the local registry rather than being copied into every UI response. Existing CLI registry/import and single-run API shapes remain unchanged; consumers opt into the semantic projection through its new route and schema discriminator.

`POST /api/app-map/assignments` changes one exact visit while preserving all unrelated assignments:

```json
{
  "expectedRevision": 0,
  "visitId": "COPY THE EXACT visitId FROM THE RUN ENDPOINT",
  "appId": "application-id",
  "screen": { "screenId": "events", "screenLabel": "Events", "stateLabel": "Empty results" }
}
```

Use `screen: null` to remove that visit's assignment. Reassignment and removal use the same revision-checked path and retain prior assignment sets in the audit; run events, outcomes, screenshots and hashes are unchanged. Even removal verifies that the supplied visit belongs to the exact application and registered evidence. Screen labels must agree with existing assignments for the same app and screen ID; bulk screen renaming remains an explicit CLI replacement operation.

Writes require the existing exact Studio host, same-origin header, JSON content type, and CSRF token from `/api/csrf`, with the existing 16 KiB body limit. Unknown request fields, invalid assignments, and unavailable exact evidence return 400. A stale revision or active writer returns 409 `REVISION_CONFLICT`; clients must reload and preview again instead of silently retrying against a new revision. A successful response returns the updated registry summary. An unreadable registry returns 503 `APP_MAP_REGISTRY_UNAVAILABLE` and cannot be overwritten through this route.

## Named variants and agent proposals

Assignments may additionally carry `variantId` and `variantLabel` together, plus an optional `journeyLabel`. A variant identity is scoped by application and core screen, and its label must be consistent within that scope. Existing assignments without variants remain valid. `stateLabel` describes a particular capture; `journeyLabel` supplies its contextual display name. Neither changes the core screen roll-up. Selecting a journey continues to select that journey's exact recorded capture.

The agent bridge uses `workflow app-map inspect --run RUN_ID --root PROJECT --json` to inspect a run and `workflow app-map proposals --root PROJECT --json` to list proposals. `propose`, `apply`, and `undo` each take `--file JSON_PATH`, along with the same project/store options. Agents author proposals after inspecting evidence; the bridge does not perform image classification itself.

Studio routes use the same mutation security as assignment editing:

- `GET /api/app-map/proposals` returns the current registry revision and durable proposals.
- `POST /api/app-map/proposals` accepts `{ expectedRevision, items: [{ visitId, appId, screen, explanation }] }`. `screen` uses the assignment shape, or null for removal. Creation verifies identities and evidence but does not change assignments.
- `POST /api/app-map/proposals/apply` accepts `{ proposalId, expectedRevision, visitIds }` for an explicitly selected subset. It changes that subset atomically, preserving unrelated assignments, and returns `{ registry, receipt: { proposalId, appliedRevision, visitIds } }`.
- `POST /api/app-map/proposals/undo` accepts `{ proposalId, appliedRevision, expectedRevision, visitIds }` from an application receipt plus the current revision. It verifies the audited application and restores its selected prior assignments, returning `{ registry }`.

Proposals retain the original affected assignments for comparison. A current revision does not alone make a stale proposal safe: the affected before-values must also match. Conflicts require rereading and reviewing current state. Undo cannot silently replace later edits. Proposal explanations are untrusted display text, never instructions or execution authority. Every accepted mutation preserves run events, screenshots and outcome history.

## Classification coverage and collection follow-through

`app-map inspect` returns an ordered work queue derived from existing registered
captures, rather than creating a second queue that could drift from evidence.
Each visit includes sequence, ordinal, step/checkpoint, its current assignment,
classification (`evidence-unavailable`, `screen-unassigned`, `variant-unassigned`,
`classified`), and outstanding proposal IDs/statuses. Coverage counts describe
recorded captures only. `variant-unassigned` means no named variant is recorded;
it does not establish that a variation is required or that execution failed.
A proposal-inventory failure is explicit in diagnostics and does not hide evidence.

After registering captures, collecting agents inspect this queue, inspect actual
verified screenshots, reuse pending proposals, and propose missing classifications.
Classification must not delay lease-bound action commits or modify run outcomes.
Resume by inspecting again; do not duplicate pending work or infer screen identity
from a URL, filename, expected step result, or another run's screenshot.

Core screen identity describes a functional destination. A named variant describes
a meaningful visible presentation (for example mobile populated Events versus
mobile no-results Events). The same variant may recur at several visits. Search
cleared is contextual state when the populated presentation returns, not necessarily
a new variant. Minor focus, tooltip, or data-text differences need not create variants.
Use a stable named Default variant only after review establishes that the screen
needs no more specific distinction; an absent variant remains unclassified.

Studio displays capture verification and screen assignment independently, shows
named variants on exact-run cards and selectors, and annotates adjacent variant
changes within a core screen. Unresolved captures remain in sequence and interrupt
shared screen edges. Coverage is not an assertion of complete application coverage.

Proposal creation derives a stable proposal ID from the expected registry revision
and canonical item content (independent of item and object-key ordering). Atomic
no-overwrite publication makes concurrent identical retries return the same durable
proposal. Existing malformed or mismatched content at that identity fails closed.
Registry revision checks and verified screenshot checks still apply to retries.

Exact map-run responses also include `requiredCaptures`, reusing the authoritative
required screenshot review from the run projection. Studio displays this separately
from observed-capture counts and lists missing checkpoints without manufacturing
visits. Optional-handler evidence does not satisfy ordinary screenshot requirements.
