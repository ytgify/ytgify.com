# Private package distribution

## Current status

Published prereleases remain immutable. They predate the stable authenticated-workflow contract.
The repository release candidate identity is `@lineagehq/workflows@0.4.0`; the executable remains `workflow`.
The source `package.json` retains `"private": true`, which makes npm refuse direct publication. Published
`@lineagehq/workflows@0.1.0` and the unrelated public `@neonwatty/agent-workflows@0.1.0` are immutable external
state and must not be changed or unpublished as part of this work.

Candidate construction is local proof, not publication approval. From a clean reviewed commit, run
`npm run package:release-candidate -- --commit FULL_SHA --output NEW_DIRECTORY`. The constructor rejects mutable
refs, a dirty or non-HEAD source, package/lock drift, missing provenance, an existing destination, and unverifiable
installed output. Its immutable record binds the candidate bytes, exact commit, complete package contents, package
and Studio digests, and installed-package doctor output. Building the same commit twice must produce byte-identical
tarballs and records. No tag, registry credential, or publication confirmation is required for this local proof.

Consumers install the exact candidate with their package manager as a development dependency, including exact
manifest and lockfile provenance. The package does not self-install, use `postinstall` to mutate the repository, or
edit consumer package metadata. After that package-manager-owned step, `workflow init --host codex` is the single
repository-initialization command.

The two reversible pilot constructors consume only that candidate and each requires a new workspace and receipt
path. Run the anonymous starter with `npm run pilot:anonymous -- --candidate PATH --journey benchmarks/debtisfun-lab/workflow/debtisfun-shared-card.workflow.yaml --workspace NEW_PATH --output
RECEIPT_PATH`. Run the media pilot with `npm run pilot:media -- --candidate PATH --journey WORKFLOW_YAML --workspace
NEW_PATH --output RECEIPT_PATH`; it copies and validates only that external workflow fixture. Both stop after
installed-package readiness and plain-language discovery. They stop at readiness and discovery. Subsequent workflow execution requires no Workflows approval; optional
review and historical human acceptance remain distinct from execution.

Each constructor passes its owned `workflows.localhost` runtime origin to `workflow init`; it does not rewrite config
after initialization or ask a person for a URL. Before continuing, the constructor verifies config v1 has one
`local` default, that the target is non-production and owns that exact origin, and that the generated workflow v1
starter keeps only an origin-relative route. Optional preview and production targets are distinct and never implicit.
The pilot receipt then preserves the selected target ID, label,
environment, normalized base URL, `configured-default` selection reason, `configured-v1` provenance, and measured
bootstrap duration against a 120-second budget. This target proof is metadata, not authority: the constructor stops at its documented readiness boundary without requesting terminal approval.

This repository is configured defensively for the leading candidate, GitHub Packages:

- `publishConfig.registry` and the repository `.npmrc` map only `@lineagehq` to `https://npm.pkg.github.com`.
- `publishConfig.access` is `restricted`.
- `npm run package:policy` rejects identity, lockfile, CLI, repository, privacy, registry, and credential-policy drift.
- The manual workflow is the only publication path; there is no package-level publish script. No token belongs in the repository `.npmrc`.

GitHub Packages was approved as the authoritative registry on August 25, 2026. Version `0.1.0` has been published privately, linked to this repository, and recorded as the immutable `v0.1.0` GitHub Release. Future versions still require the same deliberate, approved release process. Do not remove `private: true`, dispatch the workflow, create a release tag, publish another package version, or change organization/package settings without that approval.

## Registry comparison

| Concern            | GitHub Packages npm registry                                                                                                                                                                                                                                                                                                                                                                                                                        | Private npm organization                                                                                                                                                                                                      |
| ------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Package identity   | Supports scoped, lowercase npm packages such as `@lineagehq/workflows`; package tarballs must be below 256 MB.                                                                                                                                                                                                                                                                                                                                      | Supports private organization-scoped packages such as `@lineagehq/workflows`.                                                                                                                                                 |
| Authentication     | Local npm clients require a GitHub personal access token (classic); use `read:packages` for installation. A workflow in the source repository can publish with its short-lived `GITHUB_TOKEN`.                                                                                                                                                                                                                                                      | Local clients authenticate to npm. CI can use npm trusted publishing with GitHub Actions OIDC, or a suitably constrained npm publishing credential.                                                                           |
| Access model       | A package linked before first publication normally inherits access from the private source repository. The organization can disable automatic inheritance. Other repositories must be granted Actions access to use their `GITHUB_TOKEN`.                                                                                                                                                                                                           | Organization teams receive read-only or read/write access per package. A paid npm Teams organization is required for private organization packages.                                                                           |
| Local installation | Map `@lineagehq` to `https://npm.pkg.github.com`, authenticate, then install `@lineagehq/workflows`. Authentication is required even for most public GitHub npm packages.                                                                                                                                                                                                                                                                           | The normal npm registry remains in use; authenticated users with team read access install the scoped package normally.                                                                                                        |
| CI publication     | Grant only `contents: read` and `packages: write`, configure `https://npm.pkg.github.com`, and pass `GITHUB_TOKEN` as `NODE_AUTH_TOKEN`. No long-lived publishing token is needed in the source repository.                                                                                                                                                                                                                                         | Trusted publishing removes the long-lived publish token and requires `id-token: write`, npm CLI 11.5.1+, and a preconfigured trusted-publisher relationship. Private repositories do not receive npm provenance attestations. |
| Cost and limits    | Private package storage and downloads count against the GitHub owner's plan allowance. Current included allowances range from 500 MB storage/1 GB monthly transfer for Free organizations to 2 GB/10 GB for Team and 50 GB/100 GB for Enterprise Cloud. Actions downloads authenticated with `GITHUB_TOKEN` do not consume package transfer allowance. Overages require billing capacity; usage can be blocked when no payment method is available. | npm Teams currently lists unlimited private packages at USD $7 per user per month. This is seat-based rather than GitHub's storage/transfer metering.                                                                         |
| Operational fit    | Repository membership, package access, Actions publishing, and audit history stay in the existing private GitHub organization. Consumers must manage GitHub npm authentication and scope mapping.                                                                                                                                                                                                                                                   | Familiar default npm registry behavior and package-specific npm teams, at the cost of a second organization, separate membership/billing, and separate access administration.                                                 |

Official references:

- GitHub: [npm registry authentication and publishing](https://docs.github.com/en/packages/working-with-a-github-packages-registry/working-with-the-npm-registry), [package permissions and repository inheritance](https://docs.github.com/en/packages/learn-github-packages/about-permissions-for-github-packages), [access control and Actions access](https://docs.github.com/en/packages/learn-github-packages/configuring-a-packages-access-control-and-visibility), and [Packages billing](https://docs.github.com/en/billing/concepts/product-billing/github-packages).
- npm: [`private: true` publication guard](https://docs.npmjs.com/files/package.json/), [private package requirements](https://docs.npmjs.com/creating-and-publishing-private-packages/), [organization requirements](https://docs.npmjs.com/organizations/), [team access](https://docs.npmjs.com/managing-team-access-to-organization-packages/), [trusted publishing](https://docs.npmjs.com/trusted-publishers/), and [current product pricing](https://www.npmjs.com/products).

## Recommended release and access model

GitHub Packages is the approved registry. It fits the existing private repository, can inherit repository access, and lets the publisher use `GITHUB_TOKEN` rather than a stored registry write token.

Before each release, an organization owner should confirm without changing settings:

1. `lineagehq` permits creation of private npm packages.
2. Automatic inheritance from the linked source repository is enabled, or the intended initial users/teams are documented for granular access.
3. The GitHub plan's package allowance and budget posture are acceptable.
4. The repositories that need package access are enumerated; only those repositories should receive Actions access.
5. The approval mechanism supported by the organization's GitHub plan is chosen.

### Approval and publication flow

The manual `.github/workflows/publish-private-package.yml` workflow implements this publication path but must not be dispatched until the first release is separately approved:

1. A release pull request changes the version, records release notes, and passes the full CI and package smoke suite. Branch protection supplies review before release code reaches `main`.
2. A maintainer creates a signed or annotated `vX.Y.Z` tag on the reviewed `main` commit.
3. A manually dispatched workflow requires the exact tag and the typed confirmation `publish @lineagehq/workflows@X.Y.Z to GitHub Packages`. It validates that the annotated tag commit is on `main`, the version exactly matches the tag and manifest, the package name is `@lineagehq/workflows`, and both registry configurations are exactly `https://npm.pkg.github.com`.
4. The read-only verification job runs the full CI suite, reconstructs the candidate from the exact tagged commit,
   removes `private` only from that temporary manifest, and verifies the immutable provenance record, installation,
   initialization, local doctor readiness, and the `workflow` executable.
5. Only after verification succeeds, a separate publication job downloads and rechecks the retained candidate from the same tag. That job alone receives `packages: write`, uses an explicit GitHub Packages registry and restricted access, and authenticates with `GITHUB_TOKEN`. The repository source manifest remains private throughout.
6. After publication, a bounded job with only `packages: read` installs the exact registry version in a clean consumer using a new cache. It verifies package identity, executes the installed CLI, and requires the registry integrity recorded in the consumer lockfile to equal the approved candidate tarball's SHA-512. A failed registry download or mismatch prevents release creation.
7. Only after the clean-consumer gate succeeds, a separate job with only `contents: write` creates the GitHub Release from the already-verified tag. Release creation is idempotent, uses `--verify-tag`, generates notes, and never attaches a duplicate npm tarball. The GitHub Package remains the authoritative distributable.
8. After publication, a human verifies the package is private, linked to `lineagehq/workflows`, inherits the intended access, exposes only the intended files, and has a matching immutable GitHub Release.

The rc.19 checksum incident and the limits of the available evidence are recorded in
[`published-package-integrity-incident.md`](published-package-integrity-incident.md).

Use a protected `package-release` environment with required reviewers and disabled self-review when the GitHub plan supports those protections for private repositories. GitHub's current documentation says required reviewers for private repositories are not available on Free, Pro, or Team, so this must not be assumed. On those plans, require the reviewed release pull request plus a deliberate manual workflow dispatch by an authorized maintainer; consider a custom external approval control if two-person approval at publish time is mandatory.

Never publish automatically on every push to `main`, from a pull request, or from a mutable branch. Never grant `packages: write` to the ordinary CI workflow.

Repository release immutability is enabled. Once a GitHub Release is published, its tag and assets cannot be changed; prepare all intended release metadata before publication. Release notes may still be corrected, but package versions and release tags are never reused.

### Version policy

- Keep published `0.1.0`, `0.2.0`, `0.2.1`, `0.3.0`, `0.3.1`, `0.3.2`, and every prerelease immutable. The current stable release is `0.3.2`; later compatible
  fixes increment the patch version, and substantial pre-1.0 changes increment the minor version.
- Follow Semantic Versioning. Before `1.0.0`, increment minor for incompatible or substantial feature changes and patch for backwards-compatible fixes.
- Never reuse a published version. A failed or incorrect release is followed by a new patch version; do not delete and recreate it as routine recovery.
- Keep the package version, lockfile root version, generated skill pin, tag, and release notes synchronized in the release pull request.

## Consumer authentication

Do not commit a token. Each local consumer adds this non-secret scope mapping to its project or user configuration:

```ini
@lineagehq:registry=https://npm.pkg.github.com
```

The user creates a GitHub personal access token (classic) with only `read:packages` plus any access GitHub requires for the private repository, authorizes SSO when the organization requires it, and supplies the token through their user-level npm configuration or interactive login:

```bash
npm login --scope=@lineagehq --auth-type=legacy --registry=https://npm.pkg.github.com
npm install --save-dev --save-exact @lineagehq/workflows@0.3.2
```

That registry command installs the current published stable release. The `0.4.0` plugin and generated skill must be
paired with `candidate.tgz` from the candidate-construction command above until the protected publication workflow
has completed; do not combine the candidate plugin with the `0.3.2` runner.

Commit both consumer manifests. The exact version must appear under `devDependencies` in `package.json` and in the
lockfile root; it must not appear under runtime `dependencies`. The lockfile's installed package entry supplies the
immutable registry resolution and integrity used by `npm ci`.

For a consuming GitHub Actions repository, grant that repository package Actions access, configure `actions/setup-node` with `registry-url: https://npm.pkg.github.com` and `scope: '@lineagehq'`, then use its `GITHUB_TOKEN` as `NODE_AUTH_TOKEN` with only `packages: read` and `contents: read`. Use a classic PAT only when `GITHUB_TOKEN` cannot be granted access to the package.

## Decision checkpoint

The registry choice, repository workflow, protected release environment, first private package, and immutable `v0.1.0` Release are configured. Separate approval is still required for all of the following external actions:

- creating a future release tag or dispatching a future publication workflow;
- changing package visibility/access inheritance or granting a new consumer access;
- changing organization package policy, billing, budgets, or environment protections;
- creating, storing, or granting access to credentials.

Direct registry publication remains blocked by `private: true`; every future release must use the approved tagged workflow and human environment gate.

## Multiple repositories and upgrades

Install the exact package independently in each consumer repository. For a local pilot,
keep the candidate tarball in a durable repository-relative directory before installing it;
`npm ci` needs that artifact to remain available. Registry installation becomes available
only after the new version passes the deliberate release process above.

Run `workflow init --host codex` with the app URL and optional starting route the first time.
On later runs, omit the setup options to preserve the repository's existing configuration
and journeys. Supplying explicit setup options retains the conservative exact-match behavior;
use configuration editing for changes to an existing project's settings.

After upgrading the dependency, preview with `workflow init --host codex --dry-run --json`,
then apply with `workflow init --host codex`. Generated guidance carries a tracked
`.agents/skills/agent-workflows/.generated.json` baseline. Files matching that baseline can
update; edited files block the entire operation and must be reconciled manually. Do not
edit the baseline to bypass a conflict. Exact historical templates from rc.3 and merge
3791943 can migrate without an existing baseline. Unknown older content remains protected.
Keep the baseline and generated files together in version control. Upgrades retain displaced
files beside the originals with a unique `.backup` suffix and report their paths; inspect
and archive or remove those backups when convenient. Failed initialization
restores prior generated files when they still contain the bytes written by that operation.

`workflow studio` honors `studio.port` in the project config. The generated `auto` setting
asks the operating system for an available port, so separate repositories can run Studios
concurrently. `--port auto` overrides a fixed configured port; an explicit numeric port must
be free. Use the printed `http://workflows.localhost:PORT/` URL for each project.

Doctor reports installation, package, and registry readiness separately from execution.
`readiness.execution.status` stays `not-verified` until a journey actually runs because installation does not prove
that the browser is connected or the app is reachable. Project readiness is established automatically by
`workflow doctor --json`: `data.localStatus` and the `codex-skill` check must both be `ready`. Do not require a fresh
task, skill-catalog transcript, contract-read report, or production probe. Start a new task only when Codex has not
loaded a newly installed or updated plugin in the current runtime. Version 0.2.0 adds only bounded, runner-staged synthetic CSV upload
through the authenticated Studio broker. Version 0.2.1 adds bounded, sanitized click-failure
classification without changing click, retry, lease, or reconciliation behavior. Version 0.3.0 adds
reviewed run-owned fixture route bindings and prevents anonymous journeys from using a configured
authenticated target session. Version 0.3.1 adds the agent-first Studio review workspace, product-usage maps,
evaluation questions, independent perspective runs, published-package verification, and faster startup for large
run stores. Version 0.3.2 adds the Codex plugin, direct installation guidance, automatic readiness checks, and the
review, perspective, and question UX refinements validated by the Ytgify dogfood project. Version 0.4.0 adds the
agent protocol 1.1 recovery contract, deterministic state/lease boundary coverage, and hardened CLI concurrency,
input, idempotency, and diagnostic behavior. Arbitrary host
paths, caller-supplied selectors, generic-browser substitution, and download capabilities remain unavailable.
