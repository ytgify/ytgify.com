# Agent Workflows — Product Specification

Status: accepted design baseline for the first product slice

Reference application: `https://bleepthat.sh/bleep`

The offline lifecycle vertical stores exact candidate YAML bytes as monotonic immutable `vN` snapshots after a clean replay and runner evidence validation. Qualifications are append-only and bind revision, platform, platform-v2 effective hash, reset contract, capability snapshot hash, and promoted replay. Each evaluation group contains exactly one fresh 1440x900 desktop and one fresh 393x852 mobile run with independent evidence; final receipts are runner-derived only and reject retries or intervention taint.

Implementation note: `0.2.0-rc.3` implements the foundational schemas, validation, traversal reducer, run store, v1
transactional protocol, durable outer run control, executable training loop, generated repo-local Codex skill,
Studio review with narrowly allowlisted non-authoritative collaboration requests, an offline immutable
promotion/qualification/evaluation lifecycle, agent-facing capture of immutable findings from terminal completed
or failed evaluation notes, and immutable finding-resolution records. Trusted resume and acceptance remain
independently reverified attached-terminal actions; Browser and Studio cannot mint that authority. Screenshot
ingestion and the expected honest Bleep partial outcome are proven offline, and a genuine browser run has been
preserved for local review. Deterministic Debt Is Fun and YTgify laboratories now supply runner-written lifecycle
histories to a repeatable real-Chromium Studio gate at 1440x900 and 393x852. The [expected proof
contract](proofs/studio-browser-proof.expected.json) is a privacy-safe expectation boundary, not a committed
observed result. This specification does not claim production parity, semantic media correctness, completed
production evaluation, or Studio-driven fix execution.

The desktop reporting slice adds a simpler candidate loop: `evaluate desktop PATH` creates an approval-free routine 1440x900 run under a fixed runner-only risk policy. Each step pins the complete executor contract—action descriptions, kinds, targets, requested capability IDs, order, and count—in workflow bytes. An exact match reconstructs those fields from the workflow; other valid proposals also lease without approval; outcomes, stop conditions, and risk metadata remain observational. Action risk labels do not trigger approval. Capability and adapter input contracts still apply. Committed results may carry structured agent notes. `report RUN_ID` and Studio derive the same restart-stable report solely from pinned durable records and reverified evidence bytes.

An attached optional handler may pin a single scoped routine dismissal: one named dialog, its button named `Close`, `browser.control`, one before-state screenshot, and one application. The runner separately authorizes and records that child action under an unexpired automatic parent lease. Its authorization is adjacent, one-use, evidence-bound, and visible with its contract hash and timestamps in both report surfaces.

## 1. Product intent

Agent Workflows is a repository-local system for training, evaluating, and refining human application journeys with an agent. It keeps the runner—not an agent's conversation memory—responsible for phase, cursor, policy, evidence, and legal transitions.

Repeatability means that independent runs preserve the same actor goal, semantic checkpoints, success outcome, and evidence contract. It does not require identical coordinates, selectors, scrolling, timing, or low-level interactions.

The initial package is installed into one application repository. Workflow YAML may be checked into Git. Runs, media, drafts, promotions, and platform qualifications are local and gitignored in the first release.

## 2. Core concepts

### Workflow

A workflow describes one actor pursuing one goal through an ordered semantic journey. A workflow step has four layers:

1. stable intent;
2. expected outcome;
3. platform-specific execution guidance;
4. historical run evidence.

Only intent and expected outcome define the canonical meaning. Guidance may vary by platform, and evidence belongs to an individual run.

### Run

A run is one recorded execution with a phase of `training`, `evaluation`, `fixing`, or `replay`. `Session` is reserved for browser, device, and host connections.

A run records its parent when it is resumed or forked. Event history is append-only; resuming or forking never rewrites the earlier attempt.

### Promotion and qualification

Promotion creates a local immutable workflow revision named `v1`, `v2`, and so on, backed by a canonical content hash. Promotion and platform qualification are independent:

- promotion certifies the semantic workflow on the local operator's machine;
- qualification records whether a particular revision has a clean replay on one platform;
- a revision may be verified on desktop, stale on mobile web, and unconfigured on iOS.

Promoted snapshots and qualification records remain in the local registry for the first release. A checked-in YAML workflow imported on another machine is unqualified until that machine trains or replays it. Shared signed manifests are deferred.

## 3. Lifecycle

```text
goal + success outcome
    -> validated launch
    -> bounded agent exploration
    -> raw trace + screenshots + video
    -> agent-proposed storyboard
    -> human edits and semantic diff
    -> workflow YAML save
    -> clean supervised replay
    -> explicit local promotion
    -> independent platform qualification
    -> fresh evaluation run or run group
    -> selected finding
    -> fixing run
    -> targeted verification
    -> clean full evaluation
```

Agents can execute lifecycle transitions when their technical prerequisites pass. Promoted snapshots remain immutable; changes create a new revision.

## 4. Training

### 4.1 Brief and launch

Training requires:

- an actor goal;
- a final success outcome;
- a target profile and platform;
- an agent-proposed safety envelope, assumptions, and provisional checkpoints.

A launch card describes the requested run. CLI and agent launches create run records immediately without an approval transaction.

Safe launch-card overrides may change target URL, viewport or device, capture settings, retention, and non-secret fixtures. Every override is recorded. Overrides remain subject to input validation and are recorded as command inputs.

### 4.2 Exploration

Training executes the requested workflow autonomously. The agent may try reversible alternatives and record detours, recoveries, uncertainty, and capability gaps. Action categories do not introduce Workflows approval gates.

The agent operates in policy-authorized bounded action batches. Each batch pursues one immediate state and stops on navigation, unexpected UI, a safety boundary, or completion of that state.

Human live controls include:

- pause at the next safe action boundary;
- emergency stop and reconciliation;
- stop the run;
- mark a moment for later review;
- send timestamped guidance;
- take over and hand control back.

On handback, human actions are labeled as either a preferred demonstration or temporary assistance. Only demonstrations influence proposed workflow guidance.

### 4.3 Interrupted and incomplete training

An unsuccessful training run remains reviewable. It may be:

- resumed when the agent judges the visible state usable and records its reconciliation rationale; or
- forked into a fresh attempt carrying the brief, learned guidance, and blocker context.

A resumed or stitched training history may inform a storyboard but cannot serve as promotion proof. Evaluation runs are never resumed.

When an authorized action may have executed but no result was committed, the run enters observation-only reconciliation. The outcome must be classified as completed, not executed, or indeterminate before another action lease is issued.

Action time is finite and runner-owned. New Training, replay, and evaluation runs use `authorized-codex-browser-v1` rolling/hard/heartbeat-threshold 120/300/90 seconds without approval. The legacy standard 30/120/15 and supervised Codex Browser 120/300/90 policies remain readable and may be selected explicitly for Training; 120/300 are absolute caps. The manifest policy, its hash, and each lease snapshot are immutable replay inputs. Successful responses expose runner-authored current time and active-lease remaining budgets so the host can heartbeat at or below the pinned threshold. Runner time at or beyond rolling expiry forbids new mutations, while exact cached responses, including their original timing, remain replayable.

### 4.4 Storyboard

After exploration, the agent proposes grouped semantic steps beside the complete raw trace. The user may merge, split, reorder, rename, or exclude proposed material.

Editing supports both structured cards and natural-language agent edits. Multi-step agent edits are proposals that require acceptance. The save review leads with a semantic diff and offers an expandable YAML diff.

Studio edits remain in a recoverable local draft until explicitly written to the checked-in YAML. If the source changes outside the studio, the draft rebases by semantic identity; conflicting fields require explicit resolution.

## 5. Guards and recoveries

Optional overlays, permission prompts, onboarding, empty states, and similar interruptions are bounded guards and recoveries rather than canonical journey steps.

A guard declares:

- the recognizable activating state;
- the narrow recovery goal;
- the expected restored state;
- its action and time budget;
- its evidence requirement.

During evaluation, one reversible recovery may be attempted for an unknown but apparently benign state. Success produces `passed_with_deviation`, preserves evidence, and proposes a future guard without changing the promoted workflow. A deviated run cannot qualify a platform.

## 6. Evidence and verdicts

Training captures continuous video plus explicit before-and-after checkpoint screenshots. Evidence remains in the gitignored local store and is reviewed only through the studio in the first release. Portable report export is deferred.

Evidence retention is tiered:

- promoted replay evidence remains pinned until superseded or explicitly unpinned;
- evaluation evidence follows a rolling age or count policy;
- training and abandoned attempts have shorter retention.

Privacy is user-managed in the first release. The studio warns that captures may contain sensitive material. The package never uploads evidence automatically.

A step verdict contains:

- the claimed outcome;
- registered evidence references;
- deterministic assertion results, when available;
- a short rationale tied to the expected outcome;
- confidence and uncertainty;
- any adapter capability gap.

The runner owns the final verdict. Missing required evidence cannot be replaced silently with agent confidence. Training may proceed with a visible capability gap, but replay, qualification, and evaluation cannot claim a clean verdict that depends on the unavailable evidence.

Screenshot evidence crosses a runner-issued neutral `.screenshot` slot boundary. The slot is bound to the active owner, lease, step, checkpoint, capability, type, expiry, and byte limit. Without converting the bytes, the runner structurally validates conforming PNG or bounded 8-bit baseline JFIF JPEG, hashes and sizes the exact Browser output, and chooses the durable identity, canonical `image/png`/`.png` or `image/jpeg`/`.jpg` metadata, and path before registration. Legacy v1 PNG artifacts may omit `mimeType` and legacy runner-issued `.png` slots remain recoverable. Agents never author format verdicts or artifact metadata.

## 7. Evaluation and lenses

Evaluation always starts from a declared reset contract containing setup, reset, health check, fixtures, identity, and teardown. Preflight stops the run when the initial state cannot be proven.

`workflow evaluate` selects the latest locally promoted revision by default, shows its revision and hash before launch, and pins that exact identity in the run manifest.

The default evaluation perspective is neutral. The native catalog provides `neutral`, `ux`, `mobile-ux`, `adversarial`, and `performance`. Security, smoke, arbitrary custom rubrics, and physical-device execution are deferred. An evaluation perspective is distinct from an authentication identity profile.

Each selected perspective performs a separate, freshly reset full run. A durable perspective batch contains one neutral control for each selected platform plus independently selected specialist runs. Mobile UX supports mobile only. Every run pins its rubric version, hash, criteria, and control identity. Findings remain per-run; the system does not invent cross-run comparisons or label historical untagged runs neutral.

`workflow evaluate perspectives` requires `--source candidate` or `--source promoted`. Promoted selects the latest verified promoted source with required platform qualifications. Candidate selects the current anonymous routine candidate contract and never implies promotion or qualification. Omission fails before launch so a promoted revision cannot silently replace intended candidate work. The journal pins source bytes, target, selections, required/optional membership, and severity policy before launch. Interrupted launches return surviving receipts and can resume the same batch without duplicating its runs.

Canonical journey outcome, quality outcome, criterion coverage, and batch gate remain distinct. Quality is `clear`, `findings`, `unassessed`, or `unavailable`; no assessment is an unassessed gap. Required out-of-scope or unassessed criteria block clearance. Required execution failure, unavailable proof, or a finding at the selected severity gate fails the batch; optional failures remain visible. An agent assessment verifies provenance and links, not objective correctness or human acceptance.

Criterion scenarios map to declared steps through `evaluation.perspectiveScenarios`. This mapping is part of the pinned workflow definition. Missing mappings cannot be satisfied by an unrelated screenshot. Adversarial malformed-file, boundary-value, repeated-action, and race criteria remain explicit gaps until those scenarios are trained. Rubrics never expand action authority.

The Performance perspective runs independently on desktop and mobile browser viewports. It evaluates the declared workload envelope, visible responsiveness and progress, completion latency, limit degradation and recovery, and the limits of browser timing evidence. The built-in rubric contains no product threshold. It consumes pinned requirements such as `maximum-source-bytes` and `reference-workload-completion-milliseconds`; the legacy `maximum-completion-milliseconds` key remains valid for products that explicitly promise one absolute bound. A reference completion budget names its workload and observable browser environment and cannot be generalized to arbitrary client hardware. Progress visibility, cancellation responsiveness, and emergency processing cutoffs remain separate behaviors; a safety timeout is not acceptable latency. If a required threshold is absent, the criterion remains unassessed and may raise an evidence-bound product question. Large-input, completion, limit, progress, and recovery behavior must map to trained journey steps. Missing timing or resource instrumentation is a capability gap, and viewport evidence cannot establish physical-device, CPU, memory, or network performance.

## 8. Supervised replay

The human watches replay live and may pause, annotate, reject, or take over. Guidance or takeover makes the replay non-clean. A pause is permitted, but timing across the pause is excluded.

Promotion requires:

1. a clean reset and preflight;
2. uninterrupted agent execution without guidance or takeover;
3. all required checkpoint evidence;
4. successful cleanup accounting;
5. runner verification of the complete evidence chain.

## 9. Fixing

A fixing run targets one selected finding or failed step. The agent may edit application code and replay the relevant workflow section. A promoted workflow cannot be changed from fixing; workflow changes return to training.

Completion requires a targeted verification followed by a fresh full evaluation. Fixing links application changes and verification evidence to the source finding without rewriting that finding's original run.

## 10. Initial platform and host scope

The first platform scope is desktop web and mobile web. The iOS simulator uses the same capability and evidence contracts later.

The first host integration is a Codex skill that drives a host-neutral transactional CLI protocol. The npm package does not embed a model provider. Future agent hosts can implement the same protocol without changing workflow files.

The studio embeds the target app when permitted by site policy. Otherwise, the real browser, desktop app, or simulator remains in a separate window while the studio displays timestamped evidence frames. Embed failure is an adapter limitation, not an application failure.

## Finding correction proof

Each new correction contract pins an immutable finding hash and agent-authored expected corrections, applicable platforms, and evidence requirements. Existing findings may receive append-only sidecar contracts. Canonical workflow checks remain readable separately; they cannot substitute for the specific correction.

A new resolution requires targeted criterion proof recorded before fresh full desktop and mobile evaluations on the same newer candidate and agent-supplied implementation identity. Targeted notes and artifacts are reverified on reads, as are full evaluation receipts. Missing or corrupt proof reopens the current projection. Historical canonical-only resolutions remain readable and explicitly labeled without claiming the new contract was met.

Explicit issue relations group original findings for review without merging their evidence or resolving a sibling automatically. Agent execution, agent assessment, user authorization, and human acceptance remain separate provenance.

## Evaluation questions and adjustable requirements

Evaluation can surface a product question when exact step evidence reveals that a lens cannot judge a declared criterion because intent is undefined. Questions are tailored to the lens, journey, platform, and app, while their structured answer types and provenance rules are common. The default Balanced inquiry depth admits blockers and material questions; Focused keeps blockers only, and Exploratory adds bounded open-ended inquiry. Depth changes discovery effort, not action authority or lens severity.

Studio presents questions beside the journey and binds each one to exact run, step, criterion, note, and evidence. When multiple platforms or criteria in one batch expose the same compatible requirement key, Studio presents one decision and retains all source occurrences. Before deciding, a person can append free-text discussion responses that remain attached to the open question and are readable by agents through the supported CLI. A discussion response creates no requirement and carries no approval or acceptance authority. A person can then answer with a trusted native control, choose journey or project scope, or dismiss with a reason. The system records that answer as a human product-requirement decision and writes a portable lens-wide requirement for future evaluations. It does not claim that the person approved an action or accepted the application. Historical evaluations retain their original requirement and policy snapshots.
