# Launching a reviewed fixture candidate

The installed Workflows package exports `fixtureCandidateHash` and
`launchReviewedFixtureCandidate`. This host entry point consumes the exact
`pending-recipe-review` artifact emitted by `workflow fixture-needs compile`.
It works for repository files and application records; the latter still needs
app-specific adapter code on the host. The entry point launches one Training
run and makes its fixture ready. It does not execute browser steps, promote a
workflow, or turn a fixture receipt into a journey outcome.

## Prepare and review

1. Inspect the retained evidence with `workflow fixture-needs review RUN_ID`.
   Accept each need through `fixture-needs decide` in its source Store, then
   compile the candidate with `fixture-needs compile --file REQUEST.json
--output CANDIDATE.json`. Keep the source Store available: launch replays
   the compiler against the current decisions and evidence.
2. Review the candidate's `provenance.sources`, `fields`, and `unresolved`.
   Confirm the target and identity, workflow entry and outcome, generator or
   adapter revision and operation meanings, exact allowed writes, ownership,
   cleanup or retention, and any changed source scope. Generate and Git-index
   a repository file before compiling, and confirm its size, MIME, digest,
   label, and supported app revision. For a mutable record, review the private
   Store, idempotency marker, ID/key readback, and exact-ID deletion.
3. Save a separate review JSON document containing the exact candidate hash.
   Example:

   ```json
   {
     "schema": "agent-workflow-fixture-review/v1",
     "status": "approved",
     "candidateHash": "sha256:<hash from fixtureCandidateHash(candidate)>",
     "reviewer": "operator-name",
     "reason": "Reviewed local target, identity, operations, ownership, and cleanup"
   }
   ```

   Keep this document with the operator's run record. It is an explicit host
   review assertion, not an App Map promotion or a signature. A target, recipe,
   workflow, evidence, or decision change requires a newly reviewed candidate.

## Host integration

Use the following pattern in the app's persistent host. `sourceStore` is the
Store containing the accepted need decisions; `runStore` can be a fresh
private Store. `projectRoot` is the absolute app checkout that contains the
currently indexed file for a repository-file recipe. For an application
record, the host supplies `adapter` with `create`, `readById`, `readByKey`, and
`deleteById`; its operations must implement the candidate's exact adapter
contract. Omit `adapter` for a repository file.

```js
import { readFile } from "node:fs/promises";
import {
  AgentService,
  RunControlStore,
  createSchemaRegistry,
  fixtureCandidateHash,
  launchReviewedFixtureCandidate,
} from "@lineagehq/workflows";

const registry = await createSchemaRegistry();
const sourceStore = await new RunControlStore(sourceStorePath, { registry }).init();
const runStore = await new RunControlStore(privateRunStorePath, { registry }).init();
const candidate = JSON.parse(await readFile(candidatePath, "utf8"));
const review = JSON.parse(await readFile(reviewPath, "utf8"));
if (review.candidateHash !== fixtureCandidateHash(candidate)) {
  throw new Error("Reviewed candidate hash changed");
}

const launched = await launchReviewedFixtureCandidate({
  candidate,
  review,
  workflowId,
  applicationTarget: {
    targetId,
    label,
    environment: "local",
    selection: "product-language-match",
    provenance: "configured-v1",
    baseUrl: appOrigin,
  },
  platform: "desktop-web",
  profile,
  projectRoot,
  sourceStore,
  runStore,
  registry,
  ...(adapter ? { adapter } : {}),
});

// Keep this process and service alive while operating a mutable run.
const agentService = new AgentService(runStore, registry, {
  ...(launched.fixtureService ? { fixtureService: launched.fixtureService } : {}),
});
```

Supply paths, target fields, and the app adapter from the host's
own configuration. Never derive a new target or adapter from screenshot text.
The entry point recompiles from current source evidence, checks the exact
reviewed artifact hash, and then relies on Training's recipe, workflow,
target, identity, file-byte, and capability checks. It returns a launch card,
ready fixture instance, and, for application records, the registered
`fixtureService` to pass to `AgentService`. A missing adapter is rejected
before a run is created. Mutable setup uncertainty leaves a run-owned journal.
An error after run creation was attempted carries `details.runId` and
`details.candidateHash`. Treat the run ID as a reconciliation key: first
inspect `readRun(runId)` and the fixture instance on the same Store. For a
create failure, `details.runPublication` is `unknown`; a generated ID alone
does not prove the run was published. For a later binding failure it is
`confirmed`. Retain uncertain or published run state and do not blindly
launch another run to repair it. A preflight failure has no run ID.

## Recovery and completion

For an uncertain mutable setup, reconstruct `FixtureApplicationService` on
the same `runStore` after restart, register the same contract and adapter for
the immutable run manifest's exact target and identity hashes, and call
`reconcileSetup(runId)`. Inspect `status(runId)` and `readReady(runId)` before
an action. Close any borrowed-child lease, call `cleanup(ownerRunId)`, and
confirm the exact record is absent through an independent app read. If cleanup
acknowledgement is lost, call `reconcileCleanup(ownerRunId)` after restart.
The lifecycle service never treats an unknown result as cleaned and never
retries an ambiguous create or broad delete. For repository files, re-read
`runStore.readFixtureInstance(runId, { projectRoot })` before use; the bytes
must still match the pinned index entry. Complete and report browser steps
through the normal agent protocol, including evidence and outcome assertions.

The API launches one workflow at a time. A host can use `launchPinnedRun` and
the returned ready instance for a compatible borrowed child, preserving one
cleanup owner. This remains host-driven composition, not automatic child
scheduling. Candidate workflow definitions and recipe fields still require
operator input; the compiler does not infer them from screenshots.
