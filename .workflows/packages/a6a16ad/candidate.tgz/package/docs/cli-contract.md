# CLI and Agent Protocol Contract — Design Draft

Status: accepted behavioral design; v1 schemas, stateful training, and Tranche 0 semantic contracts frozen

Binary: `workflow`

`workflow explore start --target WORDS --route /PATH --intent 'INTENT[;INTENT]' --platform desktop-web|mobile-web [--fixture 'NAME=RELATIVE_PATH=CONTROL_LABEL[;...]'] [--root PATH] [--config PATH] [--store PATH] --json` launches a distinct anonymous local exploration run from the verified configured target selection. It pins 24 actions, 20 captures, four branch attempts, and 45 minutes. The optional fixture flag pins one to four exact Git-indexed project files and upload control labels; uploads are otherwise denied. `workflow explore review RUN_ID` rebuilds a read-only review from exact registered screenshot bytes. After claim and capability preflight, the owner uses ordinary `agent.propose`, `agent.evidence`, and `agent.commit` with exploration observation fields; each proposal leases one in-origin reversible action. `agent.exploration.finish` explicitly records `complete` or `partial` and supplies `blocked` or `unvisited` reasons for every intent without a verified visit. A run with exhausted budgets remains reviewable and finishable. See [the exploration contract](app-exploration-contract.md).

Project-aware commands consume one shared `ProjectContext`: explicit config path overrides `.workflows/config.yaml`, which overrides legacy no-config fallback. An invalid higher-precedence source fails closed. Agent discovery emits a verified `DiscoverySnapshot`; `current` is the repository-bound editable candidate and `latest` is the numerically highest verified immutable revision. Ambiguity returns sorted candidates and one product-language question without guessing. JSON includes exact IDs and route hints, but human text never asks a person to supply an ID. Freshness and integrity remain independent, and degraded output cannot support acceptance or another authority claim. The full frozen contract is in `cli-studio-semantic-bridge-contract.md`.

Config v1 defines a bounded `project.targets` inventory with human labels, environment classes, and verified HTTP(S) URLs. ProjectContext v2 resolves it once and DiscoverySnapshot v2 returns the same exact target inventory and selection. Only a sole local target or configured local default may select without prompting; preview and production always require an explicit label/environment phrase. Human text names labels and environments only, while agents retain target IDs and URLs from JSON. Config v0 is adapted in memory with provenance and a migration warning through 0.2.x.

A configured v1 target may opt in with `authentication.mode: user-session`. That mode binds one local browser profile and one confirmed non-secret marker to the exact project ID, target ID, environment, and canonical origin. Config v0, targets without authentication, and expert `--target-url` launches remain anonymous. Preview, staging, production, local, and other targets never share or fall back to another target's profile.

After a package manager records the exact Workflows devDependency and lockfile entry, `workflow init --host codex` is
the single repository-initialization command. It creates a required `local` target and may add distinct `preview` and
`production` targets through `--preview-url` and `--production-url`. Every target URL flag accepts an HTTP(S) origin
only, with an optional trailing slash; credentials, pathnames, queries, and fragments fail before mutation.
`--start-route` independently supplies the starter workflow's origin-relative route, while `--health-path` supplies
only each generated target's readiness path; both default to `/`. Only `local` is the configured implicit default;
preview and production require explicit product-language selection. `--local-url` is preferred, while `--base-url`
remains a local-only compatibility alias; supplying both fails before mutation. Initialization never installs the
package, changes consumer package metadata, or rewrites an existing divergent config.

`agent-workflow/v1` replaces the embedded environment URL with `start.route`; it cannot contain `target.baseUrl`. All training, replay, routine-evaluation, and evaluation-group launch APIs receive an already-resolved application target and record its ID, label, environment, selection reason, source provenance, route, canonical joined URL, and effective URL in the immutable run manifest and launch card. Reports and agent inspection return that same record. Run creation never performs target selection, and both evaluation-group members pin identical target provenance. `agent-workflow/v0`, positional definition paths, and config v0 remain supported through 0.2.x.

Route hints remain entity-specific: workflow `list`/`status` navigation consumes `selection.route`, run navigation
consumes the matching verified `activity[].route`, and review navigation consumes the matching verified
`pendingAttention[].route`. Agents keep the associated identities and route bytes internal and never reconstruct a
route from another entity. Language-first Training launch resolves only the current catalog and configured target;
it does not reconstruct unrelated run, finding, review, or acceptance history before creating a run.

`workflow doctor` is offline by default. Its top-level status is local operability; package identity/provenance and
registry readiness are separately named results with their contributing checks. Missing provenance stays
unavailable, failed Git/store safety makes local readiness fail, and skipped registry checks are `not-requested`,
never ready. `workflow doctor --registry` is the only form that requests bounded registry availability and still
requires explicit authentication presence for registry readiness. Any non-server HTTP response proves the registry
is reachable, including a method rejection from the registry root; authentication readiness remains a separate check.

Workflows has no approval gates for local or production execution. Complete requested launch, execution, retry, resume, replay, promotion, qualification, and evaluation without asking for permission in Workflows. Preserve leases, revision checks, evidence integrity, authentication, and cleanup. Record agent execution and runner validation accurately; optional review never gates completion and must never be presented as human acceptance unless a human actually recorded it.

The candidate lifecycle uses the same verified language-first selection: `workflow train --journey "shared fictional card" [--platform PLATFORM]`, `workflow replay candidate --journey "shared fictional card" --platform PLATFORM`, and `workflow promote --journey "shared fictional card" --replay RUN_ID`. Positional PATH forms remain unchanged compatibility only for callers already holding a trusted path. After restart, rerunning `workflow status shared fictional card --json` reconstructs the exact latest promotion, qualifications, evaluation group, and member identities/routes in `data.snapshot.lifecycle`; agents consume those identities internally for immutable promoted replay, qualification, evaluation finalize/inspect, and acceptance commands. They never scan, guess, reconstruct, or ask humans for paths, IDs, or revisions. Verified group identity remains outcome-neutral (`not-asserted`) and does not claim evaluation passed.

`workflow train PATH --platform PLATFORM --target-url URL` remains an expert compatibility adapter. For workflow v0 it preserves the 0.2.x `{source,url,canonicalUrl}` record. For workflow v1 it records `selection: expert-target-url` and `provenance: target-url-adapter`; when a verified selected target is also present, its joined URL remains canonical and only the effective URL is overridden. Non-HTTP(S), credential-bearing, fragment-bearing, relative, or empty values fail. The adapter changes neither workflow bytes nor source/effective hashes and remains behind the ordinary training launch approval.

For a reviewed `repository-file` fixture requirement, `workflow train --journey WORDS --target TARGET --fixture-recipe PATH --root PROJECT --platform PLATFORM` validates the recipe, requires the exact selected target and identity, verifies the indexed file bytes before creating the run, pins the immutable fixture contract, and binds a ready run-owned instance. `--fixture-recipe` also works with the expert PATH form when `--root` points to the file's project repository. A missing or mismatched recipe fails launch. Application-record recipes can be pinned by a host integration, but the built-in CLI does not create a mutable instance without a registered adapter. A launched run is not a completed journey.

`agent.optional-state.authorize` accepts only a current automatic parent lease ID, attached handler ID, and registered evidence IDs. The handler pins one named dialog, the button named `Close`, `browser.control`, one screenshot-before checkpoint, and one application. The runner reverifies those bytes and derives the scope and contract hash. `agent.optional-state.complete` accepts only those IDs plus the issued authorization ID and must be the immediately following durable revision. Generic Close/Escape, caller-authored targets, sensitive actions, extra capabilities, replay, and second application are rejected.

`workflow report RUN_ID [--store PATH] [--json]` rereads the immutable manifest, workflow, and event journal and reopens every registered screenshot. Its DTO contains the immutable run target, exact revision/hashes, event-derived timestamps, runner-derived outcomes, optional structured agent notes, cleanup status, and screenshot integrity. It accepts no caller-authored report fields and is equivalent after restart when durable inputs are unchanged.

`workflow findings create RUN_ID [--file PATH] [--store PATH] [--json]` converts one exact note from a terminal completed or failed evaluation into an immutable finding. Its strict JSON input names the step and note index plus a UX, security, accessibility, reliability, or custom lens, severity, title, and recommendation. The CLI rereads the run and report, derives workflow revision, platform, source text, timestamps, and evidence, and rejects training, replay, incomplete, blocked, abandoned, missing-note, extra-field, and conflicting-retry inputs. Identical retries return the existing deterministic finding. `findings list WORKFLOW_ID` and `findings show WORKFLOW_ID FINDING_ID` are read-only and return the same independently reverified, path-sanitized projection as Studio.

`workflow findings resolve WORKFLOW_ID FINDING_ID --desktop-run RUN_ID --mobile-run RUN_ID --commit SHA` creates a separate immutable resolution; it never edits the finding. The source finding must independently reverify and identify a candidate revision. Both proof runs must be terminal, clean, untainted routine evaluations of the same newer candidate revision and content, with exact desktop/mobile platforms, one attempt per passed step, passed cleanup, verified required screenshots, no uncertainty, rejection, approval, pause, reconciliation, emergency stop, or host replacement. The full implementation commit is provenance rather than a caller-authored verdict. Identical retries are idempotent. `list`, `show`, and Studio reverify both reports and all evidence on every read, deriving `verified-resolved` only while the complete proof remains valid.

Collaboration writes use strict revision-checked requests. `pause`, `stop`, and `emergency-stop` require an opaque idempotency key; they persist neutral adapter provenance and never claim who operated the calling surface. An identical retry returns the original receipt, while a reused key with different bytes or a stale expected revision exits `4`. `resume` records authorized agent execution after rechecking the exact paused resumable revision. An identical retry returns the original receipt without another event.

Acceptance similarly takes an exact workflow revision, content hash, evaluation group, and decision. The CLI independently reverifies that the revision is still latest and every immutable evaluation member, receipt, qualification, run, and artifact is intact both before the prompt and immediately before append-only commit. Passing evaluation is only evidence and never creates or upgrades acceptance.

Lifecycle commands are `replay candidate|promoted|finalize`, `promote`, `qualify`, `evaluate launch|finalize|inspect`, `versions`, and `run inspect`. No operation requires Workflows approval. Every operation independently verifies immutable source, run, policy, revision and evidence. Evaluation groups durably bind both member identities. Agents cannot provide human-approval fields or enlarge the runner-selected lease policy.

Promotion and qualification verify the complete run journal, every screenshot, reset/cleanup evidence, and the immutable replay receipt. Qualification binds workflow, revision, platform, effective hash and replay identity. Evaluation launch durably publishes the group before authorizing its exact members. These are runner operations, never human acceptance.

Workflows has no approval gates. Runner validation, agent execution, and optional human review remain distinct. See [Execution without approval gates](approval-authority.md).

## 1. Authority and audiences

The runner is authoritative for phase, revision, cursor, policy, leases, evidence requirements and legal transitions.

The CLI serves two audiences:

- humans use task-oriented lifecycle commands;
- agent hosts use transactional commands under `workflow agent`.

`workflow --help`, `workflow -h`, and `workflow help` render a concise daily loop and task-grouped command index. `workflow help COMMAND` and `workflow COMMAND --help` render every usage form for that command; nested topics such as `workflow evaluate perspectives --help` narrow the result further. Valid help exits successfully, unknown topics return `INVALID_USAGE`, and `--json` retains the complete machine-readable usage catalog.

The package does not launch or own a model runtime. A Codex skill is the first host integration and drives the same neutral protocol available to later hosts.

For a run requiring an application-record fixture, the built-in `workflow agent propose` command cannot load a consumer's host-registered adapter. An otherwise valid, current proposal from the owning host fails with `CAPABILITY_UNAVAILABLE` and an explicit host-adapter-required message. An unclaimed run returns `ILLEGAL_TRANSITION`, and a stale expected revision returns `REVISION_CONFLICT` before fixture readiness is checked. A host can import `AgentService` and `FixtureApplicationService` from the installed package, register an exact disposable adapter, and pass that fixture service to the agent service. Matching cached protocol responses remain replayable by request hash; fresh proposals require a current ready readback.

## 2. Human command surface

```text
workflow init --host codex [--root PATH]
workflow validate [WORKFLOW_ID]
workflow list
workflow show WORKFLOW_ID [--revision REVISION] [--platform PLATFORM]
workflow doctor [--registry]
workflow studio [--store PATH] [--port PORT]
workflow evaluate desktop --journey "stable product words" [--root PATH] [--config PATH] [--store PATH]
workflow evaluate mobile --journey "stable product words" [--root PATH] [--config PATH] [--store PATH]
workflow evaluate desktop PATH [--store PATH]
workflow evaluate mobile PATH [--store PATH]
workflow train --journey "stable product words" [--platform PLATFORM] [--root PATH] [--config PATH] [--store PATH]
workflow replay candidate --journey "stable product words" --platform PLATFORM [--root PATH] [--config PATH] [--store PATH]
workflow promote --journey "stable product words" --replay RUN_ID [--root PATH] [--config PATH] [--store PATH]
workflow report RUN_ID [--store PATH]
workflow findings create RUN_ID [--file PATH] [--store PATH]
workflow findings resolve WORKFLOW_ID FINDING_ID --desktop-run RUN_ID --mobile-run RUN_ID --commit SHA [--store PATH]
workflow findings list WORKFLOW_ID [--store PATH]
workflow findings show WORKFLOW_ID FINDING_ID [--store PATH]

workflow train PATH --platform PLATFORM [--target-url URL] [--lease-policy standard|supervised-codex-browser]
workflow evaluate WORKFLOW_ID [--revision REVISION] [--lens LENS]
workflow replay candidate PATH --platform PLATFORM
workflow replay promoted WORKFLOW_ID REVISION --platform PLATFORM
workflow fix --run RUN_ID --finding FINDING_ID
workflow promote PATH --replay RUN_ID

workflow run inspect RUN_ID
workflow run pause RUN_ID
workflow run emergency-stop RUN_ID
workflow run resume RUN_ID
workflow run stop RUN_ID
```

The `--journey` forms are the normal human-to-agent bridge. The positional PATH forms are retained for compatibility only.

`workflow train` prepares a launch card from an existing candidate containing goal, success outcome, profile, platform, assumptions, provisional checkpoints, safety policy, capabilities, and overrides. It does not collect a new journey brief interactively.

`workflow init` requires an inspectable Git repository so local evidence ignore/tracking safety can fail closed.

`workflow studio` starts the implemented Run Review surface. It binds internally to IPv4 loopback, prints and
accepts only `workflows.localhost`, defaults to port `41737` and store `.workflows/local`, and accepts no host
override. The port must be an integer from 1 through 65535. `workflow studio --headless` runs its owned persistent browser without a visible window. The flag takes no value; the default remains headed for interactive login setup. Headless mode uses the same saved profile, authentication checks, lease authority, and screenshot evidence path. An expired session still requires login; restart without `--headless` when interactive authentication is needed. Starting, refreshing, stopping, and restarting Studio
never initializes the store. Strict same-origin mutation routes persist only neutral review intent and operational
pause/stop/emergency-stop requests; there is no Browser-callable trusted resume or acceptance route.
Source-bound review intent is verified against the durable run before append and carries its phase, run, step, and
optional screenshot artifact through `review-intent list|show --json` for agent retrieval.

`workflow evaluate` resolves the latest local promoted revision by default, displays the pinned revision and hash, and pins them in the run manifest. Evaluation defaults to a neutral actor. Each selected lens creates a separate freshly reset run in the evaluation group.

## 3. Agent command surface

```text
workflow agent claim
workflow agent inspect
workflow agent route.bind
workflow agent capabilities
workflow agent propose
workflow agent evidence
workflow agent commit
workflow agent heartbeat
workflow agent reconcile
workflow agent release
```

Agent commands accept strict JSON up to 1 MiB from standard input or a named file and emit exactly one JSON value to standard output. Diagnostics go to standard error. Long natural-language or structured inputs are not encoded into shell arguments. An over-limit input is rejected before complete parsing and therefore returns an ordinary uncorrelated CLI error; the runner never invents correlation from a partial document.

Finding creation follows the same structured-input rule even though it is not a runner transaction. Its input schema is `agent-workflow-finding-input/v1`; the agent cannot provide run-derived source text, evidence metadata, hashes, timestamps, workflow revision, platform, status, or finding identity.

`claim` binds one host instance to a run. A replacement host requires explicit handoff, capability registration, and app-state reconciliation. An expired filesystem lock alone does not authorize takeover.

`inspect` is read-only and returns the current revision, state, permitted operations, pending human control, immutable effective and canonical target URLs, active lease, and next bounded instruction.

`agent.route.bind` binds one workflow-declared route for an active run owned by the requesting host only while no lease exists. Its strict payload contains only `routeId`, typed `parameters`, and `readinessName`; it never accepts a path, URL, origin, target, or readiness role. The runner expands the immutable workflow template and returns only `{ kind: "route-binding", bindingId, routeId }`, never the derived path or marker. Route declarations are a generic Workflows capability, while every route template remains application-owned.

`agent.authentication.verify` is the only agent authentication mutation. It is available to the owning host while an authenticated run is active or `awaiting-authentication`, accepts no credentials or marker input, and verifies the exact marker hash, target, and one-way Studio session-generation binding pinned by the run through `browser.user-session/v1`. Raw session and profile IDs never enter the manifest or protocol. Clearing and reprovisioning the configured session changes that binding and makes the immutable run stale even when the same marker is confirmed again. A successful fresh check records `authentication.verified`; a clear failure records `authentication.required`, returns the sanitized `open-authentication-session` recovery action, and grants no lease. After an interrupted verification, the host inspects again and retries with the newly inspected current run revision while preserving the same pinned target, marker hash, owning host, and session binding; it never reuses the pre-start revision.

Studio is the sole long-lived browser owner. It publishes a private, mode-`0600`, loopback-only broker descriptor in the local run store; authenticated CLI agent commands delegate verification to that owner and fail closed when it is absent. The browser capability is registered as `browser.user-session` contract version `1.0` alongside `browser.control` with the same adapter identity. A successful verification supplies only an opaque `usersession_…` lease target reference; the action and evidence capability must resolve that reference through the same owner and must never substitute its generic browser context. Studio shutdown closes every owned context and removes only its matching broker descriptor. Before binding its port on startup, Studio recovers a valid stale descriptor only when a direct IPv4 loopback connection to the recorded port is explicitly refused. Reachable endpoints, timeouts, other transport errors, malformed descriptors, and concurrent descriptor operations fail closed; the probe sends no authentication data. Publication and removal use a short exclusive local lock to preserve ownership during concurrent restarts. A lock left by a process dying during this critical section is not automatically removed and requires inspection. This recovery changes no saved login, run evidence, or workflow state.

`workflow browser execute --file PATH [--root PATH] [--config PATH] [--store PATH] --json` executes one authenticated
lease and captures its screenshot through that owner. Input contains exactly `runId`, `hostId`, `leaseId`, `slotId`,
and `expectedRevision`. Obtain the lease through `agent.propose`, issue a screenshot slot through `agent.evidence`,
and use the resulting current revision. The server derives actions, origin, session, viewport, and output path from
durable runner state. It accepts observation, navigation to `declared-start-url`, and exact named controls encoded
in the approved target as `role:button:NAME`, `role:link:NAME`, `role:radio:NAME`, or `role:menuitem:NAME`. Arbitrary text, selectors, arbitrary URLs, caller-supplied
browser actions, and optional handlers are unsupported. These target forms do not bypass proposal policy or approvals.

An approved authenticated upload action is `upload-file` with exact `label:NAME`, a workflow-pinned `synthetic-file` input name plus exact filename, size, `text/csv` MIME type, SHA-256, and `file-upload`. Before execution, `workflow browser stage-upload --file PATH [--root PATH] [--config PATH] [--store PATH] --json` accepts a strict `browser.upload-stage/v1` request containing those exact fields plus run, host, action lease, step, current revision, and canonical base64 bytes. It accepts no source path or selector. The runner validates UTF-8 synthetic CSV policy, stores mode-`0600` bytes and a durable receipt bound to every listed identity, then the Studio owner reopens and hashes that artifact and sets it on a single approved labeled file input using the same opaque session and leased page. Valid same-lease heartbeats preserve the staging binding. Execution, uncertainty, emergency stop, expiry, or reconciliation consumes and cleans the staged bytes; altered content, wrong revision, unapproved input, and replay fail closed.

On navigation back to the confirmed authentication-marker route, the owner waits for that exact visible marker before continuing; it checks again before capture on that route. The marker comes from the immediately verified owned session, never request input. Each wait is bounded by the existing five-second operation limit and remaining lease/slot authority. Missing or ambiguous markers, route changes, and credential challenges prevent capture and leave the attempted lease unreplayable. This is readiness for the confirmed route, not proof that every widget or another destination has finished loading; screenshot assessment is still required.

The run writer lock and target session queue cover execution. A durable attempt record is flushed before any action;
an interrupted or repeated attempt cannot replay. Failed attempts require inspection and reconciliation, and cannot
commit a passing result. The original screenshot bytes must match the manifest viewport and runner slot limit before
staging. Register the returned slot through the ordinary evidence command and assess/commit normally afterward.
This command does not register evidence, assess expectations, grant acceptance, or claim a complete product journey.

`workflow routine-actions export RUN_ID --output PATH [--root PATH] [--config PATH] [--store PATH] --json` reads one clean completed supervised Training history and writes a mode-`0600` review document containing only exact single-attempt, leased, passing action batches. It reopens every registered screenshot and requires verified overall, evidence, and cleanup integrity before exporting. The commit must declare the leased action descriptions (legacy kind declarations remain compatible), record one performed action for every leased action, and contain no uncertainty or unexpected states; the immutable structured batch is reconstructed only from the durable lease, never from those narrative commit strings. Without `--store`, it resolves the configured project `paths.runStore`; `--store` remains the explicit override. After a reviewer inspects every executor field and changes only the top-level `reviewed` flag to `true`, `workflow routine-actions apply WORKFLOW_PATH --review PATH --output NEW_PATH [--root PATH] [--config PATH] [--store PATH] --json` revalidates the source run and candidate hash, authenticated action vocabulary, synthetic-input policy, and capability set, increments `candidateRevision`, writes a new file exclusively, and records a durable attestation under the same run store. Authenticated candidate evaluation reconstructs the clean source Training run, reopens its evidence again, and requires that attestation to match the exact candidate content hash, reviewed document, source run, lease IDs, and action hashes. Altered exports, missing or corrupt evidence, missing or tainted source histories, unsupported actions, existing destinations, in-place edits, manually authored authenticated batches, and missing attestations fail closed. These commands do not infer actions from prose, promote a workflow, or record acceptance.

`propose` submits one bounded action batch. A route-bound navigation uses only the opaque `run-route:binding_…` target with `observe`; it never supplies a path or URL. The runner permits, denies, requests refinement, or requests missing technical inputs. An allowed proposal returns a short-lived lease.

`evidence` has two actions under an active unexpired lease. `issue` returns a runner-chosen screenshot slot bound to the run, owner, lease, step, checkpoint, capability, type, expiry, and maximum byte size. Every declared screenshot checkpoint is eligible for issuance, including `required: false`; only required declarations participate in pass completeness. Handler evidence additionally supplies `optionalHandlerId`; the runner accepts only an attached handler whose pinned evidence and capability match exactly and carries the ID into the artifact relation. Ordinary evidence omits it. After the host writes Browser screenshot bytes to that exact slot, `register` validates and atomically ingests them. The request accepts no source path or artifact metadata.

Registration derives a deterministic runner-owned artifact identity and timestamp from the issued slot, active lease, and verified bytes. New slots have neutral `.screenshot` names; exact legacy runner-issued `.png` slots remain recoverable. The runner structurally sniffs bytes rather than filenames, accepting conforming PNG or bounded 8-bit baseline JFIF JPEG and deriving optional v1 `mimeType` plus canonical `.png` or `.jpg`. It durably journals that complete artifact, writes the unchanged verified bytes through a runner-owned temporary file, and atomically publishes them. A final journal-backed reopen immediately before `evidence.registered` must match the runner-issued path and slot, request hash, inode, full media structure, exact size, content hash, MIME, and extension. Identical retries preserve both formats across every ingestion cut point; legacy PNG artifacts without `mimeType` remain valid.

`commit` records actual actions, observations, evidence, uncertainty, structured rationale, and optional structured notes for one lease. Note evidence references must belong to the same commit. The runner, not the agent, derives cursor changes and verdicts.

`heartbeat` deterministically sets expiry to `min(runnerNow + rollingSeconds, hardExpiresAt)`. It cannot add actions, widen policy, or change stop conditions. The host should heartbeat only when the runner-reported remaining lease time is at or below the pinned threshold.

`reconcile` is available only in an observation-only reconciliation state. `release` ends the current host's authority without deleting or closing the run.

## 4. Common request envelope

```json
{
  "schema": "agent-workflow-protocol-request/v1",
  "protocolVersion": "1.1",
  "requestId": "req_01K...",
  "command": "agent.release",
  "runId": "run_01K...",
  "expectedRevision": 12,
  "actor": {
    "kind": "agent-host",
    "id": "host_01K..."
  },
  "issuedAt": "2026-08-24T18:00:00Z",
  "payload": {
    "reason": "The host is shutting down cleanly."
  },
  "extensions": {}
}
```

Rules:

- every mutation requires a caller-generated `requestId`;
- every mutation requires the revision observed by the caller;
- request time is provenance and never substitutes for runner time;
- unknown core fields are rejected;
- adapter-specific data belongs in registered namespaced extensions;
- unregistered extensions may be preserved but cannot influence policy, verdicts, or transitions.
- protocol `1.0` remains accepted during the `0.4.x` compatibility window and receives exact `1.0` responses;
- protocol `1.1` is preferred and adds authoritative typed recovery actions to failures.

## 5. Success and error envelopes

```json
{
  "schema": "agent-workflow-protocol-response/v1",
  "ok": true,
  "protocolVersion": "1.1",
  "requestId": "req_01K...",
  "receiptId": "receipt_01K...",
  "runId": "run_01K...",
  "previousRevision": 12,
  "revision": 13,
  "state": {
    "phase": "training",
    "status": "active"
  },
  "allowedOperations": ["agent.inspect"],
  "result": {
    "kind": "acknowledgement"
  },
  "warnings": []
}
```

```json
{
  "schema": "agent-workflow-protocol-response/v1",
  "ok": false,
  "protocolVersion": "1.1",
  "requestId": "req_01K...",
  "runId": "run_01K...",
  "revision": 14,
  "error": {
    "code": "REVISION_CONFLICT",
    "message": "The run changed after this caller inspected it.",
    "retryable": true,
    "recovery": "Inspect the run and decide whether the proposal is still applicable.",
    "details": {},
    "recoveryAction": {
      "id": "inspect-and-rebuild",
      "automatic": true,
      "allowedCommands": ["agent.inspect"],
      "preserveRequestId": false
    }
  }
}
```

Errors remain valid protocol output. In `1.1`, `recoveryAction` is authoritative and `recovery` remains explanatory.
Stack traces, logs, and terminal styling never appear in JSON standard output.

## 6. Idempotency and concurrency

- Repeating a request ID with the same normalized input returns the original receipt.
- Reusing it with different input returns `IDEMPOTENCY_CONFLICT`.
- A stale expected revision returns `REVISION_CONFLICT` without appending an event.
- The studio, interactive CLI, and agent host use the same revision protocol.
- One active agent host owns app-operation authority per run.
- Read-only inspection remains available while another caller owns the run.

This protects against lost command output, repeated tool calls, concurrent studio actions, and agent restarts.

## 7. Action proposal and lease

An action proposal contains:

```json
{
  "schema": "agent-workflow-action-proposal/v1",
  "immediateOutcome": "The Classic Bleep settings panel is open with its defaults visible.",
  "actions": [
    {
      "kind": "activate-control",
      "description": "Open the preview and download settings.",
      "target": "the Preview & Download action"
    }
  ],
  "stopConditions": ["navigation occurs", "an unexpected modal appears", "the settings panel is visible"],
  "risk": {
    "category": "reversible-ui",
    "externallyVisible": false,
    "destructive": false
  },
  "requestedCapabilities": ["browser.control", "screenshot.capture"]
}
```

The policy result is one of:

- `allowed` — issue a lease;
- `needs-human` — surface the exact boundary;
- `denied` — cite the policy rule;
- `needs-refinement` — require narrower actions or stop conditions.

A lease binds the run revision, host, adapter target, authorized actions, stop conditions, expiry, and hard limit. It cannot be reused after any relevant state change.

Human boundary decisions may allow once, create a narrowly described rule for the remainder of this run, or deny. A run-scoped rule records action, target, conditions, operator Git identity, and expiry. It never changes project policy.

## 8. Committed result

The agent returns structured rationale rather than hidden chain-of-thought:

```json
{
  "schema": "agent-workflow-committed-result/v1",
  "leaseId": "lease_01K...",
  "declaredActions": ["activate the Preview & Download action"],
  "actualActions": ["activated the Preview & Download action"],
  "immediateOutcome": "The settings panel opened.",
  "observations": [
    {
      "claim": "Classic Bleep is selected",
      "confidence": 0.99
    }
  ],
  "evidence": ["artifact_01K..."],
  "unexpectedStates": [],
  "uncertainty": [],
  "rationale": "The visible defaults satisfy the immediate outcome.",
  "proposedNextMove": "Preview the censored interval."
}
```

Declared and actual actions are both required so policy violations and accidental extra interactions remain visible. Immediately before accepting a commit, the runner reopens every referenced durable artifact and revalidates its registration journal, runner-issued path and slot, recorded inode, complete PNG/JFIF structure, exact size, content hash, and any recorded MIME. A replaced, missing, corrupt, or format-mismatched pathname rejects the commit. The runner then decides whether another batch, human input, step completion, or cleanup is legal.

## 9. Capabilities and evidence

Hosts register versioned capability contracts rather than flat booleans:

```json
{
  "schema": "agent-workflow-capability/v1",
  "id": "download.inspect",
  "contractVersion": "1.0",
  "adapter": {
    "id": "codex-browser",
    "version": "26.810"
  },
  "operations": ["observe-event", "read-metadata"],
  "evidenceTypes": ["download-metadata"],
  "constraints": {
    "contentAccess": false,
    "hashing": false
  }
}
```

Preflight probes only capabilities required by the selected workflow and phase. Probe receipts and exact missing capability IDs are recorded. Training may continue with a visible gap until the first step that requires it; that step may become `blocked` only with the structured `capability_unavailable` reason, after which descendants are dependency-blocked and cleanup runs. Replay, qualification, and evaluation remain preflight-blocked by the same gap.

For screenshots, the active host writes Browser `tab.screenshot()` bytes unchanged to a runner-issued neutral slot. Registration rejects missing files, non-regular files, symlinks, oversize bytes, expired leases, stale revisions, duplicate use, identity mismatches, malformed PNG chunks/CRC/scanlines, PNG chunk types with the reserved bit set, truncation, trailing/polyglot data, and unknown formats. Accepted JPEG is bounded 8-bit baseline Huffman JFIF with one or three components and the explicit marker set APP0(JFIF), DQT, SOF0, DHT, SOS, and EOI. Exif-only, progressive, arithmetic, hierarchical, DHP, EXP, DNL, JPG extensions, TEM, restart intervals, and every other marker are rejected. The runner computes artifact ID, observed time, relative path, SHA-256, size, optional canonical MIME, sensitivity, capability, and step/checkpoint relation. Commits name registered artifact IDs only; caller-authored paths, format claims, and metadata are not evidence.

## 10. Lost results and interruption

Every newly generated successful protocol response includes authoritative `timing.runnerNow`; while a lease is active it also includes expiry, hard expiry, remaining budgets, threshold, and `heartbeatRecommended`. At runner time equal to expiry, heartbeat, evidence issue/register, and commit are rejected. An already durable identical request replays its exact cached response, including timing, after expiry. Expiry, emergency stop, host crash, or ambiguous commit moves the run to `reconciling`.

In reconciliation:

- only observation capabilities are available;
- the uncertain batch is classified as completed, not executed, or indeterminate;
- another action lease is illegal until resolution;
- an indeterminate training run may fork or receive a human override;
- an indeterminate evaluation run ends as blocked.

Any completed or not-executed reconciliation also closes a non-resumable evaluation as abandoned. This preserves the uncertain history and prevents release followed by a fresh-host claim from manufacturing a resumable evaluation. A fresh evaluation is required for clean proof.

Pause takes effect at the next atomic action boundary. Emergency stop revokes the lease immediately and forces reconciliation.

## 11. Exit codes

| Code | Meaning                                                                   |
| ---: | ------------------------------------------------------------------------- |
|  `0` | Command and domain operation succeeded.                                   |
|  `1` | Unexpected internal or storage error.                                     |
|  `2` | Invalid command usage or malformed JSON.                                  |
|  `3` | Schema or semantic validation failed.                                     |
|  `4` | Illegal transition, stale revision, or idempotency conflict.              |
|  `5` | Required adapter capability is unavailable.                               |
|  `6` | Run is owned by another live agent host.                                  |
|  `7` | Reserved legacy approval error; no current operation emits it.            |
|  `8` | Requested workflow, revision, run, or artifact was not found.             |
|  `9` | A required evaluation-group member failed, blocked, or violated its gate. |

Read-only inspection and report commands exit `0` when they successfully return a failing domain result. An evaluation invocation intended as a gate exits `9` when required members do not pass.

## 12. Security boundaries

- Credentials, cookies, authorization headers, and resolved secret values are prohibited from protocol records.
- User-managed authentication never accepts credentials through chat, flags, standard input, environment variables, protocol payloads, screenshots, recordings, or evidence. Browser cookies, tokens, and storage state remain only in the browser-owned local profile.
- `browser.user-session/v1` opens and verifies only the opaque profile bound to the exact configured target. Profile existence and historical verification never satisfy the live marker gate, and a missing capability cannot fall back to another browser session.
- Checked-in profiles contain logical secret references only.
- Agent and adapter input remains untrusted until validation and policy checks pass.
- Artifact paths are runner-generated and constrained to the local registry.
- Evidence slots are valid only for their active unexpired lease and current declared checkpoint; optional-handler slots also require the exact attached pinned handler ID.
- Relative traversal and symlink escape are rejected.
- An agent cannot synthesize a human approval through the agent namespace.
- Operator provenance snapshots the repository Git author name and email at decision time.

### Synthetic text entry

Authenticated routine batches may pin `enter-text` with `target: role:textbox:NAME` or `role:searchbox:NAME` and `textInput: {kind: synthetic, value: dogfood-example}`. The value is immutable executor data and participates in the exact batch hash. Only an empty clear value or a `dogfood-` prefix followed by ASCII letters, digits, spaces, and hyphens is accepted, at most 120 characters total and no line breaks. Changes to the field or value require a different workflow revision; execution requests still accept only run/host/lease/slot/revision identifiers.

The owner fills exactly one visible ordinary text/search input or textarea. Credential-like field hints, non-text input types, and autocomplete purposes other than absent/off are rejected before filling. Existing credential-page and origin checks remain active; the field must retain the exact approved value before capture. This contract supplies synthetic test data only and does not authorize submitting a form, selecting choices, or deleting records. Those remain separately declared actions and boundaries.

Authenticated route transitions preserve the workflow page. If it is on another route within the bound origin, verification loads the human-confirmed marker route in a temporary page of the same persistent context. The marker must still match its exact route and role/name; redirects, missing markers, and expired sessions fail closed. When an app page already exists, the temporary page is closed after each probe. After a Studio restart with no page at the bound origin, verification opens the confirmed marker route using the saved profile and retains that page only on successful verification, making the returned session usable without a separate open action. Failed probes are closed. This checks authentication, not readiness of the workflow destination.

Authenticated browser failures may return `error.details.executionDiagnostic` with a fixed `phase` (`preparation`, `action`, `readiness`, or `capture`) and, only for `action`, a zero-based `actionIndex` from 0 to 2. A failed exact role/name click may additionally include a fixed `failureCategory` (`ambiguity`, `actionability`, `interception`, `navigation`, `timeout`, or `unknown`), a capped `locatorCount` from 0 to 2 (`2` means two or more), and boolean `visible` / `enabled` facts when exactly one locator remained inspectable. The same bounded diagnostic is persisted in the local execution receipt while its status remains `started`. It identifies where execution failed, not whether a side effect completed. Raw browser errors, URLs, accessible names, selector values, and page content are excluded. Reconciliation is still required; the attempted lease cannot replay. A process crash or failure before diagnostic persistence may retain only the original started receipt.

## App-map metadata bridge

`workflow app-map registry` and `import --file PATH --expected-revision N` remain compatible. `inspect --run RUN_ID` projects exact verified captures; `proposals` lists durable assignment proposals. `propose --file PATH`, `apply --file PATH`, and `undo --file PATH` use the shared Studio services and accept the JSON bodies documented in [App map data contract](app-map-data-contract.md#named-variants-and-agent-proposals). All commands support project `--root`, `--config`, explicit `--store`, and `--json` through the existing CLI context. Creating a proposal changes no assignments; apply and undo preserve recorded evidence and require an explicit current revision.

### Default Training coverage

Omitting `--platform` from `train --journey` launches all workflow-supported platforms present and enabled in project configuration (or all supported platforms without a config). The response contains `selection: all-enabled-platforms`, `status: launched|partial|failed`, and `runs` with a platform, launch status, and either the existing launch card/state or a structured error. If any platform fails to launch, the CLI returns `ok: false` and a nonzero exit code, preserving the complete summary in `error.details`, including successful launch cards. Launch status is not execution outcome. Agents must execute every launched member and report partial completion if any platform is blocked or fails. Explicit `--platform` preserves the single-run response. The expert PATH form still requires a platform.

## Native evaluation perspectives and correction proof

- `workflow perspectives list --json` returns the fixed versioned neutral/UX/mobile-UX/adversarial catalog.
- `workflow evaluate perspectives --journey WORDS --selection PATH --source candidate|promoted [--batch BATCH_ID] --json` pins a durable independent batch. Source is required: promoted uses verified platform qualifications, while candidate selects current anonymous routine work. Omission fails before launch. Selections contain `{perspectiveId, platform, required}` and optional policy `{findingSeverityGate:"high"}`. Each platform receives one neutral control. Target/root/config/store flags follow semantic evaluation discovery.
- `workflow perspectives inspect BATCH_ID --store PATH --json` derives canonical, quality, coverage, required/optional status and severity gate from current proof. A partial launch exits nonzero with every surviving member in `error.details`; resume its batch ID.
- `workflow perspectives assess RUN_ID --file PATH --store PATH --json` records `{criterionId,outcome,reason,observations,supersedesAssessmentId?}`. Observations identify `{scenarioId,stepId,noteIndex?,artifactId?,findingId?}` against the pinned rubric and scenario mapping. Outcomes are satisfied/finding/unassessed/out-of-scope. Semantic input failures return `VALIDATION_FAILED` with structured details. For newly created assessments, immutable `createdAt` records the first persistence time. Exact retries and preexisting records retain their stored timestamp; legacy records created before this contract may contain the run launch time and are not reinterpreted. Concurrent divergent corrections conflict.
- `workflow findings verification WORKFLOW_ID FINDING_ID --file PATH --store PATH --json` appends `{criteria:[{id,expectedCorrection,applicablePlatforms,evidenceRequirements}]}` as an immutable contract. Finding creation also accepts optional `verification` with that shape.
- `workflow findings verify WORKFLOW_ID FINDING_ID --run RUN_ID --file PATH --store PATH --json` persists targeted correction checks. Each check contains `{criterionId,stepId,noteIndex,artifactIds,assessment:{outcome,actor:{kind:"agent",id},statement,implementationCommit}}`.
- `workflow findings resolve WORKFLOW_ID FINDING_ID --desktop-run RUN_ID --mobile-run RUN_ID --commit SHA --verification PATH --store PATH --json` reads an array of targeted verification receipt IDs. Both targeted execution and recorded assessment must precede the fresh full evaluations on the same newer candidate. Canonical-only new resolution is rejected.
- `workflow findings relate WORKFLOW_ID --file PATH --store PATH --json` records `{findingIds:[...],reason}` without merging or resolving evidence.

All source finding and correction report hashes use the canonical report, excluding additive perspective assessments. Adding an assessment does not alter historical evidence. Ordinary report output includes read-only perspective/coverage/quality projections; old untagged runs remain not-recorded. No terminal approval challenge is introduced.

## Evaluation questions, requirements, and inquiry policy

`workflow questions propose RUN_ID --file PATH [--store PATH] [--json]` records one immutable, evidence-bound question for a verified perspective evaluation and returns its exact `studioRoute`. The JSON names a pinned criterion and scenario, an exact current-run step plus note or registered artifact, a stable requirement key, prompt and rationale, priority, assessment impact, a native answer specification, optional plain-text suggestions, and allowed journey/project scopes. `workflow questions list WORKFLOW_ID` reads the records and returns any human `discussionResponses` for those questions. `workflow questions show RUN_ID QUESTION_ID` returns the record, the same route, and its `discussionResponses`. Agents use these commands to read discussion; they do not guess identities or scan the local store.

New perspective batches pin the project inquiry policy (`focused`, `balanced`, or `exploratory`), policy revision and hash, requirements catalog hash, normalized applicable requirements, and effective rubric hash. `workflow evaluate perspectives ... --inquiry-depth DEPTH` overrides depth for that batch without rewriting project policy. Focused admits criterion blockers, Balanced also admits material questions, and Exploratory also admits bounded exploratory questions. Open questions never pause a run. Assessments that cannot judge undefined intent remain `unassessed`, use `unassessedReason: "undefined-product-intent"`, and link the exact verified question ID.

Portable requirements live in `.workflows/requirements.yaml`. Journey scope overrides project scope, platform-specific overrides platform-neutral, and equal-specificity duplicates fail. Studio groups compatible questions from the same batch, lens, and requirement key into one decision with every platform, criterion, run, step, and evidence occurrence retained. The resulting requirement applies across that lens's criteria so one product decision can satisfy every criterion that declares the key. Studio answers use the current catalog hash and question integrity, write the catalog atomically, and append a separate local human decision receipt for the answered source question. The answer affects only later batches that pin the new catalog hash; every source question, run, assessment, finding, and evaluation remains immutable. Direct repository edits are declarations and acquire no inferred human actor. Answering is a product-requirement decision, not action approval or acceptance.

Question and requirement failures are explicit: malformed or mismatched records use `VALIDATION_FAILED`, `QUESTION_INTEGRITY_CONFLICT`, `QUESTION_EVIDENCE_UNAVAILABLE`, or `QUESTION_UNAVAILABLE`; stale writes use `REQUIREMENTS_REVISION_CONFLICT` or `QUESTION_POLICY_REVISION_CONFLICT`; ambiguous catalogs use `REQUIREMENT_SCOPE_AMBIGUOUS`; and changed idempotency retries use `IDEMPOTENCY_CONFLICT` or `QUESTION_POLICY_IDEMPOTENCY_CONFLICT`. One degraded question is isolated and never changes evaluation truth.

## Downloaded GIF evidence

For a declared `download-artifact` checkpoint with an exact filename, `image/gif` MIME type, and minimum byte size, advertise `download-content` in the host capability. Issue an `agent.evidence` slot with `type: download-content` and the browser download's `filename`, then save the original downloaded bytes to the returned staging path. Register the slot immediately under its active lease and commit the returned artifact ID along with required screenshots.

The runner validates GIF headers, palettes, frame bounds, LZW pixels, animation limits, trailer, and declared minimum size. It retains content-hashed `.gif` bytes and records filename, dimensions, frame count, and duration. GIF evidence is distinct from screenshots and has no viewport geometry. Other download MIME types remain unsupported. Limits are 10 MiB (or the capability's lower limit), 1,000 frames and 100 million decoded pixels; plain-text GIF extensions are unsupported. Both protocol 1.0 and 1.1 use this contract. Never substitute a screenshot or host assertion for a required downloaded artifact.

Repository-file recipes supplied with `--fixture-recipe` can include up to three `additionalFiles` with unique IDs and full file metadata. Launch verifies every file; each upload lease selects exactly one pinned file. Single-file recipe and protocol 1.0 request shapes are unchanged.
