import { randomUUID } from "node:crypto";
import { basename } from "node:path";

import { WorkflowError } from "./errors.js";
import { verifyExplorationFile } from "./exploration-fixtures.js";
import { sha256 } from "./stable-json.js";

function reject(message) {
  throw new WorkflowError("FIXTURE_INCOMPATIBLE", message, { exitCode: 4 });
}

function same(left, right) {
  return sha256(left) === sha256(right);
}

function isLoopbackHttpUrl(value) {
  if (typeof value !== "string") return false;
  try {
    const url = new URL(value);
    return (
      ["http:", "https:"].includes(url.protocol) &&
      !url.username &&
      !url.password &&
      (url.hostname === "localhost" ||
        url.hostname.endsWith(".localhost") ||
        url.hostname === "127.0.0.1" ||
        url.hostname === "[::1]")
    );
  } catch {
    return false;
  }
}

/** The retained browser page must still be on both pinned local origins. */
export function assertCurrentFixtureUploadOrigin(manifest, currentUrl) {
  if (!isLoopbackHttpUrl(currentUrl)) reject("Current browser URL is not a local HTTP(S) page");
  const current = new URL(currentUrl).origin;
  if (
    current !== new URL(manifest.target.canonicalUrl).origin ||
    current !== new URL(manifest.target.effectiveUrl).origin
  )
    reject("Current browser origin differs from the pinned fixture target");
  return current;
}

export function fixtureIdentityBinding(manifest) {
  return { identity: manifest.identity, authentication: manifest.authentication ?? null };
}

function assertFixtureRecipe(recipe) {
  if (!new Set(["repository-file", "application-record"]).has(recipe?.kind)) reject("Unknown fixture recipe kind");
  if (
    recipe.schema !== "agent-workflow-fixture-recipe/v1" ||
    !recipe.id ||
    !/^v[1-9][0-9]*$/u.test(recipe.revision ?? "") ||
    !recipe.purpose ||
    !Array.isArray(recipe.allowedJourneys) ||
    !recipe.allowedJourneys.length ||
    !recipe.target ||
    !recipe.identity
  )
    reject("Fixture recipe is incomplete");
  if (recipe.kind === "application-record") {
    const adapter = recipe.adapter;
    if (
      recipe.retention !== "cleanup-required" ||
      !adapter?.id ||
      !/^v[1-9][0-9]*$/u.test(adapter.revision ?? "") ||
      !adapter.setupOperation ||
      !adapter.readByIdOperation ||
      !adapter.readByKeyOperation ||
      !adapter.deleteByIdOperation ||
      !["uuid", "opaque-id"].includes(adapter.recordIdFormat)
    )
      reject("Application fixture adapter contract is incomplete");
    return;
  }
  if (recipe.retention !== "repository-owned" || !same(recipe.requiredCapabilities, ["browser.control", "file-upload"]))
    reject("Repository fixture recipe is incomplete");
  for (const file of repositoryRecipeFiles(recipe)) assertRepositoryFile(file);
}

export function repositoryRecipeFiles(recipe) {
  const files = [recipe, ...(recipe.additionalFiles ?? [])];
  if (files.length > 4 || new Set(files.map((file) => file.id)).size !== files.length)
    reject("Fixture file identities must be unique and bounded");
  return files;
}

function assertRepositoryFile(recipe) {
  if (
    !/^[^\\/][^\\]*$/u.test(recipe.relativePath ?? "") ||
    recipe.relativePath.startsWith(".") ||
    recipe.relativePath.includes(":") ||
    recipe.relativePath.split("/").some((part) => !part || part === "." || part === "..")
  )
    reject("Fixture recipe path is unsafe");
  if (recipe.filename !== basename(recipe.relativePath) || !/^label:[^\r\n]{1,200}$/u.test(recipe.uploadTarget ?? ""))
    reject("Fixture upload target is invalid");
}

export async function pinRepositoryFileRecipe(projectRoot, declaration) {
  if (declaration?.kind !== "repository-file") reject("Application-record recipes require the mutable lifecycle");
  if (
    !declaration.purpose ||
    !declaration.id ||
    !declaration.revision ||
    !declaration.relativePath ||
    !declaration.uploadTarget ||
    !declaration.target ||
    !declaration.identity ||
    !declaration.allowedJourneys
  )
    reject("Fixture recipe declaration is incomplete");
  const verified = await verifyExplorationFile(projectRoot, declaration);
  if (declaration.sha256 && declaration.sha256 !== verified.sha256) reject("Fixture recipe digest drifted");
  if (declaration.sizeBytes && declaration.sizeBytes !== verified.sizeBytes) reject("Fixture recipe size drifted");
  if (declaration.mimeType && declaration.mimeType !== verified.mimeType) reject("Fixture recipe MIME drifted");
  const recipe = {
    schema: "agent-workflow-fixture-recipe/v1",
    kind: "repository-file",
    id: declaration.id,
    revision: declaration.revision,
    purpose: declaration.purpose,
    allowedJourneys: structuredClone(declaration.allowedJourneys),
    target: structuredClone(declaration.target),
    identity: structuredClone(declaration.identity),
    requiredCapabilities: ["browser.control", "file-upload"],
    relativePath: declaration.relativePath,
    uploadTarget: declaration.uploadTarget,
    filename: basename(declaration.relativePath),
    sizeBytes: verified.sizeBytes,
    mimeType: verified.mimeType,
    sha256: verified.sha256,
    retention: "repository-owned",
  };
  if (declaration.additionalFiles !== undefined) {
    if (
      !Array.isArray(declaration.additionalFiles) ||
      !declaration.additionalFiles.length ||
      declaration.additionalFiles.length > 3
    )
      reject("Additional fixture files must contain one to three entries");
    recipe.additionalFiles = [];
    for (const file of declaration.additionalFiles) {
      if (!file?.id || !file.relativePath || !file.uploadTarget) reject("Additional fixture declaration is incomplete");
      const pinned = await pinRepositoryFileRecipe(projectRoot, {
        ...declaration,
        ...file,
        sizeBytes: file.sizeBytes,
        sha256: file.sha256,
        mimeType: file.mimeType,
        additionalFiles: undefined,
      });
      recipe.additionalFiles.push(
        Object.fromEntries(
          ["id", "relativePath", "uploadTarget", "filename", "sizeBytes", "mimeType", "sha256"].map((key) => [
            key,
            pinned[key],
          ]),
        ),
      );
    }
  }
  assertFixtureRecipe(recipe);
  return recipe;
}

export function pinApplicationRecipe(declaration) {
  const adapter = declaration?.adapter;
  if (declaration?.kind !== "application-record" || !adapter) reject("Application fixture declaration is incomplete");
  const recipeKeys = new Set(["kind", "id", "revision", "purpose", "allowedJourneys", "target", "identity", "adapter"]);
  const adapterKeys = new Set([
    "id",
    "revision",
    "setupOperation",
    "readByIdOperation",
    "readByKeyOperation",
    "deleteByIdOperation",
    "recordIdFormat",
  ]);
  if (
    Object.keys(declaration).some((key) => !recipeKeys.has(key)) ||
    Object.keys(adapter).some((key) => !adapterKeys.has(key))
  )
    reject("Application fixture declarations contain unsupported fields");
  const recipe = {
    schema: "agent-workflow-fixture-recipe/v1",
    kind: "application-record",
    id: declaration.id,
    revision: declaration.revision,
    purpose: declaration.purpose,
    allowedJourneys: structuredClone(declaration.allowedJourneys),
    target: structuredClone(declaration.target),
    identity: structuredClone(declaration.identity),
    adapter: {
      id: adapter.id,
      revision: adapter.revision,
      setupOperation: adapter.setupOperation,
      readByIdOperation: adapter.readByIdOperation,
      readByKeyOperation: adapter.readByKeyOperation,
      deleteByIdOperation: adapter.deleteByIdOperation,
      recordIdFormat: adapter.recordIdFormat,
    },
    retention: "cleanup-required",
  };
  assertFixtureRecipe(recipe);
  return recipe;
}

export function pinFixtureContract({ recipe, compatibilityVersion, childRevision, journeyId, target, identity }) {
  assertFixtureRecipe(recipe);
  if (!compatibilityVersion || !childRevision) reject("Fixture compatibility and child revisions must be pinned");
  if (!recipe.allowedJourneys.includes(journeyId)) reject("Journey is not allowed to consume this fixture");
  if (!same(recipe.target, target) || !same(recipe.identity, identity)) reject("Fixture target or identity differs");
  return {
    recipe: structuredClone(recipe),
    recipeHash: sha256(recipe),
    childRevision,
    compatibilityVersion,
  };
}

export function assertPinnedFixtureContract(manifest, workflow = null) {
  const contract = manifest.fixtureContract;
  const requirement = workflow?.fixtureRequirement;
  if (!contract && !requirement) return;
  if (!contract || !manifest.workflowRef || !manifest.target || !manifest.identity)
    reject("Fixture run manifest is incomplete");
  if (workflow && workflow.metadata?.id !== manifest.workflowRef.id)
    reject("Stored fixture workflow ID differs from the pinned journey");
  const expected = pinFixtureContract({
    recipe: contract.recipe,
    compatibilityVersion: contract.compatibilityVersion,
    childRevision: manifest.workflowRef.effectiveHash,
    journeyId: manifest.workflowRef.id,
    target: manifest.target,
    identity: manifest.identity,
  });
  if (!same(expected, contract)) reject("Fixture run manifest pins differ");
  if (
    workflow &&
    (!requirement ||
      requirement.kind !== contract.recipe.kind ||
      requirement.recipeId !== contract.recipe.id ||
      requirement.recipeRevision !== contract.recipe.revision ||
      requirement.compatibilityVersion !== contract.compatibilityVersion ||
      requirement.requiredState !== "ready")
  )
    reject("Workflow fixture requirement differs from the run manifest");
}

/** Match the one anonymous, local upload declared by a pinned file recipe. */
export function matchesRepositoryFixtureUpload(manifest, proposal) {
  const recipe = manifest.fixtureContract?.recipe;
  const action = proposal?.actions?.[0];
  const input = action?.inputRef;
  const file = recipe && repositoryRecipeFiles(recipe).find((item) => item.id === input?.name);
  if (
    !["training", "replay", "evaluation"].includes(manifest.phase) ||
    manifest.authentication ||
    manifest.localDogfood ||
    manifest.target?.source !== "application-target" ||
    manifest.target.environment !== "local" ||
    !isLoopbackHttpUrl(manifest.target.canonicalUrl) ||
    !isLoopbackHttpUrl(manifest.target.effectiveUrl) ||
    new URL(manifest.target.canonicalUrl).origin !== new URL(manifest.target.effectiveUrl).origin ||
    manifest.identity?.requirement !== "anonymous" ||
    recipe?.kind !== "repository-file" ||
    manifest.fixtureContract.recipeHash !== sha256(recipe) ||
    !same(recipe.target, manifest.target) ||
    !same(recipe.identity, manifest.identity) ||
    manifest.fixtureContract.childRevision !== manifest.workflowRef?.effectiveHash ||
    proposal.actions.length !== 1 ||
    action.kind !== "upload-file" ||
    !file ||
    action.target !== file.uploadTarget ||
    input?.kind !== "project-file" ||
    input.name !== file.id ||
    input.filename !== file.filename ||
    input.sizeBytes !== file.sizeBytes ||
    input.mimeType !== file.mimeType ||
    input.sha256 !== file.sha256 ||
    proposal.risk?.category !== "reversible-ui" ||
    proposal.risk.externallyVisible ||
    proposal.risk.destructive ||
    !Array.isArray(proposal.requestedCapabilities) ||
    proposal.requestedCapabilities.length !== 2 ||
    !proposal.requestedCapabilities.includes("browser.control") ||
    !proposal.requestedCapabilities.includes("file-upload")
  )
    return false;
  return true;
}

export async function verifyFixtureBinding(projectRoot, manifest, instance, selectedFileId) {
  assertPinnedFixtureContract(manifest);
  const contract = manifest.fixtureContract;
  if (!contract || contract.recipeHash !== sha256(contract.recipe)) reject("Fixture recipe pin differs");
  assertFixtureRecipe(contract.recipe);
  if (contract.recipe.kind !== "repository-file") reject("Repository file verification requires a file recipe");
  if (!contract.recipe.allowedJourneys.includes(manifest.workflowRef?.id))
    reject("Journey is not allowed to consume this fixture");
  if (!same(contract.recipe.target, manifest.target) || !same(contract.recipe.identity, manifest.identity))
    reject("Fixture target or identity differs");
  if (contract.childRevision !== manifest.workflowRef?.effectiveHash) reject("Child journey revision differs");
  if (instance?.state === "uncertain" || (instance && instance.state !== "ready")) reject("Fixture is not ready");
  const verified = await verifyExplorationFile(projectRoot, contract.recipe);
  if (
    verified.sha256 !== contract.recipe.sha256 ||
    verified.sizeBytes !== contract.recipe.sizeBytes ||
    verified.mimeType !== contract.recipe.mimeType
  )
    reject("Fixture bytes differ from the pinned recipe");
  if (
    instance &&
    (instance.sha256 !== verified.sha256 ||
      instance.targetHash !== sha256(manifest.target) ||
      instance.identityHash !== sha256(fixtureIdentityBinding(manifest)) ||
      instance.recipeId !== contract.recipe.id ||
      instance.recipeRevision !== contract.recipe.revision ||
      instance.childRevision !== contract.childRevision ||
      instance.compatibilityVersion !== contract.compatibilityVersion ||
      instance.relativePath !== contract.recipe.relativePath ||
      instance.uploadTarget !== contract.recipe.uploadTarget ||
      instance.sizeBytes !== verified.sizeBytes ||
      instance.mimeType !== verified.mimeType ||
      instance.cleanup?.ownerRunId !== instance.cleanupOwnerRunId)
  )
    reject("Fixture instance binding differs");
  const verifiedFiles = new Map([[contract.recipe.id, verified]]);
  for (const file of contract.recipe.additionalFiles ?? []) {
    const extra = await verifyExplorationFile(projectRoot, file);
    if (extra.mimeType !== file.mimeType) reject("Additional fixture MIME differs");
    verifiedFiles.set(file.id, extra);
  }
  if (selectedFileId && !verifiedFiles.has(selectedFileId)) reject("Unknown fixture file");
  return verifiedFiles.get(selectedFileId ?? contract.recipe.id);
}

export function createFixtureInstance(
  manifest,
  verified,
  { parentRunId = null, sourceInstance = null, now = new Date() } = {},
) {
  const ownerRunId = sourceInstance?.cleanupOwnerRunId ?? manifest.runId;
  return {
    schema: "agent-workflow-fixture-instance/v1",
    instanceId: `fixture_${randomUUID().replaceAll("-", "")}`,
    runId: manifest.runId,
    creatorRunId: sourceInstance?.creatorRunId ?? manifest.runId,
    cleanupOwnerRunId: ownerRunId,
    recipeId: manifest.fixtureContract.recipe.id,
    recipeRevision: manifest.fixtureContract.recipe.revision,
    recipeHash: manifest.fixtureContract.recipeHash,
    childRevision: manifest.fixtureContract.childRevision,
    compatibilityVersion: manifest.fixtureContract.compatibilityVersion,
    targetHash: sha256(manifest.target),
    identityHash: sha256(fixtureIdentityBinding(manifest)),
    relativePath: manifest.fixtureContract.recipe.relativePath,
    uploadTarget: manifest.fixtureContract.recipe.uploadTarget,
    sha256: verified.sha256,
    sizeBytes: verified.sizeBytes,
    mimeType: verified.mimeType,
    state: "ready",
    verifiedAt: now.toISOString(),
    lineage: parentRunId ? { parentRunId, sourceInstanceId: sourceInstance.instanceId } : null,
    cleanup: { kind: "repository-owned", ownerRunId, required: false },
  };
}

export function assertFixtureHandoff(parent, child, source) {
  const a = parent.fixtureContract;
  const b = child.fixtureContract;
  if (!a || !b || source.state !== "ready") reject("Parent fixture is unavailable or uncertain");
  if (child.parentRunId !== parent.runId) reject("Child does not pin the exact fixture parent run");
  if (
    a.recipeHash !== b.recipeHash ||
    a.recipe.revision !== b.recipe.revision ||
    a.compatibilityVersion !== b.compatibilityVersion ||
    !same(parent.target, child.target) ||
    !same(fixtureIdentityBinding(parent), fixtureIdentityBinding(child))
  )
    reject("Parent and child fixture contracts differ");
  if (source.runId !== parent.runId || source.cleanupOwnerRunId !== parent.runId)
    reject("Parent does not own the source fixture");
  if (b.childRevision !== child.workflowRef?.effectiveHash) reject("Child journey revision differs");
}
